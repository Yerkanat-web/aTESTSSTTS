import React, { createContext, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Organization {
  id: string;
  name: string;
  slug?: string | null;
}

interface OrgContextValue {
  organizations: Organization[];
  currentOrgId: string | null;
  currentOrg: Organization | null;
  loading: boolean;
  error: string | null;
  selectOrg: (orgId: string) => void;
  refresh: () => Promise<void>;
}

const OrgContext = createContext<OrgContextValue | undefined>(undefined);

export const OrgProvider = ({ children }: { children: ReactNode }) => {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [currentOrgId, setCurrentOrgId] = useState<string | null>(
    typeof window !== "undefined" ? localStorage.getItem("currentOrgId") : null
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const currentOrg = useMemo(() => {
    if (!organizations?.length) return null;
    const found = organizations.find((o) => o.id === currentOrgId);
    return found || organizations[0] || null;
  }, [organizations, currentOrgId]);

  const selectOrg = (orgId: string) => {
    setCurrentOrgId(orgId);
    try {
      localStorage.setItem("currentOrgId", orgId);
    } catch {}
  };

  const loadOrganizations = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: sessionRes } = await supabase.auth.getSession();
      const userId = sessionRes.session?.user?.id;
      if (!userId) {
        setOrganizations([]);
        setLoading(false);
        return;
      }

      // Fetch organizations via membership (using untyped client to avoid type mismatch until types are regenerated)
      const client: any = supabase as any;
      const { data, error } = await client
        .from("organization_members")
        .select("organizations:org_id(id,name,slug)")
        .order("created_at", { ascending: true });

      if (error) throw error;

      const orgs: Organization[] = (data || [])
        .map((row: any) => row.organizations)
        .filter(Boolean);

      setOrganizations(orgs);

      // Ensure currentOrgId is valid
      if (orgs?.length) {
        const exists = orgs.some((o) => o.id === currentOrgId);
        if (!exists) {
          selectOrg(orgs[0].id);
        }
      }
    } catch (e: any) {
      setError(e?.message || "Failed to load organizations");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrganizations();

    const { data: sub } = supabase.auth.onAuthStateChange(() => {
      // Re-evaluate organizations on auth changes
      setTimeout(() => {
        loadOrganizations();
      }, 0);
    });

    return () => {
      sub.subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value: OrgContextValue = {
    organizations,
    currentOrgId: currentOrg?.id ?? null,
    currentOrg,
    loading,
    error,
    selectOrg,
    refresh: loadOrganizations,
  };

  return <OrgContext.Provider value={value}>{children}</OrgContext.Provider>;
};

export const useOrg = () => {
  const ctx = useContext(OrgContext);
  if (!ctx) throw new Error("useOrg must be used within OrgProvider");
  return ctx;
};
