interface AnalysisRequest {
  employees: Array<{
    id: number;
    name: string;
    role: string;
    department: string;
    tasks: number;
    completedTasks: number;
    points: number;
    activeHours: number;
    efficiency: number;
  }>;
  periodDays: number;
  startDate?: string;
  endDate?: string;
}

interface EmployeeAnalysis {
  id: number;
  name: string;
  role: string;
  performanceScore: number;
  trends: {
    productivity: 'up' | 'down' | 'stable';
    efficiency: 'up' | 'down' | 'stable';
    workload: 'high' | 'normal' | 'low';
  };
  strengths: string[];
  improvements: string[];
  recommendations: string[];
  riskLevel: 'low' | 'medium' | 'high';
}

interface TeamInsights {
  overallHealth: number;
  productivityTrend: 'up' | 'down' | 'stable';
  burnoutRisk: number;
  teamEfficiency: number;
  workloadBalance: number;
}

interface AnalysisResult {
  teamInsights: TeamInsights;
  employeeAnalyses: EmployeeAnalysis[];
  analysisDate: string;
  period: string;
}

class OpenAIService {
  private baseUrl = 'https://api.openai.com/v1/chat/completions';

  constructor() {
    // No longer need to store API key locally - it's in Supabase secrets
  }

  private createAnalysisPrompt(request: AnalysisRequest): string {
    const periodText = request.periodDays === 1 ? '1 день' :
                      request.periodDays === 7 ? '7 дней' :
                      request.periodDays === 30 ? '30 дней' :
                      request.periodDays === 90 ? '90 дней' :
                      request.periodDays === 365 ? '365 дней' :
                      `${request.periodDays} дней`;

    return `
Ты профессиональный HR-аналитик. Проанализируй данные команды за период ${periodText} и верни ТОЛЬКО JSON без дополнительного текста.

Данные сотрудников:
${JSON.stringify(request.employees, null, 2)}

Верни JSON в точно таком формате:
{
  "teamInsights": {
    "overallHealth": 87,
    "productivityTrend": "up",
    "burnoutRisk": 15,
    "teamEfficiency": 92,
    "workloadBalance": 78
  },
  "employeeAnalyses": [
    {
      "id": 1,
      "name": "Имя сотрудника",
      "role": "Роль",
      "performanceScore": 95,
      "trends": {
        "productivity": "up",
        "efficiency": "up", 
        "workload": "normal"
      },
      "strengths": ["Сильная сторона 1", "Сильная сторона 2"],
      "improvements": ["Область роста 1", "Область роста 2"],
      "recommendations": ["Рекомендация 1", "Рекомендация 2"],
      "riskLevel": "low"
    }
  ]
}

Требования:
- performanceScore: 0-100
- trends: только "up", "down", "stable"
- workload: только "high", "normal", "low"  
- riskLevel: только "low", "medium", "high"
- productivityTrend: только "up", "down", "stable"
- Все значения teamInsights: 0-100
- Рекомендации должны быть конкретными и практичными
- Анализируй на основе задач, эффективности, активных часов, набранных баллов
`;
  }

  async analyzeTeam(request: AnalysisRequest): Promise<AnalysisResult> {
    try {
      // Use Supabase Edge Function instead of direct API call
      const { supabase } = await import('@/integrations/supabase/client');
      
      const { data, error } = await supabase.functions.invoke('ai-analysis', {
        body: request
      });

      if (error) {
        console.error('Supabase function error:', error);
        throw new Error(`AI Analysis Error: ${error.message}`);
      }

      if (!data) {
        throw new Error('Пустой ответ от AI сервиса');
      }

      // Кэшируем результат
      localStorage.setItem('cached_analysis', JSON.stringify(data));
      
      return data;
    } catch (error) {
      console.error('AI Analysis Error:', error);
      throw error;
    }
  }

  async askAssistant(message: string, context?: any): Promise<string> {
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { message, context }
      });

      if (error) {
        console.error('Supabase function error:', error);
        throw new Error(`AI Assistant Error: ${error.message}`);
      }

      if (!data?.response) {
        throw new Error('Пустой ответ от AI помощника');
      }

      return data.response;
    } catch (error) {
      console.error('AI Assistant Error:', error);
      throw error;
    }
  }

  getCachedAnalysis(): AnalysisResult | null {
    try {
      const cached = localStorage.getItem('cached_analysis');
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { 
          message: 'Test connection. Reply with "OK".', 
          context: {} 
        }
      });

      return !error && !!data?.response;
    } catch {
      return false;
    }
  }
}

export const openAIService = new OpenAIService();
export type { AnalysisRequest, AnalysisResult, EmployeeAnalysis, TeamInsights };