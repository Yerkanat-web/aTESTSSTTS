import { supabase } from '@/integrations/supabase/client';

export class AdminOperationsService {
  // Clear all tasks for an employee
  static async clearEmployeeTasks(employeeId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employee_tasks')
        .delete()
        .eq('employee_id', employeeId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error clearing employee tasks:', error);
      return false;
    }
  }

  // Clear all points for an employee (reset to 0)
  static async clearEmployeePoints(employeeId: string): Promise<boolean> {
    try {
      // Delete all achievements (this will trigger point recalculation)
      const { error: achievementsError } = await supabase
        .from('employee_achievements')
        .delete()
        .eq('employee_id', employeeId);

      if (achievementsError) throw achievementsError;

      // Recalculate points (should be 0 now)
      const { error: recalcError } = await supabase.rpc('calculate_employee_points', {
        emp_id: employeeId
      });

      if (recalcError) throw recalcError;

      return true;
    } catch (error) {
      console.error('Error clearing employee points:', error);
      return false;
    }
  }

  // Add points to employee
  static async addEmployeePoints(employeeId: string, points: number, description?: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employee_achievements')
        .insert({
          employee_id: employeeId,
          achievement_name: description || `Bonus points`,
          description: description || `Manual points adjustment: +${points}`,
          points: points
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error adding employee points:', error);
      return false;
    }
  }

  // Subtract points from employee
  static async subtractEmployeePoints(employeeId: string, points: number, description?: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employee_achievements')
        .insert({
          employee_id: employeeId,
          achievement_name: description || `Points deduction`,
          description: description || `Manual points adjustment: -${points}`,
          points: -points
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error subtracting employee points:', error);
      return false;
    }
  }

  // Update employee information
  static async updateEmployee(
    employeeId: string, 
    updates: { name?: string; email?: string; position?: string; department?: string }
  ): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employees')
        .update(updates)
        .eq('id', employeeId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating employee:', error);
      return false;
    }
  }

  // Deactivate employee (soft delete)
  static async deactivateEmployee(employeeId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employees')
        .update({ status: 'inactive' })
        .eq('id', employeeId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error deactivating employee:', error);
      return false;
    }
  }

  // Update employee role
  static async updateEmployeeRole(employeeId: string, role: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employees')
        .update({ role })
        .eq('id', employeeId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating employee role:', error);
      return false;
    }
  }

  // Permanently delete employee and all associated data
  static async deleteEmployeePermanently(employeeId: string): Promise<boolean> {
    try {
      // 1. Delete task attachments
      await supabase
        .from('task_attachments')
        .delete()
        .eq('employee_id', employeeId);

      // 2. Delete task comments
      await supabase
        .from('task_comments')
        .delete()
        .eq('employee_id', employeeId);

      // 3. Delete work time logs
      await supabase
        .from('work_time_logs')
        .delete()
        .eq('employee_id', employeeId);

      // 4. Delete project tasks where employee is assignee
      await supabase
        .from('project_tasks')
        .delete()
        .eq('assignee_id', employeeId);

      // 5. Get sales results to delete related data
      const { data: salesResults } = await supabase
        .from('sales_results')
        .select('id')
        .eq('employee_id', employeeId);

      if (salesResults && salesResults.length > 0) {
        const salesResultIds = salesResults.map(sr => sr.id);

        // Delete monthly payments for these sales
        await supabase
          .from('monthly_payments')
          .delete()
          .in('sales_result_id', salesResultIds);

        // Delete project accounts for these sales
        await supabase
          .from('project_accounts')
          .delete()
          .in('sales_result_id', salesResultIds);
      }

      // 6. Delete sales results
      await supabase
        .from('sales_results')
        .delete()
        .eq('employee_id', employeeId);

      // 7. Delete employee tasks
      await supabase
        .from('employee_tasks')
        .delete()
        .eq('employee_id', employeeId);

      // 8. Delete employee achievements
      await supabase
        .from('employee_achievements')
        .delete()
        .eq('employee_id', employeeId);

      // 9. Delete shop purchases
      await supabase
        .from('shop_purchases')
        .delete()
        .eq('employee_id', employeeId);

      // 10. Delete daily reports
      await supabase
        .from('daily_reports')
        .delete()
        .eq('employee_id', employeeId);

      // 11. Delete sales targets
      await supabase
        .from('sales_targets')
        .delete()
        .eq('employee_id', employeeId);

      // 12. Delete employee points
      await supabase
        .from('employee_points')
        .delete()
        .eq('employee_id', employeeId);

      // 13. Finally, delete the employee
      const { error } = await supabase
        .from('employees')
        .delete()
        .eq('id', employeeId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error permanently deleting employee:', error);
      return false;
    }
  }

  // Clear all achievements for an employee
  static async clearEmployeeAchievements(employeeId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('employee_achievements')
        .delete()
        .eq('employee_id', employeeId);

      if (error) throw error;

      // Recalculate points after clearing achievements
      const { error: recalcError } = await supabase.rpc('calculate_employee_points', {
        emp_id: employeeId
      });

      if (recalcError) throw recalcError;

      return true;
    } catch (error) {
      console.error('Error clearing employee achievements:', error);
      return false;
    }
  }
}