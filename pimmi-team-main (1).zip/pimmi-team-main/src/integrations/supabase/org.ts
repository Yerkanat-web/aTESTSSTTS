export function withOrg<T extends Record<string, any>>(payload: T, orgId?: string | null): T {
  if (!orgId) return payload;
  return { ...payload, org_id: orgId } as T;
}

export function scopeToOrg(query: any, orgId?: string | null) {
  if (!orgId || !query?.eq) return query;
  return query.eq('org_id', orgId);
}
