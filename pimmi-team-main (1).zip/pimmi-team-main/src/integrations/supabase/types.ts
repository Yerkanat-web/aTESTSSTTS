export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      achievement_templates: {
        Row: {
          category: string
          condition_data: Json | null
          condition_type: string
          condition_value: number
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          org_id: string | null
          points: number
          rarity: string
          sort_order: number
          target_group: string
          updated_at: string
        }
        Insert: {
          category?: string
          condition_data?: Json | null
          condition_type: string
          condition_value?: number
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          org_id?: string | null
          points?: number
          rarity?: string
          sort_order?: number
          target_group?: string
          updated_at?: string
        }
        Update: {
          category?: string
          condition_data?: Json | null
          condition_type?: string
          condition_value?: number
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          org_id?: string | null
          points?: number
          rarity?: string
          sort_order?: number
          target_group?: string
          updated_at?: string
        }
        Relationships: []
      }
      call_records: {
        Row: {
          call_date: string
          created_at: string
          direction: string
          duration: number | null
          id: string
          phone_number: string
          recording_url: string | null
          sipuni_call_id: string
          user_id: string | null
        }
        Insert: {
          call_date: string
          created_at?: string
          direction: string
          duration?: number | null
          id?: string
          phone_number: string
          recording_url?: string | null
          sipuni_call_id: string
          user_id?: string | null
        }
        Update: {
          call_date?: string
          created_at?: string
          direction?: string
          duration?: number | null
          id?: string
          phone_number?: string
          recording_url?: string | null
          sipuni_call_id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      call_statistics: {
        Row: {
          created_at: string
          date: string
          id: string
          incoming_calls: number | null
          missed_calls: number | null
          outgoing_calls: number | null
          total_duration: number | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          date: string
          id?: string
          incoming_calls?: number | null
          missed_calls?: number | null
          outgoing_calls?: number | null
          total_duration?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          incoming_calls?: number | null
          missed_calls?: number | null
          outgoing_calls?: number | null
          total_duration?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      courses: {
        Row: {
          created_at: string
          description: string | null
          duration_hours: number | null
          id: string
          image_url: string | null
          level: string | null
          price: number | null
          title: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          duration_hours?: number | null
          id?: string
          image_url?: string | null
          level?: string | null
          price?: number | null
          title: string
        }
        Update: {
          created_at?: string
          description?: string | null
          duration_hours?: number | null
          id?: string
          image_url?: string | null
          level?: string | null
          price?: number | null
          title?: string
        }
        Relationships: []
      }
      daily_reports: {
        Row: {
          categories: string[] | null
          created_at: string
          employee_id: string
          id: string
          leads_count: number
          org_id: string | null
          project_name: string | null
          qualified_leads_count: number
          report_date: string
          updated_at: string
        }
        Insert: {
          categories?: string[] | null
          created_at?: string
          employee_id: string
          id?: string
          leads_count?: number
          org_id?: string | null
          project_name?: string | null
          qualified_leads_count?: number
          report_date: string
          updated_at?: string
        }
        Update: {
          categories?: string[] | null
          created_at?: string
          employee_id?: string
          id?: string
          leads_count?: number
          org_id?: string | null
          project_name?: string | null
          qualified_leads_count?: number
          report_date?: string
          updated_at?: string
        }
        Relationships: []
      }
      employee_achievements: {
        Row: {
          achievement_name: string
          created_at: string
          description: string | null
          earned_at: string
          employee_id: string
          id: string
          org_id: string | null
          points: number
        }
        Insert: {
          achievement_name: string
          created_at?: string
          description?: string | null
          earned_at?: string
          employee_id: string
          id?: string
          org_id?: string | null
          points?: number
        }
        Update: {
          achievement_name?: string
          created_at?: string
          description?: string | null
          earned_at?: string
          employee_id?: string
          id?: string
          org_id?: string | null
          points?: number
        }
        Relationships: []
      }
      employee_activity_logs: {
        Row: {
          action_description: string
          action_type: string
          created_at: string
          employee_id: string
          id: string
          ip_address: string | null
          metadata: Json | null
          target_id: string | null
          target_type: string | null
          user_agent: string | null
        }
        Insert: {
          action_description: string
          action_type: string
          created_at?: string
          employee_id: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
        }
        Update: {
          action_description?: string
          action_type?: string
          created_at?: string
          employee_id?: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_activity_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_activity_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_points: {
        Row: {
          created_at: string
          employee_id: string
          id: string
          org_id: string | null
          total_points: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          employee_id: string
          id?: string
          org_id?: string | null
          total_points?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          employee_id?: string
          id?: string
          org_id?: string | null
          total_points?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_points_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_points_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_tasks: {
        Row: {
          actual_minutes: number | null
          assigned_by: string | null
          category: string | null
          completed_at: string | null
          created_at: string
          description: string | null
          due_date: string | null
          employee_id: string
          estimated_minutes: number | null
          id: string
          org_id: string | null
          priority: string | null
          status: string | null
          title: string
          updated_at: string
        }
        Insert: {
          actual_minutes?: number | null
          assigned_by?: string | null
          category?: string | null
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          employee_id: string
          estimated_minutes?: number | null
          id?: string
          org_id?: string | null
          priority?: string | null
          status?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          actual_minutes?: number | null
          assigned_by?: string | null
          category?: string | null
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          employee_id?: string
          estimated_minutes?: number | null
          id?: string
          org_id?: string | null
          priority?: string | null
          status?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_employee_tasks_assigned_by"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_employee_tasks_assigned_by"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_employee_tasks_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_employee_tasks_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      employees: {
        Row: {
          created_at: string
          department: string
          email: string
          id: string
          name: string
          org_id: string | null
          position: string
          role: string
          sipuni_user_id: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          department: string
          email: string
          id?: string
          name: string
          org_id?: string | null
          position: string
          role?: string
          sipuni_user_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          department?: string
          email?: string
          id?: string
          name?: string
          org_id?: string | null
          position?: string
          role?: string
          sipuni_user_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      lessons: {
        Row: {
          content: string | null
          course_id: string | null
          created_at: string
          duration_minutes: number | null
          id: string
          order_index: number
          title: string
          video_url: string | null
        }
        Insert: {
          content?: string | null
          course_id?: string | null
          created_at?: string
          duration_minutes?: number | null
          id?: string
          order_index: number
          title: string
          video_url?: string | null
        }
        Update: {
          content?: string | null
          course_id?: string | null
          created_at?: string
          duration_minutes?: number | null
          id?: string
          order_index?: number
          title?: string
          video_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lessons_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_payments: {
        Row: {
          actual_payment_date: string | null
          amount: number
          created_at: string
          id: string
          notes: string | null
          org_id: string | null
          payment_date: string
          prepayment: number | null
          remainder: number | null
          remainder_due_date: string | null
          sales_result_id: string
          status: string
          updated_at: string
        }
        Insert: {
          actual_payment_date?: string | null
          amount?: number
          created_at?: string
          id?: string
          notes?: string | null
          org_id?: string | null
          payment_date: string
          prepayment?: number | null
          remainder?: number | null
          remainder_due_date?: string | null
          sales_result_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          actual_payment_date?: string | null
          amount?: number
          created_at?: string
          id?: string
          notes?: string | null
          org_id?: string | null
          payment_date?: string
          prepayment?: number | null
          remainder?: number | null
          remainder_due_date?: string | null
          sales_result_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "monthly_payments_sales_result_id_fkey"
            columns: ["sales_result_id"]
            isOneToOne: false
            referencedRelation: "sales_results"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_members: {
        Row: {
          created_at: string
          id: string
          org_id: string
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          org_id: string
          role?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          org_id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_members_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          id: string
          join_code: string | null
          join_code_enabled: boolean
          join_code_expires_at: string | null
          name: string
          slug: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          join_code?: string | null
          join_code_enabled?: boolean
          join_code_expires_at?: string | null
          name: string
          slug?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          join_code?: string | null
          join_code_enabled?: boolean
          join_code_expires_at?: string | null
          name?: string
          slug?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      project_accounts: {
        Row: {
          created_at: string
          id: string
          login: string | null
          org_id: string | null
          password: string | null
          sales_result_id: string
          service_type: string | null
          subscription_end_date: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          login?: string | null
          org_id?: string | null
          password?: string | null
          sales_result_id: string
          service_type?: string | null
          subscription_end_date?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          login?: string | null
          org_id?: string | null
          password?: string | null
          sales_result_id?: string
          service_type?: string | null
          subscription_end_date?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_accounts_sales_result_id_fkey"
            columns: ["sales_result_id"]
            isOneToOne: false
            referencedRelation: "sales_results"
            referencedColumns: ["id"]
          },
        ]
      }
      project_cases: {
        Row: {
          category: string
          created_at: string
          id: string
          instagram_url: string | null
          is_active: boolean
          org_id: string | null
          our_work_description: string | null
          point_a_description: string | null
          point_b_description: string | null
          project_name: string
          result_screenshots: string[] | null
          services: string[]
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          instagram_url?: string | null
          is_active?: boolean
          org_id?: string | null
          our_work_description?: string | null
          point_a_description?: string | null
          point_b_description?: string | null
          project_name: string
          result_screenshots?: string[] | null
          services?: string[]
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          instagram_url?: string | null
          is_active?: boolean
          org_id?: string | null
          our_work_description?: string | null
          point_a_description?: string | null
          point_b_description?: string | null
          project_name?: string
          result_screenshots?: string[] | null
          services?: string[]
          updated_at?: string
        }
        Relationships: []
      }
      project_categories: {
        Row: {
          created_at: string
          id: string
          name: string
          org_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          org_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          org_id?: string | null
        }
        Relationships: []
      }
      project_tasks: {
        Row: {
          actual_minutes: number | null
          assignee_id: string | null
          category: string | null
          completed_at: string | null
          created_at: string
          description: string | null
          due_date: string | null
          estimated_minutes: number | null
          id: string
          org_id: string | null
          priority: string | null
          sales_result_id: string | null
          status: string | null
          task_name: string
          task_type: string
          updated_at: string
        }
        Insert: {
          actual_minutes?: number | null
          assignee_id?: string | null
          category?: string | null
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          estimated_minutes?: number | null
          id?: string
          org_id?: string | null
          priority?: string | null
          sales_result_id?: string | null
          status?: string | null
          task_name: string
          task_type: string
          updated_at?: string
        }
        Update: {
          actual_minutes?: number | null
          assignee_id?: string | null
          category?: string | null
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          estimated_minutes?: number | null
          id?: string
          org_id?: string | null
          priority?: string | null
          sales_result_id?: string | null
          status?: string | null
          task_name?: string
          task_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_tasks_assignee_id_fkey"
            columns: ["assignee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_tasks_assignee_id_fkey"
            columns: ["assignee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_tasks_sales_result_id_fkey"
            columns: ["sales_result_id"]
            isOneToOne: false
            referencedRelation: "sales_results"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_results: {
        Row: {
          client_name: string | null
          client_phone: string | null
          client_source:
            | Database["public"]["Enums"]["client_source_type"]
            | null
          client_type: Database["public"]["Enums"]["client_type_enum"] | null
          comments: string | null
          created_at: string
          description: string | null
          employee_id: string
          extension_sequence: number
          id: string
          is_extension: boolean
          is_test: boolean | null
          org_id: string | null
          original_employee_id: string | null
          paid_full: boolean | null
          paid_until: string | null
          parent_project_id: string | null
          prepayment: number | null
          project_name: string | null
          project_status:
            | Database["public"]["Enums"]["project_status_enum"]
            | null
          project_type: string | null
          remainder: number | null
          remainder_due_date: string | null
          sale_amount: number
          sale_date: string
          tasks_generated: boolean | null
          test_ends_at: string | null
          updated_at: string
          work_format: string[] | null
        }
        Insert: {
          client_name?: string | null
          client_phone?: string | null
          client_source?:
            | Database["public"]["Enums"]["client_source_type"]
            | null
          client_type?: Database["public"]["Enums"]["client_type_enum"] | null
          comments?: string | null
          created_at?: string
          description?: string | null
          employee_id: string
          extension_sequence?: number
          id?: string
          is_extension?: boolean
          is_test?: boolean | null
          org_id?: string | null
          original_employee_id?: string | null
          paid_full?: boolean | null
          paid_until?: string | null
          parent_project_id?: string | null
          prepayment?: number | null
          project_name?: string | null
          project_status?:
            | Database["public"]["Enums"]["project_status_enum"]
            | null
          project_type?: string | null
          remainder?: number | null
          remainder_due_date?: string | null
          sale_amount?: number
          sale_date: string
          tasks_generated?: boolean | null
          test_ends_at?: string | null
          updated_at?: string
          work_format?: string[] | null
        }
        Update: {
          client_name?: string | null
          client_phone?: string | null
          client_source?:
            | Database["public"]["Enums"]["client_source_type"]
            | null
          client_type?: Database["public"]["Enums"]["client_type_enum"] | null
          comments?: string | null
          created_at?: string
          description?: string | null
          employee_id?: string
          extension_sequence?: number
          id?: string
          is_extension?: boolean
          is_test?: boolean | null
          org_id?: string | null
          original_employee_id?: string | null
          paid_full?: boolean | null
          paid_until?: string | null
          parent_project_id?: string | null
          prepayment?: number | null
          project_name?: string | null
          project_status?:
            | Database["public"]["Enums"]["project_status_enum"]
            | null
          project_type?: string | null
          remainder?: number | null
          remainder_due_date?: string | null
          sale_amount?: number
          sale_date?: string
          tasks_generated?: boolean | null
          test_ends_at?: string | null
          updated_at?: string
          work_format?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_sales_results_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_sales_results_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_results_original_employee_id_fkey"
            columns: ["original_employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_results_original_employee_id_fkey"
            columns: ["original_employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_results_parent_project_id_fkey"
            columns: ["parent_project_id"]
            isOneToOne: false
            referencedRelation: "sales_results"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_targets: {
        Row: {
          created_at: string
          employee_id: string
          id: string
          org_id: string | null
          target_amount: number
          target_period: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          employee_id: string
          id?: string
          org_id?: string | null
          target_amount?: number
          target_period: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          employee_id?: string
          id?: string
          org_id?: string | null
          target_amount?: number
          target_period?: string
          updated_at?: string
        }
        Relationships: []
      }
      shop_categories: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      shop_items: {
        Row: {
          category: string
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          image_url: string | null
          is_available: boolean
          name: string
          org_id: string
          price: number
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_available?: boolean
          name: string
          org_id: string
          price?: number
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_available?: boolean
          name?: string
          org_id?: string
          price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "shop_items_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shop_items_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shop_items_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      shop_purchases: {
        Row: {
          created_at: string
          employee_id: string
          id: string
          item_name: string
          item_price: number
          org_id: string | null
          points_after: number
          points_before: number
          purchase_date: string
        }
        Insert: {
          created_at?: string
          employee_id: string
          id?: string
          item_name: string
          item_price: number
          org_id?: string | null
          points_after: number
          points_before: number
          purchase_date?: string
        }
        Update: {
          created_at?: string
          employee_id?: string
          id?: string
          item_name?: string
          item_price?: number
          org_id?: string | null
          points_after?: number
          points_before?: number
          purchase_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "shop_purchases_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shop_purchases_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      task_attachments: {
        Row: {
          content_type: string | null
          created_at: string
          employee_id: string
          file_name: string
          file_path: string | null
          file_size: number | null
          file_url: string | null
          id: string
          org_id: string | null
          storage_path: string | null
          task_id: string
        }
        Insert: {
          content_type?: string | null
          created_at?: string
          employee_id: string
          file_name: string
          file_path?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          org_id?: string | null
          storage_path?: string | null
          task_id: string
        }
        Update: {
          content_type?: string | null
          created_at?: string
          employee_id?: string
          file_name?: string
          file_path?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          org_id?: string | null
          storage_path?: string | null
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_task_attachments_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_task_attachments_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_task_attachments_task"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "employee_tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_task_attachments_task"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "employee_tasks_with_attachments_view"
            referencedColumns: ["id"]
          },
        ]
      }
      task_categories: {
        Row: {
          color: string | null
          created_at: string
          description: string | null
          employee_id: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          description?: string | null
          employee_id?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          description?: string | null
          employee_id?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_categories_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "task_categories_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      task_comments: {
        Row: {
          comment_text: string
          created_at: string
          employee_id: string
          id: string
          task_id: string
        }
        Insert: {
          comment_text: string
          created_at?: string
          employee_id: string
          id?: string
          task_id: string
        }
        Update: {
          comment_text?: string
          created_at?: string
          employee_id?: string
          id?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_task_comments_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_task_comments_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_task_comments_task"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "employee_tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_task_comments_task"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "employee_tasks_with_attachments_view"
            referencedColumns: ["id"]
          },
        ]
      }
      user_progress: {
        Row: {
          completed_at: string | null
          course_id: string | null
          created_at: string
          id: string
          lesson_id: string | null
          progress_percent: number | null
          user_id: string | null
        }
        Insert: {
          completed_at?: string | null
          course_id?: string | null
          created_at?: string
          id?: string
          lesson_id?: string | null
          progress_percent?: number | null
          user_id?: string | null
        }
        Update: {
          completed_at?: string | null
          course_id?: string | null
          created_at?: string
          id?: string
          lesson_id?: string | null
          progress_percent?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_progress_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_progress_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
        ]
      }
      work_time_logs: {
        Row: {
          created_at: string
          description: string | null
          employee_id: string
          end_time: string | null
          hours_worked: number | null
          id: string
          org_id: string | null
          start_time: string
          task_id: string | null
          updated_at: string
          work_type: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          employee_id: string
          end_time?: string | null
          hours_worked?: number | null
          id?: string
          org_id?: string | null
          start_time: string
          task_id?: string | null
          updated_at?: string
          work_type?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          employee_id?: string
          end_time?: string | null
          hours_worked?: number | null
          id?: string
          org_id?: string | null
          start_time?: string
          task_id?: string | null
          updated_at?: string
          work_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_work_time_logs_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_work_time_logs_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_work_time_logs_task"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "employee_tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_work_time_logs_task"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "employee_tasks_with_attachments_view"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      employee_activity_logs_view: {
        Row: {
          action_description: string | null
          action_type: string | null
          created_at: string | null
          department: string | null
          employee_email: string | null
          employee_id: string | null
          employee_name: string | null
          id: string | null
          ip_address: string | null
          metadata: Json | null
          position: string | null
          target_id: string | null
          target_type: string | null
          user_agent: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_activity_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_activity_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_stats_view: {
        Row: {
          completed_tasks: number | null
          department: string | null
          efficiency: number | null
          email: string | null
          id: string | null
          name: string | null
          position: string | null
          role: string | null
          status: string | null
          total_hours: number | null
          total_minutes: number | null
          total_points: number | null
          total_tasks: number | null
        }
        Relationships: []
      }
      employee_tasks_with_attachments_view: {
        Row: {
          actual_minutes: number | null
          assigned_by: string | null
          attachment_count: number | null
          attachments: Json | null
          category: string | null
          completed_at: string | null
          created_at: string | null
          description: string | null
          due_date: string | null
          employee_id: string | null
          estimated_minutes: number | null
          id: string | null
          priority: string | null
          status: string | null
          title: string | null
          updated_at: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_employee_tasks_assigned_by"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_employee_tasks_assigned_by"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_employee_tasks_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employee_stats_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_employee_tasks_employee"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      unified_employee_tasks: {
        Row: {
          actual_minutes: number | null
          assigned_by: string | null
          assignee_id: string | null
          category: string | null
          client_name: string | null
          completed_at: string | null
          created_at: string | null
          description: string | null
          due_date: string | null
          estimated_minutes: number | null
          id: string | null
          priority: string | null
          project_name: string | null
          sales_result_id: string | null
          source: string | null
          status: string | null
          task_name: string | null
          task_type: string | null
          updated_at: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      almaty_date_string: {
        Args: { input_date?: string }
        Returns: string
      }
      award_achievement_safely: {
        Args: {
          emp_id: string
          ach_name: string
          ach_description: string
          ach_points: number
        }
        Returns: boolean
      }
      calculate_employee_points: {
        Args: { emp_id: string }
        Returns: number
      }
      can_view_employee: {
        Args: { target_employee_id: string }
        Returns: boolean
      }
      can_view_sales_employees: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      can_view_sales_employees_in_org: {
        Args: { p_org_id: string; p_user_id?: string }
        Returns: boolean
      }
      check_sales_achievements: {
        Args: { emp_id: string }
        Returns: undefined
      }
      check_task_achievements: {
        Args: { emp_id: string }
        Returns: undefined
      }
      cleanup_old_activity_logs: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      clear_employee_shop_purchases: {
        Args: { emp_id: string }
        Returns: undefined
      }
      create_employee_with_auth: {
        Args: {
          employee_name: string
          employee_email: string
          employee_position: string
          employee_department: string
          default_password?: string
        }
        Returns: string
      }
      create_next_monthly_payment: {
        Args: {
          p_sales_result_id: string
          p_monthly_amount: number
          p_from_date?: string
        }
        Returns: undefined
      }
      format_almaty_date: {
        Args: { input_date: string }
        Returns: string
      }
      generate_monthly_payments: {
        Args: {
          p_sales_result_id: string
          p_monthly_amount: number
          p_start_date: string
          p_months_count?: number
        }
        Returns: undefined
      }
      generate_org_join_code: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_department_employees: {
        Args: { manager_user_id?: string }
        Returns: {
          id: string
          name: string
          email: string
          emp_position: string
          department: string
          role: string
          status: string
          user_id: string
        }[]
      }
      get_employee_by_user_id: {
        Args: { check_user_id?: string }
        Returns: {
          id: string
          name: string
          email: string
          emp_position: string
          department: string
          role: string
          status: string
        }[]
      }
      get_org_join_settings: {
        Args: { p_org_id?: string }
        Returns: {
          org_id: string
          join_code: string
          join_code_enabled: boolean
          join_code_expires_at: string
        }[]
      }
      get_single_org_id_for_user: {
        Args: { p_user_id?: string }
        Returns: string
      }
      is_admin: {
        Args: { check_user_id?: string }
        Returns: boolean
      }
      is_admin_in_org: {
        Args: { p_org_id: string; p_user_id?: string }
        Returns: boolean
      }
      is_admin_or_tech_lead: {
        Args: { check_user_id?: string }
        Returns: boolean
      }
      is_admin_or_tech_lead_in_org: {
        Args: { p_org_id: string; p_user_id?: string }
        Returns: boolean
      }
      is_ai_lead: {
        Args: { check_user_id?: string }
        Returns: boolean
      }
      is_financist: {
        Args: { check_user_id?: string }
        Returns: boolean
      }
      is_financist_in_org: {
        Args: { p_org_id: string; p_user_id?: string }
        Returns: boolean
      }
      is_member_of_org: {
        Args: { p_org_id: string; p_user_id?: string }
        Returns: boolean
      }
      is_role_in_org: {
        Args: { p_org_id: string; p_role: string; p_user_id?: string }
        Returns: boolean
      }
      is_sales_lead: {
        Args: { check_user_id?: string }
        Returns: boolean
      }
      log_employee_action: {
        Args: {
          p_employee_id: string
          p_action_type: string
          p_action_description: string
          p_target_type?: string
          p_target_id?: string
          p_metadata?: Json
        }
        Returns: undefined
      }
      mark_payment_as_paid: {
        Args: { p_payment_id: string; p_actual_date?: string; p_notes?: string }
        Returns: undefined
      }
      now_almaty: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      process_shop_purchase: {
        Args: { emp_id: string; item_name: string; item_price: number }
        Returns: Json
      }
      resolve_current_org_id: {
        Args: { p_org_id?: string }
        Returns: string
      }
      rotate_org_join_code: {
        Args: { p_org_id?: string }
        Returns: {
          org_id: string
          join_code: string
          join_code_enabled: boolean
          join_code_expires_at: string
        }[]
      }
      set_org_join_enabled: {
        Args: { p_org_id?: string; p_enabled?: boolean; p_expires_at?: string }
        Returns: {
          org_id: string
          join_code: string
          join_code_enabled: boolean
          join_code_expires_at: string
        }[]
      }
      update_overdue_payments: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
    }
    Enums: {
      client_source_type:
        | "Сарафанка"
        | "Таргет реклама"
        | "Ерқанат инста"
        | "Ұлан"
      client_type_enum:
        | "Сразу купил"
        | "Перешел из тестового"
        | "Единоразовая услуга"
      project_status_enum:
        | "Работаем"
        | "Еще не начали"
        | "Закончили"
        | "Ждём остаток"
        | "Не указан"
        | "Завершили работу"
        | "Пауза"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      client_source_type: [
        "Сарафанка",
        "Таргет реклама",
        "Ерқанат инста",
        "Ұлан",
      ],
      client_type_enum: [
        "Сразу купил",
        "Перешел из тестового",
        "Единоразовая услуга",
      ],
      project_status_enum: [
        "Работаем",
        "Еще не начали",
        "Закончили",
        "Ждём остаток",
        "Не указан",
        "Завершили работу",
        "Пауза",
      ],
    },
  },
} as const
