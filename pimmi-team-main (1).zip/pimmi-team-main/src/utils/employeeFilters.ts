interface Employee {
  id: string;
  name: string;
  position: string;
  department: string;
}

export const filterEmployeesByWorkFormat = (
  employees: Employee[],
  workFormats: string[]
): Employee[] => {
  if (!workFormats || workFormats.length === 0) return employees;

  return employees.filter(employee => {
    const workFormatsLower = workFormats.map(f => f.toLowerCase());
    const positionLower = employee.position.toLowerCase();
    const departmentLower = employee.department.toLowerCase();

    return workFormatsLower.some(format => {
      switch (format) {
        case "таргет":
        case "таргетинг":
          return positionLower.includes("таргет") || departmentLower.includes("таргет");
        case "дожим":
          return positionLower.includes("дожим") || departmentLower.includes("дожим");
        case "ии продажи":
        case "ai продажи":
          return positionLower.includes("ии") || positionLower.includes("ai") || 
                 departmentLower.includes("ии") || departmentLower.includes("ai");
        case "smm":
          return positionLower.includes("smm") || departmentLower.includes("smm");
        case "контент":
          return positionLower.includes("контент") || departmentLower.includes("контент");
        case "дизайн":
          return positionLower.includes("дизайн") || departmentLower.includes("дизайн");
        case "видео":
          return positionLower.includes("видео") || departmentLower.includes("видео");
        default:
          return true;
      }
    });
  });
};