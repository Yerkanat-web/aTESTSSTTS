/**
 * Централизованная система логирования
 * В production режиме логирование отключено
 */

interface LogContext {
  component?: string;
  userId?: string;
  action?: string;
  data?: any;
}

class Logger {
  private isDevelopment = import.meta.env.DEV;

  private formatMessage(level: string, message: string, context?: LogContext): string {
    const timestamp = new Date().toISOString();
    const contextStr = context ? ` | Context: ${JSON.stringify(context)}` : '';
    return `[${timestamp}] ${level.toUpperCase()}: ${message}${contextStr}`;
  }

  info(message: string, context?: LogContext): void {
    if (this.isDevelopment) {
      console.info(this.formatMessage('info', message, context));
    }
  }

  warn(message: string, context?: LogContext): void {
    if (this.isDevelopment) {
      console.warn(this.formatMessage('warn', message, context));
    }
  }

  error(message: string, error?: Error | unknown, context?: LogContext): void {
    if (this.isDevelopment) {
      const errorContext = {
        ...context,
        error: error instanceof Error ? {
          message: error.message,
          stack: error.stack
        } : error
      };
      console.error(this.formatMessage('error', message, errorContext));
    }
  }

  debug(message: string, data?: any, context?: LogContext): void {
    if (this.isDevelopment) {
      const debugContext = { ...context, data };
      console.log(this.formatMessage('debug', message, debugContext));
    }
  }

  // Для критических ошибок, которые должны логироваться даже в production
  critical(message: string, error?: Error | unknown, context?: LogContext): void {
    const errorContext = {
      ...context,
      error: error instanceof Error ? {
        message: error.message,
        stack: error.stack
      } : error
    };
    console.error(this.formatMessage('critical', message, errorContext));
  }
}

export const logger = new Logger();

// Экспорт для обратной совместимости
export default logger;