// Helper functions for time formatting and parsing
import { formatInTimeZone, fromZonedTime, toZonedTime } from 'date-fns-tz';
import { format, parseISO } from 'date-fns';
import { ru } from 'date-fns/locale';

// Константа для временной зоны Алматы (GMT+5)
export const ALMATY_TIMEZONE = 'Asia/Almaty';

export interface TimeComponents {
  hours: number;
  minutes: number;
}

/**
 * Format minutes as "1ч 30м" or "30м" if less than an hour
 */
export function formatTime(totalMinutes: number | null): string {
  if (!totalMinutes || totalMinutes === 0) return '0м';
  
  const hours = Math.floor(totalMinutes / 60);
  const minutes = Math.round(totalMinutes % 60);
  
  if (hours === 0) {
    return `${minutes}м`;
  }
  
  if (minutes === 0) {
    return `${hours}ч`;
  }
  
  return `${hours}ч ${minutes}м`;
}

/**
 * Parse hours and minutes into total minutes
 */
export function parseTimeToMinutes(hours: number, minutes: number): number {
  return (hours || 0) * 60 + (minutes || 0);
}

/**
 * Parse total minutes into hours and minutes components
 */
export function parseMinutesToHoursAndMinutes(totalMinutes: number | null): TimeComponents {
  if (!totalMinutes) return { hours: 0, minutes: 0 };
  
  return {
    hours: Math.floor(totalMinutes / 60),
    minutes: totalMinutes % 60
  };
}

/**
 * Format time for display in forms (separate hours and minutes)
 */
export function formatTimeForInput(totalMinutes: number | null): { hours: string; minutes: string } {
  const { hours, minutes } = parseMinutesToHoursAndMinutes(totalMinutes);
  return {
    hours: hours.toString(),
    minutes: minutes.toString()
  };
}

// ============ ВРЕМЕННАЯ ЗОНА GMT+5 (АЛМАТЫ) ============

/**
 * Получить текущую дату и время в GMT+5
 */
export function nowInAlmaty(): Date {
  return toZonedTime(new Date(), ALMATY_TIMEZONE);
}

/**
 * Преобразовать UTC дату в локальное время Алматы
 */
export function toAlmatyTime(date: Date): Date {
  return toZonedTime(date, ALMATY_TIMEZONE);
}

/**
 * Преобразовать локальное время Алматы в UTC
 */
export function fromAlmatyTime(date: Date): Date {
  return fromZonedTime(date, ALMATY_TIMEZONE);
}

/**
 * Форматировать дату в временной зоне Алматы
 */
export function formatInAlmaty(date: Date, formatStr: string = 'dd.MM.yyyy HH:mm'): string {
  return formatInTimeZone(date, ALMATY_TIMEZONE, formatStr, { locale: ru });
}

/**
 * Получить строку даты в формате YYYY-MM-DD для временной зоны Алматы
 */
export function getAlmatyDateString(date?: Date): string {
  const targetDate = date || new Date();
  return formatInTimeZone(targetDate, ALMATY_TIMEZONE, 'yyyy-MM-dd');
}

/**
 * Получить строку времени в формате HH:mm для временной зоны Алматы
 */
export function getAlmatyTimeString(date?: Date): string {
  const targetDate = date || new Date();
  return formatInTimeZone(targetDate, ALMATY_TIMEZONE, 'HH:mm');
}

/**
 * Получить полную строку даты и времени для отображения пользователю
 */
export function getAlmatyDateTimeString(date?: Date): string {
  const targetDate = date || new Date();
  return formatInTimeZone(targetDate, ALMATY_TIMEZONE, 'dd.MM.yyyy в HH:mm', { locale: ru });
}

/**
 * Парсинг строки даты как дата в временной зоне Алматы
 */
export function parseAlmatyDate(dateString: string): Date {
  // Парсим дату как если она была в временной зоне Алматы
  return fromZonedTime(parseISO(dateString), ALMATY_TIMEZONE);
}

/**
 * Проверить, является ли дата сегодняшней в временной зоне Алматы
 */
export function isToday(date: Date): boolean {
  const today = formatInTimeZone(new Date(), ALMATY_TIMEZONE, 'yyyy-MM-dd');
  const checkDate = formatInTimeZone(date, ALMATY_TIMEZONE, 'yyyy-MM-dd');
  return today === checkDate;
}

/**
 * Получить начало дня в временной зоне Алматы
 */
export function startOfDayInAlmaty(date?: Date): Date {
  const targetDate = date || new Date();
  const dateString = formatInTimeZone(targetDate, ALMATY_TIMEZONE, 'yyyy-MM-dd');
  return fromZonedTime(parseISO(dateString + 'T00:00:00'), ALMATY_TIMEZONE);
}

/**
 * Получить конец дня в временной зоне Алматы
 */
export function endOfDayInAlmaty(date?: Date): Date {
  const targetDate = date || new Date();
  const dateString = formatInTimeZone(targetDate, ALMATY_TIMEZONE, 'yyyy-MM-dd');
  return fromZonedTime(parseISO(dateString + 'T23:59:59'), ALMATY_TIMEZONE);
}

/**
 * Добавить дни к дате в временной зоне Алматы
 */
export function addDaysInAlmaty(date: Date, days: number): Date {
  const almatyDate = toAlmatyTime(date);
  almatyDate.setDate(almatyDate.getDate() + days);
  return fromAlmatyTime(almatyDate);
}

/**
 * Проверить, попадает ли дата на воскресенье в временной зоне Алматы
 */
export function isSundayInAlmaty(date: Date): boolean {
  const almatyDate = toAlmatyTime(date);
  return almatyDate.getDay() === 0;
}

/**
 * Проверить, попадает ли дата на субботу в временной зоне Алматы
 */
export function isSaturdayInAlmaty(date: Date): boolean {
  const almatyDate = toAlmatyTime(date);
  return almatyDate.getDay() === 6;
}

// ============ SUPABASE SQL ФУНКЦИИ ============

/**
 * Получить текущее время из базы данных в GMT+5
 * Использует SQL функцию now_almaty()
 */
export async function getCurrentAlmatyTimeFromDB() {
  const { supabase } = await import('@/integrations/supabase/client');
  
  const { data, error } = await supabase.rpc('now_almaty');
  
  if (error) {
    console.error('Error getting Almaty time from DB:', error);
    return new Date(); // fallback to local time
  }
  
  return new Date(data);
}

/**
 * Форматировать дату через SQL функцию базы данных в GMT+5
 * Использует SQL функцию format_almaty_date()
 */
export async function formatAlmatyDateFromDB(date: Date): Promise<string> {
  const { supabase } = await import('@/integrations/supabase/client');
  
  const { data, error } = await supabase.rpc('format_almaty_date', {
    input_date: date.toISOString()
  });
  
  if (error) {
    console.error('Error formatting Almaty date from DB:', error);
    return formatInAlmaty(date); // fallback to client-side formatting
  }
  
  return data;
}

/**
 * Получить строку даты через SQL функцию базы данных в GMT+5
 * Использует SQL функцию almaty_date_string()
 */
export async function getAlmatyDateStringFromDB(date?: Date): Promise<string> {
  const { supabase } = await import('@/integrations/supabase/client');
  
  const { data, error } = await supabase.rpc('almaty_date_string', {
    input_date: date ? date.toISOString() : null
  });
  
  if (error) {
    console.error('Error getting Almaty date string from DB:', error);
    return getAlmatyDateString(date); // fallback to client-side
  }
  
  return data;
}