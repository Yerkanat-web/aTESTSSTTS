import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface EmployeeStats {
  id: string;
  name: string;
  email: string;
  position: string;
  department: string;
  role: string;
  status: string;
  total_points: number;
  total_tasks: number;
  completed_tasks: number;
  total_hours: number;
  total_minutes: number;
  efficiency: number;
}

export const useEmployeeStats = (employeeId?: string) => {
  const [stats, setStats] = useState<EmployeeStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStats = async () => {
    console.log('📊 useEmployeeStats fetchStats called with employeeId:', employeeId);
    
    if (!employeeId) {
      console.log('❌ No employeeId provided');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      console.log('🔄 Fetching stats for employee:', employeeId);
      
      const { data, error } = await supabase
        .from('employee_stats_view')
        .select('*')
        .eq('id', employeeId)
        .single();

      console.log('📈 Stats query result:', { data, error });

      if (error) throw error;

      setStats(data);
      setError(null);
      console.log('✅ Stats loaded successfully:', data);
    } catch (err) {
      console.error('❌ Error fetching employee stats:', err);
      setError('Failed to fetch employee statistics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [employeeId]);

  return {
    stats,
    loading,
    error,
    refetch: fetchStats
  };
};

export const useAllEmployeeStats = (department?: string) => {
  const [stats, setStats] = useState<EmployeeStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAllStats = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('employee_stats_view')
        .select('*');
      
      // Filter by department if specified
      if (department) {
        query = query.eq('department', department);
      }
      
      const { data, error } = await query.order('total_points', { ascending: false });

      if (error) throw error;

      setStats(data || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching all employee stats:', err);
      setError('Failed to fetch employee statistics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllStats();
  }, []);

  // Subscribe to real-time updates
  useEffect(() => {
    const channel = supabase
      .channel('employee-stats-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employee_points'
        },
        () => {
          fetchAllStats();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employee_tasks'
        },
        () => {
          fetchAllStats();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return {
    stats,
    loading,
    error,
    refetch: fetchAllStats
  };
};