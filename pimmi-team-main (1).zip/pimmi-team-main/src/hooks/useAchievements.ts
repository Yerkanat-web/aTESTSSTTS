import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { scopeToOrg } from "@/integrations/supabase/org";
export interface Achievement {
  id: string;
  employee_id: string;
  achievement_name: string;
  description: string | null;
  points: number;
  earned_at: string;
  created_at: string;
}

export interface AchievementRule {
  id: string;
  name: string;
  description: string;
  category: string;
  points: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  condition_type: 'task_count' | 'task_streak' | 'points_total' | 'category_tasks' | 'fast_completion' | 'work_hours' | 'sales_count' | 'sales_amount';
  condition_value: number;
  condition_data?: any;
}

// Функция для расчета последовательности дней с выполненными задачами
const calculateStreakDays = (tasks: any[]) => {
  if (!tasks || tasks.length === 0) return 0;

  // Группируем задачи по дням
  const tasksByDate = new Map();
  tasks.forEach(task => {
    if (task.completed_at) {
      const date = new Date(task.completed_at).toDateString();
      if (!tasksByDate.has(date)) {
        tasksByDate.set(date, []);
      }
      tasksByDate.get(date).push(task);
    }
  });

  // Сортируем даты
  const sortedDates = Array.from(tasksByDate.keys()).sort();
  if (sortedDates.length === 0) return 0;

  let maxStreak = 1;
  let currentStreak = 1;

  for (let i = 1; i < sortedDates.length; i++) {
    const prevDate = new Date(sortedDates[i - 1]);
    const currentDate = new Date(sortedDates[i]);
    const diffDays = Math.floor((currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      currentStreak++;
      maxStreak = Math.max(maxStreak, currentStreak);
    } else {
      currentStreak = 1;
    }
  }

  return maxStreak;
};

export const ACHIEVEMENT_RULES: AchievementRule[] = [
  {
    id: 'first_task',
    name: 'Первые шаги',
    description: 'Выполните первую задачу',
    category: 'Начинающий',
    points: 50,
    rarity: 'common',
    condition_type: 'task_count',
    condition_value: 1
  },
  {
    id: 'task_master_10',
    name: 'Исполнитель',
    description: 'Выполните 10 задач',
    category: 'Продуктивность',
    points: 100,
    rarity: 'common',
    condition_type: 'task_count',
    condition_value: 10
  },
  {
    id: 'task_master_50',
    name: 'Мастер задач',
    description: 'Выполните 50 задач',
    category: 'Продуктивность',
    points: 250,
    rarity: 'rare',
    condition_type: 'task_count',
    condition_value: 50
  },
  {
    id: 'task_master_100',
    name: 'Легенда продуктивности',
    description: 'Выполните 100 задач',
    category: 'Продуктивность',
    points: 500,
    rarity: 'epic',
    condition_type: 'task_count',
    condition_value: 100
  },
  {
    id: 'easy_tasks_master',
    name: 'Мастер простых задач',
    description: 'Выполните 200 легких задач',
    category: 'Мастерство',
    points: 300,
    rarity: 'epic',
    condition_type: 'category_tasks',
    condition_value: 200,
    condition_data: { priority: 'easy' }
  },
  {
    id: 'hard_streak_5',
    name: 'Мастер сложности',
    description: 'Выполните 25 сложных задач',
    category: 'Мастерство',
    points: 600,
    rarity: 'epic',
    condition_type: 'category_tasks',
    condition_value: 25,
    condition_data: { priority: 'hard' }
  },
  {
    id: 'streak_100',
    name: 'Железная воля',
    description: 'Выполните задачи 100 дней подряд',
    category: 'Постоянство',
    points: 1000,
    rarity: 'legendary',
    condition_type: 'task_streak',
    condition_value: 100
  },
  {
    id: 'hard_worker',
    name: 'Сложные вызовы',
    description: 'Выполните 10 сложных задач',
    category: 'Мастерство',
    points: 200,
    rarity: 'rare',
    condition_type: 'category_tasks',
    condition_value: 10,
    condition_data: { priority: 'hard' }
  },
  {
    id: 'points_collector_500',
    name: 'Коллекционер',
    description: 'Наберите 500 баллов',
    category: 'Достижения',
    points: 100,
    rarity: 'common',
    condition_type: 'points_total',
    condition_value: 500
  },
  {
    id: 'points_collector_1000',
    name: 'Магнат баллов',
    description: 'Наберите 1000 баллов',
    category: 'Достижения',
    points: 200,
    rarity: 'rare',
    condition_type: 'points_total',
    condition_value: 1000
  }
];

export const useAchievements = (employeeId?: string) => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [actualProgress, setActualProgress] = useState<Record<string, number>>({});
  const [rules, setRules] = useState<AchievementRule[]>(ACHIEVEMENT_RULES);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  // Load achievement templates from DB with fallback to static rules
  const fetchRules = async () => {
    try {
      
      const { data, error } = await scopeToOrg(
        (supabase as any)
          .from('achievement_templates')
          .select('id, name, description, category, points, rarity, condition_type, condition_value, condition_data, is_active')
          .eq('is_active', true)
          .eq('target_group', 'general')
          .order('sort_order', { ascending: true }),
        currentOrgId
      );


      if (error) {
        console.error('Error fetching achievement templates:', error);
        setRules(ACHIEVEMENT_RULES);
        return;
      }

      if (data && data.length > 0) {
        const mapped = data.map((t: any) => ({
          id: t.id,
          name: t.name,
          description: t.description || '',
          category: t.category || 'Общее',
          points: t.points || 0,
          rarity: t.rarity || 'common',
          condition_type: t.condition_type,
          condition_value: t.condition_value || 0,
          condition_data: t.condition_data || undefined,
        })) as AchievementRule[];
        setRules(mapped);
      } else {
        setRules(ACHIEVEMENT_RULES);
      }
    } catch (e) {
      console.error('Error loading achievement templates:', e);
      setRules(ACHIEVEMENT_RULES);
    }
  };
  const fetchAchievements = async () => {
    if (!employeeId) return;

    try {
      const { data, error } = await supabase
        .from('employee_achievements')
        .select('*')
        .eq('employee_id', employeeId)
        .order('earned_at', { ascending: false });

      if (error) throw error;
      setAchievements(data || []);
    } catch (error) {
      console.error('Error fetching achievements:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkAndAwardAchievements = async () => {
    if (!employeeId) return;
    
    try {
      console.log('🏆 Checking achievements for employee:', employeeId);
      
      // Получаем подробную статистику сотрудника
      const { data: statsData } = await supabase
        .from('employee_stats_view')
        .select('*')
        .eq('id', employeeId)
        .single();

      if (!statsData) {
        console.log('❌ No stats found for employee');
        return;
      }

      console.log('📊 Employee stats:', statsData);

      // Получаем уже полученные достижения
      const { data: existingAchievements } = await supabase
        .from('employee_achievements')
        .select('achievement_name')
        .eq('employee_id', employeeId);

      const achievedNames = existingAchievements?.map(a => a.achievement_name) || [];
      console.log('✅ Already achieved:', achievedNames);

      // Получаем все задачи для более точных проверок
      const { data: allTasks } = await supabase
        .from('employee_tasks')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'completed')
        .order('completed_at', { ascending: true });

      console.log('📝 Completed tasks:', allTasks?.length || 0);

      // Проверяем каждое правило достижений
      for (const rule of rules) {
        if (achievedNames.includes(rule.name)) {
          console.log(`⏭️ Achievement ${rule.name} already earned`);
          continue;
        }

        let shouldAward = false;

        switch (rule.condition_type) {
          case 'task_count':
            shouldAward = (statsData.completed_tasks || 0) >= rule.condition_value;
            console.log(`📊 Tasks completed check (${rule.name}): ${statsData.completed_tasks} >= ${rule.condition_value} = ${shouldAward}`);
            break;
            
          case 'points_total':
            shouldAward = (statsData.total_points || 0) >= rule.condition_value;
            console.log(`💰 Points total check (${rule.name}): ${statsData.total_points} >= ${rule.condition_value} = ${shouldAward}`);
            break;
            
          case 'category_tasks':
            if (rule.condition_data?.priority) {
              const categoryTasks = allTasks?.filter(task => task.priority === rule.condition_data.priority) || [];
              
              // Если требуется последовательность (например, 5 сложных задач подряд)
              if (rule.condition_data.consecutive) {
                // Проверяем сложные задачи в один день
                const tasksByDate = new Map();
                categoryTasks.forEach(task => {
                  if (task.completed_at) {
                    const date = new Date(task.completed_at).toDateString();
                    if (!tasksByDate.has(date)) {
                      tasksByDate.set(date, []);
                    }
                    tasksByDate.get(date).push(task);
                  }
                });
                
                let maxTasksInDay = 0;
                tasksByDate.forEach(tasksInDay => {
                  maxTasksInDay = Math.max(maxTasksInDay, tasksInDay.length);
                });
                
                shouldAward = maxTasksInDay >= rule.condition_value;
                console.log(`🔥 Consecutive category tasks check (${rule.name}): max ${maxTasksInDay} ${rule.condition_data.priority} tasks in one day >= ${rule.condition_value} = ${shouldAward}`);
              } else {
                shouldAward = categoryTasks.length >= rule.condition_value;
                console.log(`📝 Category tasks check (${rule.name}): ${categoryTasks.length} ${rule.condition_data.priority} tasks >= ${rule.condition_value} = ${shouldAward}`);
              }
            }
            break;
            
          case 'task_streak':
            if (allTasks && allTasks.length > 0) {
              const streak = calculateStreakDays(allTasks);
              shouldAward = streak >= rule.condition_value;
              console.log(`🔥 Task streak check (${rule.name}): ${streak} days streak >= ${rule.condition_value} = ${shouldAward}`);
            }
            break;
            
          default:
            console.log(`❓ Unknown condition type: ${rule.condition_type}`);
        }

        if (shouldAward) {
          console.log(`🎉 Awarding achievement: ${rule.name}`);
          await awardAchievement(rule);
        }
      }
    } catch (error) {
      console.error('❌ Error checking achievements:', error);
    }
  };

  const awardAchievement = async (rule: AchievementRule) => {
    if (!employeeId) return;

    try {
      console.log(`🎉 Attempting to award achievement: ${rule.name}`);
      
      // Используем безопасную функцию для присуждения достижений
      const { data, error } = await supabase.rpc('award_achievement_safely', {
        emp_id: employeeId,
        ach_name: rule.name,
        ach_description: rule.description,
        ach_points: rule.points
      });

      if (error) {
        console.error('❌ Error calling award_achievement_safely:', error);
        throw error;
      }

      if (data === true) {
        console.log(`✅ Achievement ${rule.name} awarded successfully`);
        
        toast({
          title: "🏆 Новое достижение!",
          description: `Вы получили достижение "${rule.name}" (+${rule.points} баллов)`,
        });

        // Обновляем список достижений
        fetchAchievements();
      } else {
        console.log(`ℹ️ Achievement ${rule.name} was already earned`);
      }
    } catch (error) {
      console.error('❌ Error awarding achievement:', error);
    }
  };

  // Функция для загрузки реального прогресса
  const fetchActualProgress = async () => {
    if (!employeeId) return;

    const progressMap: Record<string, number> = {};

    try {
      // Получаем все завершенные задачи
      const { data: allTasks } = await supabase
        .from('employee_tasks')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'completed')
        .order('completed_at', { ascending: true });

      // Получаем статистику
      const { data: statsData } = await supabase
        .from('employee_stats_view')
        .select('*')
        .eq('id', employeeId)
        .single();

      if (!statsData || !allTasks) return;

      // Рассчитываем реальный прогресс для каждого правила
      for (const rule of rules) {
        switch (rule.condition_type) {
          case 'task_count':
            progressMap[rule.id] = Math.min(statsData.completed_tasks || 0, rule.condition_value);
            break;
          case 'points_total':
            progressMap[rule.id] = Math.min(statsData.total_points || 0, rule.condition_value);
            break;
          case 'category_tasks':
            if (rule.condition_data?.priority) {
              const categoryTasks = allTasks.filter(task => task.priority === rule.condition_data.priority);
              progressMap[rule.id] = Math.min(categoryTasks.length, rule.condition_value);
            }
            break;
          case 'task_streak':
            const streak = calculateStreakDays(allTasks);
            progressMap[rule.id] = Math.min(streak, rule.condition_value);
            break;
        }
      }

      setActualProgress(progressMap);
    } catch (error) {
      console.error('Error fetching actual progress:', error);
    }
  };

  const getAchievementProgress = (rule: AchievementRule, stats: any) => {
    // Сначала проверяем реальный прогресс, если он доступен
    if (actualProgress[rule.id] !== undefined) {
      return actualProgress[rule.id];
    }

    // Возвращаем синхронный прогресс для базовых типов
    switch (rule.condition_type) {
      case 'task_count':
        return Math.min(stats.completed_tasks || 0, rule.condition_value);
        
      case 'points_total':
        return Math.min(stats.total_points || 0, rule.condition_value);
        
      case 'category_tasks':
        // Для категориальных достижений используем приблизительный расчет
        // на основе общего количества выполненных задач
        const estimatedCategoryTasks = Math.floor((stats.completed_tasks || 0) * 0.3);
        return Math.min(estimatedCategoryTasks, rule.condition_value);
        
      case 'task_streak':
        // Для полосы успеха показываем приблизительный прогресс
        const estimatedStreak = Math.floor((stats.completed_tasks || 0) * 0.1);
        return Math.min(estimatedStreak, rule.condition_value);
        
      default:
        return 0;
    }
  };

  // Функция для ручной проверки всех пользователей (для администраторов)
  const checkAllEmployeesAchievements = async () => {
    try {
      console.log('🔄 Checking achievements for all employees...');
      
      const { data: employees } = await supabase
        .from('employees')
        .select('id')
        .eq('status', 'active');

      if (!employees) return;

      for (const employee of employees) {
        console.log(`Checking employee ${employee.id}...`);
        // Временно устанавливаем ID для проверки
        const tempEmployeeId = employee.id;
        
        // Получаем статистику
        const { data: statsData } = await supabase
          .from('employee_stats_view')
          .select('*')
          .eq('id', tempEmployeeId)
          .single();

        if (!statsData) continue;

        // Получаем уже полученные достижения
        const { data: existingAchievements } = await supabase
          .from('employee_achievements')
          .select('achievement_name')
          .eq('employee_id', tempEmployeeId);

        const achievedNames = existingAchievements?.map(a => a.achievement_name) || [];

        // Получаем все задачи
        const { data: allTasks } = await supabase
          .from('employee_tasks')
          .select('*')
          .eq('employee_id', tempEmployeeId)
          .eq('status', 'completed')
          .order('completed_at', { ascending: true });

        // Проверяем достижения
        for (const rule of rules) {
          if (achievedNames.includes(rule.name)) continue;

          let shouldAward = false;

          switch (rule.condition_type) {
            case 'task_count':
              shouldAward = (statsData.completed_tasks || 0) >= rule.condition_value;
              break;
            case 'points_total':
              shouldAward = (statsData.total_points || 0) >= rule.condition_value;
              break;
            case 'category_tasks':
              if (rule.condition_data?.priority) {
                const categoryTasks = allTasks?.filter(task => task.priority === rule.condition_data.priority) || [];
                if (rule.condition_data.consecutive) {
                  const tasksByDate = new Map();
                  categoryTasks.forEach(task => {
                    if (task.completed_at) {
                      const date = new Date(task.completed_at).toDateString();
                      if (!tasksByDate.has(date)) {
                        tasksByDate.set(date, []);
                      }
                      tasksByDate.get(date).push(task);
                    }
                  });
                  let maxTasksInDay = 0;
                  tasksByDate.forEach(tasksInDay => {
                    maxTasksInDay = Math.max(maxTasksInDay, tasksInDay.length);
                  });
                  shouldAward = maxTasksInDay >= rule.condition_value;
                } else {
                  shouldAward = categoryTasks.length >= rule.condition_value;
                }
              }
              break;
            case 'task_streak':
              if (allTasks && allTasks.length > 0) {
                const streak = calculateStreakDays(allTasks);
                shouldAward = streak >= rule.condition_value;
              }
              break;
          }

          if (shouldAward) {
            console.log(`🎉 Awarding ${rule.name} to employee ${tempEmployeeId}`);
            
            // Используем безопасную функцию для присуждения достижений
            const { data, error } = await supabase.rpc('award_achievement_safely', {
              emp_id: tempEmployeeId,
              ach_name: rule.name,
              ach_description: rule.description,
              ach_points: rule.points
            });
            
            if (error) {
              console.error(`❌ Error awarding ${rule.name} to ${tempEmployeeId}:`, error);
            } else if (data === true) {
              console.log(`✅ Successfully awarded ${rule.name} to ${tempEmployeeId}`);
            }
          }
        }
      }
      
      console.log('✅ Finished checking all employees');
    } catch (error) {
      console.error('❌ Error checking all employees achievements:', error);
    }
  };

  useEffect(() => {
    fetchRules();
    fetchAchievements();
    fetchActualProgress();
  }, [employeeId]);

  useEffect(() => {
    // Автоматически проверяем достижения при первой загрузке или изменении данных
    if (employeeId && achievements.length >= 0) {
      const timeoutId = setTimeout(checkAndAwardAchievements, 2000);
      return () => clearTimeout(timeoutId);
    }
  }, [employeeId, achievements.length]);

  return {
    achievements,
    loading,
    rules,
    refetch: fetchAchievements,
    checkAchievements: checkAndAwardAchievements,
    checkAllEmployeesAchievements,
    getAchievementProgress
  };
};