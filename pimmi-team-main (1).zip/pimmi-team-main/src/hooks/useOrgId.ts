
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Returns current organization id for the logged-in user.
 * Tries RPC get_single_org_id_for_user; if null and employeeId provided, falls back to employees table.
 */
export function useOrgId(employeeId?: string) {
  return useQuery({
    queryKey: ["orgId", employeeId],
    queryFn: async () => {
      // 1) Try single-org RPC
      const { data: singleOrg, error: orgErr } = await supabase.rpc("get_single_org_id_for_user");
      if (orgErr) {
        console.warn("useOrgId.get_single_org_id_for_user error:", orgErr);
      }
      if (singleOrg) return singleOrg as string;

      // 2) Fallback by employeeId
      if (employeeId) {
        const { data, error } = await supabase
          .from("employees")
          .select("org_id")
          .eq("id", employeeId)
          .single();
        if (error) throw error;
        return data?.org_id as string;
      }

      throw new Error("Не удалось определить организацию пользователя");
    },
  });
}
