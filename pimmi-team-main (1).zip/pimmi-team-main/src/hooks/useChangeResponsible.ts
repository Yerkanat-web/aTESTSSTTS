import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useCallback } from "react";
import { filterEmployeesByWorkFormat } from "@/utils/employeeFilters";

interface Employee {
  id: string;
  name: string;
  position: string;
  department: string;
}

interface ProjectTask {
  id: string;
  task_name: string;
  task_type: string;
  assignee_id: string | null;
  assignee_name: string | null;
  status: string | null;
}

interface ProjectData {
  id: string;
  project_name: string | null;
  client_name: string | null;
  work_format: string[] | null;
  employee_id: string;
  manager_name: string;
}

export const useChangeResponsible = (project: ProjectData | null) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [projectTasks, setProjectTasks] = useState<ProjectTask[]>([]);
  const [taskAssignments, setTaskAssignments] = useState<{ [taskId: string]: string }>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    if (!project) return;

    setLoading(true);
    try {
      // Загружаем задачи проекта с исполнителями
      const { data: tasksData, error: tasksError } = await supabase
        .from("project_tasks")
        .select(`
          id, task_name, task_type, assignee_id, status,
          assignee:employees!project_tasks_assignee_id_fkey(name)
        `)
        .eq("sales_result_id", project.id);

      if (tasksError) throw tasksError;

      const tasks = tasksData?.map(task => ({
        id: task.id,
        task_name: task.task_name,
        task_type: task.task_type,
        assignee_id: task.assignee_id,
        assignee_name: task.assignee?.name || null,
        status: task.status
      })) || [];

      setProjectTasks(tasks);

      // Инициализируем текущие назначения
      const assignments: { [taskId: string]: string } = {};
      tasks.forEach(task => {
        if (task.assignee_id) {
          assignments[task.id] = task.assignee_id;
        }
      });
      setTaskAssignments(assignments);

      // Загружаем доступных сотрудников по формату работы
      const { data: employeesData, error: employeesError } = await supabase
        .from("employees")
        .select("id, name, position, department")
        .eq("status", "active")
        .neq("role", "admin")
        .order("name");

      if (employeesError) throw employeesError;

      // Фильтруем сотрудников по формату работы (если форматы указаны)
      const filteredEmployees = project.work_format && project.work_format.length > 0
        ? filterEmployeesByWorkFormat(employeesData || [], project.work_format)
        : employeesData || [];

      setEmployees(filteredEmployees);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [project, toast]);

  const saveChanges = useCallback(async () => {
    if (!project) return false;

    setSaving(true);
    try {
      // Обновляем назначения для всех измененных задач
      const updatePromises = Object.entries(taskAssignments).map(([taskId, assigneeId]) => {
        return supabase
          .from("project_tasks")
          .update({ assignee_id: assigneeId })
          .eq("id", taskId);
      });

      const results = await Promise.all(updatePromises);
      
      // Проверяем на ошибки
      const errors = results.filter(result => result.error);
      if (errors.length > 0) {
        throw new Error("Ошибка при обновлении задач");
      }

      toast({
        title: "Успешно",
        description: "Исполнители задач обновлены",
      });

      return true;
    } catch (error) {
      console.error("Error updating task assignments:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить назначения",
        variant: "destructive",
      });
      return false;
    } finally {
      setSaving(false);
    }
  }, [project, taskAssignments, toast]);

  const updateTaskAssignment = useCallback((taskId: string, assigneeId: string) => {
    setTaskAssignments(prev => ({ ...prev, [taskId]: assigneeId }));
  }, []);

  const resetAssignments = useCallback(() => {
    setTaskAssignments({});
  }, []);

  return {
    employees,
    projectTasks,
    taskAssignments,
    loading,
    saving,
    fetchData,
    saveChanges,
    updateTaskAssignment,
    resetAssignments
  };
};