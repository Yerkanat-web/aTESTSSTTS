import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface LogActivityParams {
  actionType: string;
  actionDescription: string;
  targetType?: string;
  targetId?: string;
  metadata?: any;
}

export const useActivityLogger = () => {
  const [currentEmployee, setCurrentEmployee] = useState<any>(null);

  useEffect(() => {
    const getCurrentEmployee = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from('employees')
          .select('id, name, email, department, position')
          .eq('user_id', user.id)
          .single();
        
        setCurrentEmployee(data);
      }
    };

    getCurrentEmployee();
  }, []);

  const logActivity = async ({
    actionType,
    actionDescription,
    targetType,
    targetId,
    metadata
  }: LogActivityParams) => {
    if (!currentEmployee) return;

    try {
      const { error } = await supabase.rpc('log_employee_action', {
        p_employee_id: currentEmployee.id,
        p_action_type: actionType,
        p_action_description: actionDescription,
        p_target_type: targetType || null,
        p_target_id: targetId || null,
        p_metadata: metadata || null
      });

      if (error) {
        console.error('Error logging activity:', error);
      }
    } catch (error) {
      console.error('Error logging activity:', error);
    }
  };

  // Предустановленные методы для часто используемых действий
  const logLogin = () => {
    logActivity({
      actionType: 'login',
      actionDescription: `${currentEmployee?.name} вошел в систему`
    });
  };

  const logLogout = () => {
    logActivity({
      actionType: 'logout',
      actionDescription: `${currentEmployee?.name} вышел из системы`
    });
  };

  const logTaskCreate = (taskName: string, taskId?: string) => {
    logActivity({
      actionType: 'create',
      actionDescription: `Создана задача: ${taskName}`,
      targetType: 'task',
      targetId: taskId,
      metadata: { task_name: taskName }
    });
  };

  const logTaskUpdate = (taskName: string, taskId?: string, changes?: any) => {
    logActivity({
      actionType: 'update',
      actionDescription: `Обновлена задача: ${taskName}`,
      targetType: 'task',
      targetId: taskId,
      metadata: { task_name: taskName, changes }
    });
  };

  const logTaskComplete = (taskName: string, taskId?: string) => {
    logActivity({
      actionType: 'update',
      actionDescription: `Выполнена задача: ${taskName}`,
      targetType: 'task',
      targetId: taskId,
      metadata: { task_name: taskName, status: 'completed' }
    });
  };

  const logSaleCreate = (clientName: string, amount: number, saleId?: string) => {
    logActivity({
      actionType: 'create',
      actionDescription: `Создана продажа для клиента ${clientName} на сумму ${amount.toLocaleString()} тг`,
      targetType: 'sale',
      targetId: saleId,
      metadata: { client_name: clientName, amount }
    });
  };

  const logSaleUpdate = (clientName: string, saleId?: string, changes?: any) => {
    logActivity({
      actionType: 'update',
      actionDescription: `Обновлена продажа для клиента ${clientName}`,
      targetType: 'sale',
      targetId: saleId,
      metadata: { client_name: clientName, changes }
    });
  };

  const logSaleDelete = (clientName: string, saleId?: string) => {
    logActivity({
      actionType: 'delete',
      actionDescription: `Удалена продажа для клиента ${clientName}`,
      targetType: 'sale',
      targetId: saleId,
      metadata: { client_name: clientName }
    });
  };

  const logProjectStart = (projectName: string, projectId?: string) => {
    logActivity({
      actionType: 'update',
      actionDescription: `Запущен проект: ${projectName}`,
      targetType: 'project',
      targetId: projectId,
      metadata: { project_name: projectName, status: 'Работаем' }
    });
  };

  const logProjectExtension = (projectName: string, projectId?: string, amount?: number) => {
    logActivity({
      actionType: 'create',
      actionDescription: `Создано продление проекта: ${projectName}${amount ? ` на сумму ${amount.toLocaleString()} тг` : ''}`,
      targetType: 'project_extension',
      targetId: projectId,
      metadata: { project_name: projectName, amount }
    });
  };

  const logReportCreate = (reportDate: string) => {
    logActivity({
      actionType: 'create',
      actionDescription: `Создан ежедневный отчет за ${reportDate}`,
      targetType: 'report',
      metadata: { report_date: reportDate }
    });
  };

  const logShopPurchase = (itemName: string, itemPrice: number) => {
    logActivity({
      actionType: 'create',
      actionDescription: `Покупка в магазине: ${itemName} за ${itemPrice} баллов`,
      targetType: 'shop_purchase',
      metadata: { item_name: itemName, item_price: itemPrice }
    });
  };

  const logFileUpload = (fileName: string, fileType?: string) => {
    logActivity({
      actionType: 'upload',
      actionDescription: `Загружен файл: ${fileName}`,
      targetType: 'file',
      metadata: { file_name: fileName, file_type: fileType }
    });
  };

  const logPageView = (pageName: string) => {
    logActivity({
      actionType: 'view',
      actionDescription: `Просмотр страницы: ${pageName}`,
      targetType: 'page',
      metadata: { page_name: pageName }
    });
  };

  return {
    logActivity,
    logLogin,
    logLogout,
    logTaskCreate,
    logTaskUpdate,
    logTaskComplete,
    logSaleCreate,
    logSaleUpdate,
    logSaleDelete,
    logProjectStart,
    logProjectExtension,
    logReportCreate,
    logShopPurchase,
    logFileUpload,
    logPageView,
    currentEmployee
  };
};