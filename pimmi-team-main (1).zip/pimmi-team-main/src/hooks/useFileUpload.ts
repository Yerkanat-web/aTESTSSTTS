import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface UploadedFile {
  id: string;
  file_name: string;
  file_url: string | null;
  content_type: string;
  file_size: number;
  storage_path: string;
}

export const useFileUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const uploadFile = async (
    file: File,
    taskId: string,
    employeeId: string
  ): Promise<UploadedFile | null> => {
    try {
      setUploading(true);
      setError(null);

      console.log('Starting file upload:', { fileName: file.name, taskId, employeeId });

      // Check if user is authenticated
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError) {
        console.error('Auth check error:', authError);
        throw new Error('Authentication check failed');
      }
      
      if (!user) {
        console.error('User not authenticated');
        throw new Error('User not authenticated');
      }
      
      console.log('User authenticated:', user.id);

      // Validate file size (50MB limit)
      const maxSize = 50 * 1024 * 1024; // 50MB
      if (file.size > maxSize) {
        console.error('File too large:', file.size, 'bytes, max:', maxSize);
        throw new Error('File size exceeds 50MB limit');
      }

      // Create unique file path: employee_id/task_id/filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${employeeId}/${taskId}/${fileName}`;

      console.log('Upload details:', {
        filePath,
        fileSize: file.size,
        fileType: file.type,
        maxSize
      });

      // Upload file to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('task-attachments')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Storage upload error:', uploadError);
        console.error('Upload error details:', {
          message: uploadError.message,
          name: uploadError.name
        });
        throw uploadError;
      }

      console.log('File uploaded successfully:', uploadData);

      // Private bucket: do not use public URLs; we'll generate signed URLs when displaying

      // Save file metadata to database
      console.log('Saving attachment metadata to database...');
      const { data: attachmentData, error: attachmentError } = await supabase
        .from('task_attachments')
        .insert({
          task_id: taskId,
          employee_id: employeeId,
          file_name: file.name,
          file_url: null,
          storage_path: filePath,
          content_type: file.type,
          file_size: file.size
        })
        .select()
        .single();

      if (attachmentError) {
        console.error('Database insert error:', attachmentError);
        throw attachmentError;
      }

      console.log('Attachment saved to database:', attachmentData);

      return {
        id: attachmentData.id,
        file_name: attachmentData.file_name,
        file_url: attachmentData.file_url,
        content_type: attachmentData.content_type,
        file_size: attachmentData.file_size,
        storage_path: attachmentData.storage_path
      };
    } catch (err) {
      console.error('Error uploading file:', err);
      let errorMessage = 'Failed to upload file';
      
      if (err instanceof Error) {
        if (err.message.includes('User not authenticated')) {
          errorMessage = 'Please log in to upload files';
        } else if (err.message.includes('File size exceeds')) {
          errorMessage = 'File is too large (max 50MB)';
        } else if (err.message.includes('row-level security')) {
          errorMessage = 'Permission denied. Please contact administrator.';
        } else {
          errorMessage = `Upload failed: ${err.message}`;
        }
      }
      
      setError(errorMessage);
      return null;
    } finally {
      setUploading(false);
    }
  };

  const deleteFile = async (attachmentId: string, storagePath: string): Promise<boolean> => {
    try {
      setError(null);

      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('task-attachments')
        .remove([storagePath]);

      if (storageError) throw storageError;

      // Delete from database
      const { error: dbError } = await supabase
        .from('task_attachments')
        .delete()
        .eq('id', attachmentId);

      if (dbError) throw dbError;

      return true;
    } catch (err) {
      console.error('Error deleting file:', err);
      setError('Failed to delete file');
      return false;
    }
  };

  return {
    uploadFile,
    deleteFile,
    uploading,
    error
  };
};