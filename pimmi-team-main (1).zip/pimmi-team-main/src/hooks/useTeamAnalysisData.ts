
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, subDays, startOfDay } from 'date-fns';
import { ru } from 'date-fns/locale';

export interface TeamAnalysisEmployee {
  id: string;
  name: string;
  role: string;
  department: string;
  tasks: number;
  completedTasks: number;
  points: number;
  activeHours: number;
  efficiency: number;
}

export interface SalesDynamicsData {
  date: string;
  displayDate: string;
  totalSales: number;
  totalAmount: number;
}

export interface ManagerDynamicsData {
  date: string;
  displayDate: string;
  [managerName: string]: number | string;
}

interface UseTeamAnalysisDataReturn {
  employees: TeamAnalysisEmployee[];
  loading: boolean;
  error: string | null;
  hasMinimalData: boolean;
  refetch: () => Promise<void>;
  salesDynamics: SalesDynamicsData[];
  managerDynamics: ManagerDynamicsData[];
  loadingSales: boolean;
}

// Функция для создания фиксированной структуры дат (последние 5 дней)
const createFixedDateStructure = () => {
  const dates = [];
  for (let i = 4; i >= 0; i--) {
    const date = startOfDay(subDays(new Date(), i));
    dates.push({
      date: format(date, 'yyyy-MM-dd'),
      displayDate: format(date, 'dd.MM', { locale: ru }),
      isoDate: date.toISOString()
    });
  }
  return dates;
};

export const useTeamAnalysisData = (departmentFilter?: string): UseTeamAnalysisDataReturn => {
  const [employees, setEmployees] = useState<TeamAnalysisEmployee[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingSales, setLoadingSales] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [salesDynamics, setSalesDynamics] = useState<SalesDynamicsData[]>([]);
  const [managerDynamics, setManagerDynamics] = useState<ManagerDynamicsData[]>([]);

  const fetchSalesDynamics = async () => {
    try {
      setLoadingSales(true);
      
      // Получаем фиксированную структуру дат
      const fixedDates = createFixedDateStructure();
      const startDate = fixedDates[0].date;
      const endDate = fixedDates[fixedDates.length - 1].date;

      console.log('📊 Fetching sales dynamics for dates:', startDate, 'to', endDate);

      // Получаем продажи за последние 5 дней с информацией о сотрудниках
      const { data: salesData, error: salesError } = await supabase
        .from('sales_results')
        .select(`
          id,
          sale_date,
          sale_amount,
          employee_id,
          is_extension,
          employees!employee_id(id, name, department)
        `)
        .gte('sale_date', startDate)
        .lte('sale_date', endDate)
        .eq('is_extension', false) // Исключаем продления
        .order('sale_date', { ascending: true });

      if (salesError) {
        console.error('❌ Error fetching sales data:', salesError);
        throw salesError;
      }

      console.log('📈 Sales data received:', salesData?.length || 0, 'records');

      // Применяем фильтр по отделу если задан
      let filteredSalesData = salesData || [];
      if (departmentFilter) {
        filteredSalesData = salesData?.filter(sale => 
          sale.employees?.department === departmentFilter
        ) || [];
        console.log(`🎯 Filtered by department "${departmentFilter}":`, filteredSalesData.length, 'records');
      }

      // Группируем продажи по дате для командной динамики
      const salesByDate = new Map<string, { count: number; amount: number }>();
      
      filteredSalesData.forEach(sale => {
        const dateKey = sale.sale_date;
        if (!salesByDate.has(dateKey)) {
          salesByDate.set(dateKey, { count: 0, amount: 0 });
        }
        const dayData = salesByDate.get(dateKey)!;
        dayData.count += 1;
        dayData.amount += Number(sale.sale_amount) || 0;
      });

      // Создаем данные командной динамики с фиксированными датами
      const teamSalesDynamics: SalesDynamicsData[] = fixedDates.map(dateInfo => {
        const dayData = salesByDate.get(dateInfo.date) || { count: 0, amount: 0 };
        return {
          date: dateInfo.date,
          displayDate: dateInfo.displayDate,
          totalSales: dayData.count,
          totalAmount: dayData.amount
        };
      });

      // Группируем продажи по менеджерам и датам
      const managerSalesMap = new Map<string, Map<string, number>>();
      
      filteredSalesData.forEach(sale => {
        const managerName = sale.employees?.name || 'Неизвестный';
        const dateKey = sale.sale_date;
        
        if (!managerSalesMap.has(managerName)) {
          managerSalesMap.set(managerName, new Map());
        }
        
        const managerData = managerSalesMap.get(managerName)!;
        const currentCount = managerData.get(dateKey) || 0;
        managerData.set(dateKey, currentCount + 1);
      });

      // Создаем данные динамики по менеджерам с синхронизацией дат
      const managersDynamics: ManagerDynamicsData[] = fixedDates.map(dateInfo => {
        const dayData: ManagerDynamicsData = {
          date: dateInfo.date,
          displayDate: dateInfo.displayDate
        };
        
        // Добавляем данные каждого менеджера для этого дня
        managerSalesMap.forEach((dates, managerName) => {
          dayData[managerName] = dates.get(dateInfo.date) || 0;
        });
        
        return dayData;
      });

      console.log('📊 Team sales dynamics:', teamSalesDynamics);
      console.log('👥 Manager dynamics:', managersDynamics);

      setSalesDynamics(teamSalesDynamics);
      setManagerDynamics(managersDynamics);

    } catch (err) {
      console.error('❌ Error fetching sales dynamics:', err);
      setError(err instanceof Error ? err.message : 'Ошибка при получении динамики продаж');
    } finally {
      setLoadingSales(false);
    }
  };

  const fetchTeamData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Получаем текущего пользователя и его роль
      const { data: currentUser } = await supabase.auth.getUser();
      if (!currentUser.user) {
        throw new Error('Пользователь не авторизован');
      }

      const { data: userEmployee, error: userError } = await supabase
        .from("employees")
        .select("role, department")
        .eq("user_id", currentUser.user.id)
        .single();

      if (userError) {
        throw new Error(`Ошибка при получении информации о пользователе: ${userError.message}`);
      }

      // Определяем фильтр по отделу
      let departmentToFilter = departmentFilter;
      
      // Если не передан фильтр, определяем его на основе роли пользователя
      if (!departmentToFilter && userEmployee) {
        if (userEmployee.role === 'руководитель тех отдела') {
          departmentToFilter = 'тех отдел';
        } else if (userEmployee.role === 'руководитель отдела продаж') {
          departmentToFilter = 'отдел продаж';
        } else if (userEmployee.role === 'руководитель ИИ отдела') {
          departmentToFilter = 'креатив отдел';
        }
        // Админы и другие роли увидят всех сотрудников
      }

      // Получаем данные сотрудников из представления
      let query = supabase
        .from('employee_stats_view')
        .select('*');

      // Применяем фильтр по отделу если он задан
      if (departmentToFilter) {
        query = query.eq('department', departmentToFilter);
      }

      const { data: employeeStats, error: statsError } = await query
        .order('total_points', { ascending: false });

      if (statsError) {
        throw new Error(`Ошибка при получении статистики сотрудников: ${statsError.message}`);
      }

      if (!employeeStats || employeeStats.length === 0) {
        console.log('Нет данных о сотрудниках в системе');
        setEmployees([]);
        return;
      }

      // Преобразуем данные в формат для анализа
      const transformedEmployees: TeamAnalysisEmployee[] = employeeStats.map(employee => ({
        id: employee.id || '',
        name: employee.name || 'Неизвестно',
        role: employee.position || 'Не указано',
        department: employee.department || 'Не указан',
        tasks: Number(employee.total_tasks) || 0,
        completedTasks: Number(employee.completed_tasks) || 0,
        points: Number(employee.total_points) || 0,
        activeHours: Number(employee.total_hours) || 0,
        efficiency: Number(employee.efficiency) || 0
      }));

      console.log('🔄 Получены данные сотрудников для анализа:', transformedEmployees);
      console.log(`📊 Фильтр по отделу: ${departmentToFilter || 'все отделы'}`);
      setEmployees(transformedEmployees);

    } catch (err) {
      console.error('❌ Ошибка при получении данных команды:', err);
      setError(err instanceof Error ? err.message : 'Неизвестная ошибка');
    } finally {
      setLoading(false);
    }
  };

  const refetch = async () => {
    await Promise.all([fetchTeamData(), fetchSalesDynamics()]);
  };

  useEffect(() => {
    fetchTeamData();
  }, [departmentFilter]);

  useEffect(() => {
    fetchSalesDynamics();
  }, [departmentFilter]);

  // Проверяем, достаточно ли данных для качественного анализа
  const hasMinimalData = employees.length >= 2 && 
    employees.some(emp => emp.tasks > 0 || emp.points > 0 || emp.activeHours > 0);

  return {
    employees,
    loading,
    error,
    hasMinimalData,
    refetch,
    salesDynamics,
    managerDynamics,
    loadingSales
  };
};
