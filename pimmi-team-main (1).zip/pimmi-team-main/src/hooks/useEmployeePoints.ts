import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface EmployeePoints {
  id: string;
  employee_id: string;
  total_points: number;
  updated_at: string;
}

export const useEmployeePoints = (employeeId?: string) => {
  const [points, setPoints] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPoints = async () => {
    if (!employeeId) {
      console.log('🔍 No employeeId provided, setting points to 0');
      setPoints(0);
      setLoading(false);
      setError(null);
      return;
    }

    // Validate employeeId is a proper UUID
    if (employeeId === 'NaN' || !employeeId.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
      console.error('❌ Invalid employeeId format:', employeeId);
      setPoints(0);
      setLoading(false);
      setError('Invalid employee ID format');
      return;
    }

    try {
      setLoading(true);
      console.log('🔍 Fetching points for employee:', employeeId);
      const { data, error } = await supabase
        .from('employee_points')
        .select('total_points')
        .eq('employee_id', employeeId)
        .maybeSingle(); // Use maybeSingle to handle no data gracefully

      if (error) {
        console.error('❌ Error fetching employee points:', error);
        setError(error.message);
        setPoints(0);
        return;
      }

      const points = data?.total_points || 0;
      console.log('💰 Points fetched for employee', employeeId, ':', points);
      setPoints(points);
      setError(null);
    } catch (err) {
      console.error('❌ Unexpected error fetching employee points:', err);
      setError('Failed to fetch points');
      setPoints(0);
    } finally {
      setLoading(false);
    }
  };

  const recalculatePoints = async () => {
    if (!employeeId) return;

    try {
      const { data, error } = await supabase.rpc('calculate_employee_points', {
        emp_id: employeeId
      });

      if (error) throw error;

      setPoints(data || 0);
    } catch (err) {
      console.error('Error recalculating points:', err);
      setError('Failed to recalculate points');
    }
  };

  useEffect(() => {
    fetchPoints();
  }, [employeeId]);

  // Enhanced real-time updates subscription
  useEffect(() => {
    if (!employeeId || employeeId === 'NaN' || !employeeId.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
      return;
    }

    console.log('🔔 Setting up real-time subscription for employee:', employeeId);

    const channel = supabase
      .channel(`employee-points-${employeeId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employee_points',
          filter: `employee_id=eq.${employeeId}`
        },
        (payload) => {
          console.log('💰 Employee points updated via real-time:', payload);
          if (payload.eventType === 'DELETE') {
            setPoints(0);
          } else if (payload.new && 'total_points' in payload.new) {
            setPoints(payload.new.total_points as number);
          } else {
            // Fallback to refetch
            setTimeout(() => fetchPoints(), 100);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employee_tasks',
          filter: `employee_id=eq.${employeeId}`
        },
        (payload) => {
          console.log('📋 Employee task updated, refetching points:', payload);
          // Small delay to ensure trigger has run
          setTimeout(() => fetchPoints(), 200);
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employee_achievements',
          filter: `employee_id=eq.${employeeId}`
        },
        (payload) => {
          console.log('🏆 Employee achievement updated, refetching points:', payload);
          // Small delay to ensure trigger has run
          setTimeout(() => fetchPoints(), 200);
        }
      )
      .subscribe();

    return () => {
      console.log('🔕 Cleaning up real-time subscription for employee:', employeeId);
      supabase.removeChannel(channel);
    };
  }, [employeeId]);

  return {
    points,
    loading,
    error,
    refetch: fetchPoints,
    recalculate: recalculatePoints
  };
};

export const useAllEmployeePoints = () => {
  const [pointsData, setPointsData] = useState<EmployeePoints[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAllPoints = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('employee_points')
        .select('*')
        .order('total_points', { ascending: false });

      if (error) throw error;

      setPointsData(data || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching all employee points:', err);
      setError('Failed to fetch points data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllPoints();
  }, []);

  return {
    pointsData,
    loading,
    error,
    refetch: fetchAllPoints
  };
};