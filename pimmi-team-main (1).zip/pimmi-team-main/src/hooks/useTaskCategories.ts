import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

// Обновлено: удалены все стандартные категории - v2

export interface TaskCategory {
  id: string;
  name: string;
  description?: string;
  color?: string;
  created_at: string;
}

// Удалены стандартные категории - теперь используются только пользовательские

export const useTaskCategories = () => {
  const [categories, setCategories] = useState<string[]>(() => {
    // Initialize with cached categories immediately
    const cached = localStorage.getItem('task_categories');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error('Error parsing cached categories:', e);
      }
    }
    // Пустой массив, если нет кэшированных категорий
    return [];
  });
  const [loading, setLoading] = useState(true); // Start loading immediately
  const { toast } = useToast();

  const loadCategories = async () => {
    console.log('🔄 Loading categories from database...');
    setLoading(true);
    try {
      // First get current employee ID
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) {
        console.log('❌ No authenticated user');
        setCategories([]);
        setLoading(false);
        return;
      }

      const { data: employeeData } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (!employeeData) {
        console.log('❌ No employee record found');
        setCategories([]);
        setLoading(false);
        return;
      }

      // Get global categories (employee_id IS NULL) and individual categories for current user
      const { data, error } = await supabase
        .from('task_categories')
        .select('name, description, color')
        .or(`employee_id.is.null,employee_id.eq.${employeeData.id}`)
        .order('name');

      if (error) {
        console.error('❌ Database error:', error);
        throw error;
      }

      console.log('📊 Database categories:', data);
      const categoryNames = data?.map(item => item.name) || [];
      
      console.log('✅ Final categories list:', categoryNames);
      setCategories(categoryNames);
      
      // Store in localStorage for quick access
      localStorage.setItem('task_categories', JSON.stringify(categoryNames));
      
    } catch (error) {
      console.error('❌ Error loading categories:', error);
      
      // Пустой массив при ошибке
      console.log('🔄 Using empty categories array');
      setCategories([]);
      localStorage.setItem('task_categories', JSON.stringify([]));
      
      toast({
        title: "Предупреждение",
        description: "Не удалось загрузить категории",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      console.log('✅ Categories loading completed');
    }
  };

  const addCategory = async (categoryName: string, description?: string) => {
    if (!categoryName.trim()) {
      toast({
        title: "Ошибка",
        description: "Название категории не может быть пустым",
        variant: "destructive"
      });
      return false;
    }

    const normalizedName = categoryName.trim().toLowerCase();
    
    if (categories.includes(normalizedName)) {
      toast({
        title: "Ошибка",
        description: "Такая категория уже существует",
        variant: "destructive"
      });
      return false;
    }

    try {
      // Add category to database
      const { error } = await supabase
        .from('task_categories')
        .insert({
          name: normalizedName,
          description: description || `Категория ${categoryName}`,
          color: '#6b7280'
        });

      if (error) throw error;

      // Update local state
      const newCategories = [...categories, normalizedName];
      setCategories(newCategories);
      localStorage.setItem('task_categories', JSON.stringify(newCategories));
      
      toast({
        title: "Успешно",
        description: `Категория "${categoryName}" добавлена`
      });
      
      return true;
    } catch (error) {
      console.error('Error adding category:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось добавить категорию",
        variant: "destructive"
      });
      return false;
    }
  };

  const removeCategory = async (categoryName: string) => {
    try {
      // Check if category is used in existing tasks
      const { data: tasksWithCategory } = await supabase
        .from('employee_tasks')
        .select('id')
        .eq('category', categoryName)
        .limit(1);

      if (tasksWithCategory && tasksWithCategory.length > 0) {
        toast({
          title: "Предупреждение",
          description: "Эта категория используется в существующих задачах",
          variant: "destructive"
        });
        return false;
      }

      // Remove from database
      const { error } = await supabase
        .from('task_categories')
        .delete()
        .eq('name', categoryName);

      if (error) throw error;

      // Update local state
      const newCategories = categories.filter(cat => cat !== categoryName);
      setCategories(newCategories);
      localStorage.setItem('task_categories', JSON.stringify(newCategories));
      
      toast({
        title: "Успешно",
        description: `Категория "${categoryName}" удалена`
      });
      
      return true;
    } catch (error) {
      console.error('Error removing category:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить категорию",
        variant: "destructive"
      });
      return false;
    }
  };

  const getCategoryDescription = (categoryName: string): string => {
    // Просто возвращаем название категории
    return categoryName;
  };

  const isStandardCategory = (categoryName: string): boolean => {
    // Больше нет стандартных категорий
    return false;
  };

  // Load categories on mount
  useEffect(() => {
    // Очищаем кэш стандартных категорий
    localStorage.removeItem('task_categories');
    // Always load from database first to get the most current data
    loadCategories();
  }, []);

  return {
    categories,
    loading,
    loadCategories,
    addCategory,
    removeCategory,
    getCategoryDescription,
    isStandardCategory,
    standardCategories: []
  };
};