import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface TaskAttachment {
  id: string;
  file_name: string;
  file_url: string | null;
  content_type: string;
  file_size: number;
  storage_path?: string | null;
}

export interface TaskWithAttachments {
  id: string;
  employee_id: string;
  title: string;
  description: string | null;
  priority: string | null;
  status: string | null;
  category: string | null;
  estimated_minutes: number | null;
  actual_minutes: number | null;
  due_date: string | null;
  assigned_by: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  attachment_count: number;
  attachments: TaskAttachment[] | null;
  source: 'employee_tasks' | 'project_tasks';
  task_type?: string; // для project_tasks
  // Project information (only for project_tasks)
  project_name?: string | null;
  client_name?: string | null;
  sales_result_id?: string | null;
}

const deriveStoragePath = (url?: string | null): string | null => {
  if (!url) return null;
  try {
    const patterns = [
      '/object/public/task-attachments/',
      '/object/sign/task-attachments/',
      '/object/authenticated/task-attachments/',
      '/object/task-attachments/'
    ];
    for (const p of patterns) {
      const idx = url.indexOf(p);
      if (idx !== -1) {
        return url.substring(idx + p.length);
      }
    }
    if (!url.startsWith('http')) return url;
    return null;
  } catch {
    return null;
  }
};

export const useTasksWithAttachments = (employeeId?: string) => {
  const [tasks, setTasks] = useState<TaskWithAttachments[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTasks = async () => {
    if (!employeeId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // Fetch employee tasks with attachments
      const { data: employeeTasksData, error: employeeTasksError } = await supabase
        .from('employee_tasks_with_attachments_view')
        .select('*')
        .eq('employee_id', employeeId);

      if (employeeTasksError) throw employeeTasksError;

      // Transform employee tasks
      const employeeTasksRaw = (employeeTasksData || []).map(task => ({
        ...task,
        source: 'employee_tasks' as const,
        attachments: task.attachments && Array.isArray(task.attachments) 
          ? task.attachments.filter(att => att !== null) as unknown as TaskAttachment[]
          : null
      }));

      // Generate signed URLs for attachments in the private bucket
      const employeeTasks = await Promise.all(employeeTasksRaw.map(async (t) => {
        if (!t.attachments || t.attachments.length === 0) return t;
        const newAttachments = await Promise.all(
          t.attachments.map(async (a: any) => {
            try {
              const path = a.storage_path ?? deriveStoragePath(a.file_url);
              if (path) {
                const { data, error } = await supabase.storage
                  .from('task-attachments')
                  .createSignedUrl(path, 3600);
                if (!error && data?.signedUrl) {
                  return { ...a, file_url: data.signedUrl, storage_path: path };
                }
              }
            } catch (e) {
              console.warn('Signed URL generation failed:', e);
            }
            return a;
          })
        );
        return { ...t, attachments: newAttachments };
      }));

      // Fetch project tasks for this employee with project information
      const { data: projectTasksData, error: projectTasksError } = await supabase
        .from('project_tasks')
        .select(`
          *,
          sales_results!project_tasks_sales_result_id_fkey (
            id,
            project_name,
            client_name
          )
        `)
        .eq('assignee_id', employeeId);

      if (projectTasksError) throw projectTasksError;

      // Transform project tasks to match interface
      const projectTasks = (projectTasksData || []).map(task => ({
        id: task.id,
        employee_id: employeeId, // Map assignee_id to employee_id
        title: task.task_name,
        description: task.description,
        priority: task.priority,
        status: task.status,
        category: task.category,
        estimated_minutes: task.estimated_minutes,
        actual_minutes: task.actual_minutes,
        due_date: task.due_date,
        assigned_by: null, // project_tasks don't have assigned_by
        created_at: task.created_at,
        updated_at: task.updated_at,
        completed_at: task.completed_at,
        attachment_count: 0, // project_tasks don't have attachments yet
        attachments: null,
        source: 'project_tasks' as const,
        task_type: task.task_type,
        // Project information
        project_name: task.sales_results?.project_name || null,
        client_name: task.sales_results?.client_name || null,
        sales_result_id: task.sales_results?.id || task.sales_result_id
      })) as TaskWithAttachments[];

      // Combine both arrays and sort by created_at
      const allTasks = [...employeeTasks, ...projectTasks]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      
      setTasks(allTasks);
      setError(null);
    } catch (err) {
      console.error('Error fetching tasks with attachments:', err);
      setError('Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [employeeId]);

  // Subscribe to real-time updates
  useEffect(() => {
    if (!employeeId) return;

    const channel = supabase
      .channel('tasks-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employee_tasks',
          filter: `employee_id=eq.${employeeId}`
        },
        () => {
          fetchTasks();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'project_tasks',
          filter: `assignee_id=eq.${employeeId}`
        },
        () => {
          fetchTasks();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'task_attachments'
        },
        () => {
          fetchTasks();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [employeeId]);

  return {
    tasks,
    loading,
    error,
    refetch: fetchTasks
  };
};