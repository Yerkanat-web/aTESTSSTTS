import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, 
  Settings, 
  Save, 
  RefreshCw,
  Phone,
  CheckCircle,
  AlertCircle
} from "lucide-react";

interface SalesEmployee {
  id: string;
  name: string;
  email: string;
  position: string;
  sipuni_user_id: string | null;
}

export const AdminSipuniSettings = () => {
  const [salesEmployees, setSalesEmployees] = useState<SalesEmployee[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [testingConnection, setTestingConnection] = useState(false);
  const { toast } = useToast();

  const fetchSalesEmployees = async () => {
    const { data, error } = await supabase
      .from('employees')
      .select('id, name, email, position, sipuni_user_id')
      .eq('department', 'отдел продаж')
      .eq('status', 'active');

    if (error) {
      console.error('Error fetching sales employees:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить список сотрудников",
        variant: "destructive"
      });
      return;
    }

    setSalesEmployees(data || []);
  };

  const updateSipuniUserId = async (employeeId: string, sipuniUserId: string) => {
    setSaving(employeeId);
    
    const { error } = await supabase
      .from('employees')
      .update({ sipuni_user_id: sipuniUserId || null })
      .eq('id', employeeId);

    if (error) {
      console.error('Error updating sipuni_user_id:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить настройки Sipuni",
        variant: "destructive"
      });
    } else {
      toast({
        title: "Успешно",
        description: "Настройки Sipuni обновлены",
      });
      fetchSalesEmployees();
    }
    
    setSaving(null);
  };

  const testSipuniConnection = async () => {
    setTestingConnection(true);
    try {
      const { data, error } = await supabase.functions.invoke('test-sipuni');
      
      console.log('Test Sipuni response:', { data, error });
      
      if (error) {
        console.error('Supabase function error:', error);
        toast({
          title: "❌ Ошибка вызова функции",
          description: error.message || "Не удалось вызвать функцию тестирования",
          variant: "destructive"
        });
        return;
      }

      if (!data) {
        toast({
          title: "❌ Нет ответа",
          description: "Функция не вернула данные",
          variant: "destructive"
        });
        return;
      }

      // Проверяем конфигурацию API ключа
      if (data.configured === false) {
        toast({
          title: "⚠️ API ключ не настроен",
          description: "Необходимо настроить SIPUNI_API_KEY в секретах проекта",
          variant: "destructive"
        });
        return;
      }

      // Проверяем ошибки авторизации
      if (data.error && data.error.includes('Authentication required')) {
        toast({
          title: "🔐 Требуется авторизация",
          description: "Войдите в систему как администратор",
          variant: "destructive"
        });
        return;
      }

      // Проверяем результат API теста
      if (data.success) {
        toast({
          title: "✅ Соединение успешно",
          description: "API Sipuni работает корректно",
        });
      } else {
        toast({
          title: "❌ Ошибка API Sipuni",
          description: `HTTP ${data.status}: ${data.statusText || data.message || 'Неизвестная ошибка'}`,
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('Error testing Sipuni connection:', error);
      toast({
        title: "❌ Ошибка подключения",
        description: error.message || "Не удалось протестировать соединение",
        variant: "destructive"
      });
    } finally {
      setTestingConnection(false);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchSalesEmployees();
      setLoading(false);
    };
    
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Настройки интеграции Sipuni
          </h1>
          <p className="text-muted-foreground">
            Привязка сотрудников к пользователям Sipuni
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            onClick={testSipuniConnection} 
            variant="outline" 
            size="sm"
            disabled={testingConnection}
          >
            {testingConnection ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <CheckCircle className="h-4 w-4 mr-2" />
            )}
            {testingConnection ? "Тестирование..." : "Тест соединения"}
          </Button>
          
          <Button onClick={fetchSalesEmployees} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить
          </Button>
        </div>
      </div>

      {/* Info Card */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Phone className="h-5 w-5 text-primary mt-0.5" />
            <div>
              <h3 className="font-medium text-primary">Как настроить интеграцию:</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Укажите ID пользователя или номер телефона из системы Sipuni для каждого сотрудника. 
                Это позволит получать статистику звонков только по конкретному пользователю.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employees List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Сотрудники отдела продаж ({salesEmployees.length})
          </CardTitle>
          <CardDescription>
            Настройте привязку каждого сотрудника к его аккаунту в Sipuni
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {salesEmployees.map((employee) => (
              <SipuniEmployeeCard
                key={employee.id}
                employee={employee}
                onUpdate={updateSipuniUserId}
                isSaving={saving === employee.id}
              />
            ))}

            {salesEmployees.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Сотрудники отдела продаж не найдены</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

interface SipuniEmployeeCardProps {
  employee: SalesEmployee;
  onUpdate: (employeeId: string, sipuniUserId: string) => void;
  isSaving: boolean;
}

const SipuniEmployeeCard = ({ employee, onUpdate, isSaving }: SipuniEmployeeCardProps) => {
  const [sipuniUserId, setSipuniUserId] = useState(employee.sipuni_user_id || '');

  const handleSave = () => {
    onUpdate(employee.id, sipuniUserId);
  };

  const hasChanges = sipuniUserId !== (employee.sipuni_user_id || '');

  return (
    <div className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg border border-border">
      <div className="flex items-center gap-4">
        <Avatar>
          <AvatarFallback className="bg-gradient-primary text-primary-foreground">
            {employee.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </AvatarFallback>
        </Avatar>
        
        <div>
          <h3 className="font-semibold">{employee.name}</h3>
          <p className="text-sm text-muted-foreground">{employee.position}</p>
          <p className="text-xs text-muted-foreground">{employee.email}</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Label htmlFor={`sipuni-${employee.id}`} className="text-sm font-medium whitespace-nowrap">
            Sipuni ID:
          </Label>
          <Input
            id={`sipuni-${employee.id}`}
            value={sipuniUserId}
            onChange={(e) => setSipuniUserId(e.target.value)}
            placeholder="Введите ID или номер"
            className="w-40"
          />
        </div>

        <div className="flex items-center gap-2">
          {employee.sipuni_user_id ? (
            <Badge variant="secondary" className="bg-success/20 text-success border-success/30">
              Настроено
            </Badge>
          ) : (
            <Badge variant="outline" className="text-muted-foreground">
              Не настроено
            </Badge>
          )}

          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            size="sm"
            variant={hasChanges ? "default" : "ghost"}
          >
            {isSaving ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};