
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";
import { format } from "date-fns";
import { CalendarIcon, ChevronDown } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface ProjectExtensionDialogProps {
  isOpen: boolean;
  onClose: () => void;
  project: {
    id: string;
    project_name: string | null;
    client_name: string | null;
    employee_id: string;
    work_format: string[] | null;
    project_type: string | null;
    client_type: string | null;
  } | null;
  onExtensionCreated: () => void;
}

export function ProjectExtensionDialog({
  isOpen,
  onClose,
  project,
  onExtensionCreated,
}: ProjectExtensionDialogProps) {
  const [workFormats, setWorkFormats] = useState<string[]>([]);
  const [projectName, setProjectName] = useState("");
  const [saleDate, setSaleDate] = useState<Date>(new Date());
  const [workEndDate, setWorkEndDate] = useState<Date>();
  const [saleAmount, setSaleAmount] = useState("");
  const [prepayment, setPrepayment] = useState("");
  const [remainder, setRemainder] = useState("");
  const [remainderDueDate, setRemainderDueDate] = useState<Date>();
  const [projectStatus, setProjectStatus] = useState("Еще не начали");
  const [workFormat, setWorkFormat] = useState<string[]>([]);
  const [description, setDescription] = useState("");
  const [clientType, setClientType] = useState<string>("");
  const [projectType, setProjectType] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [adminEmployeeId, setAdminEmployeeId] = useState<string | null>(null);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  // Client type options (matching database enum)
  const clientTypeOptions = [
    "Сразу купил",
    "Перешел из тестового", 
    "Единоразовая услуга"
  ];

  // Project type options
  const projectTypeOptions = [
    "Ежемесячный",
    "Разовый",
    "Тестовый"
  ];

  // Fetch admin employee ID when component mounts
  useEffect(() => {
    const fetchAdminEmployeeId = async () => {
      try {
        const { data, error } = await supabase
          .from("employees")
          .select("id")
          .eq("email", "admin@demo.kz")
          .single();

        if (error) {
          console.error("Error fetching admin employee:", error);
          toast({
            title: "Ошибка",
            description: "Не удалось найти администратора admin@demo.kz",
            variant: "destructive",
          });
          return;
        }

        setAdminEmployeeId(data.id);
      } catch (error) {
        console.error("Error fetching admin employee:", error);
      }
    };

    if (isOpen) {
      fetchAdminEmployeeId();
    }
  }, [isOpen, toast]);

  // Fetch work formats when dialog opens
  useEffect(() => {
    const fetchWorkFormats = async () => {
      try {
        const { data, error } = await supabase
          .from("sales_results")
          .select("work_format")
          .not("work_format", "is", null);

        if (error) throw error;

        // Extract unique work formats
        const allFormats = new Set<string>();
        data?.forEach(item => {
          if (item.work_format && Array.isArray(item.work_format)) {
            item.work_format.forEach(format => allFormats.add(format));
          }
        });
        setWorkFormats(Array.from(allFormats).sort());
      } catch (error) {
        console.error("Error fetching work formats:", error);
      }
    };

    if (isOpen) {
      fetchWorkFormats();
    }
  }, [isOpen]);

  // Populate form when project changes
  useEffect(() => {
    if (project) {
      setProjectName(`${project.project_name} (Продление)`);
      setSaleDate(new Date());
      setWorkEndDate(undefined);
      setSaleAmount("");
      setPrepayment("");
      setRemainder("");
      setRemainderDueDate(undefined);
      setProjectStatus("Еще не начали");
      setWorkFormat(project.work_format || []);
      setDescription(`Продление проекта "${project.project_name}"`);
      
      // Auto-set client type if original project is "Тестовый"
      if (project.project_type === "Тестовый") {
        setClientType("Перешел из тестового");
      } else {
        setClientType(project.client_type || "");
      }
      
      // Set project type for extension (can be different from original)
      setProjectType("Ежемесячный"); // Default for extensions
    }
  }, [project]);

  const handleSubmit = async () => {
    // Предотвращаем повторное сохранение
    if (isLoading) return;

    if (!project || !saleDate || !saleAmount || !projectName.trim() || !adminEmployeeId) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    const saleAmountNum = parseFloat(saleAmount);
    const prepaymentNum = prepayment ? parseFloat(prepayment) : 0;
    const remainderNum = saleAmountNum - prepaymentNum;

    if (remainderNum > 0 && !remainderDueDate) {
      toast({
        title: "Ошибка",
        description: "При наличии остатка укажите дату оплаты остатка",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Get the highest extension sequence for this project
      const { data: existingExtensions } = await supabase
        .from("sales_results")
        .select("extension_sequence")
        .eq("parent_project_id", project.id)
        .order("extension_sequence", { ascending: false })
        .limit(1);

      const nextSequence = existingExtensions && existingExtensions.length > 0 
        ? existingExtensions[0].extension_sequence + 1 
        : 1;

      // Always assign extension to admin@demo.kz employee
      const { error } = await supabase
        .from("sales_results")
        .insert(withOrg({
          employee_id: adminEmployeeId, // Use admin employee ID instead of original project employee
          project_name: projectName.trim(),
          client_name: project.client_name,
          sale_date: format(saleDate, "yyyy-MM-dd"),
          paid_until: workEndDate ? format(workEndDate, "yyyy-MM-dd") : null,
          sale_amount: saleAmountNum,
          prepayment: prepaymentNum,
          remainder: remainderNum,
          remainder_due_date: remainderNum > 0 ? format(remainderDueDate!, "yyyy-MM-dd") : null,
          project_status: projectStatus as "Еще не начали" | "Работаем" | "Закончили" | "Ждём остаток" | "Не указан" | "Завершили работу" | "Пауза",
          work_format: workFormat.length > 0 ? workFormat : null,
          description: description.trim() || null,
          is_extension: true,
          extension_sequence: nextSequence,
          parent_project_id: project.id,
          original_employee_id: project.employee_id, // Keep track of original employee
          client_type: (clientType && clientTypeOptions.includes(clientType)) ? clientType as "Сразу купил" | "Перешел из тестового" | "Единоразовая услуга" : null,
          project_type: projectType || null,
        } as any, currentOrgId));

      if (error) throw error;

      toast({
        title: "Успешно!",
        description: "Продление проекта создано и записано на admin@demo.kz",
      });

      onExtensionCreated();
      onClose();
      resetForm();
    } catch (error: any) {
      console.error("Error creating extension:", error);
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать продление проекта",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setProjectName("");
    setSaleDate(new Date());
    setWorkEndDate(undefined);
    setSaleAmount("");
    setPrepayment("");
    setRemainder("");
    setRemainderDueDate(undefined);
    setProjectStatus("Еще не начали");
    setWorkFormat([]);
    setDescription("");
    setClientType("");
    setProjectType("");
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ru-RU").format(amount) + " ₸";
  };

  const handleWorkFormatChange = (format: string, checked: boolean) => {
    if (checked) {
      setWorkFormat(prev => [...prev, format]);
    } else {
      setWorkFormat(prev => prev.filter(f => f !== format));
    }
  };

  if (!project) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Продление проекта (записывается на admin@demo.kz)</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Project name */}
          <div>
            <Label htmlFor="projectName">Название проекта *</Label>
            <Input
              id="projectName"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="Введите название проекта"
            />
          </div>

          {/* Client Type */}
          <div>
            <Label>Тип клиента</Label>
            <Select value={clientType} onValueChange={setClientType}>
              <SelectTrigger>
                <SelectValue placeholder="Выберите тип клиента" />
              </SelectTrigger>
              <SelectContent>
                {clientTypeOptions.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {project.project_type === "Тестовый" && (
              <p className="text-sm text-muted-foreground mt-1">
                Автоматически установлено "Перешел из тестового" для продления тестового проекта
              </p>
            )}
          </div>

          {/* Project Type */}
          <div>
            <Label>Тип проекта</Label>
            <Select value={projectType} onValueChange={setProjectType}>
              <SelectTrigger>
                <SelectValue placeholder="Выберите тип проекта" />
              </SelectTrigger>
              <SelectContent>
                {projectTypeOptions.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Work format */}
          <div>
            <Label>Формат работы</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-between text-left font-normal",
                    workFormat.length === 0 && "text-muted-foreground"
                  )}
                >
                  <span>
                    {workFormat.length === 0
                      ? "Выберите формат работы"
                      : workFormat.length === 1
                      ? workFormat[0]
                      : `${workFormat.length} выбрано`
                    }
                  </span>
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" align="start">
                <div className="p-4 space-y-2">
                  {workFormats.map((format) => (
                    <div key={format} className="flex items-center space-x-2">
                      <Checkbox
                        id={`format-${format}`}
                        checked={workFormat.includes(format)}
                        onCheckedChange={(checked) => 
                          handleWorkFormatChange(format, checked as boolean)
                        }
                      />
                      <Label 
                        htmlFor={`format-${format}`}
                        className="text-sm font-normal cursor-pointer"
                      >
                        {format}
                      </Label>
                    </div>
                  ))}
                  {workFormats.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      Нет доступных форматов работы
                    </p>
                  )}
                </div>
              </PopoverContent>
            </Popover>
            {workFormat.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {workFormat.map((format) => (
                  <span
                    key={format}
                    className="inline-flex items-center rounded-md bg-muted px-2 py-1 text-xs font-medium text-muted-foreground"
                  >
                    {format}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Start date */}
          <div>
            <Label>Дата продления *</Label>
            <div className="flex gap-2">
              <Input
                type="date"
                value={saleDate ? format(saleDate, "yyyy-MM-dd") : ""}
                onChange={(e) => {
                  if (e.target.value) {
                    setSaleDate(new Date(e.target.value));
                  } else {
                    setSaleDate(undefined);
                  }
                }}
                className="flex-1"
              />
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="shrink-0"
                  >
                    <CalendarIcon className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={saleDate}
                    onSelect={setSaleDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Work end date */}
          <div>
            <Label>Дата окончания работы *</Label>
            <div className="flex gap-2">
              <Input
                type="date"
                value={workEndDate ? format(workEndDate, "yyyy-MM-dd") : ""}
                onChange={(e) => {
                  if (e.target.value) {
                    setWorkEndDate(new Date(e.target.value));
                  } else {
                    setWorkEndDate(undefined);
                  }
                }}
                className="flex-1"
              />
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="shrink-0"
                  >
                    <CalendarIcon className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={workEndDate}
                    onSelect={setWorkEndDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Financial fields */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="saleAmount">Сумма продления (тенге) *</Label>
              <Input
                id="saleAmount"
                type="number"
                value={saleAmount}
                onChange={(e) => {
                  setSaleAmount(e.target.value);
                  const amount = parseFloat(e.target.value) || 0;
                  const prep = parseFloat(prepayment) || 0;
                  setRemainder((amount - prep).toString());
                }}
                placeholder="Введите сумму"
              />
            </div>

            <div>
              <Label htmlFor="prepayment">Предоплата (тенге)</Label>
              <Input
                id="prepayment"
                type="number"
                value={prepayment}
                onChange={(e) => {
                  setPrepayment(e.target.value);
                  const amount = parseFloat(saleAmount) || 0;
                  const prep = parseFloat(e.target.value) || 0;
                  setRemainder((amount - prep).toString());
                }}
                placeholder="0"
              />
            </div>
          </div>

          {/* Remainder */}
          <div>
            <Label htmlFor="remainder">Остаток (автоматически)</Label>
            <Input
              id="remainder"
              type="number"
              value={remainder}
              readOnly
              className="bg-muted"
            />
            {parseFloat(remainder) > 0 && (
              <p className="text-sm text-muted-foreground mt-1">
                К доплате: {formatCurrency(parseFloat(remainder))}
              </p>
            )}
          </div>

          {/* Remainder due date */}
          {parseFloat(remainder) > 0 && (
            <div>
              <Label>Дата оплаты остатка *</Label>
              <div className="flex gap-2">
                <Input
                  type="date"
                  value={remainderDueDate ? format(remainderDueDate, "yyyy-MM-dd") : ""}
                  onChange={(e) => {
                    if (e.target.value) {
                      setRemainderDueDate(new Date(e.target.value));
                    } else {
                      setRemainderDueDate(undefined);
                    }
                  }}
                  className="flex-1"
                />
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="icon"
                      className="shrink-0"
                    >
                      <CalendarIcon className="h-4 w-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={remainderDueDate}
                      onSelect={setRemainderDueDate}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          )}

          {/* Project status */}
          <div>
            <Label>Статус проекта</Label>
            <Select value={projectStatus} onValueChange={setProjectStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Выберите статус" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Еще не начали">Еще не начали</SelectItem>
                <SelectItem value="Работаем">Работаем</SelectItem>
                <SelectItem value="Завершили работу">Завершили работу</SelectItem>
                <SelectItem value="Пауза">Пауза</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Описание</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Дополнительная информация о продлении"
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              Отмена
            </Button>
            <Button onClick={handleSubmit} disabled={isLoading || !adminEmployeeId}>
              {isLoading ? "Создание..." : "Создать продление"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
