
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { User, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AuthHeader } from "./auth/AuthHeader";
import { LoginForm } from "./auth/LoginForm";
import { RegisterForm } from "./auth/RegisterForm";
import { logger } from "@/utils/logger";
import { useOrg } from "@/contexts/OrgContext";

interface AuthPageProps {
  onBack: () => void;
  onLogin: (role: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела', userData: any) => void;
}

export const AuthPage = ({ onBack, onLogin }: AuthPageProps) => {
  const { toast } = useToast();
  const { currentOrgId } = useOrg();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [selectedRole, setSelectedRole] = useState<'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела'>('employee');
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
    name: "",
    position: "",
    department: ""
  });
  
  const [createOrg, setCreateOrg] = useState(false);
  const [orgName, setOrgName] = useState("");
  const [orgCode, setOrgCode] = useState(""); // новый стейт

  const departments = [
    "тех отдел",
    "отдел продаж", 
    "креатив отдел",
    "отдел маркетинга"
  ];

  // Проверка существующей сессии при загрузке
  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        await handleExistingSession(session);
      }
    };
    checkSession();
  }, []);

  const handleExistingSession = async (session: any) => {
    try {
      logger.debug('Checking existing session', { userId: session.user.id });
      // Получаем данные сотрудника из базы
      const { data: employee, error } = await supabase
        .from('employees')
        .select('*')
        .eq('user_id', session.user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (employee) {
        const userData = {
          name: employee.name,
          email: employee.email,
          employeeId: employee.id,
          role: employee.role,
          department: employee.department
        };
        
        logger.debug('Found existing employee session', {
          name: employee.name,
          employeeId: employee.id,
          role: employee.role,
          department: employee.department,
          departmentNormalized: employee.department?.toLowerCase().trim()
        });
        
        onLogin(employee.role as 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела', userData);
      } else {
        // Если сотрудника нет в базе, выходим из системы
        await supabase.auth.signOut();
      }
    } catch (error) {
      logger.error('Error checking existing session', error);
      // При ошибке выходим из системы
      await supabase.auth.signOut();
    }
  };

  const handleLogin = async () => {
    if (!credentials.email || !credentials.password) {
      toast({
        title: "Ошибка",
        description: "Введите email и пароль",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      // Авторизация через Supabase
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: credentials.email,
        password: credentials.password
      });

      if (authError) throw authError;

      if (authData.user) {
        // Получаем данные сотрудника из базы
        const { data: employee, error: employeeError } = await supabase
          .from('employees')
          .select('*')
          .eq('user_id', authData.user.id)
          .maybeSingle();

        console.log('Employee query result:', { employee, employeeError, userId: authData.user.id });

        if (employeeError && employeeError.code !== 'PGRST116') {
          console.error('Employee error details:', employeeError);
          throw new Error(`Ошибка при получении данных сотрудника: ${employeeError.message}`);
        }

        // Если сотрудника нет в базе, создаем базовую запись или показываем ошибку
        if (!employee) {
          throw new Error('Ваш аккаунт не связан с сотрудником. Обратитесь к администратору.');
        }

        const userData = {
          name: employee.name,
          email: employee.email,
          employeeId: employee.id,
          role: employee.role,
          department: employee.department
        };

        logger.debug('Login successful', {
          name: employee.name,
          employeeId: employee.id,
          role: employee.role,
          department: employee.department,
          departmentNormalized: employee.department?.toLowerCase().trim()
        });

        toast({
          title: "Успешно",
          description: `Добро пожаловать, ${employee.name}!`
        });

        onLogin(employee.role as 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела', userData);
      }
    } catch (error: any) {
      logger.error('Login error', error);
      toast({
        title: "Ошибка входа",
        description: error.message || "Неверный email или пароль",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!credentials.email || !credentials.password || !credentials.name) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive"
      });
      return;
    }

    if (!createOrg && !orgCode.trim()) {
      toast({
        title: "Код организации обязателен",
        description: "Введите код организации для присоединения",
        variant: "destructive"
      });
      return;
    }

    if (selectedRole === 'employee' && (!credentials.position || !credentials.department) && !createOrg) {
      toast({
        title: "Ошибка",
        description: "Для сотрудника укажите должность и отдел",
        variant: "destructive"
      });
      return;
    }

    // Доп. проверка при создании организации
    if (createOrg && !orgName.trim()) {
      toast({
        title: "Ошибка",
        description: "Укажите название бизнеса",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      // Регистрация через Edge Function
      const { data, error } = await supabase.functions.invoke('register-user', {
        body: {
          email: credentials.email,
          password: credentials.password,
          name: credentials.name,
          position: credentials.position,
          department: credentials.department,
          role: createOrg ? 'admin' : selectedRole,
          org_id: createOrg ? undefined : (currentOrgId || undefined),
          org_code: createOrg ? undefined : orgCode.trim().toUpperCase(),
          create_org: createOrg,
          org_name: createOrg ? orgName : undefined
        }
      });

      if (error) throw error;

      if (data.success) {
        toast({
          title: "Регистрация успешна!",
          description: createOrg
            ? "Организация создана. Можете поделиться кодом организации с сотрудниками."
            : "Аккаунт создан. Можете войти в систему."
        });

        // Переключаемся на вход и заполняем email
        setMode('login');
        setCredentials({
          email: credentials.email,
          password: "",
          name: "",
          position: "",
          department: ""
        });
        setOrgName("");
        setOrgCode("");
        setCreateOrg(false);
      } else {
        throw new Error(data.error || 'Неизвестная ошибка');
      }
    } catch (error: any) {
      logger.error('Registration error', error);
      const errAny: any = error;
      const backendMsg = errAny?.context?.error || errAny?.context?.message || errAny?.message;
      let description = typeof backendMsg === 'string' ? backendMsg : 'Не удалось создать аккаунт';
      if (typeof description === 'string' && description.toLowerCase().includes('already been registered')) {
        description = 'Этот email уже зарегистрирован. Войдите или используйте другой email.';
      }
      toast({
        title: 'Ошибка регистрации',
        description,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };


  const resetForm = () => {
    setCredentials({
      email: "",
      password: "",
      name: "",
      position: "",
      department: ""
    });
    setSelectedRole('employee');
    setOrgName("");
    setOrgCode("");
    setCreateOrg(false);
  };

  const handleModeChange = (newMode: 'login' | 'register') => {
    setMode(newMode);
    resetForm();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-blue/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <AuthHeader mode={mode} onBack={onBack} />

        {/* Auth Form */}
        <Card className="shadow-elegant border border-border/50">
          <CardHeader>
            <div className="flex justify-center">
              <Tabs value={mode} onValueChange={(value) => handleModeChange(value as 'login' | 'register')} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Вход
                  </TabsTrigger>
                  <TabsTrigger value="register" className="flex items-center gap-2">
                    <UserPlus className="h-4 w-4" />
                    Регистрация
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          
          <CardContent>
            <Tabs value={mode} className="w-full">
              {/* Вход */}
              <TabsContent value="login" className="space-y-4 mt-0">
                <LoginForm
                  credentials={credentials}
                  showPassword={showPassword}
                  isLoading={isLoading}
                  onCredentialsChange={setCredentials}
                  onShowPasswordToggle={() => setShowPassword(!showPassword)}
                  onSubmit={handleLogin}
                />
              </TabsContent>

              {/* Регистрация */}
              <TabsContent value="register" className="space-y-4 mt-0">
                <RegisterForm
                  credentials={credentials}
                  selectedRole={selectedRole}
                  showPassword={showPassword}
                  isLoading={isLoading}
                  departments={departments}
                  createOrg={createOrg}
                  orgName={orgName}
                  orgCode={orgCode}
                  onCredentialsChange={setCredentials}
                  onRoleChange={setSelectedRole}
                  onShowPasswordToggle={() => setShowPassword(!showPassword)}
                  onCreateOrgChange={setCreateOrg}
                  onOrgNameChange={setOrgName}
                  onOrgCodeChange={setOrgCode}
                  onSubmit={handleRegister}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

      </div>
    </div>
  );
};
