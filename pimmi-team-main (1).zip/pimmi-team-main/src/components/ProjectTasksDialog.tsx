import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Edit, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useOrg } from "@/contexts/OrgContext";

interface ProjectTask {
  id: string;
  task_name: string;
  task_type: string;
  status: string | null;
  due_date: string | null;
  assignee_name: string;
  assignee_id: string | null;
  created_at: string;
}

interface ProjectTasksDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  projectId: string;
  projectName: string;
}

export const ProjectTasksDialog = ({ 
  isOpen, 
  onOpenChange, 
  projectId, 
  projectName 
}: ProjectTasksDialogProps) => {
  const [tasks, setTasks] = useState<ProjectTask[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editingDate, setEditingDate] = useState<Date | undefined>(undefined);
  const [updatingTaskId, setUpdatingTaskId] = useState<string | null>(null);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  useEffect(() => {
    if (isOpen && projectId) {
      fetchProjectTasks();
    }
  }, [isOpen, projectId]);

  const fetchProjectTasks = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('project_tasks')
        .select(`
          id,
          task_name,
          task_type,
          status,
          due_date,
          assignee_id,
          created_at,
          employees:assignee_id (
            name
          )
        `)
        .eq('sales_result_id', projectId)
        .order('created_at', { ascending: false });

      if (currentOrgId) {
        query = query.eq('org_id', currentOrgId);
      }

      const { data, error } = await query;

      if (error) throw error;

      const formattedTasks = data?.map(task => ({
        ...task,
        assignee_name: task.employees?.name || "Не назначен"
      })) || [];

      setTasks(formattedTasks);
    } catch (error) {
      console.error('Error fetching project tasks:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить задачи проекта",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateTaskDeadline = async (taskId: string, newDate: Date | null) => {
    setUpdatingTaskId(taskId);
    try {
      const { error } = await supabase
        .from('project_tasks')
        .update({ 
          due_date: newDate ? format(newDate, 'yyyy-MM-dd') : null 
        })
        .eq('id', taskId);

      if (error) throw error;

      // Обновляем локальное состояние
      setTasks(prevTasks => 
        prevTasks.map(task => 
          task.id === taskId 
            ? { ...task, due_date: newDate ? format(newDate, 'yyyy-MM-dd') : null }
            : task
        )
      );

      toast({
        title: "Успешно",
        description: "Дедлайн обновлен",
      });
    } catch (error) {
      console.error('Error updating task deadline:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить дедлайн",
        variant: "destructive",
      });
    } finally {
      setUpdatingTaskId(null);
      setEditingTaskId(null);
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Не установлен";
    const date = new Date(dateString);
    return format(date, "dd.MM.yyyy", { locale: ru });
  };

  const getStatusVariant = (status: string | null) => {
    switch (status) {
      case 'completed':
        return 'default' as const;
      case 'in_progress':
        return 'secondary' as const;
      case 'pending':
        return 'outline' as const;
      default:
        return 'outline' as const;
    }
  };

  const getStatusText = (status: string | null) => {
    switch (status) {
      case 'completed':
        return 'Завершена';
      case 'in_progress':
        return 'В работе';
      case 'pending':
        return 'Ожидает';
      default:
        return 'Не указан';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Задачи проекта: {projectName}
          </DialogTitle>
        </DialogHeader>
        
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Название задачи</TableHead>
                  <TableHead>Тип задачи</TableHead>
                  <TableHead>Исполнитель</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead className="w-48">Дедлайн</TableHead>
                  <TableHead>Создана</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tasks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      Задачи для этого проекта не найдены
                    </TableCell>
                  </TableRow>
                ) : (
                  tasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">
                        {task.task_name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {task.task_type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {task.assignee_name}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusVariant(task.status)}>
                          {getStatusText(task.status)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "text-sm",
                            task.due_date && new Date(task.due_date) < new Date() 
                              ? "text-destructive font-medium" 
                              : "text-muted-foreground"
                          )}>
                            {formatDate(task.due_date)}
                          </span>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 p-0"
                                onClick={() => {
                                  setEditingTaskId(task.id);
                                  setEditingDate(task.due_date ? new Date(task.due_date) : undefined);
                                }}
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={editingTaskId === task.id ? editingDate : undefined}
                                onSelect={(date) => {
                                  setEditingDate(date);
                                  updateTaskDeadline(task.id, date || null);
                                }}
                                initialFocus
                                className="p-3 pointer-events-auto"
                                locale={ru}
                              />
                            </PopoverContent>
                          </Popover>
                          {updatingTaskId === task.id && (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {formatDate(task.created_at)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};