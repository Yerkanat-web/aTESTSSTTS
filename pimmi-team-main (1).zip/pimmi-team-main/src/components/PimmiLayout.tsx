import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  LayoutDashboard, 
  CheckSquare, 
  Trophy, 
  ShoppingBag, 
  User, 
  LogOut,
  Zap,
  Brain,
  RefreshCw
} from "lucide-react";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { logger } from "@/utils/logger";
import { useOrg } from "@/contexts/OrgContext";
 
interface PimmiLayoutProps {
  children: ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
  user: {
    name: string;
    points?: number;
    employeeId?: string;
    role: 'admin' | 'employee' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
  };
  onLogout?: () => void;
}

export const PimmiLayout = ({ children, currentPage, onPageChange, user, onLogout }: PimmiLayoutProps) => {
  // Get real points from database
  const { points: realPoints, loading: pointsLoading, refetch: refetchPoints } = useEmployeePoints(user.employeeId);
  const { currentOrg } = useOrg();

  const handleRefreshPoints = async () => {
    await refetchPoints();
  };
  
  logger.debug('PimmiLayout rendered', { employeeId: user.employeeId, points: realPoints, loading: pointsLoading });
  

  const navigation = [
    { id: 'dashboard', label: 'Дашборд', icon: LayoutDashboard },
    { id: 'project-tasks', label: 'Задачи', icon: CheckSquare },
    { id: 'tasks', label: 'Сделанные работы', icon: CheckSquare },
    { id: 'achievements', label: 'Достижения', icon: Trophy },
    { id: 'shop', label: 'Магазин', icon: ShoppingBag },
    ...(user.role === 'admin' ? [{ id: 'ai-analysis', label: 'ИИ Анализ', icon: Brain }] : [])
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-primary p-2 rounded-lg shadow-glow">
                <Zap className="h-6 w-6 text-primary-foreground" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                Pimmi Team
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground font-semibold px-3 py-1">
                  {pointsLoading ? '...' : realPoints || 0} баллов
                </Badge>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleRefreshPoints}
                  disabled={pointsLoading}
                  className="h-8 w-8 p-0 hover:bg-secondary"
                >
                  <RefreshCw className={`h-4 w-4 ${pointsLoading ? 'animate-spin' : ''}`} />
                </Button>
</div>
<div className="hidden sm:block">
  <Badge variant="outline" className="text-xs">{currentOrg?.name || 'Main Company'}</Badge>
</div>

<div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">{user.name}</span>
                {user.role === 'admin' && (
                  <Badge variant="outline" className="text-xs">Админ</Badge>
                )}
              </div>
              
              <Button variant="ghost" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <aside className="w-full lg:w-64 space-y-2">
            <div className="bg-card rounded-lg p-4 shadow-card border border-border">
              <nav className="space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.id}
                      variant={currentPage === item.id ? "default" : "ghost"}
                      className={`w-full justify-start ${
                        currentPage === item.id 
                          ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                          : "hover:bg-secondary"
                      }`}
                      onClick={() => onPageChange(item.id)}
                    >
                      <Icon className="h-4 w-4 mr-3" />
                      {item.label}
                    </Button>
                  );
                })}
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};