import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Target, Zap, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEmployeeStats } from "@/hooks/useEmployeeStats";
import { useAchievements, type AchievementRule } from "@/hooks/useAchievements";
import { supabase } from "@/integrations/supabase/client";
import { logger } from "@/utils/logger";
import { useOrg } from "@/contexts/OrgContext";

// Achievement medal images
import medalGold from "@/assets/achievements/medal-gold.jpg";
import medalSilver from "@/assets/achievements/medal-silver.jpg";
import medalBronze from "@/assets/achievements/medal-bronze.jpg";
import medalLegendary from "@/assets/achievements/medal-legendary.jpg";

interface AchievementDisplayProps {
  employeeId?: string;
}

export const AchievementsPage = ({ employeeId }: AchievementDisplayProps) => {
  const { currentOrg, currentOrgId } = useOrg();
  logger.debug('AchievementsPage rendered', { employeeId, currentOrgId }, { component: 'AchievementsPage' });
  
  const { stats: employeeStats } = useEmployeeStats(employeeId);
  const { achievements, loading, rules, checkAchievements, checkAllEmployeesAchievements, getAchievementProgress } = useAchievements(employeeId);
  const [isChecking, setIsChecking] = useState(false);
  const [isCheckingAll, setIsCheckingAll] = useState(false);
  const [realProgress, setRealProgress] = useState<Record<string, number>>({});

  logger.debug('AchievementsPage data state', {
    employeeStats,
    achievements,
    achievementsLength: achievements?.length,
    rulesLength: rules?.length,
    loading
  }, { component: 'AchievementsPage' });

  const getMedalImage = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return medalLegendary;
      case 'epic': return medalGold;
      case 'rare': return medalSilver;
      default: return medalBronze;
    }
  };

  const handleCheckAchievements = async () => {
    setIsChecking(true);
    await checkAchievements();
    setIsChecking(false);
  };

  const handleCheckAllEmployees = async () => {
    setIsCheckingAll(true);
    await checkAllEmployeesAchievements();
    setIsCheckingAll(false);
  };

  // Функция для загрузки реального прогресса категориальных задач
  const fetchRealProgress = async () => {
    if (!employeeId) return;

    try {
      // Получаем все завершенные задачи пользователя
      const { data: allTasks } = await supabase
        .from('employee_tasks')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'completed')
        .order('completed_at', { ascending: true });

      if (!allTasks) return;

      const progressMap: Record<string, number> = {};

      // Рассчитываем реальный прогресс для каждого правила
      for (const rule of rules) {
        if (rule.condition_type === 'category_tasks' && rule.condition_data?.priority) {
          const categoryTasks = allTasks.filter(task => task.priority === rule.condition_data.priority);
          progressMap[rule.id] = Math.min(categoryTasks.length, rule.condition_value);
          console.log(`Real progress for ${rule.name}: ${categoryTasks.length}/${rule.condition_value} (${rule.condition_data.priority} tasks)`);
        }
      }

      setRealProgress(progressMap);
      console.log('Real progress loaded:', progressMap);
    } catch (error) {
      console.error('Error fetching real progress:', error);
    }
  };

  // useEffect для загрузки реального прогресса
  useEffect(() => {
    fetchRealProgress();
  }, [employeeId, achievements]);

  // Получаем реальный прогресс для категориальных задач
  const getRealProgress = (rule: AchievementRule, stats: any) => {
    switch (rule.condition_type) {
      case 'task_count':
        return Math.min(stats.completed_tasks || 0, rule.condition_value);
      case 'points_total':
        return Math.min(stats.total_points || 0, rule.condition_value);
      case 'category_tasks':
        // Используем реальные данные, если они загружены
        return realProgress[rule.id] ?? 0;
      case 'task_streak':
        // Для последовательности задач пока возвращаем 0
        return 0;
      default:
        return 0;
    }
  };

  // Объединяем полученные достижения с правилами
  const allAchievements = rules.map(rule => {
    const earned = achievements.find(a => a.achievement_name === rule.name);
    const progress = employeeStats ? getRealProgress(rule, employeeStats) : 0;
    
    return {
      ...rule,
      earned: !!earned,
      progress,
      maxProgress: rule.condition_value,
      earnedAt: earned?.earned_at,
      medalImage: getMedalImage(rule.rarity)
    };
  });

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-muted text-muted-foreground border-muted';
      case 'rare': return 'bg-blue/10 text-blue border-blue/20';
      case 'epic': return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
      case 'legendary': return 'bg-gradient-gold text-gold-foreground border-warning/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getRarityLabel = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'Обычное';
      case 'rare': return 'Редкое';
      case 'epic': return 'Эпическое';
      case 'legendary': return 'Легендарное';
      default: return rarity;
    }
  };

  const earnedAchievements = allAchievements.filter(a => a.earned);
  const totalAchievementPoints = earnedAchievements.reduce((sum, a) => sum + a.points, 0);
  const rareAchievements = earnedAchievements.filter(a => 
    a.rarity === 'rare' || a.rarity === 'epic' || a.rarity === 'legendary'
  );
  const completionPercentage = allAchievements.length > 0 ? (earnedAchievements.length / allAchievements.length) * 100 : 0;

  logger.debug('Achievement statistics calculated', {
    allAchievements: allAchievements.length,
    earnedAchievements: earnedAchievements.length,
    totalAchievementPoints,
    rareAchievements: rareAchievements.length,
    completionPercentage
  });

if (loading) {
  return (
    <div className="space-y-6">
      <div className="text-center py-8">
        <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
        <p className="text-muted-foreground">Загружаем достижения...</p>
      </div>
    </div>
  );
}

// Пустое состояние при отсутствии правил
if (rules.length === 0) {
  return (
    <div className="space-y-6">
      <div className="text-center py-8 text-muted-foreground">
        Для текущей организации нет активных шаблонов общих достижений.
      </div>
    </div>
  );
}

// Добавляем отладочную информацию, если данных нет
if (!employeeId) {
  return (
    <div className="space-y-6">
      <div className="text-center py-8">
        <p className="text-muted-foreground">❌ Employee ID не передан</p>
      </div>
    </div>
  );
}

  return (
    <div className="space-y-6">
      {/* Header */}
<div className="flex items-center justify-between">
  <div>
    <h2 className="text-3xl font-bold">Достижения</h2>
    <p className="text-muted-foreground mt-1">Отслеживайте свой прогресс и получайте награды</p>
  </div>
  <div className="flex items-center gap-2">
    {currentOrg && (
      <Badge variant="outline" className="text-xs">Организация: {currentOrg.name}</Badge>
    )}
    <Button onClick={handleCheckAchievements} disabled={isChecking || !employeeId} variant="outline">
      <RefreshCw className={`h-4 w-4 mr-2 ${isChecking ? 'animate-spin' : ''}`} />
      Проверить достижения
    </Button>
  </div>
</div>


      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-primary/10 to-blue/10 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Получено</p>
                <p className="text-2xl font-bold">{earnedAchievements.length}/{allAchievements.length}</p>
                <p className="text-xs text-muted-foreground">из {rules.length} правил</p>
              </div>
              <Trophy className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-success/10 to-green/10 border-success/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Прогресс</p>
                <p className="text-2xl font-bold">{completionPercentage.toFixed(0)}%</p>
              </div>
              <Target className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-warning/10 to-gold/10 border-warning/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Баллы за достижения</p>
                <p className="text-2xl font-bold">{totalAchievementPoints}</p>
              </div>
              <Zap className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500/10 to-primary/10 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Редких достижений</p>
                <p className="text-2xl font-bold">{rareAchievements.length}</p>
              </div>
              <Star className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Overview */}
      <Card className="shadow-card border border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Общий прогресс
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Завершено достижений</span>
              <span>{earnedAchievements.length} из {allAchievements.length}</span>
            </div>
            <Progress value={completionPercentage} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {allAchievements.map((achievement) => (
          <Card 
            key={achievement.id} 
            className={`shadow-card border transition-all duration-200 overflow-hidden ${
              achievement.earned 
                ? "bg-gradient-to-br from-warning/5 to-gold/5 border-warning/30 shadow-lg" 
                : "hover:shadow-lg hover:scale-105"
            }`}
          >
            <div className="relative">
              <div className="h-32 overflow-hidden bg-gradient-to-br from-slate-900 to-slate-700">
                <img 
                  src={achievement.medalImage} 
                  alt={achievement.name}
                  className={`w-full h-full object-contain p-4 transition-all duration-200 ${
                    achievement.earned ? 'scale-110 brightness-110' : 'grayscale opacity-60'
                  }`}
                />
                {achievement.earned && (
                  <div className="absolute inset-0 bg-gradient-to-t from-gold/20 to-transparent" />
                )}
              </div>
              <div className="absolute top-2 right-2">
                <Badge className={getRarityColor(achievement.rarity)}>
                  {getRarityLabel(achievement.rarity)}
                </Badge>
              </div>
              {achievement.earned && (
                <div className="absolute top-2 left-2">
                  <Badge variant="secondary" className="bg-success/90 text-success-foreground">
                    ✓ Получено
                  </Badge>
                </div>
              )}
            </div>
            
            <CardHeader className="pb-3">
              <CardTitle className={`text-lg text-center ${achievement.earned ? 'text-foreground' : 'text-muted-foreground'}`}>
                {achievement.name}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{achievement.description}</p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Прогресс</span>
                  <span>{achievement.progress}/{achievement.maxProgress}</span>
                </div>
                <Progress 
                  value={(achievement.progress / achievement.maxProgress) * 100} 
                  className="h-2"
                />
              </div>
              
              <div className="flex items-center justify-between pt-2 border-t border-border">
                <Badge variant="outline" className="text-xs">
                  {achievement.category}
                </Badge>
                <div className="flex items-center space-x-1">
                  <Zap className="h-3 w-3 text-warning" />
                  <span className="text-sm font-medium">{achievement.points} баллов</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};