import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, CheckSquare, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { 
  getAlmatyDateString, 
  parseAlmatyDate, 
  isSaturdayInAlmaty, 
  isSundayInAlmaty,
  addDaysInAlmaty,
  formatInAlmaty 
} from "@/utils/timeHelpers";

interface ProjectData {
  id: string;
  project_name: string | null;
  work_format: string[] | null;
  client_name: string | null;
  sale_date: string;
  client_type: string | null;
  project_type: string | null;
}

interface Employee {
  id: string;
  name: string;
  position: string;
}

interface AssignmentData {
  targetologist?: string;
  dojimEngineer?: string;
  creativeManager?: string;
  siteSpecialist?: string;
  aiEngineer?: string;
  crmIntegrator?: string;
  consultant?: string;
}

interface ProjectAssignmentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  project: ProjectData | null;
  onSuccess: () => void;
}

// Задачи для других форматов (дедлайн ставит админ)
const OTHER_TASK_TEMPLATES = {
  'видео': [
    { name: 'Создание видео', type: 'video_production' }
  ],
  'сайт': [
    { name: 'Разработка дизайна сайта', type: 'design' },
    { name: 'Верстка и разработка', type: 'development' },
    { name: 'Тестирование и запуск', type: 'testing' }
  ],
  'crm': [
    { name: 'Настройка CRM-системы', type: 'crm_setup' },
    { name: 'Интеграция с внешними сервисами', type: 'integration' },
    { name: 'Обучение пользователей', type: 'training' }
  ],
  'консультация': [
    { name: 'Первичная консультация', type: 'consultation' },
    { name: 'Разработка стратегии', type: 'strategy' },
    { name: 'Финальные рекомендации', type: 'recommendations' }
  ]
};

export const ProjectAssignmentDialog = ({
  isOpen,
  onClose,
  project,
  onSuccess
}: ProjectAssignmentDialogProps) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [assignments, setAssignments] = useState<AssignmentData>({});
  const [dueDate, setDueDate] = useState<Date>();
  const [formatDueDates, setFormatDueDates] = useState<Record<string, Date>>({});
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  // Mapping of roles to specific employee IDs
  const roleEmployeeMapping = {
    targetologist: ['f899bac0-1d6c-4dee-a5ae-15fb40147cdc', '57314bec-4750-40f0-b224-7c83631f5c3a', '3fb7ca99-eaa6-4cda-887f-4aa447c4b758'], // Amirbek, Нурдаулет, Муха
    dojimEngineer: ['f464cede-cfc8-466b-9c1b-e2ccdb4f0843'], // Нуржан
    creativeManager: ['60338059-0cb0-4a2e-a8b9-fa790bef21e6'], // Балнур
    siteSpecialist: ['a8a57ace-6adb-4419-8bcf-daae8eb07864'], // Anet
    aiEngineer: ['a8a57ace-6adb-4419-8bcf-daae8eb07864'], // Anet
    crmIntegrator: ['f464cede-cfc8-466b-9c1b-e2ccdb4f0843'], // Нуржан
    consultant: [] // Пока не назначен
  };

  const getEmployeesForRole = (roleKey: string) => {
    const allowedIds = roleEmployeeMapping[roleKey as keyof typeof roleEmployeeMapping];
    return employees.filter(emp => allowedIds.includes(emp.id));
  };

  useEffect(() => {
    if (isOpen) {
      fetchEmployees();
      // Set default due date to 2 weeks from now
      const defaultDate = new Date();
      defaultDate.setDate(defaultDate.getDate() + 14);
      setDueDate(defaultDate);
    }
  }, [isOpen]);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('employees')
        .select('id, name, position')
        .eq('status', 'active')
        .order('name');

      if (error) throw error;
      setEmployees(data || []);
    } catch (error) {
      console.error('Error fetching employees:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить список сотрудников",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getRequiredRoles = () => {
    if (!project?.work_format) return [];
    
    const roles = [];
    const workFormats = project.work_format.map(format => format.toLowerCase());
    
    if (workFormats.some(f => f.includes('таргет'))) {
      roles.push({ key: 'targetologist', label: 'Таргетолог' });
    }
    if (workFormats.some(f => f.includes('дожим') || f.includes('чатбот'))) {
      roles.push({ key: 'dojimEngineer', label: 'Дожим инженер' });
    }
    if (workFormats.some(f => f.includes('видео'))) {
      roles.push({ key: 'creativeManager', label: 'Креатив менеджер' });
    }
    if (workFormats.some(f => f.includes('сайт'))) {
      roles.push({ key: 'siteSpecialist', label: 'Сайт специалист' });
    }
    if (workFormats.some(f => f.includes('ии продажник'))) {
      roles.push({ key: 'aiEngineer', label: 'ИИ инженер' });
    }
    if (workFormats.some(f => f.includes('crm'))) {
      roles.push({ key: 'crmIntegrator', label: 'CRM интегратор' });
    }
    if (workFormats.some(f => f.includes('консультация'))) {
      roles.push({ key: 'consultant', label: 'Консультант' });
    }
    
    return roles;
  };

  const getManualDueDateFormats = () => {
    if (!project?.work_format) return [];
    const workFormats = project.work_format.map(format => format.toLowerCase());
    const manualFormats = [];
    
    if (workFormats.some(f => f.includes('видео'))) {
      manualFormats.push({ key: 'видео', label: 'Видео' });
    }
    if (workFormats.some(f => f.includes('сайт'))) {
      manualFormats.push({ key: 'сайт', label: 'Сайт' });
    }
    if (workFormats.some(f => f.includes('crm'))) {
      manualFormats.push({ key: 'crm', label: 'CRM' });
    }
    if (workFormats.some(f => f.includes('консультация'))) {
      manualFormats.push({ key: 'консультация', label: 'Консультация' });
    }
    
    return manualFormats;
  };

  const requiresManualDueDate = () => {
    return getManualDueDateFormats().length > 0;
  };

  const generateTasks = async () => {
    if (!project) {
      toast({
        title: "Ошибка",
        description: "Проект не найден",
        variant: "destructive",
      });
      return;
    }

    try {
      setGenerating(true);
      
      const tasksToCreate = [];
      const workFormats = project.work_format?.map(format => format.toLowerCase()) || [];
      const startDate = parseAlmatyDate(project.sale_date + 'T00:00:00');
      
  // Функция для расчета даты с добавлением дней и переносом с воскресенья (GMT+5)
  const addDaysSkipSunday = (date: Date, days: number) => {
    // Если дата продажи попадает на субботу в GMT+5, добавляем +1 день к подготовке
    const extraDay = isSaturdayInAlmaty(date) ? 1 : 0;
    const resultDate = addDaysInAlmaty(date, days + extraDay);
    
    // Если итоговый день приходится на воскресенье в GMT+5, переносим на понедельник
    if (isSundayInAlmaty(resultDate)) {
      return addDaysInAlmaty(resultDate, 1);
    }
    
    return resultDate;
  };

  // Функция для генерации интервалов отчетов по таргету
  const getTargetReportIntervals = (clientType: string | null, projectType: string | null) => {
    if (projectType === "Тестовый") {
      // Для тестовых: подготовка 3 дня + отчеты через 3-3-4
      return [
        { name: 'Кабинет', type: 'cabinet', daysOffset: 1 },
        { name: 'Крео', type: 'creative', daysOffset: 2 },
        { name: 'Запуск таргета', type: 'launch', daysOffset: 3 },
        { name: 'Таргет отчёт 1', type: 'report_1', daysOffset: 6 }, // 3 подготовка + 3
        { name: 'Таргет отчёт 2', type: 'report_2', daysOffset: 9 }, // 6 + 3
        { name: 'Таргет отчёт 3', type: 'report_3', daysOffset: 13 }, // 9 + 4
      ];
    } else if (projectType === "Ежемесячный") {
      // Для ежемесячных: подготовка 3 дня + отчеты через 3-3-4-5-5-5-5
      return [
        { name: 'Кабинет', type: 'cabinet', daysOffset: 1 },
        { name: 'Крео', type: 'creative', daysOffset: 2 },
        { name: 'Запуск таргета', type: 'launch', daysOffset: 3 },
        { name: 'Таргет отчёт 1', type: 'report_1', daysOffset: 6 }, // 3 + 3
        { name: 'Таргет отчёт 2', type: 'report_2', daysOffset: 9 }, // 6 + 3
        { name: 'Таргет отчёт 3', type: 'report_3', daysOffset: 13 }, // 9 + 4
        { name: 'Таргет отчёт 4', type: 'report_4', daysOffset: 18 }, // 13 + 5
        { name: 'Таргет отчёт 5', type: 'report_5', daysOffset: 23 }, // 18 + 5
        { name: 'Таргет отчёт 6', type: 'report_6', daysOffset: 28 }, // 23 + 5
        { name: 'Таргет отчёт 7', type: 'report_7', daysOffset: 33 }, // 28 + 5
      ];
    } else {
      // Стандартная логика для остальных
      return [
        { name: 'Кабинет', type: 'cabinet', daysOffset: 1 },
        { name: 'Крео', type: 'creative', daysOffset: 2 },
        { name: 'Запуск таргета', type: 'launch', daysOffset: 3 },
        { name: 'Таргет отчёт 1', type: 'report_1', daysOffset: 5 },
        { name: 'Таргет отчёт 2', type: 'report_2', daysOffset: 10 },
        { name: 'Таргет отчёт 3', type: 'report_3', daysOffset: 15 },
        { name: 'Таргет отчёт 4', type: 'report_4', daysOffset: 20 },
      ];
    }
  };

  // Функция для генерации интервалов ИИ продажника
  const getAiSalesIntervals = (clientType: string | null, projectType: string | null) => {
    if (projectType === "Тестовый") {
      // Для тестовых: через 1-5 дней
      return [
        { name: 'ИИ отчёт 1', type: 'ai_report_1', daysOffset: 1 },
        { name: 'ИИ отчёт 2', type: 'ai_report_2', daysOffset: 6 }, // 1 + 5
      ];
    } else if (projectType === "Ежемесячный") {
      // Для ежемесячных: через 1-5-5-5-5-5-4
      return [
        { name: 'ИИ отчёт 1', type: 'ai_report_1', daysOffset: 1 },
        { name: 'ИИ отчёт 2', type: 'ai_report_2', daysOffset: 6 }, // 1 + 5
        { name: 'ИИ отчёт 3', type: 'ai_report_3', daysOffset: 11 }, // 6 + 5
        { name: 'ИИ отчёт 4', type: 'ai_report_4', daysOffset: 16 }, // 11 + 5
        { name: 'ИИ отчёт 5', type: 'ai_report_5', daysOffset: 21 }, // 16 + 5
        { name: 'ИИ отчёт 6', type: 'ai_report_6', daysOffset: 26 }, // 21 + 5
        { name: 'ИИ отчёт 7', type: 'ai_report_7', daysOffset: 30 }, // 26 + 4
      ];
    } else {
      // Стандартная логика
      return [
        { name: 'ИИ интеграция', type: 'ai_integration', daysOffset: 3 }
      ];
    }
  };

  // Функция для генерации интервалов дожим чатбота
  const getDojimIntervals = (projectType: string | null) => {
    if (projectType === "Ежемесячный") {
      // Для ежемесячных: каждые 4 дня
      return [
        { name: 'Wappi', type: 'wappi', daysOffset: 2 },
        { name: 'CRM', type: 'crm_setup', daysOffset: 3 },
        { name: 'Дожим отчёт 1', type: 'dojim_report_1', daysOffset: 4 },
        { name: 'Дожим отчёт 2', type: 'dojim_report_2', daysOffset: 8 }, // 4 + 4
        { name: 'Дожим отчёт 3', type: 'dojim_report_3', daysOffset: 12 }, // 8 + 4
        { name: 'Дожим отчёт 4', type: 'dojim_report_4', daysOffset: 16 }, // 12 + 4
        { name: 'Дожим отчёт 5', type: 'dojim_report_5', daysOffset: 20 }, // 16 + 4
        { name: 'Дожим отчёт 6', type: 'dojim_report_6', daysOffset: 24 }, // 20 + 4
      ];
    } else {
      // Стандартная логика
      return [
        { name: 'Wappi', type: 'wappi', daysOffset: 2 },
        { name: 'CRM', type: 'crm_setup', daysOffset: 3 },
        { name: 'Дожим отчёт 1', type: 'dojim_report_1', daysOffset: 5 },
        { name: 'Дожим отчёт 2', type: 'dojim_report_2', daysOffset: 10 },
        { name: 'Дожим отчёт 3', type: 'dojim_report_3', daysOffset: 15 },
        { name: 'Дожим отчёт 4', type: 'dojim_report_4', daysOffset: 20 }
      ];
    }
  };

      for (const format of workFormats) {
        if (format.includes('таргет')) {
          // Генерируем задачи для таргета с учетом типа клиента и проекта
          const targetologistId = assignments.targetologist;
          if (targetologistId) {
            const targetTasks = getTargetReportIntervals(project.client_type, project.project_type);
            targetTasks.forEach(task => {
              tasksToCreate.push({
                sales_result_id: project.id,
                task_name: task.name,
                task_type: task.type,
                assignee_id: targetologistId,
                due_date: getAlmatyDateString(addDaysSkipSunday(startDate, task.daysOffset)),
                status: 'pending'
              });
            });
          }
        }

        if (format.includes('дожим') || format.includes('чатбот')) {
          // Генерируем задачи для дожима с учетом типа проекта
          const dojimEngineerId = assignments.dojimEngineer;
          if (dojimEngineerId) {
            const dojimTasks = getDojimIntervals(project.project_type);
            dojimTasks.forEach(task => {
              tasksToCreate.push({
                sales_result_id: project.id,
                task_name: task.name,
                task_type: task.type,
                assignee_id: dojimEngineerId,
                due_date: getAlmatyDateString(addDaysSkipSunday(startDate, task.daysOffset)),
                status: 'pending'
              });
            });
          }
        }

        if (format.includes('ии продажник')) {
          // Генерируем задачи для ИИ продажника с учетом типа клиента и проекта
          const aiEngineerId = assignments.aiEngineer;
          if (aiEngineerId) {
            const aiTasks = getAiSalesIntervals(project.client_type, project.project_type);
            aiTasks.forEach(task => {
              tasksToCreate.push({
                sales_result_id: project.id,
                task_name: task.name,
                task_type: task.type,
                assignee_id: aiEngineerId,
                due_date: getAlmatyDateString(addDaysSkipSunday(startDate, task.daysOffset)),
                status: 'pending'
              });
            });
          }
        }

        // Остальные форматы - дедлайн ставит админ
        if (format.includes('видео')) {
          const formatDueDate = formatDueDates['видео'];
          if (!formatDueDate) {
            toast({
              title: "Ошибка",
              description: "Не указан срок выполнения для видео",
              variant: "destructive",
            });
            return;
          }

          const templates = OTHER_TASK_TEMPLATES['видео'];
          const assigneeId = assignments.creativeManager;
          
           templates.forEach(template => {
             tasksToCreate.push({
               sales_result_id: project.id,
               task_name: template.name,
               task_type: template.type,
               assignee_id: assigneeId,
               due_date: getAlmatyDateString(addDaysSkipSunday(formatDueDate, 0)),
               status: 'pending'
             });
           });
        }

        if (format.includes('сайт')) {
          const formatDueDate = formatDueDates['сайт'];
          if (!formatDueDate) {
            toast({
              title: "Ошибка",
              description: "Не указан срок выполнения для сайта",
              variant: "destructive",
            });
            return;
          }

          const templates = OTHER_TASK_TEMPLATES['сайт'];
          const assigneeId = assignments.siteSpecialist;
          
           templates.forEach(template => {
             tasksToCreate.push({
               sales_result_id: project.id,
               task_name: template.name,
               task_type: template.type,
               assignee_id: assigneeId,
               due_date: getAlmatyDateString(addDaysSkipSunday(formatDueDate, 0)),
               status: 'pending'
             });
           });
        }

        if (format.includes('crm')) {
          const formatDueDate = formatDueDates['crm'];
          if (!formatDueDate) {
            toast({
              title: "Ошибка",
              description: "Не указан срок выполнения для CRM",
              variant: "destructive",
            });
            return;
          }

          const templates = OTHER_TASK_TEMPLATES['crm'];
          const assigneeId = assignments.crmIntegrator;
          
           templates.forEach(template => {
             tasksToCreate.push({
               sales_result_id: project.id,
               task_name: template.name,
               task_type: template.type,
               assignee_id: assigneeId,
               due_date: getAlmatyDateString(addDaysSkipSunday(formatDueDate, 0)),
               status: 'pending'
             });
           });
        }

        if (format.includes('консультация')) {
          const formatDueDate = formatDueDates['консультация'];
          if (!formatDueDate) {
            toast({
              title: "Ошибка",
              description: "Не указан срок выполнения для консультации",
              variant: "destructive",
            });
            return;
          }

          const templates = OTHER_TASK_TEMPLATES['консультация'];
          const assigneeId = assignments.consultant;
          
           templates.forEach(template => {
             tasksToCreate.push({
               sales_result_id: project.id,
               task_name: template.name,
               task_type: template.type,
               assignee_id: assigneeId,
               due_date: getAlmatyDateString(addDaysSkipSunday(formatDueDate, 0)),
               status: 'pending'
             });
           });
        }
      }

      if (tasksToCreate.length === 0) {
        toast({
          title: "Предупреждение",
          description: "Нет задач для создания. Проверьте назначенных исполнителей.",
          variant: "destructive",
        });
        return;
      }

      // Create tasks
      const { error: tasksError } = await supabase
        .from('project_tasks')
        .insert(tasksToCreate.map((t) => withOrg(t as any, currentOrgId)));

      if (tasksError) throw tasksError;

      // Update sales_results
      const { error: updateError } = await supabase
        .from('sales_results')
        .update({
          project_status: 'Работаем',
          tasks_generated: true
        })
        .eq('id', project.id);

      if (updateError) throw updateError;

      toast({
        title: "Успешно",
        description: `Создано ${tasksToCreate.length} задач. Статус проекта обновлен.`,
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error generating tasks:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось создать задачи",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const requiredRoles = getRequiredRoles();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="text-sm text-muted-foreground">
            Проект: {project?.project_name || "Без названия"} • Клиент: {project?.client_name || "Не указан"}
          </div>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid gap-4">
              <div className="text-sm font-medium">
                Форматы работы: {project?.work_format?.join(", ") || "Не указано"}
              </div>
              
              {requiredRoles.map((role) => {
                const availableEmployees = getEmployeesForRole(role.key);
                return (
                  <div key={role.key} className="space-y-2">
                    <Label htmlFor={role.key}>{role.label}</Label>
                    <Select
                      value={assignments[role.key as keyof AssignmentData] || ""}
                      onValueChange={(value) => 
                        setAssignments(prev => ({ ...prev, [role.key]: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={`Выберите ${role.label.toLowerCase()}`} />
                      </SelectTrigger>
                       <SelectContent>
                         {availableEmployees.length > 0 ? (
                           availableEmployees.filter(employee => employee.id && employee.id.trim() !== '').map((employee) => (
                             <SelectItem key={employee.id} value={employee.id}>
                               {employee.name} ({employee.position})
                             </SelectItem>
                           ))
                         ) : (
                           <div className="p-2 text-sm text-muted-foreground">
                             Нет доступных специалистов
                           </div>
                         )}
                       </SelectContent>
                    </Select>
                  </div>
                );
               })}

              {getManualDueDateFormats().map((formatInfo) => (
                <div key={formatInfo.key} className="space-y-2">
                  <Label>Срок выполнения для {formatInfo.label}</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formatDueDates[formatInfo.key] && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formatDueDates[formatInfo.key] 
                          ? format(formatDueDates[formatInfo.key], "dd.MM.yyyy") 
                          : `Выберите дату для ${formatInfo.label.toLowerCase()}`
                        }
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={formatDueDates[formatInfo.key]}
                        onSelect={(date) => {
                          if (date) {
                            setFormatDueDates(prev => ({
                              ...prev,
                              [formatInfo.key]: date
                            }));
                          }
                        }}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              ))}
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Отмена
          </Button>
          <Button
            onClick={generateTasks}
            disabled={
              generating || 
              requiredRoles.length === 0 ||
              getManualDueDateFormats().some(format => !formatDueDates[format.key])
            }
            className="gap-2"
          >
            {generating ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <CheckSquare className="h-4 w-4" />
            )}
            Сгенерировать задачи
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
