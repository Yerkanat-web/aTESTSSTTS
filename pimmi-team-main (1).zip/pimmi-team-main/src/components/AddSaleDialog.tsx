import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { WORK_FORMATS, sanitizeWorkFormats } from "@/constants/workFormats";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";

interface AddSaleDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSaleAdded: () => void;
}

export const AddSaleDialog = ({ isOpen, onClose, onSaleAdded }: AddSaleDialogProps) => {
  const [saving, setSaving] = useState(false);
  const [salesEmployees, setSalesEmployees] = useState<{id: string, name: string}[]>([]);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  const [newSale, setNewSale] = useState({
    // Основная информация
    amount: '',
    date: new Date(),
    client: '',
    project: '',
    type: '',
    soldBy: '',
    
    // Информация о клиенте
    clientPhone: '',
    clientSource: '',
    clientType: '',
    
    // Информация о проекте  
    workFormat: [] as string[],
    
    // Финансовая информация
    prepayment: '',
    remainderDueDate: undefined as Date | undefined,
    
    // Тип проекта
    projectType: '' as 'ежемесячный' | 'тестовый' | 'единоразовый' | '',
    testEndsAt: undefined as Date | undefined
  });

  const clientSourceOptions = [
    { value: 'Сарафанка', label: 'Сарафанка' },
    { value: 'Таргет реклама', label: 'Таргет реклама' },
    { value: 'Ерқанат инста', label: 'Ерқанат инста' },
    { value: 'Ұлан', label: 'Ұлан' }
  ];

  const clientTypeOptions = [
    { value: 'Сразу купил', label: 'Сразу купил' },
    { value: 'Перешел из тестового', label: 'Перешел из тестового' },
    { value: 'Единоразовая услуга', label: 'Единоразовая услуга' }
  ];

  const workFormatOptions = WORK_FORMATS.map((v) => ({ value: v, label: v }));

  useEffect(() => {
    if (isOpen) {
      fetchSalesEmployees();
      resetForm();
    }
  }, [isOpen]);

  const resetForm = () => {
    setNewSale({
      amount: '',
      date: new Date(),
      client: '',
      project: '',
      type: '',
      soldBy: '',
      clientPhone: '',
      clientSource: '',
      clientType: '',
      workFormat: [],
      prepayment: '',
      remainderDueDate: undefined,
      projectType: '',
      testEndsAt: undefined
    });
  };

  const fetchSalesEmployees = async () => {
    try {
      let query = supabase
        .from('employees')
        .select('id, name, role, department')
        .or('department.eq.отдел продаж,role.eq.руководитель тех отдела,role.eq.admin')
        .eq('status', 'active');

      if (currentOrgId) {
        query = query.eq('org_id', currentOrgId);
      }

      const { data, error } = await query;

      if (error) throw error;
      setSalesEmployees(data || []);
    } catch (error) {
      console.error('Error fetching sales employees:', error);
    }
  };

  const handleSaveSale = async () => {
    // Предотвращаем повторное сохранение
    if (saving) return;

    // Валидация данных
    if (!newSale.amount || !newSale.client || !newSale.project || !newSale.type || !newSale.soldBy) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(newSale.amount) <= 0) {
      toast({
        title: "Ошибка",  
        description: "Сумма должна быть больше 0",
        variant: "destructive",
      });
      return;
    }

    try {
      setSaving(true);

      // Находим ID выбранного продавца
      const selectedEmployee = salesEmployees.find(emp => emp.name === newSale.soldBy);
      if (!selectedEmployee) {
        toast({
          title: "Ошибка",
          description: "Выбранный сотрудник не найден",
          variant: "destructive",
        });
        return;
      }

      const prepaymentAmount = newSale.prepayment ? parseFloat(newSale.prepayment) : 0;
      const saleAmount = parseFloat(newSale.amount);
      const remainderAmount = saleAmount - prepaymentAmount;

      const saleData = {
        employee_id: selectedEmployee.id,
        sale_amount: saleAmount,
        sale_date: newSale.date.toISOString().split('T')[0],
        client_name: newSale.client,
        project_name: newSale.project,
        description: newSale.project,
        
        // Информация о клиенте
        client_phone: newSale.clientPhone || null,
        client_source: newSale.clientSource as any || null,
        client_type: newSale.clientType as any || null,
        
        // Информация о проекте
        work_format: sanitizeWorkFormats(newSale.workFormat),
        project_type: newSale.projectType === 'ежемесячный' ? 'Ежемесячный' : 
                     newSale.projectType === 'тестовый' ? 'Тестовый' : 
                     newSale.projectType === 'единоразовый' ? 'Единоразовый' : 'Единоразовый',
        
        // Финансовая информация
        prepayment: prepaymentAmount,
        remainder: remainderAmount,
        remainder_due_date: newSale.remainderDueDate ? newSale.remainderDueDate.toISOString().split('T')[0] : null,
        paid_full: newSale.projectType === 'единоразовый' || remainderAmount <= 0,
        
        // Тестовые продажи
        is_test: newSale.projectType === 'тестовый',
        test_ends_at: newSale.testEndsAt ? newSale.testEndsAt.toISOString().split('T')[0] : null,
        
        // Данные для продлений (по умолчанию)
        is_extension: false,
        extension_sequence: 0,
        parent_project_id: null
      };

      console.log('Sale data being sent:', saleData);

      const { error } = await supabase
        .from('sales_results')
        .insert([withOrg(saleData as any, currentOrgId)])

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Продажа добавлена",
      });

      onSaleAdded();
      onClose();

    } catch (error) {
      console.error('Error saving sale:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить продажу",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Добавить продажу</DialogTitle>
          <DialogDescription>
            Создайте новую продажу в системе
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Основная информация */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Основная информация</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="amount">Сумма (тг) *</Label>
                <Input
                  id="amount"
                  type="number"
                  value={newSale.amount}
                  onChange={(e) => setNewSale({...newSale, amount: e.target.value})}
                  placeholder="100000"
                />
              </div>
              
              <div>
                <Label htmlFor="client">Клиент *</Label>
                <Input
                  id="client"
                  value={newSale.client}
                  onChange={(e) => setNewSale({...newSale, client: e.target.value})}
                  placeholder="Название компании"
                />
              </div>

              <div>
                <Label htmlFor="project">Проект *</Label>
                <Input
                  id="project"
                  value={newSale.project}
                  onChange={(e) => setNewSale({...newSale, project: e.target.value})}
                  placeholder="Описание проекта"
                />
              </div>

              <div>
                <Label htmlFor="type">Тип продажи *</Label>
                <Select value={newSale.type} onValueChange={(value) => setNewSale({...newSale, type: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите тип" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">Новый клиент</SelectItem>
                    <SelectItem value="existing">Существующий клиент</SelectItem>
                    <SelectItem value="upsell">Допродажа</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="soldBy">Кто продал *</Label>
                <Select value={newSale.soldBy} onValueChange={(value) => setNewSale({...newSale, soldBy: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите сотрудника" />
                  </SelectTrigger>
                  <SelectContent>
                    {salesEmployees.map((emp) => (
                      <SelectItem key={emp.id} value={emp.name}>
                        {emp.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Дата *</Label>
                <div className="flex gap-2">
                  <Input
                    type="date"
                    value={newSale.date ? format(newSale.date, "yyyy-MM-dd") : ""}
                    onChange={(e) => {
                      if (e.target.value) {
                        setNewSale({...newSale, date: new Date(e.target.value)});
                      }
                    }}
                    className="flex-1"
                  />
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="icon">
                        <CalendarIcon className="h-4 w-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={newSale.date}
                        onSelect={(date) => date && setNewSale({...newSale, date})}
                        initialFocus
                        className={cn("p-3 pointer-events-auto")}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>
          </div>

          {/* Информация о клиенте */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Информация о клиенте</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="clientPhone">Телефон клиента</Label>
                <Input
                  id="clientPhone"
                  value={newSale.clientPhone}
                  onChange={(e) => setNewSale({...newSale, clientPhone: e.target.value})}
                  placeholder="+7 (777) 123-45-67"
                />
              </div>

              <div>
                <Label htmlFor="clientSource">Источник клиента</Label>
                <Select value={newSale.clientSource} onValueChange={(value) => setNewSale({...newSale, clientSource: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите источник" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientSourceOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="clientType">Тип клиента</Label>
                <Select value={newSale.clientType} onValueChange={(value) => setNewSale({...newSale, clientType: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите тип клиента" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientTypeOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Информация о проекте */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Информация о проекте</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="projectType">Тип проекта</Label>
                <Select value={newSale.projectType} onValueChange={(value) => setNewSale({...newSale, projectType: value as 'ежемесячный' | 'тестовый' | 'единоразовый'})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите тип проекта" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ежемесячный">Ежемесячный</SelectItem>
                    <SelectItem value="тестовый">Тестовый</SelectItem>
                    <SelectItem value="единоразовый">Единоразовый</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {newSale.projectType === 'тестовый' && (
                <div>
                  <Label>Тест заканчивается</Label>
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={newSale.testEndsAt ? format(newSale.testEndsAt, "yyyy-MM-dd") : ""}
                      onChange={(e) => {
                        if (e.target.value) {
                          setNewSale({...newSale, testEndsAt: new Date(e.target.value)});
                        } else {
                          setNewSale({...newSale, testEndsAt: undefined});
                        }
                      }}
                      className="flex-1"
                    />
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="icon">
                          <CalendarIcon className="h-4 w-4" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={newSale.testEndsAt}
                          onSelect={(date) => setNewSale({...newSale, testEndsAt: date})}
                          initialFocus
                          className={cn("p-3 pointer-events-auto")}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label>Формат работы</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {workFormatOptions.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`work-${option.value}`}
                      checked={newSale.workFormat?.includes(option.value) || false}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setNewSale({
                            ...newSale,
                            workFormat: [...newSale.workFormat, option.value]
                          });
                        } else {
                          setNewSale({
                            ...newSale,
                            workFormat: newSale.workFormat.filter(w => w !== option.value)
                          });
                        }
                      }}
                    />
                    <Label htmlFor={`work-${option.value}`} className="text-sm">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Финансовая информация */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Финансовая информация</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="prepayment">Предоплата (тг)</Label>
                <Input
                  id="prepayment"
                  type="number"
                  value={newSale.prepayment}
                  onChange={(e) => setNewSale({...newSale, prepayment: e.target.value})}
                  placeholder="50000"
                />
              </div>

              <div>
                <Label>Дата платежа остатка</Label>
                <div className="flex gap-2">
                  <Input
                    type="date"
                    value={newSale.remainderDueDate ? format(newSale.remainderDueDate, "yyyy-MM-dd") : ""}
                    onChange={(e) => {
                      if (e.target.value) {
                        setNewSale({...newSale, remainderDueDate: new Date(e.target.value)});
                      } else {
                        setNewSale({...newSale, remainderDueDate: undefined});
                      }
                    }}
                    className="flex-1"
                  />
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="icon">
                        <CalendarIcon className="h-4 w-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={newSale.remainderDueDate}
                        onSelect={(date) => setNewSale({...newSale, remainderDueDate: date})}
                        initialFocus
                        className={cn("p-3 pointer-events-auto")}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>

            {newSale.prepayment && parseFloat(newSale.prepayment) > 0 && (
              <div className="p-3 bg-muted/30 rounded-lg">
                <p className="text-sm">
                  <strong>Остаток к доплате:</strong> {' '}
                  {newSale.amount && parseFloat(newSale.amount) > 0 
                    ? (parseFloat(newSale.amount) - parseFloat(newSale.prepayment || '0')).toLocaleString() 
                    : '0'} тг
                </p>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex justify-end space-x-2 mt-6">
          <Button variant="outline" onClick={onClose}>
            Отмена
          </Button>
          <Button onClick={handleSaveSale} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Сохранить продажу
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
