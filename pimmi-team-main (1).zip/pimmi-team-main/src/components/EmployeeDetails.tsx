import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { 
  ArrowLeft, 
  Clock, 
  Target, 
  Trophy, 
  Zap,
  BarChart3,
  User,
  Calendar,
  CalendarIcon,
  TrendingUp,
  Award,
  FileText,
  Paperclip,
  List,
  ExternalLink,
  X,
  Plus,
  Edit,
  Trash2
} from "lucide-react";
import { format, isWithinInterval, startOfDay } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useEmployeeStats } from "@/hooks/useEmployeeStats";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useTasksWithAttachments } from "@/hooks/useTasksWithAttachments";
import { formatTime } from "@/utils/timeHelpers";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";

interface Employee {
  id: string;
  name: string;
  role: string;
  totalHours: number;
  totalTasks: number;
  points: number;
  efficiency: number;
  weeklyData: Array<{ day: string; hours: number; date: string }>;
  categories: Array<{ name: string; hours: number; percentage: number }>;
  status: 'active' | 'inactive';
}

interface EmployeeTask {
  id: string;
  title: string;
  estimated_minutes: number | null;
  actual_minutes: number | null;
  category: string | null;
  priority: string | null;
  status: string | null;
  created_at: string;
  attachment?: {
    file_name: string;
    file_size: number | null;
    content_type: string | null;
  };
}

interface EmployeeDetailsProps {
  employee: Employee;
  onBack: () => void;
}

export const EmployeeDetails = ({ employee, onBack }: EmployeeDetailsProps) => {
  // Use real employee data from database
  const employeeId = employee.id;
  const { stats: realStats, loading: statsLoading } = useEmployeeStats(employeeId);
  const { points: realPoints, loading: pointsLoading } = useEmployeePoints(employeeId);
  const { tasks, loading: tasksLoading, refetch: refetchTasks } = useTasksWithAttachments(employeeId);
  const { currentOrgId } = useOrg();

  const [workTimeLogs, setWorkTimeLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState<Date | undefined>();
  const [dateTo, setDateTo] = useState<Date | undefined>();
  const [projectDateFrom, setProjectDateFrom] = useState<Date | undefined>();
  const [projectDateTo, setProjectDateTo] = useState<Date | undefined>();
  const [activeTab, setActiveTab] = useState<'completed_tasks' | 'project_tasks'>('project_tasks');
  const [projectTasks, setProjectTasks] = useState<any[]>([]);
  const [salesResults, setSalesResults] = useState<any[]>([]);
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false);
  const [isEditTaskDialogOpen, setIsEditTaskDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<any>(null);
  const [newTask, setNewTask] = useState({
    task_name: '',
    task_type: '',
    due_date: ''
  });
  const [editTask, setEditTask] = useState({
    id: '',
    task_name: '',
    task_type: '',
    due_date: '',
    priority: 'medium'
  });
  const [completedTasksSortOrder, setCompletedTasksSortOrder] = useState<'newest' | 'oldest'>('newest');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch work time logs
        const { data: workData, error: workError } = await supabase
          .from('work_time_logs')
          .select('*')
          .eq('employee_id', employeeId)
          .order('start_time', { ascending: false });

        if (workError) throw workError;
        setWorkTimeLogs(workData || []);

        // Project tasks are not needed for employee tasks functionality
        setProjectTasks([]);
        setSalesResults([]);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [employeeId]);

  // Calculate weekly data using the same logic as Dashboard
  const calculateWeeklyData = () => {
    const weekData = [];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayKey = date.toDateString();
      
      // Use the same logic as Dashboard: tasks by due_date
      const dayTasks = tasks?.filter(task => {
        if (task.status !== 'completed' || !task.due_date) return false;
        const taskDate = new Date(task.due_date);
        return taskDate.toDateString() === dayKey;
      }) || [];

      // Calculate hours from tasks with this due_date
      const dayHours = dayTasks.reduce((sum, task) => sum + ((Number(task.actual_minutes) || 0) / 60), 0);
      
      weekData.push({
        day: date.toLocaleDateString('ru-RU', { weekday: 'short' }),
        hours: Number(dayHours.toFixed(1)),
        date: date.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' })
      });
    }

    return weekData;
  };

  // Filter completed tasks by date range (only tasks with status = 'completed')
  const filteredTasks = useMemo(() => {
    if (!tasks) return [];
    
    console.log('All tasks:', tasks);
    console.log('Tasks with pending status:', tasks.filter(task => task.status === 'pending'));
    console.log('Tasks with completed status:', tasks.filter(task => task.status === 'completed'));
    
    // Filter only completed tasks
    let completedTasks = tasks.filter(task => task.status === 'completed');
    
    // Sort by completion date based on user selection
    completedTasks = completedTasks.sort((a, b) => {
      const dateA = new Date(a.completed_at || a.due_date || a.created_at);
      const dateB = new Date(b.completed_at || b.due_date || b.created_at);
      
      if (completedTasksSortOrder === 'newest') {
        return dateB.getTime() - dateA.getTime(); // Latest first
      } else {
        return dateA.getTime() - dateB.getTime(); // Oldest first
      }
    });
    
    if (!dateFrom && !dateTo) return completedTasks;

    return completedTasks.filter(task => {
      if (!task.completed_at && !task.due_date) return false;
      
      // Use completed_at if available, otherwise use due_date
      const taskDate = new Date(task.completed_at || task.due_date);
      
      if (dateFrom && dateTo) {
        return isWithinInterval(taskDate, { 
          start: startOfDay(dateFrom), 
          end: startOfDay(dateTo) 
        });
      } else if (dateFrom) {
        return taskDate >= startOfDay(dateFrom);
      } else if (dateTo) {
        return taskDate <= startOfDay(dateTo);
      }
      
      return true;
    });
  }, [tasks, dateFrom, dateTo, completedTasksSortOrder]);

  // Filter active tasks by date range
  const filteredActiveTasks = useMemo(() => {
    if (!tasks) return [];
    
    // Filter only active tasks (pending, in_progress, postponed, issues)
    const activeTasks = tasks.filter(task => 
      task.status === 'pending' || task.status === 'in_progress' || task.status === 'postponed' || task.status === 'issues'
    );
    
    console.log('Active tasks (pending/in_progress):', activeTasks);
    
    if (!projectDateFrom && !projectDateTo) return activeTasks;

    return activeTasks.filter(task => {
      if (!task.due_date && !task.created_at) return false;
      
      // Use due_date if available, otherwise use created_at
      const taskDate = new Date(task.due_date || task.created_at);
      
      if (projectDateFrom && projectDateTo) {
        return isWithinInterval(taskDate, { 
          start: startOfDay(projectDateFrom), 
          end: startOfDay(projectDateTo) 
        });
      } else if (projectDateFrom) {
        return taskDate >= startOfDay(projectDateFrom);
      } else if (projectDateTo) {
        return taskDate <= startOfDay(projectDateTo);
      }
      
      return true;
    });
  }, [tasks, projectDateFrom, projectDateTo]);

  // Filter project tasks by date range
  const filteredProjectTasks = useMemo(() => {
    if (!projectTasks) return [];
    
    let filtered = projectTasks;
    
    if (projectDateFrom || projectDateTo) {
      filtered = projectTasks.filter(task => {
        if (!task.due_date) return false;
        
        const taskDate = new Date(task.due_date);
        
        if (projectDateFrom && projectDateTo) {
          return isWithinInterval(taskDate, { 
            start: startOfDay(projectDateFrom), 
            end: startOfDay(projectDateTo) 
          });
        } else if (projectDateFrom) {
          return taskDate >= startOfDay(projectDateFrom);
        } else if (projectDateTo) {
          return taskDate <= startOfDay(projectDateTo);
        }
        
        return true;
      });
    }

    // Sort by due date - nearest dates first
    return filtered.sort((a, b) => {
      if (!a.due_date && !b.due_date) return 0;
      if (!a.due_date) return 1;
      if (!b.due_date) return -1;
      
      const dateA = new Date(a.due_date);
      const dateB = new Date(b.due_date);
      
      return dateA.getTime() - dateB.getTime();
    });
  }, [projectTasks, projectDateFrom, projectDateTo]);

  // Calculate category distribution from filtered tasks
  const calculateCategoryData = () => {
    if (!filteredTasks || filteredTasks.length === 0) return [];

    const categoryHours: Record<string, number> = {};
    
    filteredTasks.forEach(task => {
      const category = task.category || 'Общие';
      const hours = (task.actual_minutes || task.estimated_minutes || 0) / 60;
      categoryHours[category] = (categoryHours[category] || 0) + hours;
    });

    const totalHours = Object.values(categoryHours).reduce((sum, hours) => sum + hours, 0);
    
    return Object.entries(categoryHours).map(([name, hours]) => ({
      name,
      hours: Number(hours.toFixed(2)),
      percentage: totalHours > 0 ? Math.round((hours / totalHours) * 100) : 0
    }));
  };

  const weeklyData = calculateWeeklyData();
  const categories = calculateCategoryData();

  // Calculate total hours from filtered tasks
  const totalActualMinutes = filteredTasks?.reduce((sum, task) => sum + (task.actual_minutes || 0), 0) || 0;

  // Merge real data with employee prop data
  const mergedEmployee = {
    ...employee,
    points: realPoints || 0,
    totalHours: totalActualMinutes / 60 || realStats?.total_hours || 0, // Use actual hours from tasks
    totalTasks: realStats?.total_tasks || 0,
    efficiency: realStats?.efficiency || 0,
    weeklyData,
    categories
  };
  
  const categoryColors = [
    'hsl(var(--primary))',
    'hsl(var(--blue))',
    'hsl(var(--success))',
    'hsl(var(--warning))',
    'hsl(var(--info))'
  ];

  const pieData = categories.map((cat, index) => ({
    name: cat.name,
    value: cat.hours,
    percentage: cat.percentage,
    color: categoryColors[index % categoryColors.length]
  }));

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency >= 90) return "text-success";
    if (efficiency >= 80) return "text-warning";
    return "text-destructive";
  };

  const getEfficiencyBadge = (efficiency: number) => {
    if (efficiency >= 90) return "bg-success/20 text-success border-success/30";
    if (efficiency >= 80) return "bg-warning/20 text-warning border-warning/30";
    return "bg-destructive/20 text-destructive border-destructive/30";
  };

  const getPriorityColor = (priority: string | null) => {
    switch (priority?.toLowerCase()) {
      case 'hard':
        return "bg-destructive/20 text-destructive border-destructive/30";
      case 'medium':
        return "bg-warning/20 text-warning border-warning/30";
      case 'easy':
        return "bg-success/20 text-success border-success/30";
      default:
        return "bg-muted/20 text-muted-foreground border-muted/30";
    }
  };

  const getPriorityText = (priority: string | null) => {
    switch (priority?.toLowerCase()) {
      case 'hard':
        return "Сложная";
      case 'medium':
        return "Средняя";
      case 'easy':
        return "Легкая";
      default:
        return "Не указано";
    }
  };

  const getTaskStatusDisplay = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Завершена';
      case 'in_progress':
        return 'В работе';
      case 'pending':
        return 'Ожидает';
      case 'postponed':
        return 'Перенесен';
      case 'issues':
        return 'Проблемы с задачей';
      default:
        return 'Ожидает';
    }
  };

  const getTaskStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-success/20 text-success border-success/30';
      case 'in_progress':
        return 'bg-info/20 text-info border-info/30';
      case 'pending':
        return 'bg-muted/20 text-muted-foreground border-muted/30';
      case 'postponed':
        return 'bg-warning/20 text-warning border-warning/30';
      case 'issues':
        return 'bg-destructive/20 text-destructive border-destructive/30';
      default:
        return 'bg-muted/20 text-muted-foreground border-muted/30';
    }
  };

  const totalWeeklyHours = weeklyData.reduce((sum, day) => sum + day.hours, 0);
  const averageDailyHours = totalWeeklyHours / 7;

  const handleAddTask = async () => {
    if (!newTask.task_name || !newTask.task_type) {
      return;
    }

    try {
      const taskData = {
        title: newTask.task_name,
        description: `Тип: ${newTask.task_type}`,
        employee_id: employeeId,
        due_date: newTask.due_date || null,
        status: 'pending',
        priority: 'medium',
        category: newTask.task_type
      };

      const { error } = await supabase
        .from('employee_tasks')
        .insert(withOrg(taskData as any, currentOrgId));

      if (error) throw error;

      // Manually refresh task data to show new task immediately
      await refetchTasks();

      // Reset form and close dialog
      setNewTask({
        task_name: '',
        task_type: '',
        due_date: ''
      });
      setIsAddTaskDialogOpen(false);
    } catch (error) {
      console.error('Error adding task:', error);
    }
  };

  const handleEditTask = async () => {
    if (!editTask.task_name || !editTask.task_type || !editingTask) {
      return;
    }

    try {
      // Determine which table to update based on task source
      const tableName = editingTask.source === 'project_tasks' ? 'project_tasks' : 'employee_tasks';
      
      let taskData: any;
      
      if (editingTask.source === 'project_tasks') {
        taskData = {
          task_name: editTask.task_name,
          description: `Тип: ${editTask.task_type}`,
          due_date: editTask.due_date || null,
          priority: editTask.priority || 'medium',
          category: editTask.task_type,
          task_type: editTask.task_type
        };
      } else {
        taskData = {
          title: editTask.task_name,
          description: `Тип: ${editTask.task_type}`,
          due_date: editTask.due_date || null,
          priority: editTask.priority || 'medium',
          category: editTask.task_type
        };
      }

      const { error } = await supabase
        .from(tableName)
        .update(taskData)
        .eq('id', editTask.id);

      if (error) throw error;

      // Manually refresh task data to show changes immediately
      await refetchTasks();

      // Reset form and close dialog
      setEditTask({
        id: '',
        task_name: '',
        task_type: '',
        due_date: '',
        priority: 'medium'
      });
      setEditingTask(null);
      setIsEditTaskDialogOpen(false);
    } catch (error) {
      console.error('Error editing task:', error);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      // Find the task to determine which table to delete from
      const task = tasks?.find(t => t.id === taskId);
      if (!task) return;

      const tableName = task.source === 'project_tasks' ? 'project_tasks' : 'employee_tasks';
      
      const { error } = await supabase
        .from(tableName)
        .delete()
        .eq('id', taskId);

      if (error) throw error;

      // Manually refresh task data to show changes immediately
      await refetchTasks();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const handleChangeTaskStatus = async (taskId: string, newStatus: string) => {
    try {
      // Find the task to determine which table to update
      const task = tasks?.find(t => t.id === taskId);
      if (!task) return;

      const tableName = task.source === 'project_tasks' ? 'project_tasks' : 'employee_tasks';
      
      const { error } = await supabase
        .from(tableName)
        .update({ 
          status: newStatus,
          completed_at: newStatus === 'completed' ? new Date().toISOString() : null
        })
        .eq('id', taskId);

      if (error) throw error;

      // Manually refresh task data to show changes immediately
      await refetchTasks();
    } catch (error) {
      console.error('Error changing task status:', error);
    }
  };

  const openEditDialog = (task: any) => {
    setEditingTask(task);
    setEditTask({
      id: task.id,
      task_name: task.title || task.task_name,
      task_type: task.category || task.task_type,
      due_date: task.due_date || '',
      priority: task.priority || 'medium'
    });
    setIsEditTaskDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Назад к списку
          </Button>
          <div>
            <h2 className="text-3xl font-bold">{mergedEmployee.name}</h2>
            <p className="text-muted-foreground mt-1">{mergedEmployee.role}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Date filters */}
          <div className="flex items-center space-x-2">
            {/* Date From Filter */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "justify-start text-left font-normal",
                    !dateFrom && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? (
                    format(dateFrom, "d MMM", { locale: ru })
                  ) : (
                    <span>От</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={dateFrom}
                  onSelect={setDateFrom}
                  disabled={(date) =>
                    date > new Date() || date < new Date("1900-01-01")
                  }
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>

            {/* Date To Filter */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "justify-start text-left font-normal",
                    !dateTo && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? (
                    format(dateTo, "d MMM", { locale: ru })
                  ) : (
                    <span>До</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={dateTo}
                  onSelect={setDateTo}
                  disabled={(date) =>
                    date > new Date() || date < new Date("1900-01-01") || 
                    (dateFrom && date < dateFrom)
                  }
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>

            {/* Clear Filters Button */}
            {(dateFrom || dateTo) && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setDateFrom(undefined);
                  setDateTo(undefined);
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              mergedEmployee.status === 'active' ? 'bg-success' : 'bg-muted-foreground'
            }`} />
            <span className={`text-sm font-medium ${
              mergedEmployee.status === 'active' ? 'text-success' : 'text-muted-foreground'
            }`}>
              {mergedEmployee.status === 'active' ? 'Активен' : 'Неактивен'}
            </span>
          </div>
        </div>
      </div>

      {/* Employee Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="bg-gradient-to-br from-primary/10 to-blue/10 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Общие часы</p>
                <p className="text-2xl font-bold">{formatTime(totalActualMinutes)}</p>
              </div>
              <Clock className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-success/10 to-green/10 border-success/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Всего задач</p>
                <p className="text-2xl font-bold">{mergedEmployee.totalTasks}</p>
              </div>
              <Target className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-gold border-warning/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gold-foreground/80">Баллы</p>
                <p className="text-2xl font-bold text-gold-foreground">{mergedEmployee.points}</p>
              </div>
              <Zap className="h-8 w-8 text-gold-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card className={`bg-gradient-to-br ${
          mergedEmployee.efficiency >= 90 ? 'from-success/10 to-green/10 border-success/20' :
          mergedEmployee.efficiency >= 80 ? 'from-warning/10 to-gold/10 border-warning/20' :
          'from-destructive/10 to-red-500/10 border-destructive/20'
        }`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Эффективность</p>
                <p className={`text-2xl font-bold ${getEfficiencyColor(mergedEmployee.efficiency)}`}>
                  {mergedEmployee.efficiency}%
                </p>
              </div>
              <Trophy className={`h-8 w-8 ${getEfficiencyColor(mergedEmployee.efficiency)}`} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-info/10 to-blue/10 border-info/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Среднее/день</p>
                <p className="text-2xl font-bold">{averageDailyHours.toFixed(1)}ч</p>
              </div>
              <TrendingUp className="h-8 w-8 text-info" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Hours Chart */}
        <Card className="shadow-card border border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Рабочие часы за неделю
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={mergedEmployee.weeklyData}>
                <XAxis 
                  dataKey="day" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <Bar 
                  dataKey="hours" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Categories Pie Chart */}
        <Card className="shadow-card border border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Распределение по категориям
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col lg:flex-row items-center gap-4">
              <div className="w-full lg:w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      stroke="none"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full lg:w-1/2 space-y-2">
                {pieData.map((category, index) => (
                  <div key={category.name} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: category.color }}
                      />
                      <span className="text-sm font-medium">{category.name}</span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold">{category.value}ч</p>
                      <p className="text-xs text-muted-foreground">{category.percentage}%</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>



      {/* Employee Tasks Table */}
      <Card className="shadow-card border border-border">
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
             <CardTitle className="flex items-center gap-2">
               <List className="h-5 w-5 text-primary" />
               Работы сотрудника
             </CardTitle>
             <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant={activeTab === 'completed_tasks' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('completed_tasks')}
                >
                  Сделанные работы
                </Button>
                <Button
                  variant={activeTab === 'project_tasks' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('project_tasks')}
                >
                   Активные задачи
                 </Button>
                
                 {/* Фильтры для вкладки "Сделанные работы" */}
                 {activeTab === 'completed_tasks' && (
                   <div className="flex items-center space-x-2">
                     <Select value={completedTasksSortOrder} onValueChange={(value: 'newest' | 'oldest') => setCompletedTasksSortOrder(value)}>
                       <SelectTrigger className="w-[140px] h-8">
                         <SelectValue />
                       </SelectTrigger>
                       <SelectContent>
                         <SelectItem value="newest">Сначала новые</SelectItem>
                         <SelectItem value="oldest">Сначала старые</SelectItem>
                       </SelectContent>
                     </Select>
                     
                     {/* Date From Filter */}
                     <Popover>
                       <PopoverTrigger asChild>
                         <Button
                           variant="outline"
                           size="sm"
                           className={cn(
                             "justify-start text-left font-normal",
                             !dateFrom && "text-muted-foreground"
                           )}
                         >
                           <CalendarIcon className="mr-2 h-4 w-4" />
                           {dateFrom ? (
                             format(dateFrom, "d MMM", { locale: ru })
                           ) : (
                             <span>От</span>
                           )}
                         </Button>
                       </PopoverTrigger>
                       <PopoverContent className="w-auto p-0" align="start">
                         <CalendarComponent
                           mode="single"
                           selected={dateFrom}
                           onSelect={setDateFrom}
                           disabled={(date) =>
                             date < new Date("1900-01-01")
                           }
                           initialFocus
                           className="pointer-events-auto"
                         />
                       </PopoverContent>
                     </Popover>

                     {/* Date To Filter */}
                     <Popover>
                       <PopoverTrigger asChild>
                         <Button
                           variant="outline"
                           size="sm"
                           className={cn(
                             "justify-start text-left font-normal",
                             !dateTo && "text-muted-foreground"
                           )}
                         >
                           <CalendarIcon className="mr-2 h-4 w-4" />
                           {dateTo ? (
                             format(dateTo, "d MMM", { locale: ru })
                           ) : (
                             <span>До</span>
                           )}
                         </Button>
                       </PopoverTrigger>
                       <PopoverContent className="w-auto p-0" align="start">
                         <CalendarComponent
                           mode="single"
                           selected={dateTo}
                           onSelect={setDateTo}
                           disabled={(date) =>
                             date < new Date("1900-01-01") || 
                             (dateFrom && date < dateFrom)
                           }
                           initialFocus
                           className="pointer-events-auto"
                         />
                       </PopoverContent>
                     </Popover>

                     {/* Clear Filters Button */}
                     {(dateFrom || dateTo) && (
                       <Button 
                         variant="outline" 
                         size="sm"
                         onClick={() => {
                           setDateFrom(undefined);
                           setDateTo(undefined);
                         }}
                       >
                         <X className="h-4 w-4" />
                       </Button>
                     )}
                   </div>
                 )}
                
                {/* Фильтр по дате для вкладки "Задачи" */}
               {activeTab === 'project_tasks' && (
                 <>
                   <div className="flex items-center space-x-2">
                     {/* Project Date From Filter */}
                     <Popover>
                       <PopoverTrigger asChild>
                         <Button
                           variant="outline"
                           size="sm"
                           className={cn(
                             "justify-start text-left font-normal",
                             !projectDateFrom && "text-muted-foreground"
                           )}
                         >
                           <CalendarIcon className="mr-2 h-4 w-4" />
                           {projectDateFrom ? (
                             format(projectDateFrom, "d MMM", { locale: ru })
                           ) : (
                             <span>От</span>
                           )}
                         </Button>
                       </PopoverTrigger>
                       <PopoverContent className="w-auto p-0" align="start">
                         <CalendarComponent
                           mode="single"
                           selected={projectDateFrom}
                           onSelect={setProjectDateFrom}
                           disabled={(date) =>
                             date < new Date("1900-01-01")
                           }
                           initialFocus
                           className="pointer-events-auto"
                         />
                       </PopoverContent>
                     </Popover>

                     {/* Project Date To Filter */}
                     <Popover>
                       <PopoverTrigger asChild>
                         <Button
                           variant="outline"
                           size="sm"
                           className={cn(
                             "justify-start text-left font-normal",
                             !projectDateTo && "text-muted-foreground"
                           )}
                         >
                           <CalendarIcon className="mr-2 h-4 w-4" />
                           {projectDateTo ? (
                             format(projectDateTo, "d MMM", { locale: ru })
                           ) : (
                             <span>До</span>
                           )}
                         </Button>
                       </PopoverTrigger>
                       <PopoverContent className="w-auto p-0" align="start">
                         <CalendarComponent
                           mode="single"
                           selected={projectDateTo}
                           onSelect={setProjectDateTo}
                           disabled={(date) =>
                             date < new Date("1900-01-01") || 
                             (projectDateFrom && date < projectDateFrom)
                           }
                           initialFocus
                           className="pointer-events-auto"
                         />
                       </PopoverContent>
                     </Popover>

                     {/* Clear Project Filters Button */}
                     {(projectDateFrom || projectDateTo) && (
                       <Button 
                         variant="outline" 
                         size="sm"
                         onClick={() => {
                           setProjectDateFrom(undefined);
                           setProjectDateTo(undefined);
                         }}
                       >
                         <X className="h-4 w-4" />
                       </Button>
                     )}
                   </div>
                 </>
               )}

               {activeTab === 'project_tasks' && (
                 <Dialog open={isAddTaskDialogOpen} onOpenChange={setIsAddTaskDialogOpen}>
                   <DialogTrigger asChild>
                     <Button size="sm">
                       <Plus className="h-4 w-4 mr-2" />
                       Добавить задачу
                     </Button>
                   </DialogTrigger>
                   <DialogContent className="sm:max-w-[500px]">
                     <DialogHeader>
                       <DialogTitle>Добавить новую задачу</DialogTitle>
                     </DialogHeader>
                     <div className="grid gap-4 py-4">
                       <div className="grid gap-2">
                         <Label htmlFor="task_name">Название задачи</Label>
                         <Input
                           id="task_name"
                           value={newTask.task_name}
                           onChange={(e) => setNewTask({ ...newTask, task_name: e.target.value })}
                           placeholder="Введите название задачи"
                         />
                       </div>
                       <div className="grid gap-2">
                         <Label htmlFor="task_type">Тип задачи</Label>
                         <Select
                           value={newTask.task_type}
                           onValueChange={(value) => setNewTask({ ...newTask, task_type: value })}
                         >
                           <SelectTrigger>
                             <SelectValue placeholder="Выберите тип задачи" />
                           </SelectTrigger>
                           <SelectContent>
                             <SelectItem value="По проектам">По проектам</SelectItem>
                             <SelectItem value="По агентству">По агентству</SelectItem>
                             <SelectItem value="Другое">Другое</SelectItem>
                           </SelectContent>
                         </Select>
                       </div>
                       <div className="grid gap-2">
                         <Label htmlFor="due_date">Срок выполнения (опционально)</Label>
                         <Input
                           id="due_date"
                           type="date"
                           value={newTask.due_date}
                           onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                         />
                       </div>
                     </div>
                     <div className="flex justify-end space-x-2">
                       <Button
                         variant="outline"
                         onClick={() => setIsAddTaskDialogOpen(false)}
                       >
                         Отмена
                       </Button>
                        <Button
                          onClick={handleAddTask}
                          disabled={!newTask.task_name || !newTask.task_type}
                        >
                          Добавить задачу
                        </Button>
                     </div>
                   </DialogContent>
                 </Dialog>
               )}
             </div>
            
            {/* Edit Task Dialog */}
            <Dialog open={isEditTaskDialogOpen} onOpenChange={setIsEditTaskDialogOpen}>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Редактировать задачу</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="edit_task_name">Название задачи</Label>
                    <Input
                      id="edit_task_name"
                      value={editTask.task_name}
                      onChange={(e) => setEditTask({ ...editTask, task_name: e.target.value })}
                      placeholder="Введите название задачи"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="edit_task_type">Тип задачи</Label>
                    <Select
                      value={editTask.task_type}
                      onValueChange={(value) => setEditTask({ ...editTask, task_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите тип задачи" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="По проектам">По проектам</SelectItem>
                        <SelectItem value="По агентству">По агентству</SelectItem>
                        <SelectItem value="Другое">Другое</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                   <div className="grid gap-2">
                     <Label htmlFor="edit_priority">Приоритет</Label>
                     <Select
                       value={editTask.priority}
                       onValueChange={(value) => setEditTask({ ...editTask, priority: value })}
                     >
                       <SelectTrigger>
                         <SelectValue placeholder="Выберите приоритет" />
                       </SelectTrigger>
                       <SelectContent>
                         <SelectItem value="easy">Легкая</SelectItem>
                         <SelectItem value="medium">Средняя</SelectItem>
                         <SelectItem value="hard">Сложная</SelectItem>
                       </SelectContent>
                     </Select>
                   </div>
                  <div className="grid gap-2">
                    <Label htmlFor="edit_due_date">Срок выполнения (опционально)</Label>
                    <Input
                      id="edit_due_date"
                      type="date"
                      value={editTask.due_date}
                      onChange={(e) => setEditTask({ ...editTask, due_date: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsEditTaskDialogOpen(false)}
                  >
                    Отмена
                  </Button>
                   <Button
                     onClick={handleEditTask}
                     disabled={!editTask.task_name || !editTask.task_type}
                   >
                     Сохранить изменения
                   </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {activeTab === 'completed_tasks' ? (
            // Сделанные работы (существующий список задач)
            tasksLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-muted-foreground">Загрузка задач...</div>
              </div>
            ) : filteredTasks.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-muted-foreground">
                  {tasks?.length === 0 ? 'У сотрудника пока нет задач' : 'Нет задач в выбранном периоде'}
                </div>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                   <TableHeader>
                     <TableRow>
                       <TableHead>Название работы</TableHead>
                       <TableHead>Дата выполнения</TableHead>
                       <TableHead>Количество часов</TableHead>
                       <TableHead>Категория</TableHead>
                       <TableHead>Проект</TableHead>
                       <TableHead>Сложность</TableHead>
                       <TableHead>Прикрепленный файл</TableHead>
                       <TableHead>Действия</TableHead>
                     </TableRow>
                   </TableHeader>
                   <TableBody>
                     {filteredTasks.map((task) => (
                        <TableRow key={task.id}>
                          <TableCell className="font-medium">
                            {task.title}
                          </TableCell>
                          <TableCell>
                            {task.completed_at ? (
                              <span className="text-sm text-muted-foreground">
                                {format(new Date(task.completed_at), "dd.MM.yyyy", { locale: ru })}
                              </span>
                            ) : task.due_date ? (
                              <span className="text-sm text-muted-foreground opacity-60">
                                {format(new Date(task.due_date), "dd.MM.yyyy", { locale: ru })} (плановая)
                              </span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {task.actual_minutes ? (
                              <span className="text-success font-medium">
                                {formatTime(task.actual_minutes)} (факт)
                              </span>
                            ) : task.estimated_minutes ? (
                              <span className="text-muted-foreground">
                                {formatTime(task.estimated_minutes)} (план)
                              </span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                            <TableCell>
                              <div className="flex flex-col gap-1">
                                {task.category ? (
                                  <Badge variant="outline" className="bg-muted/30">
                                    {task.category}
                                  </Badge>
                                ) : (
                                  <span className="text-muted-foreground">-</span>
                                )}
                                {task.source === 'project_tasks' && (
                                  <Badge variant="outline" className="bg-blue/20 text-blue border-blue/30 text-xs">
                                    Проектная
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              {task.source === 'project_tasks' && (task.project_name || task.client_name) ? (
                                <div className="flex flex-col gap-1">
                                  {task.project_name && (
                                    <span className="text-sm font-medium">
                                      {task.project_name}
                                    </span>
                                  )}
                                  {task.client_name && (
                                    <span className="text-xs text-muted-foreground">
                                      {task.client_name}
                                    </span>
                                  )}
                                </div>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                          <TableCell>
                            <Badge 
                              variant="outline" 
                              className={getPriorityColor(task.priority)}
                            >
                              {getPriorityText(task.priority)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {task.attachments && task.attachments.length > 0 ? (
                              <div className="flex items-center gap-2">
                                <FileText className="h-4 w-4 text-muted-foreground" />
                                <div>
                                  {task.attachments[0].file_url ? (
                                    <a 
                                      href={task.attachments[0].file_url} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-primary hover:underline flex items-center gap-1 text-sm"
                                    >
                                      {task.attachments[0].file_name}
                                      <ExternalLink className="h-3 w-3" />
                                    </a>
                                  ) : (
                                    <span className="text-sm text-muted-foreground">
                                      {task.attachments[0].file_name}
                                    </span>
                                  )}
                                  {task.attachments[0].file_size && (
                                    <div className="text-xs text-muted-foreground">
                                      {Math.round(task.attachments[0].file_size / 1024)}KB • {task.attachments[0].content_type || 'Тип неизвестен'}
                                    </div>
                                  )}
                                </div>
                              </div>
                            ) : task.attachment_count && task.attachment_count > 0 ? (
                              <div className="flex items-center gap-2">
                                <Paperclip className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm text-muted-foreground">
                                  {task.attachment_count} файл(ов)
                                </span>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                           </TableCell>
                           <TableCell>
                             <Button
                               variant="outline"
                               size="sm"
                               onClick={() => handleChangeTaskStatus(task.id, 'pending')}
                               title="Перевести в активные"
                             >
                               ↺
                             </Button>
                           </TableCell>
                         </TableRow>
                     ))}
                   </TableBody>
                </Table>
              </div>
            )
          ) : (
            // Активные задачи (pending, in_progress, postponed, issues)
            tasksLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-muted-foreground">Загрузка активных задач...</div>
              </div>
            ) : filteredActiveTasks.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-muted-foreground">
                  {tasks?.filter(t => t.status === 'pending' || t.status === 'in_progress' || t.status === 'postponed' || t.status === 'issues').length === 0 ? 'У сотрудника нет активных задач' : 'Нет активных задач в выбранном периоде'}
                </div>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                   <TableHeader>
                     <TableRow>
                       <TableHead>Название задачи</TableHead>
                       <TableHead>Категория</TableHead>
                       <TableHead>Проект</TableHead>
                       <TableHead>Приоритет</TableHead>
                       <TableHead>Статус</TableHead>
                       <TableHead>Срок выполнения</TableHead>
                       <TableHead>Действия</TableHead>
                     </TableRow>
                   </TableHeader>
                  <TableBody>
                    {filteredActiveTasks.map((task) => (
                      <TableRow key={task.id}>
                        <TableCell className="font-medium">
                          {task.title}
                        </TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1">
                              {task.category ? (
                                <Badge variant="outline" className="bg-muted/30">
                                  {task.category}
                                </Badge>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                              {task.source === 'project_tasks' && (
                                <Badge variant="outline" className="bg-blue/20 text-blue border-blue/30 text-xs">
                                  Проектная
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {task.source === 'project_tasks' && (task.project_name || task.client_name) ? (
                              <div className="flex flex-col gap-1">
                                {task.project_name && (
                                  <span className="text-sm font-medium">
                                    {task.project_name}
                                  </span>
                                )}
                                {task.client_name && (
                                  <span className="text-xs text-muted-foreground">
                                    {task.client_name}
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={getPriorityColor(task.priority)}
                          >
                            {getPriorityText(task.priority)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={getTaskStatusColor(task.status)}
                          >
                            {getTaskStatusDisplay(task.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {task.due_date ? (
                            <span className="text-sm">
                              {format(new Date(task.due_date), 'd MMM yyyy', { locale: ru })}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleChangeTaskStatus(task.id, 'completed')}
                              title="Завершить задачу"
                            >
                              ✓
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditDialog(task)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Удалить задачу?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Это действие нельзя отменить. Задача "{task.title}" будет удалена навсегда.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Отмена</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteTask(task.id)}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Удалить
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )
          )}
        </CardContent>
      </Card>
    </div>
  );
};