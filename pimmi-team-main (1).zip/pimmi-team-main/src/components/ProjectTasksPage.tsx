import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar as CalendarIcon, CheckCircle, Clock, User, Building2, Filter, X, Plus } from "lucide-react";
import { useTaskCategories } from "@/hooks/useTaskCategories";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { TaskKanban } from "@/components/TaskKanban";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg, scopeToOrg } from "@/integrations/supabase/org";

interface ProjectTask {
  id: string;
  task_name: string;
  task_type: string;
  status: string | null;
  due_date: string | null;
  sales_result_id: string | null;
  sales_results: {
    client_name: string | null;
    project_name: string | null;
    sale_date: string;
  } | null;
  source: 'project' | 'employee'; // Новое поле для различения источника
  title?: string; // Для задач сотрудников
  description?: string; // Для задач сотрудников
  priority?: string; // Для задач сотрудников
  category?: string; // Для задач сотрудников
  assigned_by?: string | null; // Кто назначил задачу
  currentEmployeeId?: string; // ID текущего сотрудника для сравнения
}

export const ProjectTasksPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { currentOrgId } = useOrg();
  
  // Filter states
  const [dateFrom, setDateFrom] = useState<Date | undefined>();
  const [dateTo, setDateTo] = useState<Date | undefined>();
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>(["pending", "in_progress", "postponed", "issues", "completed"]);
  
  // Postpone dialog states
  const [isPostponeDialogOpen, setIsPostponeDialogOpen] = useState(false);
  const [selectedTaskForPostpone, setSelectedTaskForPostpone] = useState<string | null>(null);
  const [newPostponeDate, setNewPostponeDate] = useState<Date | undefined>(undefined);

  // Add task dialog states
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false);
  const [newTaskData, setNewTaskData] = useState({
    task_name: "",
    task_type: "",
    due_date: undefined as Date | undefined
  });

  // Complete task dialog states
  const [isCompleteDialogOpen, setIsCompleteDialogOpen] = useState(false);
  const [selectedTaskForComplete, setSelectedTaskForComplete] = useState<ProjectTask | null>(null);
  const [completeTaskData, setCompleteTaskData] = useState({
    category: "",
    priority: "medium" as string,
    actual_hours: 0,
    actual_minutes: 0
  });

  // Use task categories hook
  const { categories, loading: categoriesLoading } = useTaskCategories();

  const { data: tasks, isLoading } = useQuery({
    queryKey: ["all-tasks", dateFrom, dateTo, selectedProject, selectedStatuses],
    queryFn: async () => {
      // Get current user's employee ID first
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: employee, error: employeeError } = await supabase
        .from("employees")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (employeeError || !employee) throw new Error("Employee not found");

      const currentEmployeeId = employee.id;

      // Получаем проектные задачи
      let projectQuery = supabase
        .from("project_tasks")
        .select(`
          *,
          sales_results (
            client_name,
            project_name,
            sale_date
          )
        `)
        .eq("assignee_id", employee.id);
        // Убираем фильтр по статусу - показываем все задачи

      // Получаем все задачи сотрудников (убираем фильтр по статусу)
      let employeeQuery = supabase
        .from("employee_tasks")
        .select("*, assigned_by")
        .eq("employee_id", employee.id);

      // Apply date filters for project tasks
      if (dateFrom) {
        projectQuery = projectQuery.gte("due_date", format(dateFrom, "yyyy-MM-dd"));
        employeeQuery = employeeQuery.gte("due_date", format(dateFrom, "yyyy-MM-dd"));
      }
      if (dateTo) {
        projectQuery = projectQuery.lte("due_date", format(dateTo, "yyyy-MM-dd"));
        employeeQuery = employeeQuery.lte("due_date", format(dateTo, "yyyy-MM-dd"));
      }

      // Scope queries to current org
      projectQuery = scopeToOrg(projectQuery, currentOrgId);
      employeeQuery = scopeToOrg(employeeQuery, currentOrgId);

      const [projectTasksResult, employeeTasksResult] = await Promise.all([
        projectQuery.order("due_date", { ascending: true }),
        employeeQuery.order("due_date", { ascending: true })
      ]);

      if (projectTasksResult.error) throw projectTasksResult.error;
      if (employeeTasksResult.error) throw employeeTasksResult.error;

      // Преобразуем проектные задачи
      const projectTasks: ProjectTask[] = (projectTasksResult.data || []).map(task => ({
        ...task,
        source: 'project' as const
      }));

      // Преобразуем задачи сотрудников в формат ProjectTask
      const employeeTasks: ProjectTask[] = (employeeTasksResult.data || []).map(task => ({
        id: task.id,
        task_name: task.title,
        task_type: task.category || 'Общая задача',
        status: task.status,
        due_date: task.due_date,
        sales_result_id: null,
        sales_results: null,
        source: 'employee' as const,
        title: task.title,
        description: task.description,
        priority: task.priority,
        category: task.category,
        assigned_by: task.assigned_by
      }));

      // Объединяем все задачи
      let allTasks = [...projectTasks, ...employeeTasks];

      // Добавляем информацию о текущем сотруднике к каждой задаче
      allTasks = allTasks.map(task => ({
        ...task,
        currentEmployeeId
      }));

      // Filter by project name  
      if (selectedProject !== "all") {
        if (selectedProject === "no_project") {
          // Show tasks without project (employee tasks + project tasks without project)
          allTasks = allTasks.filter(task => 
            task.source === 'employee' || !task.sales_results?.project_name
          );
        } else if (selectedProject === "employee_tasks") {
          // Show only employee tasks
          allTasks = allTasks.filter(task => task.source === 'employee');
        } else {
          // Show tasks for specific project
          allTasks = allTasks.filter(
            task => task.sales_results?.project_name === selectedProject
          );
        }
      }

      // Filter by selected statuses
      if (selectedStatuses.length > 0) {
        allTasks = allTasks.filter(task => task.status && selectedStatuses.includes(task.status));
      }

      // Сортируем по дате
      allTasks.sort((a, b) => {
        const dateA = a.due_date ? new Date(a.due_date).getTime() : Infinity;
        const dateB = b.due_date ? new Date(b.due_date).getTime() : Infinity;
        return dateA - dateB;
      });
      
      return allTasks;
    },
  });

  // Get unique projects for filter dropdown
  const { data: projects } = useQuery({
    queryKey: ["project-names"],
    queryFn: async () => {
      const { data, error } = await scopeToOrg(
        supabase
          .from("project_tasks")
          .select(`
          sales_results (
            project_name
          )
        `),
        currentOrgId
      );

      if (error) throw error;
      
      const uniqueProjects = Array.from(
        new Set(
          data
            .map(item => item.sales_results?.project_name)
            .filter(name => name && typeof name === 'string' && name.trim() !== '')
        )
      );
      
      return uniqueProjects as string[];
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, status, dueDate, source }: { taskId: string; status: string; dueDate?: string; source: 'project' | 'employee' }) => {
      console.log("Updating task:", { taskId, status, dueDate, source });
      
      const updateData: any = { status };
      if (dueDate) {
        updateData.due_date = dueDate;
      }
      
      const tableName = source === 'project' ? 'project_tasks' : 'employee_tasks';
      console.log("Table name:", tableName, "Update data:", updateData);
      
      const { data, error } = await supabase
        .from(tableName)
        .update(updateData)
        .eq("id", taskId)
        .select();

      console.log("Update result:", { data, error });
      if (error) throw error;
      
      return data;
    },
    onMutate: async ({ taskId, status, dueDate }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ["all-tasks"] });

      // Snapshot previous value
      const previousTasks = queryClient.getQueryData(["all-tasks"]);

      // Optimistically update
      queryClient.setQueryData(["all-tasks"], (old: any) => {
        if (!old) return old;
        return old.map((task: any) => {
          if (task.id === taskId) {
            const updatedTask = { ...task, status };
            if (dueDate) {
              updatedTask.due_date = dueDate;
            }
            return updatedTask;
          }
          return task;
        });
      });

      return { previousTasks };
    },
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousTasks) {
        queryClient.setQueryData(["all-tasks"], context.previousTasks);
      }
      
      console.error("Update failed:", err);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус задачи",
        variant: "destructive",
      });
    },
    onSuccess: (data, variables) => {
      console.log("Update successful:", data);
      
      // Invalidate and refetch all related queries
      queryClient.invalidateQueries({ queryKey: ["all-tasks"] });
      queryClient.invalidateQueries({ queryKey: ["project-tasks"] });
      queryClient.invalidateQueries({ queryKey: ["employee-tasks"] });
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      
      const statusMessages: { [key: string]: string } = {
        completed: "Задача помечена как выполненная и больше не отображается в этом разделе",
        in_progress: "Задача переведена в статус 'В работе'",
        pending: "Задача возвращена в ожидание"
      };
      
      toast({
        title: "Задача обновлена",
        description: statusMessages[variables.status] || "Статус задачи успешно изменен",
      });
    },
  });

  const addTaskMutation = useMutation({
    mutationFn: async (taskData: typeof newTaskData) => {
      // Get current user's employee ID
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: employee, error: employeeError } = await supabase
        .from("employees")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (employeeError || !employee) throw new Error("Employee not found");

      const { error } = await supabase
        .from("project_tasks")
        .insert(withOrg({
          task_name: taskData.task_name,
          task_type: taskData.task_type,
          due_date: taskData.due_date ? format(taskData.due_date, 'yyyy-MM-dd') : null,
          assignee_id: employee.id,
          status: "pending"
        } as any, currentOrgId));

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-tasks"] });
      toast({
        title: "Задача создана",
        description: "Новая задача успешно добавлена",
      });
      setIsAddTaskDialogOpen(false);
      setNewTaskData({
        task_name: "",
        task_type: "",
        due_date: undefined
      });
    },
    onError: (error) => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать задачу",
        variant: "destructive",
      });
      console.error("Error creating task:", error);
    },
  });

  const handleStatusChange = (task: ProjectTask, newStatus: string) => {
    if (newStatus === "postponed") {
      // Открываем диалог выбора новой даты
      setSelectedTaskForPostpone(task.id);
      setIsPostponeDialogOpen(true);
    } else if (newStatus === "completed") {
      // Открываем диалог заполнения данных о завершении
      setSelectedTaskForComplete(task);
      setIsCompleteDialogOpen(true);
    } else {
      // Обычное обновление статуса
      updateTaskMutation.mutate({ taskId: task.id, status: newStatus, source: task.source });
    }
  };

  const handlePostponeConfirm = () => {
    if (!selectedTaskForPostpone || !newPostponeDate) return;

    const formattedDate = format(newPostponeDate, 'yyyy-MM-dd');
    
    // Найдем задачу для определения источника
    const task = tasks?.find(t => t.id === selectedTaskForPostpone);
    if (!task) return;
    
    updateTaskMutation.mutate({
      taskId: selectedTaskForPostpone,
      status: "postponed",
      dueDate: formattedDate,
      source: task.source
    });

    // Закрываем диалог и сбрасываем состояние
    setIsPostponeDialogOpen(false);
    setSelectedTaskForPostpone(null);
    setNewPostponeDate(undefined);
  };

  const handleCompleteConfirm = async () => {
    if (!selectedTaskForComplete) return;

    // Обновляем дополнительные поля в зависимости от типа задачи
    try {
      const totalMinutes = (completeTaskData.actual_hours * 60) + completeTaskData.actual_minutes;
      
      if (selectedTaskForComplete.source === 'employee') {
        const { error } = await supabase
          .from('employee_tasks')
          .update({
            category: completeTaskData.category,
            priority: completeTaskData.priority,
            actual_minutes: totalMinutes,
            status: "completed"
          })
          .eq('id', selectedTaskForComplete.id);

        if (error) throw error;
      } else if (selectedTaskForComplete.source === 'project') {
        const { error } = await supabase
          .from('project_tasks')
          .update({
            category: completeTaskData.category,
            priority: completeTaskData.priority,
            actual_minutes: totalMinutes,
            status: "completed"
          })
          .eq('id', selectedTaskForComplete.id);

        if (error) throw error;
      }

      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["all-tasks"] });
      
      toast({
        title: "Задача завершена",
        description: "Задача помечена как выполненная с дополнительной информацией",
      });
      
    } catch (error) {
      console.error('Error updating task details:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить дополнительные данные задачи",
        variant: "destructive",
      });
    }

    // Закрываем диалог и сбрасываем состояние
    setIsCompleteDialogOpen(false);
    setSelectedTaskForComplete(null);
    setCompleteTaskData({
      category: "",
      priority: "medium",
      actual_hours: 0,
      actual_minutes: 0
    });
  };

  const handleAddTask = () => {
    if (!newTaskData.task_name || !newTaskData.task_type) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    addTaskMutation.mutate(newTaskData);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500";
      case "postponed":
        return "bg-orange-500";
      case "issues":
        return "bg-red-500";
      case "in_progress":
        return "bg-blue-500";
      case "pending":
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  const isTaskOverdue = (dueDate: string, status: string) => {
    if (!dueDate || status === 'completed') return false;
    const today = new Date();
    const taskDueDate = new Date(dueDate);
    today.setHours(0, 0, 0, 0);
    taskDueDate.setHours(0, 0, 0, 0);
    return taskDueDate < today;
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Сделан";
      case "postponed":
        return "Перенесен";
      case "issues":
        return "Проблемы с задачей";
      case "in_progress":
        return "В работе";
      case "pending":
        return "Ожидает";
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-muted rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Задачи</h1>
        <div className="flex items-center gap-3">
          <Button onClick={() => setIsAddTaskDialogOpen(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Добавить задачу
          </Button>
          <Badge variant="outline" className="text-sm">
            {tasks?.length || 0} задач
          </Badge>
        </div>
      </div>

      {/* Filters Section */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span className="font-medium">Фильтры</span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Date From Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Дата с:</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !dateFrom && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateFrom ? format(dateFrom, "dd.MM.yyyy") : "Выберите дату"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-popover border shadow-md z-50" align="start">
                  <Calendar
                    mode="single"
                    selected={dateFrom}
                    onSelect={setDateFrom}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Date To Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Дата до:</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !dateTo && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateTo ? format(dateTo, "dd.MM.yyyy") : "Выберите дату"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-popover border shadow-md z-50" align="start">
                  <Calendar
                    mode="single"
                    selected={dateTo}
                    onSelect={setDateTo}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Project Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Проект:</label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Выберите проект" />
                </SelectTrigger>
                <SelectContent className="bg-popover border shadow-md z-50">
                  <SelectItem value="all">Все задачи</SelectItem>
                  <SelectItem value="employee_tasks">Задачи сотрудников</SelectItem>
                  <SelectItem value="no_project">Без проекта</SelectItem>
                  {projects?.filter(project => project && project.trim() !== '').map((project) => (
                    <SelectItem key={project} value={project}>
                      {project}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Статусы:</label>
              <div className="space-y-2">
                 {[
                   { value: "pending", label: "Ожидает" },
                   { value: "in_progress", label: "В работе" },
                   { value: "postponed", label: "Перенесен" },
                   { value: "issues", label: "Проблемы с задачей" },
                   { value: "completed", label: "Выполнено" }
                 ].map((status) => (
                  <div key={status.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={status.value}
                      checked={selectedStatuses.includes(status.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedStatuses([...selectedStatuses, status.value]);
                        } else {
                          setSelectedStatuses(selectedStatuses.filter(s => s !== status.value));
                        }
                      }}
                    />
                    <label htmlFor={status.value} className="text-sm font-normal cursor-pointer">
                      {status.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>

           {/* Clear Filters Button */}
            {(dateFrom || dateTo || selectedProject !== "all" || selectedStatuses.length !== 5 || !selectedStatuses.includes("pending") || !selectedStatuses.includes("in_progress") || !selectedStatuses.includes("postponed") || !selectedStatuses.includes("issues") || !selectedStatuses.includes("completed")) && (
            <div className="flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setDateFrom(undefined);
                  setDateTo(undefined);
                  setSelectedProject("all");
                   setSelectedStatuses(["pending", "in_progress", "postponed", "issues", "completed"]);
                }}
              >
                <X className="h-4 w-4 mr-2" />
                Сбросить фильтры
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {!tasks || tasks.length === 0 ? (
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <div className="text-center">
              <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">Нет активных задач</h3>
              <p className="text-muted-foreground">
                У вас пока нет активных задач
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <TaskKanban
          tasks={tasks.map(task => ({
            id: task.id,
            title: task.task_name,
            description: task.source === 'project' 
              ? `${task.sales_results?.client_name || 'Компания не указана'}${task.sales_results?.project_name ? ` - ${task.sales_results.project_name}` : ''}`
              : task.description || '',
            priority: task.priority,
            status: task.status || 'pending',
            category: task.category,
            estimated_minutes: undefined,
            actual_minutes: undefined,
            due_date: task.due_date,
            created_at: '',
            updated_at: '',
            completed_at: undefined,
            task_type: task.task_type,
            source: task.source === 'project' ? 'project_tasks' : 'employee_tasks'
          }))}
          onUpdateStatus={(taskId, newStatus) => {
            const task = tasks?.find(t => t.id === taskId);
            if (task) {
              handleStatusChange(task, newStatus);
            }
          }}
          onEditTask={(task) => {
            // For project tasks, we don't allow editing through the kanban interface
            // as they are managed differently
          }}
          onDeleteTask={(taskId, taskTitle) => {
            // For project tasks, we don't allow deletion through the kanban interface
            // as they are managed differently
          }}
        />
      )}

      {/* Postpone Task Dialog */}
      <Dialog open={isPostponeDialogOpen} onOpenChange={setIsPostponeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Перенести задачу</DialogTitle>
            <DialogDescription>
              Выберите новую дату дедлайна для задачи
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Новый дедлайн:</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !newPostponeDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {newPostponeDate ? format(newPostponeDate, "dd.MM.yyyy") : "Выберите дату"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-popover border shadow-md z-50" align="start">
                  <Calendar
                    mode="single"
                    selected={newPostponeDate}
                    onSelect={setNewPostponeDate}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPostponeDialogOpen(false)}>
              Отмена
            </Button>
            <Button onClick={handlePostponeConfirm} disabled={!newPostponeDate}>
              Перенести задачу
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Task Dialog */}
      <Dialog open={isAddTaskDialogOpen} onOpenChange={setIsAddTaskDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Добавить новую задачу</DialogTitle>
            <DialogDescription>
              Заполните информацию о новой проектной задаче
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="task_name">Название задачи *</Label>
              <Input
                id="task_name"
                value={newTaskData.task_name}
                onChange={(e) => setNewTaskData({...newTaskData, task_name: e.target.value})}
                placeholder="Введите название задачи"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="task_type">Тип задачи *</Label>
              <Select 
                value={newTaskData.task_type || undefined} 
                onValueChange={(value) => setNewTaskData({...newTaskData, task_type: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Выберите тип задачи" />
                </SelectTrigger>
                <SelectContent className="bg-popover border shadow-md z-50">
                  <SelectItem value="От проектов">От проектов</SelectItem>
                  <SelectItem value="От агентство">От агентство</SelectItem>
                  <SelectItem value="другое">другое</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Дедлайн (опционально)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !newTaskData.due_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {newTaskData.due_date ? format(newTaskData.due_date, "dd.MM.yyyy") : "Выберите дату"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-popover border shadow-md z-50" align="start">
                  <Calendar
                    mode="single"
                    selected={newTaskData.due_date}
                    onSelect={(date) => setNewTaskData({...newTaskData, due_date: date})}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddTaskDialogOpen(false)}>
              Отмена
            </Button>
            <Button 
              onClick={handleAddTask} 
              disabled={addTaskMutation.isPending || !newTaskData.task_name || !newTaskData.task_type}
            >
              {addTaskMutation.isPending ? "Создание..." : "Создать задачу"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Complete Task Dialog */}
      <Dialog open={isCompleteDialogOpen} onOpenChange={setIsCompleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Завершить задачу</DialogTitle>
            <DialogDescription>
              Заполните дополнительную информацию о выполненной задаче
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Категория *</Label>
              <Select 
                value={completeTaskData.category} 
                onValueChange={(value) => setCompleteTaskData({...completeTaskData, category: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Выберите категорию" />
                </SelectTrigger>
                <SelectContent className="bg-popover border shadow-md z-50">
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Сложность *</Label>
              <Select 
                value={completeTaskData.priority} 
                onValueChange={(value) => setCompleteTaskData({...completeTaskData, priority: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Выберите сложность" />
                </SelectTrigger>
                <SelectContent className="bg-popover border shadow-md z-50">
                  <SelectItem value="easy">Легкий (5 баллов)</SelectItem>
                  <SelectItem value="medium">Средний (15 баллов)</SelectItem>
                  <SelectItem value="hard">Трудный (30 баллов)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Потраченное время *</Label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label htmlFor="complete-hours" className="text-xs">Часы</Label>
                  <Input
                    id="complete-hours"
                    type="number"
                    min="0"
                    max="24"
                    value={completeTaskData.actual_hours}
                    onChange={(e) => setCompleteTaskData({...completeTaskData, actual_hours: parseInt(e.target.value) || 0})}
                    placeholder="Часы"
                  />
                </div>
                <div>
                  <Label htmlFor="complete-minutes" className="text-xs">Минуты</Label>
                  <Input
                    id="complete-minutes"
                    type="number"
                    min="0"
                    max="59"
                    value={completeTaskData.actual_minutes}
                    onChange={(e) => setCompleteTaskData({...completeTaskData, actual_minutes: parseInt(e.target.value) || 0})}
                    placeholder="Минуты"
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCompleteDialogOpen(false)}>
              Отмена
            </Button>
            <Button 
              onClick={handleCompleteConfirm} 
              disabled={updateTaskMutation.isPending || !completeTaskData.category || (completeTaskData.actual_hours === 0 && completeTaskData.actual_minutes === 0)}
            >
              {updateTaskMutation.isPending ? "Завершение..." : "Завершить задачу"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};