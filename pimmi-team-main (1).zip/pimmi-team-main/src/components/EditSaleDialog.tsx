import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { WORK_FORMATS, sanitizeWorkFormats } from "@/constants/workFormats";

interface EditSaleDialogProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: string;
  onSaleUpdated: () => void;
}

interface SaleData {
  project_name: string;
  client_name: string;
  sale_amount: number;
  client_phone: string;
  description: string;
  project_type: string;
  work_format: string[];
  prepayment: number;
  remainder: number;
  remainder_due_date: string;
  comments: string;
}

export const EditSaleDialog = ({ isOpen, onClose, projectId, onSaleUpdated }: EditSaleDialogProps) => {
  const [saleData, setSaleData] = useState<SaleData>({
    project_name: "",
    client_name: "",
    sale_amount: 0,
    client_phone: "",
    description: "",
    project_type: "",
    work_format: [],
    prepayment: 0,
    remainder: 0,
    remainder_due_date: "",
    comments: ""
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const workFormatOptions = WORK_FORMATS;


  const projectTypeOptions = [
    "Тестовый",
    "Единоразовый", 
    "Ежемесячный"
  ];

  useEffect(() => {
    if (isOpen && projectId) {
      fetchSaleData();
    }
  }, [isOpen, projectId]);

  const fetchSaleData = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from("sales_results")
        .select(`
          project_name,
          client_name,
          sale_amount,
          client_phone,
          description,
          project_type,
          work_format,
          prepayment,
          remainder,
          remainder_due_date,
          comments
        `)
        .eq("id", projectId)
        .single();

      if (error) throw error;

      setSaleData({
        project_name: data.project_name || "",
        client_name: data.client_name || "",
        sale_amount: data.sale_amount || 0,
        client_phone: data.client_phone || "",
        description: data.description || "",
        project_type: data.project_type || "",
        work_format: data.work_format || [],
        prepayment: data.prepayment || 0,
        remainder: data.remainder || 0,
        remainder_due_date: data.remainder_due_date || "",
        comments: data.comments || ""
      });

    } catch (error) {
      console.error("Error fetching sale data:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные продажи",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    // Предотвращаем повторное сохранение
    if (saving) return;

    try {
      setSaving(true);
      console.log('🔄 Начинаем сохранение продажи:', { projectId, saleData });
      
      const { error } = await supabase
        .from("sales_results")
        .update({
          project_name: saleData.project_name,
          client_name: saleData.client_name,
          sale_amount: saleData.sale_amount,
          client_phone: saleData.client_phone,
          description: saleData.description,
          project_type: saleData.project_type,
          work_format: sanitizeWorkFormats(saleData.work_format),
          prepayment: saleData.prepayment,
          remainder: saleData.remainder,
          remainder_due_date: saleData.remainder_due_date || null,
          comments: saleData.comments
        })
        .eq("id", projectId);

      console.log('📊 Результат обновления:', { error });

      if (error) throw error;

      console.log('✅ Продажа успешно обновлена');
      toast({
        title: "Успешно",
        description: "Продажа обновлена",
      });

      onSaleUpdated();
      onClose();

    } catch (error) {
      console.error("❌ Ошибка при обновлении продажи:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить продажу",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleWorkFormatChange = (format: string) => {
    setSaleData(prev => {
      const newWorkFormat = prev.work_format.includes(format)
        ? prev.work_format.filter(f => f !== format)
        : [...prev.work_format, format];
      
      return { ...prev, work_format: newWorkFormat };
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Редактировать продажу</DialogTitle>
          <DialogDescription>
            Измените данные о продаже
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <Label htmlFor="project_name">Название проекта</Label>
              <Input
                id="project_name"
                value={saleData.project_name}
                onChange={(e) => setSaleData(prev => ({ ...prev, project_name: e.target.value }))}
                placeholder="Введите название проекта"
              />
            </div>

            <div>
              <Label htmlFor="client_name">Имя клиента</Label>
              <Input
                id="client_name"
                value={saleData.client_name}
                onChange={(e) => setSaleData(prev => ({ ...prev, client_name: e.target.value }))}
                placeholder="Введите имя клиента"
              />
            </div>

            <div>
              <Label htmlFor="client_phone">Телефон клиента</Label>
              <Input
                id="client_phone"
                value={saleData.client_phone}
                onChange={(e) => setSaleData(prev => ({ ...prev, client_phone: e.target.value }))}
                placeholder="Введите телефон клиента"
              />
            </div>

            <div>
              <Label htmlFor="sale_amount">Сумма продажи</Label>
              <Input
                id="sale_amount"
                type="number"
                value={saleData.sale_amount}
                onChange={(e) => setSaleData(prev => ({ ...prev, sale_amount: Number(e.target.value) }))}
                placeholder="Введите сумму"
              />
            </div>

            <div>
              <Label htmlFor="prepayment">Предоплата</Label>
              <Input
                id="prepayment"
                type="number"
                value={saleData.prepayment}
                onChange={(e) => setSaleData(prev => ({ ...prev, prepayment: Number(e.target.value) }))}
                placeholder="Введите предоплату"
              />
            </div>

            <div>
              <Label htmlFor="remainder">Остаток</Label>
              <Input
                id="remainder"
                type="number"
                value={saleData.remainder}
                onChange={(e) => setSaleData(prev => ({ ...prev, remainder: Number(e.target.value) }))}
                placeholder="Введите остаток"
              />
            </div>

            <div>
              <Label htmlFor="remainder_due_date">Дата оплаты остатка</Label>
              <Input
                id="remainder_due_date"
                type="date"
                value={saleData.remainder_due_date}
                onChange={(e) => setSaleData(prev => ({ ...prev, remainder_due_date: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="project_type">Тип проекта</Label>
              <Select 
                value={saleData.project_type}
                onValueChange={(value) => setSaleData(prev => ({ ...prev, project_type: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Выберите тип проекта" />
                </SelectTrigger>
                <SelectContent>
                  {projectTypeOptions.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Формат работы</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {workFormatOptions.map((format) => (
                  <Button
                    key={format}
                    type="button"
                    variant={saleData.work_format.includes(format) ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleWorkFormatChange(format)}
                    className="text-sm"
                  >
                    {format}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="description">Описание</Label>
              <Textarea
                id="description"
                value={saleData.description}
                onChange={(e) => setSaleData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Введите описание проекта"
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="comments">Комментарии</Label>
              <Textarea
                id="comments"
                value={saleData.comments}
                onChange={(e) => setSaleData(prev => ({ ...prev, comments: e.target.value }))}
                placeholder="Введите комментарии"
                rows={2}
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Сохранить
              </Button>
              <Button variant="outline" onClick={onClose}>
                Отмена
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
