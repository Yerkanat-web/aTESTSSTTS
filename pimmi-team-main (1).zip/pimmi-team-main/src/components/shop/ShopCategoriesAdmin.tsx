import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Tags } from "lucide-react";

interface CategoryRow {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
}

interface ShopCategoriesAdminProps {
  orgId: string;
}

export function ShopCategoriesAdmin({ orgId }: ShopCategoriesAdminProps) {
  const [newName, setNewName] = useState("");
  const [saving, setSaving] = useState<string | null>(null);

  const { data: categories = [], refetch, isLoading } = useQuery<CategoryRow[]>({
    queryKey: ["shop_categories", orgId],
    enabled: Boolean(orgId),
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("shop_categories")
        .select("id, name, is_active, created_at")
        .eq("org_id", orgId)
        .order("name", { ascending: true });
      if (error) throw error;
      return (data || []) as CategoryRow[];
    },
  });

  const addCategory = async () => {
    const name = newName.trim();
    if (!name) return;
    setSaving("add");
    try {
      const { error } = await (supabase as any)
        .from("shop_categories")
        .insert({ org_id: orgId, name });
      if (error) throw error;
      setNewName("");
      toast({ title: "Категория добавлена" });
      window.dispatchEvent(new CustomEvent("shop-categories-updated", { detail: { orgId } }));
      await refetch();
    } catch (e: any) {
      toast({ title: "Ошибка", description: e?.message ?? "Не удалось добавить категорию", variant: "destructive" });
    } finally {
      setSaving(null);
    }
  };

  const toggleActive = async (row: CategoryRow) => {
    setSaving(row.id);
    try {
      const { error } = await (supabase as any)
        .from("shop_categories")
        .update({ is_active: !row.is_active })
        .eq("id", row.id);
      if (error) throw error;
      window.dispatchEvent(new CustomEvent("shop-categories-updated", { detail: { orgId } }));
      await refetch();
    } catch (e: any) {
      toast({ title: "Ошибка", description: e?.message ?? "Не удалось обновить", variant: "destructive" });
    } finally {
      setSaving(null);
    }
  };

  const remove = async (row: CategoryRow) => {
    setSaving(row.id + "-del");
    try {
      const { error } = await (supabase as any)
        .from("shop_categories")
        .delete()
        .eq("id", row.id);
      if (error) throw error;
      toast({ title: "Категория удалена" });
      window.dispatchEvent(new CustomEvent("shop-categories-updated", { detail: { orgId } }));
      await refetch();
    } catch (e: any) {
      toast({ title: "Ошибка", description: e?.message ?? "Не удалось удалить", variant: "destructive" });
    } finally {
      setSaving(null);
    }
  };

  return (
    <Card className="border shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Tags className="h-5 w-5 text-primary" /> Категории магазина
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Новая категория"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addCategory()}
          />
        <Button onClick={addCategory} disabled={!newName.trim() || saving === "add"}>
            {saving === "add" ? <Loader2 className="h-4 w-4 animate-spin" /> : "Добавить"}
          </Button>
        </div>

        <div className="divide-y border rounded-md">
          {isLoading ? (
            <div className="p-4 text-muted-foreground">Загрузка категорий...</div>
          ) : categories.length === 0 ? (
            <div className="p-4 text-muted-foreground">Категории пока не созданы</div>
          ) : (
            categories.map((c) => (
              <div key={c.id} className="flex items-center justify-between p-3">
                <div className="font-medium">{c.name}</div>
                <div className="flex items-center gap-2">
                  <Switch checked={c.is_active} onCheckedChange={() => toggleActive(c)} disabled={saving === c.id} />
                  <Button variant="destructive" size="sm" onClick={() => remove(c)} disabled={saving === c.id + "-del"}>
                    Удалить
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
