
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

export interface ShopItemDto {
  id?: string;
  org_id?: string;
  name: string;
  description?: string;
  price: number;
  category: string;
  is_available: boolean;
  image_url?: string | null;
}

interface ShopItemFormDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  orgId: string;
  initialItem?: ShopItemDto | null;
  onSaved: () => void;
}

const defaultCategories = [
  "Еда",
  "Развлечения",
  "Творчество",
  "Мерч",
  "Здоровье",
  "Отдых",
  "Офис",
  "Техника",
  "Удобства",
  "Прочее",
];

export function ShopItemFormDialog({
  open,
  onOpenChange,
  orgId,
  initialItem,
  onSaved,
}: ShopItemFormDialogProps) {
  const isEdit = Boolean(initialItem?.id);

  const [name, setName] = useState("");
  const [description, setDescription] = useState<string>("");
  const [price, setPrice] = useState<number>(0);
  const [category, setCategory] = useState<string>("Прочее");
  const [isAvailable, setIsAvailable] = useState<boolean>(true);
  const [imageUrl, setImageUrl] = useState<string>("");

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dbCategories, setDbCategories] = useState<string[]>([]);
  

  useEffect(() => {
    if (open) {
      setName(initialItem?.name ?? "");
      setDescription(initialItem?.description ?? "");
      setPrice(initialItem?.price ?? 0);
      setCategory(initialItem?.category ?? "Прочее");
      setIsAvailable(initialItem?.is_available ?? true);
      setImageUrl(initialItem?.image_url ?? "");
      setImageFile(null);
    }
  }, [open, initialItem]);

  const loadCategories = async () => {
    if (!orgId) return;
    const { data, error } = await (supabase as any)
      .from("shop_categories")
      .select("name, is_active")
      .eq("org_id", orgId)
      .order("name", { ascending: true });
    if (!error && Array.isArray(data)) {
      const names = (data as any[])
        .filter((c) => c.is_active !== false)
        .map((c) => c.name as string);
      setDbCategories(names);
    }
  };

  // Load categories when dialog opens and when org changes
  useEffect(() => {
    if (open) loadCategories();
  }, [orgId, open]);

  // Listen to global category updates
  useEffect(() => {
    const handler = () => loadCategories();
    window.addEventListener("shop-categories-updated", handler as any);
    return () => window.removeEventListener("shop-categories-updated", handler as any);
  }, []);

  const suggestedCategories = useMemo(() => {
    const set = new Set<string>([...defaultCategories, ...dbCategories]);
    if (initialItem?.category && !set.has(initialItem.category)) {
      set.add(initialItem.category);
    }
    return Array.from(set);
  }, [initialItem, dbCategories]);


  const handleUploadImage = async (): Promise<string | undefined> => {
    if (!imageFile) return undefined;

    const ext = imageFile.name.split(".").pop();
    const path = `${orgId}/${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("shop-images").upload(path, imageFile, {
      upsert: false,
      cacheControl: "3600",
      contentType: imageFile.type,
    });
    if (upErr) {
      console.error("Image upload error:", upErr);
      toast({
        title: "Ошибка загрузки изображения",
        description: "Не удалось загрузить файл. Попробуйте другое изображение.",
        variant: "destructive",
      });
      return undefined;
    }
    const { data } = supabase.storage.from("shop-images").getPublicUrl(path);
    return data.publicUrl;
  };

  const handleSubmit = async () => {
    if (!name || price <= 0) {
      toast({
        title: "Проверьте форму",
        description: "Название обязательно, цена должна быть больше 0",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      let finalImageUrl = imageUrl || undefined;
      if (imageFile) {
        const uploaded = await handleUploadImage();
        if (uploaded) finalImageUrl = uploaded;
      }

      // Build explicit payloads to satisfy Supabase insert/update type requirements
      const insertPayload = {
        name,
        description: description || undefined,
        price,
        category,
        is_available: isAvailable,
        image_url: finalImageUrl,
        org_id: orgId,
      };

      const updatePayload = {
        name,
        description: description || undefined,
        price,
        category,
        is_available: isAvailable,
        image_url: finalImageUrl,
      };

      if (isEdit && initialItem?.id) {
        const { error } = await supabase.from("shop_items").update(updatePayload).eq("id", initialItem.id);
        if (error) throw error;
        toast({ title: "Товар обновлен" });
      } else {
        const { error } = await supabase.from("shop_items").insert(insertPayload);
        if (error) throw error;
        toast({ title: "Товар добавлен" });
      }

      onSaved();
      onOpenChange(false);
    } catch (e: any) {
      console.error("Save shop item error:", e);
      toast({
        title: "Ошибка",
        description: e?.message ?? "Не удалось сохранить товар",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Редактировать товар" : "Добавить товар"}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="name">Название</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Например, Бургер «Баханди»" />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="description">Описание</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="price">Цена (баллы)</Label>
              <Input
                id="price"
                type="number"
                min={0}
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category">Категория</Label>
              <Select
                value={suggestedCategories.includes(category) ? category : undefined}
                onValueChange={(v) => setCategory(v)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Выберите категорию" />
                </SelectTrigger>
                <SelectContent className="z-50 bg-popover">
                  {suggestedCategories.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2">
            <div className="grid gap-2 flex-1">
              <Label htmlFor="image_url">URL изображения</Label>
              <Input
                id="image_url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://..."
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="image_file">или загрузить</Label>
              <Input id="image_file" type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files?.[0] || null)} />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Switch id="is_available" checked={isAvailable} onCheckedChange={setIsAvailable} />
            <Label htmlFor="is_available">Доступен для покупки</Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
            Отмена
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isEdit ? "Сохранить" : "Добавить"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
