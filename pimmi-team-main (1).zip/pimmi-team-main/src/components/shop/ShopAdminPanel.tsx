
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ShopItemFormDialog, ShopItemDto } from "./ShopItemFormDialog";
import { Pencil, Plus, Trash2 } from "lucide-react";

interface ShopAdminPanelProps {
  orgId: string;
  items: ShopItemDto[];
  refetch: () => void;
}

export function ShopAdminPanel({ orgId, items, refetch }: ShopAdminPanelProps) {
  const [open, setOpen] = useState(false);
  const [editItem, setEditItem] = useState<ShopItemDto | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const onAdd = () => {
    setEditItem(null);
    setOpen(true);
  };

  const onEdit = (item: ShopItemDto) => {
    setEditItem(item);
    setOpen(true);
  };

  const onDelete = async (id: string) => {
    if (!confirm("Удалить товар? Это действие необратимо.")) return;
    setDeletingId(id);
    try {
      const { error } = await supabase.from("shop_items").delete().eq("id", id);
      if (error) throw error;
      toast({ title: "Товар удален" });
      refetch();
    } catch (e: any) {
      console.error("Delete item error:", e);
      toast({ title: "Ошибка удаления", description: e?.message, variant: "destructive" });
    } finally {
      setDeletingId(null);
    }
  };

  const onToggleAvailable = async (item: ShopItemDto) => {
    setTogglingId(item.id!);
    try {
      const { error } = await supabase
        .from("shop_items")
        .update({ is_available: !item.is_available })
        .eq("id", item.id);
      if (error) throw error;
      refetch();
    } catch (e: any) {
      console.error("Toggle available error:", e);
      toast({ title: "Ошибка", description: e?.message, variant: "destructive" });
    } finally {
      setTogglingId(null);
    }
  };

  return (
    <Card className="p-4 border-dashed">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Управление магазином</h3>
        <Button onClick={onAdd}>
          <Plus className="h-4 w-4 mr-2" />
          Добавить товар
        </Button>
      </div>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {items.map((item) => (
          <div key={item.id} className="border rounded p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="font-medium">{item.name}</div>
              <div className="text-sm text-muted-foreground">{item.category}</div>
            </div>
            <div className="text-sm text-muted-foreground line-clamp-2">{item.description}</div>
            <div className="flex items-center justify-between">
              <div className="font-semibold">{item.price} баллов</div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Доступен</span>
                  <Switch
                    checked={item.is_available}
                    onCheckedChange={() => onToggleAvailable(item)}
                    disabled={togglingId === item.id}
                  />
                </div>
                <Button size="icon" variant="outline" onClick={() => onEdit(item)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  size="icon"
                  variant="destructive"
                  onClick={() => onDelete(item.id!)}
                  disabled={deletingId === item.id}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
        {items.length === 0 && <div className="text-sm text-muted-foreground">Пока нет товаров</div>}
      </div>

      <ShopItemFormDialog
        open={open}
        onOpenChange={setOpen}
        orgId={orgId}
        initialItem={editItem || undefined}
        onSaved={refetch}
      />
    </Card>
  );
}
