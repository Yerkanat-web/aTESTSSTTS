import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  TrendingUp, 
  Users, 
  Target, 
  DollarSign, 
  Calendar as CalendarIcon,
  Award,
  Edit,
  RefreshCw,
  BarChart3,
  Upload
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { SalesImport } from "./SalesImport";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useOrg } from "@/contexts/OrgContext";
import { scopeToOrg } from "@/integrations/supabase/org";

// Функция для форматирования больших чисел
const formatCurrency = (amount: number): string => {
  if (amount >= 1000000) {
    return `${(amount / 1000000).toFixed(1)} млн тг`;
  } else if (amount >= 1000) {
    return `${(amount / 1000).toFixed(0)} тыс тг`;
  }
  return `${amount} тг`;
};

interface Employee {
  id: string;
  name: string;
  email: string;
  position: string;
  department: string;
  status: string;
}

interface SalesTarget {
  id: string;
  employee_id: string;
  target_amount: number;
  target_period: string;
}

interface SalesResult {
  id: string;
  employee_id: string;
  sale_amount: number;
  sale_date: string;
  client_name: string;
  description: string;
}

interface ManagerStats {
  employee: Employee;
  target: number;
  achieved: number;
  percentage: number;
  last5Days: { date: string; amount: number }[];
}

interface SalesManagerMetrics {
  id: string;
  name: string;
  totalLeads: number;
  qualifiedLeads: number;
  totalSales: number;
  totalSaleAmount: number;
  conversion: number;
  qualifiedPercent: number;
  unqualifiedPercent: number;
}

export const AdminSalesManagement = () => {
  const [managersStats, setManagersStats] = useState<ManagerStats[]>([]);
  const [salesMetrics, setSalesMetrics] = useState<SalesManagerMetrics[]>([]);
  const [selectedManager, setSelectedManager] = useState<ManagerStats | null>(null);
  const [newTarget, setNewTarget] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dateFrom, setDateFrom] = useState<Date>(new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [dateTo, setDateTo] = useState<Date>(new Date());
const { toast } = useToast();
const { currentOrgId } = useOrg();

  useEffect(() => {
    fetchSalesData();
  }, [dateFrom, dateTo]);

  const fetchSalesData = async () => {
    try {
      setLoading(true);
      
      // Получаем сотрудников отдела продаж
const { data: employees, error: employeesError } = await scopeToOrg(
        supabase
          .from('employees')
          .select('*')
          .eq('department', 'отдел продаж')
          .eq('status', 'active'),
        currentOrgId
      );

      if (employeesError) throw employeesError;

      // Получаем планы на текущий месяц
      const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
      const { data: targets, error: targetsError } = await scopeToOrg(
        supabase
          .from('sales_targets')
          .select('*')
          .eq('target_period', currentMonth),
        currentOrgId
      );
      if (targetsError) throw targetsError;

      // Получаем продажи за выбранный период
const { data: salesInPeriod, error: salesError } = await scopeToOrg(
        supabase
          .from('sales_results')
          .select('*')
          .gte('sale_date', dateFrom.toISOString().split('T')[0])
          .lte('sale_date', dateTo.toISOString().split('T')[0]),
        currentOrgId
      );

      if (salesError) throw salesError;

      // Получаем продажи за последние 5 дней для динамики
      const last5Days = new Date();
      last5Days.setDate(last5Days.getDate() - 4);
const { data: salesLast5Days, error: sales5Error } = await scopeToOrg(
        supabase
          .from('sales_results')
          .select('*')
          .gte('sale_date', last5Days.toISOString().split('T')[0]),
        currentOrgId
      );

      if (sales5Error) throw sales5Error;

      // Формируем статистику по менеджерам
      const stats: ManagerStats[] = employees?.map(employee => {
        const target = targets?.find(t => t.employee_id === employee.id)?.target_amount || 0;
        const achieved = salesInPeriod?.filter(s => s.employee_id === employee.id)
          .reduce((sum, sale) => sum + Number(sale.sale_amount), 0) || 0;
        
        // Данные по последним 5 дням
        const last5DaysData = [];
        for (let i = 4; i >= 0; i--) {
          const date = new Date();
          date.setDate(date.getDate() - i);
          const dateStr = date.toISOString().split('T')[0];
          const dayAmount = salesLast5Days?.filter(s => 
            s.employee_id === employee.id && s.sale_date === dateStr
          ).reduce((sum, sale) => sum + Number(sale.sale_amount), 0) || 0;
          
          last5DaysData.push({
            date: date.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }),
            amount: dayAmount
          });
        }

        return {
          employee,
          target,
          achieved,
          percentage: target > 0 ? (achieved / target) * 100 : 0,
          last5Days: last5DaysData
        };
      }) || [];

      setManagersStats(stats);

      // Получаем метрики продажников с учетом выбранного периода
      await fetchSalesManagerMetrics();
    } catch (error) {
      console.error('Error fetching sales data:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные продаж",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchSalesManagerMetrics = async () => {
    try {
      // Получаем отдельно данные для каждой таблицы
const { data: employees, error: empError } = await scopeToOrg(
        supabase
          .from('employees')
          .select('id, name')
          .eq('department', 'отдел продаж')
          .eq('status', 'active'),
        currentOrgId
      );

      if (empError) throw empError;

      const metrics: SalesManagerMetrics[] = [];

      for (const employee of employees || []) {
        // Получаем данные по лидам из daily_reports с фильтрацией по датам
const { data: reports } = await scopeToOrg(
          supabase
            .from('daily_reports')
            .select('leads_count, qualified_leads_count')
            .eq('employee_id', employee.id)
            .gte('report_date', dateFrom.toISOString().split('T')[0])
            .lte('report_date', dateTo.toISOString().split('T')[0]),
          currentOrgId
        );

        // Получаем данные по продажам из sales_results с фильтрацией по датам
const { data: sales } = await scopeToOrg(
          supabase
            .from('sales_results')
            .select('sale_amount')
            .eq('employee_id', employee.id)
            .gte('sale_date', dateFrom.toISOString().split('T')[0])
            .lte('sale_date', dateTo.toISOString().split('T')[0]),
          currentOrgId
        );

        const totalLeads = reports?.reduce((sum, report) => 
          sum + (report.leads_count || 0), 0) || 0;
        const qualifiedLeads = reports?.reduce((sum, report) => 
          sum + (report.qualified_leads_count || 0), 0) || 0;
        const totalSales = sales?.length || 0;
        const totalSaleAmount = sales?.reduce((sum, sale) => 
          sum + Number(sale.sale_amount || 0), 0) || 0;
        
        const conversion = totalLeads > 0 ? (totalSales / totalLeads) * 100 : 0;
        const qualifiedPercent = totalLeads > 0 ? (qualifiedLeads / totalLeads) * 100 : 0;
        const unqualifiedPercent = totalLeads > 0 ? ((totalLeads - qualifiedLeads) / totalLeads) * 100 : 0;

        metrics.push({
          id: employee.id,
          name: employee.name,
          totalLeads,
          qualifiedLeads,
          totalSales,
          totalSaleAmount,
          conversion,
          qualifiedPercent,
          unqualifiedPercent,
        });
      }

      setSalesMetrics(metrics);
    } catch (error) {
      console.error('Error fetching sales manager metrics:', error);
    }
  };

  const updateManagerTarget = async () => {
    if (!selectedManager || !newTarget) return;

    try {
      const targetAmount = parseFloat(newTarget);
      const currentMonth = new Date().toISOString().slice(0, 7) + '-01';

      // Проверяем, есть ли уже план на этот месяц
      const { data: existingTarget } = await supabase
        .from('sales_targets')
        .select('id')
        .eq('employee_id', selectedManager.employee.id)
        .eq('target_period', currentMonth)
        .maybeSingle();

      if (existingTarget) {
        // Обновляем существующий план
        const { error } = await supabase
          .from('sales_targets')
          .update({ target_amount: targetAmount })
          .eq('id', existingTarget.id);

        if (error) throw error;
      } else {
        // Создаем новый план
        const { error } = await supabase
          .from('sales_targets')
          .insert({
            employee_id: selectedManager.employee.id,
            target_amount: targetAmount,
            target_period: currentMonth,
            org_id: currentOrgId
          });
        if (error) throw error;
      }

      toast({
        title: "Успешно",
        description: "План обновлен",
      });

      // Обновляем данные
      await fetchSalesData();
      setDialogOpen(false);
      setSelectedManager(null);
      setNewTarget("");
    } catch (error) {
      console.error('Error updating target:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить план",
        variant: "destructive",
      });
    }
  };

  // Рассчитываем общую статистику
  const totalTarget = managersStats.reduce((sum, manager) => sum + manager.target, 0);
  const totalAchieved = managersStats.reduce((sum, manager) => sum + manager.achieved, 0);
  const overallPercentage = totalTarget > 0 ? (totalAchieved / totalTarget) * 100 : 0;

  // Данные для командной динамики за последние 5 дней
  const teamDynamicsData = managersStats.length > 0 
    ? managersStats[0].last5Days.map(day => ({
        date: day.date,
        team: managersStats.reduce((sum, manager) => {
          const dayData = manager.last5Days.find(d => d.date === day.date);
          return sum + (dayData?.amount || 0);
        }, 0)
      }))
    : [];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Управление отделом продаж
          </h1>
          <p className="text-muted-foreground">
            Менеджеры, показатели и аналитика
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          {/* Фильтр по датам */}
          <div className="flex items-center gap-2">
            <Label className="text-sm font-medium">Период:</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "justify-start text-left font-normal",
                    !dateFrom && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? format(dateFrom, "dd.MM.yyyy", { locale: ru }) : "От"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dateFrom}
                  onSelect={(date) => date && setDateFrom(date)}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
            
            <span className="text-muted-foreground">-</span>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "justify-start text-left font-normal",
                    !dateTo && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? format(dateTo, "dd.MM.yyyy", { locale: ru }) : "До"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dateTo}
                  onSelect={(date) => date && setDateTo(date)}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <Button onClick={fetchSalesData} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить
          </Button>
        </div>
      </div>

      {/* Tabs для переключения между аналитикой и импортом */}
      <Tabs defaultValue="analytics" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="analytics">Аналитика</TabsTrigger>
          <TabsTrigger value="import">
            <Upload className="h-4 w-4 mr-2" />
            Импорт продаж
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="space-y-6">
          {/* Основные метрики */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="bg-gradient-to-r from-primary/10 to-blue/10 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Общий план</p>
                    <p className="text-2xl font-bold">{formatCurrency(totalTarget)}</p>
                  </div>
                  <Target className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-success/10 to-green/10 border-success/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Выполнено</p>
                    <p className="text-2xl font-bold">{formatCurrency(totalAchieved)}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-success" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-warning/10 to-gold/10 border-warning/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Прогресс к цели</p>
                    <p className="text-2xl font-bold">{overallPercentage.toFixed(1)}%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-warning" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500/10 to-primary/10 border-purple-500/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Менеджеров</p>
                    <p className="text-2xl font-bold">{managersStats.length}</p>
                  </div>
                  <Users className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Прогресс к месячной цели */}
          <Card className="shadow-card border border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                Прогресс к месячной цели
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Выполнение плана</span>
                  <span>{formatCurrency(totalAchieved)} из {formatCurrency(totalTarget)}</span>
                </div>
                <Progress value={overallPercentage} className="h-3" />
              </div>
            </CardContent>
          </Card>

          {/* Командная динамика продаж */}
          <Card className="shadow-card border border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Командная динамика продаж (последние 5 дней)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={teamDynamicsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => [formatCurrency(value), 'Командные продажи']} />
                    <Line 
                      type="monotone" 
                      dataKey="team" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Динамика по каждому менеджеру */}
          <Card className="shadow-card border border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Динамика по менеджерам (последние 5 дней)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={managersStats.map(manager => ({
                    name: manager.employee.name.split(' ')[0],
                    ...manager.last5Days.reduce((acc, day, index) => {
                      acc[`day${index + 1}`] = day.amount;
                      return acc;
                    }, {} as Record<string, number>)
                  }))}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    {managersStats.length > 0 && managersStats[0].last5Days.map((_, index) => (
                      <Bar 
                        key={index}
                        dataKey={`day${index + 1}`} 
                        fill={`hsl(${200 + index * 30}, 70%, 50%)`}
                        name={managersStats[0].last5Days[index].date}
                      />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Менеджеры отдела продаж */}
          <Card className="shadow-card border border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Менеджеры отдела продаж ({managersStats.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {managersStats.map((manager) => (
                  <Card key={manager.employee.id} className="shadow-card border border-border hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{manager.employee.name}</CardTitle>
                          <p className="text-sm text-muted-foreground">{manager.employee.position}</p>
                        </div>
                        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                          <DialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedManager(manager);
                                setNewTarget(manager.target.toString());
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Установить план для {selectedManager?.employee.name}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label htmlFor="target">План продаж (тг)</Label>
                                <Input
                                  id="target"
                                  type="number"
                                  value={newTarget}
                                  onChange={(e) => setNewTarget(e.target.value)}
                                  placeholder="Введите сумму плана"
                                />
                              </div>
                              <Button onClick={updateManagerTarget} className="w-full">
                                Сохранить план
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">План</span>
                        <span className="font-medium">{formatCurrency(manager.target)}</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Выполнено</span>
                        <span className="font-medium">{formatCurrency(manager.achieved)}</span>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Прогресс</span>
                          <span>{manager.percentage.toFixed(1)}%</span>
                        </div>
                        <Progress value={manager.percentage} className="h-3" />
                      </div>
                      
                      <div className="pt-3 border-t border-border">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">Статус</span>
                          <Badge variant={manager.percentage >= 100 ? "default" : manager.percentage >= 75 ? "secondary" : "outline"}>
                            {manager.percentage >= 100 ? "Цель достигнута" : 
                             manager.percentage >= 75 ? "Хороший прогресс" : "Требует внимания"}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Таблица показателей продажников */}
          <Card className="shadow-card border border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Показатели продажников
              </CardTitle>
            </CardHeader>
            <CardContent>
              {salesMetrics.length === 0 ? (
                <div className="flex items-center justify-center py-8">
                  <div className="text-muted-foreground">Данные загружаются...</div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Имя продажника</TableHead>
                        <TableHead className="text-center">Лиды</TableHead>
                        <TableHead className="text-center">Продажи</TableHead>
                        <TableHead className="text-center">Конверсия</TableHead>
                        <TableHead className="text-right">Сумма продаж</TableHead>
                        <TableHead className="text-center">% Квал. лидов</TableHead>
                        <TableHead className="text-center">% Неквал. лидов</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {salesMetrics.map((metric) => (
                        <TableRow key={metric.id}>
                          <TableCell className="font-medium">
                            {metric.name}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline" className="bg-blue/10 text-blue border-blue/30">
                              {metric.totalLeads}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                              {metric.totalSales}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge 
                              variant="outline" 
                              className={
                                metric.conversion >= 10 
                                  ? "bg-success/10 text-success border-success/30" 
                                  : metric.conversion >= 5 
                                  ? "bg-warning/10 text-warning border-warning/30" 
                                  : "bg-destructive/10 text-destructive border-destructive/30"
                              }
                            >
                              {metric.conversion.toFixed(1)}%
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {formatCurrency(metric.totalSaleAmount)}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                              {metric.qualifiedPercent.toFixed(1)}%
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline" className="bg-muted/30 text-muted-foreground border-muted/30">
                              {metric.unqualifiedPercent.toFixed(1)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import">
          <SalesImport />
        </TabsContent>
      </Tabs>
    </div>
  );
};
