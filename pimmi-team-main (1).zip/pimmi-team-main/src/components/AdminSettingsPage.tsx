import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle 
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { AdminOperationsService } from "@/services/admin-operations";
import { useAllEmployeeStats } from "@/hooks/useEmployeeStats";
import { useTaskCategories } from "@/hooks/useTaskCategories";
import { EmployeeCategoriesDialog } from "./EmployeeCategoriesDialog";
import { AdminActivityLogs } from "@/components/AdminActivityLogs";
import { useOrg } from "@/contexts/OrgContext";
import { 
  Users, 
  Key,
  Database,
  Save,
  RefreshCw,
  MoreHorizontal,
  Edit,
  Trash2,
  RotateCcw,
  Plus,
  Minus,
  Tag,
  X,
  Activity,
  Settings,
  Copy,
  Check
} from "lucide-react";

interface Employee {
  id: string;
  name: string;
  email: string;
  position: string;
  role: string;
  status: string;
}

export const AdminSettingsPage = () => {
  const [openaiApiKey, setOpenaiApiKey] = useState('');
  const [savingApiKey, setSavingApiKey] = useState(false);
  const [isRealDataMode, setIsRealDataMode] = useState(() => {
    return localStorage.getItem('dataMode') === 'real';
  });
const [newCategory, setNewCategory] = useState('');
const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
const { toast } = useToast();
const { currentOrgId } = useOrg();

// Org join code state
const [joinCode, setJoinCode] = useState<string | null>(null);
const [joinEnabled, setJoinEnabled] = useState<boolean>(true);
const [joinExpiresAt, setJoinExpiresAt] = useState<string | null>(null);
const [loadingJoin, setLoadingJoin] = useState(false);
const [copied, setCopied] = useState(false);

// Use the optimized hook for employee stats
const { stats: employees, loading, refetch: refetchEmployees } = useAllEmployeeStats();
  
  // Use task categories hook
  const {
    categories,
    loading: loadingCategories,
    addCategory,
    removeCategory,
    isStandardCategory,
    getCategoryDescription
  } = useTaskCategories();

  const updateEmployeeRole = async (employeeId: string, newRole: string) => {
    const success = await AdminOperationsService.updateEmployeeRole(employeeId, newRole);
    
    if (success) {
      toast({
        title: "Успешно",
        description: "Роль сотрудника обновлена",
      });
      refetchEmployees();
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить роль сотрудника",
        variant: "destructive"
      });
    }
  };

  const saveApiKey = async () => {
    setSavingApiKey(true);
    
    // Сохраняем в localStorage (для всех админов)
    localStorage.setItem('openai_api_key', openaiApiKey);
    
    toast({
      title: "Успешно",
      description: "API ключ сохранен",
    });
    
    setSavingApiKey(false);
  };

  const toggleDataMode = (useRealData: boolean) => {
    setIsRealDataMode(useRealData);
    localStorage.setItem('dataMode', useRealData ? 'real' : 'demo');
    
    toast({
      title: useRealData ? "Реальные данные" : "Демо данные",
      description: useRealData ? "Переключен режим реальных данных" : "Переключен режим демо данных",
    });
    
    // Перезагружаем страницу чтобы применить изменения
    window.location.reload();
  };

  const handleAddCategory = async () => {
    if (!newCategory.trim()) return;
    
    const success = await addCategory(newCategory.trim());
    if (success) {
      setNewCategory('');
    }
  };

  const handleRemoveCategory = async (categoryName: string) => {
    await removeCategory(categoryName);
  };

  useEffect(() => {
    // Загружаем сохраненный API ключ
    const savedApiKey = localStorage.getItem('openai_api_key');
    if (savedApiKey) {
      setOpenaiApiKey(savedApiKey);
    }
    
    // Получаем роль текущего пользователя
    fetchCurrentUserRole();
  }, []);

  const fetchCurrentUserRole = async () => {
    try {
      const { data: currentUser } = await supabase.auth.getUser();
      if (!currentUser.user) return;

      const { data: employee, error } = await supabase
        .from("employees")
        .select("role")
        .eq("user_id", currentUser.user.id)
        .single();

      if (error) {
        console.error("Error fetching user role:", error);
        return;
      }

      setCurrentUserRole(employee?.role || null);
    } catch (error) {
      console.error("Error fetching current user role:", error);
    }
  };

  // Load organization join code settings for admins
  const loadJoinSettings = async () => {
    if (!currentOrgId || currentUserRole !== 'admin') return;
    try {
      setLoadingJoin(true);
      const { data, error } = await (supabase as any).rpc('get_org_join_settings', { p_org_id: currentOrgId });
      if (error) throw error;
      const row = Array.isArray(data) ? data[0] : data;
      setJoinCode(row?.join_code ?? null);
      setJoinEnabled(row?.join_code_enabled !== false);
      setJoinExpiresAt(row?.join_code_expires_at ?? null);
    } catch (e) {
      console.error('Ошибка загрузки кода организации:', e);
    } finally {
      setLoadingJoin(false);
    }
  };

  const rotateJoinCode = async () => {
    if (!currentOrgId) return;
    setLoadingJoin(true);
    const { data, error } = await (supabase as any).rpc('rotate_org_join_code', { p_org_id: currentOrgId });
    if (error) {
      console.error('Не удалось сгенерировать новый код:', error);
      toast({ title: 'Ошибка', description: 'Не удалось сгенерировать код', variant: 'destructive' });
    } else {
      const row = Array.isArray(data) ? data[0] : data;
      setJoinCode(row?.join_code ?? null);
      setJoinEnabled(row?.join_code_enabled !== false);
      setJoinExpiresAt(row?.join_code_expires_at ?? null);
      toast({ title: 'Готово', description: 'Новый код сгенерирован' });
    }
    setLoadingJoin(false);
  };

  const onToggleJoinEnabled = async (enabled: boolean) => {
    if (!currentOrgId) return;
    setJoinEnabled(enabled);
    const { data, error } = await (supabase as any).rpc('set_org_join_enabled', {
      p_org_id: currentOrgId,
      p_enabled: enabled,
      p_expires_at: null
    });
    if (error) {
      console.error('Не удалось изменить доступность кода:', error);
      toast({ title: 'Ошибка', description: 'Не удалось изменить доступность', variant: 'destructive' });
    } else {
      const row = Array.isArray(data) ? data[0] : data;
      setJoinCode(row?.join_code ?? null);
      setJoinEnabled(row?.join_code_enabled !== false);
      setJoinExpiresAt(row?.join_code_expires_at ?? null);
    }
  };

  useEffect(() => {
    loadJoinSettings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentOrgId, currentUserRole]);

  // Определяем, является ли пользователь только руководителем отдела (не админом)
  const isDepartmentLead = currentUserRole && 
    ['руководитель тех отдела', 'руководитель отдела продаж', 'руководитель ИИ отдела'].includes(currentUserRole);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Настройки системы
          </h1>
          <p className="text-muted-foreground">
            Управление пользователями, настройками системы и просмотр логов активности
          </p>
        </div>
        
        <Button onClick={refetchEmployees} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Обновить
        </Button>
      </div>

      {/* Tabs for different sections */}
      <Tabs defaultValue="settings" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Настройки
          </TabsTrigger>
          {!isDepartmentLead && (
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Логи активности
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="settings" className="space-y-6 mt-6">
          {/* Data Mode Toggle - только для админов */}
          {!isDepartmentLead && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  Режим данных
                </CardTitle>
                <CardDescription>
                  Переключение между демо данными и реальными данными
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="font-medium">
                      {isRealDataMode ? "Реальные данные" : "Демо данные"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {isRealDataMode 
                        ? "Система работает с реальными данными из базы" 
                        : "Система показывает демо данные для демонстрации"
                      }
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Label htmlFor="data-mode" className="text-sm">
                      Демо
                    </Label>
                    <Switch
                      id="data-mode"
                      checked={isRealDataMode}
                      onCheckedChange={toggleDataMode}
                    />
                    <Label htmlFor="data-mode" className="text-sm">
                      Реальные
                    </Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Organization Join Code - только для админов */}
          {!isDepartmentLead && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  Код организации для подключения сотрудников
                </CardTitle>
                <CardDescription>
                  Сообщите сотрудникам этот код. При регистрации они введут его, чтобы присоединиться к вашей организации.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Input
                      value={joinCode ?? ''}
                      readOnly
                      placeholder={loadingJoin ? 'Загрузка…' : 'Код отсутствует'}
                      className="font-mono tracking-widest"
                    />
                    <Button
                      variant="outline"
                      onClick={async () => {
                        if (!joinCode) return;
                        await navigator.clipboard.writeText(joinCode);
                        setCopied(true);
                        setTimeout(() => setCopied(false), 1500);
                        toast({ title: 'Скопировано', description: 'Код организации скопирован в буфер' });
                      }}
                      disabled={!joinCode || loadingJoin}
                    >
                      {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                      {copied ? 'Скопировано' : 'Копировать'}
                    </Button>
                    <Button onClick={rotateJoinCode} disabled={loadingJoin}>
                      {loadingJoin ? (
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <RotateCcw className="h-4 w-4 mr-2" />
                      )}
                      Новый код
                    </Button>
                  </div>

                  <div className="flex items-center gap-3">
                    <Label htmlFor="join-enabled" className="text-sm">Код включен</Label>
                    <Switch id="join-enabled" checked={joinEnabled} onCheckedChange={onToggleJoinEnabled} />
                    {joinExpiresAt && (
                      <span className="text-xs text-muted-foreground">истекает: {new Date(joinExpiresAt).toLocaleString()}</span>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Task Categories Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Tag className="h-5 w-5" />
                Категории задач ({categories.length})
              </CardTitle>
              <CardDescription>
                Управление категориями для классификации задач сотрудников
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Add new category */}
                <div className="flex gap-2">
                  <Input
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    placeholder="Название новой категории..."
                    onKeyPress={(e) => e.key === 'Enter' && handleAddCategory()}
                    className="flex-1"
                  />
                  <Button 
                    onClick={handleAddCategory}
                    disabled={!newCategory.trim() || loadingCategories}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Добавить
                  </Button>
                </div>

                {/* Categories list */}
                <div className="space-y-2">
                  {loadingCategories ? (
                    <div className="flex items-center justify-center py-4">
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {categories.map((category) => (
                        <div 
                          key={category} 
                          className="flex items-center gap-2 px-3 py-2 bg-secondary/30 rounded-lg border border-border"
                        >
                          <div className="flex flex-col">
                            <span className="text-sm font-medium">{category}</span>
                            <span className="text-xs text-muted-foreground">
                              {getCategoryDescription(category)}
                            </span>
                          </div>
                          {!isStandardCategory(category) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0 hover:bg-destructive hover:text-destructive-foreground"
                              onClick={() => handleRemoveCategory(category)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                          {isStandardCategory(category) && (
                            <Badge variant="outline" className="text-xs">
                              стандартная
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {!loadingCategories && categories.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <Tag className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Категории не найдены</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* API Key Settings - только для админов */}
          {!isDepartmentLead && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  API ключ OpenAI
                </CardTitle>
                <CardDescription>
                  Общий API ключ для всех админов системы
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Input
                      type="password"
                      value={openaiApiKey}
                      onChange={(e) => setOpenaiApiKey(e.target.value)}
                      placeholder="Введите API ключ OpenAI"
                      className="font-mono"
                    />
                  </div>
                  <Button
                    onClick={saveApiKey}
                    disabled={!openaiApiKey || savingApiKey}
                  >
                    {savingApiKey ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4 mr-2" />
                    )}
                    Сохранить
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Users and Roles - только для админов */}
          {!isDepartmentLead && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Пользователи и роли ({employees.length})
                </CardTitle>
                <CardDescription>
                  Управление ролями сотрудников системы
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {employees.map((employee) => (
                    <EmployeeRoleCard
                      key={employee.id}
                      employee={employee}
                      onRoleUpdate={updateEmployeeRole}
                      onEmployeeUpdate={refetchEmployees}
                    />
                  ))}

                  {employees.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Сотрудники не найдены</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Activity Logs Tab - только для админов */}
        {!isDepartmentLead && (
          <TabsContent value="logs" className="mt-6">
            <AdminActivityLogs />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

interface EmployeeRoleCardProps {
  employee: any; // Using employee stats from the view
  onRoleUpdate: (employeeId: string, newRole: string) => void;
  onEmployeeUpdate: () => void;
}

const EmployeeRoleCard = ({ employee, onRoleUpdate, onEmployeeUpdate }: EmployeeRoleCardProps) => {
  const [selectedRole, setSelectedRole] = useState(employee.role);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isPointsDialogOpen, setIsPointsDialogOpen] = useState(false);
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [isCategoriesDialogOpen, setIsCategoriesDialogOpen] = useState(false);
  const [pointsAction, setPointsAction] = useState<'add' | 'subtract'>('add');
  const [pointsAmount, setPointsAmount] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [editForm, setEditForm] = useState({
    name: employee.name,
    email: employee.email,
    position: employee.position
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleRoleChange = (newRole: string) => {
    setSelectedRole(newRole);
    onRoleUpdate(employee.id, newRole);
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'admin':
        return 'destructive';
      case 'manager':
        return 'default';
      default:
        return 'secondary';
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Администратор';
      case 'manager':
        return 'Менеджер';
      default:
        return 'Сотрудник';
    }
  };

  const handleClearTasks = async () => {
    setIsLoading(true);
    const success = await AdminOperationsService.clearEmployeeTasks(employee.id);
    
    if (success) {
      toast({
        title: "Успешно",
        description: "Все задачи сотрудника удалены"
      });
      onEmployeeUpdate();
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось обнулить задачи",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleClearPoints = async () => {
    setIsLoading(true);
    const success = await AdminOperationsService.clearEmployeePoints(employee.id);
    
    if (success) {
      toast({
        title: "Успешно",
        description: "Все баллы сотрудника обнулены"
      });
      onEmployeeUpdate();
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось обнулить баллы",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const openPointsDialog = (action: 'add' | 'subtract') => {
    setPointsAction(action);
    setPointsAmount('');
    setIsPointsDialogOpen(true);
  };

  const handlePointsSubmit = async () => {
    const amount = parseInt(pointsAmount);
    if (!amount || amount <= 0) {
      toast({
        title: "Ошибка",
        description: "Введите корректное количество баллов",
        variant: "destructive"
      });
      return;
    }

    const finalAmount = pointsAction === 'add' ? amount : -amount;
    await handleAddPoints(finalAmount);
    setIsPointsDialogOpen(false);
  };

  const handleAddPoints = async (points: number) => {
    setIsLoading(true);
    const success = await AdminOperationsService.addEmployeePoints(
      employee.id, 
      Math.abs(points), 
      points > 0 ? `Добавлено ${Math.abs(points)} баллов` : `Снято ${Math.abs(points)} баллов`
    );

    if (success) {
      toast({
        title: "Успешно",
        description: `${points > 0 ? 'Добавлено' : 'Снято'} ${Math.abs(points)} балл${Math.abs(points) !== 1 ? 'ов' : ''}`
      });
      onEmployeeUpdate();
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось изменить баллы",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleClearAchievements = async () => {
    setIsLoading(true);
    const success = await AdminOperationsService.clearEmployeeAchievements(employee.id);
    
    if (success) {
      toast({
        title: "Успешно",
        description: "Все достижения сотрудника обнулены"
      });
      onEmployeeUpdate();
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось обнулить достижения",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleUpdateEmployee = async () => {
    setIsLoading(true);
    const success = await AdminOperationsService.updateEmployee(employee.id, {
      name: editForm.name,
      email: editForm.email,
      position: editForm.position
    });

    if (success) {
      toast({
        title: "Успешно",
        description: "Данные сотрудника обновлены"
      });
      setIsEditDialogOpen(false);
      onEmployeeUpdate();
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить данные сотрудника",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleDeleteEmployee = async () => {
    setIsLoading(true);
    try {
      const success = await AdminOperationsService.deleteEmployeePermanently(employee.id);
      
      if (success) {
        toast({
          title: "Успешно",
          description: `Сотрудник ${employee.name} полностью удален из системы`
        });
        setIsDeleteDialogOpen(false);
        onEmployeeUpdate();
      } else {
        throw new Error('Не удалось удалить сотрудника');
      }
    } catch (error: any) {
      console.error('Ошибка удаления сотрудника:', error);
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить сотрудника",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleResetPassword = async () => {
    if (!newPassword.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите новый пароль",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('reset-user-password', {
        body: {
          email: employee.email,
          newPassword: newPassword.trim()
        }
      });

      if (error) {
        throw error;
      }

      toast({
        title: "Успешно",
        description: `Пароль для ${employee.email} успешно сброшен`
      });
      setIsPasswordDialogOpen(false);
      setNewPassword('');
    } catch (error: any) {
      console.error('Ошибка сброса пароля:', error);
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось сбросить пароль",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  return (
    <div className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg border border-border">
      <div className="flex items-center gap-4">
        <Avatar>
          <AvatarFallback className="bg-gradient-primary text-primary-foreground">
            {employee.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </AvatarFallback>
        </Avatar>
        
        <div>
          <h3 className="font-semibold">{employee.name}</h3>
          <p className="text-sm text-muted-foreground">{employee.position} - {employee.department}</p>
          <p className="text-xs text-muted-foreground">{employee.email}</p>
          <div className="flex gap-4 mt-1">
            <span className="text-sm text-muted-foreground">Баллы: {employee.total_points}</span>
            <span className="text-sm text-muted-foreground">Задачи: {employee.completed_tasks}/{employee.total_tasks}</span>
            <span className="text-sm text-muted-foreground">Эффективность: {employee.efficiency}%</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Badge variant={getRoleBadgeVariant(selectedRole)}>
          {getRoleLabel(selectedRole)}
        </Badge>
        
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={selectedRole === 'employee' ? 'default' : 'outline'}
            onClick={() => handleRoleChange('employee')}
          >
            Сотрудник
          </Button>
          <Button
            size="sm"
            variant={selectedRole === 'manager' ? 'default' : 'outline'}
            onClick={() => handleRoleChange('manager')}
          >
            Менеджер
          </Button>
          <Button
            size="sm"
            variant={selectedRole === 'admin' ? 'destructive' : 'outline'}
            onClick={() => handleRoleChange('admin')}
          >
            Админ
          </Button>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setIsEditDialogOpen(true)}>
              <Edit className="mr-2 h-4 w-4" />
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleClearTasks}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Обнулить задачи
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleClearPoints}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Обнулить баллы
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleClearAchievements}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Обнулить достижения
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => openPointsDialog('add')}>
              <Plus className="mr-2 h-4 w-4" />
              Добавить баллы
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => openPointsDialog('subtract')}>
              <Minus className="mr-2 h-4 w-4" />
              Снять баллы
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setIsCategoriesDialogOpen(true)}>
              <Tag className="mr-2 h-4 w-4" />
              Посмотреть категории
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setIsPasswordDialogOpen(true)}>
              <Key className="mr-2 h-4 w-4" />
              Сбросить пароль
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setIsDeleteDialogOpen(true)} className="text-destructive">
              <Trash2 className="mr-2 h-4 w-4" />
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Редактировать сотрудника</DialogTitle>
            <DialogDescription>
              Изменение данных сотрудника: {employee.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Имя</Label>
              <Input
                id="name"
                value={editForm.name}
                onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={editForm.email}
                onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="position">Должность</Label>
              <Input
                id="position"
                value={editForm.position}
                onChange={(e) => setEditForm(prev => ({ ...prev, position: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Отмена
            </Button>
            <Button onClick={handleUpdateEmployee} disabled={isLoading}>
              {isLoading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : null}
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Points Dialog */}
      <Dialog open={isPointsDialogOpen} onOpenChange={setIsPointsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {pointsAction === 'add' ? 'Добавить баллы' : 'Снять баллы'}
            </DialogTitle>
            <DialogDescription>
              {pointsAction === 'add' 
                ? `Добавление баллов сотруднику: ${employee.name}` 
                : `Снятие баллов у сотрудника: ${employee.name}`
              }
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="points">Количество баллов</Label>
              <Input
                id="points"
                type="number"
                min="1"
                value={pointsAmount}
                onChange={(e) => setPointsAmount(e.target.value)}
                placeholder="Введите количество баллов"
                onKeyPress={(e) => e.key === 'Enter' && handlePointsSubmit()}
              />
            </div>
            <div className="text-sm text-muted-foreground">
              Текущий баланс: {employee.total_points} баллов
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPointsDialogOpen(false)}>
              Отмена
            </Button>
            <Button 
              onClick={handlePointsSubmit} 
              disabled={isLoading || !pointsAmount}
              variant={pointsAction === 'add' ? 'default' : 'destructive'}
            >
              {isLoading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : null}
              {pointsAction === 'add' ? 'Добавить' : 'Снять'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Password Reset Dialog */}
      <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Сбросить пароль</DialogTitle>
            <DialogDescription>
              Установка нового пароля для пользователя: {employee.email}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="password">Новый пароль</Label>
              <Input
                id="password"
                type="text"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Введите новый пароль"
                onKeyPress={(e) => e.key === 'Enter' && handleResetPassword()}
              />
            </div>
            <div className="text-sm text-muted-foreground">
              Пользователь сможет войти в систему с новым паролем сразу после сброса.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPasswordDialogOpen(false)}>
              Отмена
            </Button>
            <Button 
              onClick={handleResetPassword} 
              disabled={isLoading || !newPassword.trim()}
            >
              {isLoading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : null}
              Сбросить пароль
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить сотрудника?</AlertDialogTitle>
            <AlertDialogDescription>
              Вы уверены, что хотите полностью удалить сотрудника {employee.name}? 
              Это действие необратимо и удалит все данные сотрудника из системы.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteEmployee} disabled={isLoading}>
              {isLoading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : null}
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Employee Categories Dialog */}
      <EmployeeCategoriesDialog
        open={isCategoriesDialogOpen}
        onOpenChange={setIsCategoriesDialogOpen}
        employee={employee}
      />
    </div>
  );
};