import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Target, Zap, TrendingUp, FileText, User, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useOrg } from "@/contexts/OrgContext";
import { scopeToOrg } from "@/integrations/supabase/org";
import { logger } from "@/utils/logger";
// Achievement medal images
import medalGold from "@/assets/achievements/medal-gold.jpg";
import medalSilver from "@/assets/achievements/medal-silver.jpg";
import medalBronze from "@/assets/achievements/medal-bronze.jpg";
import medalLegendary from "@/assets/achievements/medal-legendary.jpg";

interface EmployeeAchievement {
  id: string;
  achievement_name: string;
  description: string;
  points: number;
  earned_at: string;
}

interface SalesStats {
  totalLeads: number;
  qualifiedLeads: number;
  totalReports: number;
  totalSales: number;
  totalSaleAmount: number;
}

interface AchievementTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  target: number;
  points: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  medalImage: string;
  checkProgress: (stats: SalesStats) => number;
}

interface SalesAchievement extends AchievementTemplate {
  earned: boolean;
  progress: number;
  maxProgress: number;
}

interface SalesAchievementsPageProps {
  employeeId?: string;
}

export const SalesAchievementsPage = ({ employeeId }: SalesAchievementsPageProps) => {
  const [achievements, setAchievements] = useState<SalesAchievement[]>([]);
  const [earnedAchievements, setEarnedAchievements] = useState<EmployeeAchievement[]>([]);
  const [salesStats, setSalesStats] = useState<SalesStats>({
    totalLeads: 0,
    qualifiedLeads: 0,
    totalReports: 0,
    totalSales: 0,
    totalSaleAmount: 0
  });
  const [loading, setLoading] = useState(true);
  const { currentOrgId, currentOrg } = useOrg();

  // Шаблоны достижений теперь загружаются динамически из базы achievement_templates
  // для текущей организации. Формирование массива "templates" происходит в fetchData().

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeeId, currentOrgId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      logger.debug('SalesAchievementsPage.fetchData start', {
        employeeId,
        currentOrgId
      }, { component: 'SalesAchievementsPage' });

      let reportsData: any[] | null = null;
      let salesData: any[] | null = null;
      let achievementsData: EmployeeAchievement[] | null = null;

      if (employeeId) {
        // Получаем статистику по лидам и отчетам
        const { data: rData, error: rErr } = await scopeToOrg(
          supabase
            .from('daily_reports')
            .select('leads_count, qualified_leads_count')
            .eq('employee_id', employeeId),
          currentOrgId
        );
        if (rErr) logger.warn('Error fetching daily_reports', { component: 'SalesAchievementsPage', data: { error: rErr } });
        reportsData = rData || [];

        // Получаем статистику по продажам
        const { data: sData, error: sErr } = await scopeToOrg(
          supabase
            .from('sales_results')
            .select('sale_amount')
            .eq('employee_id', employeeId),
          currentOrgId
        );
        if (sErr) logger.warn('Error fetching sales_results', { component: 'SalesAchievementsPage', data: { error: sErr } });
        salesData = sData || [];

        // Получаем полученные достижения
        const { data: aData, error: aErr } = await scopeToOrg(
          supabase
            .from('employee_achievements')
            .select('*')
            .eq('employee_id', employeeId),
          currentOrgId
        );
        if (aErr) logger.warn('Error fetching employee_achievements', { component: 'SalesAchievementsPage', data: { error: aErr } });
        achievementsData = (aData as any) || [];
      } else {
        // Без employeeId показываем шаблоны с нулевым прогрессом
        reportsData = [];
        salesData = [];
        achievementsData = [];
      }

      // Вычисляем статистику
      const totalLeads = reportsData?.reduce((sum, report) => sum + (report.leads_count || 0), 0) || 0;
      const qualifiedLeads = reportsData?.reduce((sum, report) => sum + (report.qualified_leads_count || 0), 0) || 0;
      const totalReports = reportsData?.length || 0;
      const totalSales = salesData?.length || 0;
      const totalSaleAmount = salesData?.reduce((sum, sale) => sum + Number(sale.sale_amount || 0), 0) || 0;

      setSalesStats({
        totalLeads,
        qualifiedLeads,
        totalReports,
        totalSales,
        totalSaleAmount
      });

      setEarnedAchievements(achievementsData || []);

      // Загружаем активные шаблоны из базы и считаем прогресс
      const { data: tplData, error: tplError } = await scopeToOrg(
        supabase
          .from('achievement_templates')
          .select('id, name, description, category, points, rarity, condition_type, condition_value, is_active, target_group')
          .eq('is_active', true)
          .eq('target_group', 'sales')
          .order('sort_order', { ascending: true }),
        currentOrgId
      );
      if (tplError) {
        logger.error('Error fetching achievement templates', tplError, { component: 'SalesAchievementsPage' });
      }

      const templates: AchievementTemplate[] = (tplData || []).map((tpl: any) => ({
        id: tpl.id,
        name: tpl.name,
        description: tpl.description || '',
        icon: '',
        category: tpl.category || 'Общее',
        target: tpl.condition_value || 0,
        points: tpl.points || 0,
        rarity: (tpl.rarity as any) || 'common',
        medalImage: getMedalImageByRarity(((tpl.rarity as any) || 'common') as string),
        checkProgress: (stats: SalesStats) => {
          switch (tpl.condition_type) {
            case 'sales_count':
              return stats.totalSales;
            case 'sales_amount':
              return stats.totalSaleAmount;
            case 'leads_count':
              return stats.totalLeads;
            case 'qualified_leads_count':
              return stats.qualifiedLeads;
            case 'reports_count':
              return stats.totalReports;
            default:
              return 0;
          }
        }
      }));

      const achievementsWithProgress = templates.map(template => {
        const progress = template.checkProgress({
          totalLeads,
          qualifiedLeads,
          totalReports,
          totalSales,
          totalSaleAmount
        });
        const isEarned = achievementsData?.some(earned => earned.achievement_name === template.name) || false;
        return {
          ...template,
          earned: isEarned,
          progress: Math.min(progress, template.target),
          maxProgress: template.target
        };
      });

      logger.debug('SalesAchievementsPage data computed', {
        templates: templates.length,
        achievementsWithProgress: achievementsWithProgress.length,
        earnedCount: achievementsData?.length || 0,
        stats: { totalLeads, qualifiedLeads, totalReports, totalSales, totalSaleAmount }
      }, { component: 'SalesAchievementsPage' });

      setAchievements(achievementsWithProgress);
    } catch (error) {
      logger.error('Error fetching achievements data', error, { component: 'SalesAchievementsPage' });
    } finally {
      setLoading(false);
    }
  };
  const getMedalImageByRarity = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return medalLegendary;
      case 'epic': return medalGold;
      case 'rare': return medalSilver;
      default: return medalBronze;
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-muted text-muted-foreground border-muted';
      case 'rare': return 'bg-blue/10 text-blue border-blue/20';
      case 'epic': return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
      case 'legendary': return 'bg-gradient-gold text-gold-foreground border-warning/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getRarityLabel = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'Обычное';
      case 'rare': return 'Редкое';
      case 'epic': return 'Эпическое';
      case 'legendary': return 'Легендарное';
      default: return rarity;
    }
  };

  const formatCurrency = (amount: number): string => {
    if (amount >= 1000000) {
      return `${(amount / 1000000).toFixed(1)} млн тг`;
    } else if (amount >= 1000) {
      return `${(amount / 1000).toFixed(0)} тыс тг`;
    }
    return `${amount} тг`;
  };

  const formatProgress = (progress: number, maxProgress: number, category: string) => {
    if (category === "Сумма продаж") {
      return `${formatCurrency(progress)} / ${formatCurrency(maxProgress)}`;
    }
    return `${progress} / ${maxProgress}`;
  };

  const earnedCount = earnedAchievements.length; // Реальное количество из базы данных, а не из шаблонов
  const totalPoints = earnedAchievements.reduce((sum, a) => sum + a.points, 0);
  const completionPercentage = achievements.length > 0 ? (earnedCount / achievements.length) * 100 : 0;
  const rareAchievements = achievements.filter(a => a.earned && ['rare', 'epic', 'legendary'].includes(a.rarity)).length;
  
  // Подсчет следующего доступного достижения для прогресса
  const unearned = achievements.filter(a => !a.earned);
  const nextAchievement = unearned.sort((a, b) => (a.progress / a.maxProgress) - (b.progress / b.maxProgress))[0];
  const overallProgress = nextAchievement ? Math.round((nextAchievement.progress / nextAchievement.maxProgress) * 100) : 100;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-muted-foreground">Загрузка достижений...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Достижения отдела продаж</h2>
          <p className="text-muted-foreground mt-1">Ваши награды за успехи в продажах</p>
        </div>
        {currentOrg && (
          <Badge variant="outline" className="text-xs">
            Организация: {currentOrg.name}
          </Badge>
        )}
      </div>

      {/* Empty state if no templates */}
      {achievements.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="p-6 text-center text-muted-foreground">
            Для текущей организации нет активных шаблонов продажных достижений.
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-primary/10 to-blue/10 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Получено</p>
                <p className="text-2xl font-bold">{earnedCount}/{achievements.length}</p>
              </div>
              <Trophy className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-success/10 to-green/10 border-success/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Прогресс</p>
                <p className="text-2xl font-bold">
                  {nextAchievement ? `${overallProgress}%` : '100%'}
                </p>
                {nextAchievement && (
                  <p className="text-xs text-muted-foreground truncate">
                    До: {nextAchievement.name}
                  </p>
                )}
              </div>
              <Target className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-warning/10 to-gold/10 border-warning/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Баллы</p>
                <p className="text-2xl font-bold">{totalPoints}</p>
              </div>
              <Zap className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500/10 to-primary/10 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Редких</p>
                <p className="text-2xl font-bold">{rareAchievements}</p>
                <p className="text-xs text-muted-foreground">
                  из {achievements.filter(a => ['rare', 'epic', 'legendary'].includes(a.rarity)).length}
                </p>
              </div>
              <Star className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Overview */}
      <Card className="shadow-card border border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Продажные достижения
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-blue-600">{salesStats.totalLeads}</p>
              <p className="text-xs text-muted-foreground">Обработано лидов</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">{salesStats.qualifiedLeads}</p>
              <p className="text-xs text-muted-foreground">Квал. лидов</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-600">{salesStats.totalSales}</p>
              <p className="text-xs text-muted-foreground">Продаж</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-orange-600">{formatCurrency(salesStats.totalSaleAmount)}</p>
              <p className="text-xs text-muted-foreground">Сумма продаж</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Завершено достижений</span>
              <span>{earnedCount} из {achievements.length}</span>
            </div>
            <Progress value={completionPercentage} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((achievement) => (
          <Card 
            key={achievement.id} 
            className={`shadow-card border transition-all duration-200 overflow-hidden ${
              achievement.earned 
                ? "bg-gradient-to-br from-warning/5 to-gold/5 border-warning/30 shadow-lg" 
                : "hover:shadow-lg hover:scale-105"
            }`}
          >
            <div className="relative">
              <div className="h-32 overflow-hidden bg-gradient-to-br from-slate-900 to-slate-700">
                <img 
                  src={achievement.medalImage} 
                  alt={achievement.name}
                  className={`w-full h-full object-contain p-4 transition-all duration-200 ${
                    achievement.earned ? 'scale-110 brightness-110' : 'grayscale opacity-60'
                  }`}
                />
                {achievement.earned && (
                  <div className="absolute inset-0 bg-gradient-to-t from-gold/20 to-transparent" />
                )}
              </div>
              <div className="absolute top-2 right-2">
                <Badge className={getRarityColor(achievement.rarity)}>
                  {getRarityLabel(achievement.rarity)}
                </Badge>
              </div>
              {achievement.earned && (
                <div className="absolute top-2 left-2">
                  <Badge variant="secondary" className="bg-success/90 text-success-foreground">
                    ✓ Получено
                  </Badge>
                </div>
              )}
            </div>
            
            <CardHeader className="pb-3">
              <CardTitle className={`text-lg text-center ${achievement.earned ? 'text-foreground' : 'text-muted-foreground'}`}>
                {achievement.name}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{achievement.description}</p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Прогресс</span>
                  <span>{formatProgress(achievement.progress, achievement.maxProgress, achievement.category)}</span>
                </div>
                <Progress 
                  value={(achievement.progress / achievement.maxProgress) * 100} 
                  className="h-2"
                />
              </div>
              
              <div className="flex items-center justify-between pt-2 border-t border-border">
                <Badge variant="outline" className="text-xs">
                  {achievement.category}
                </Badge>
                <div className="flex items-center space-x-1">
                  <Zap className="h-3 w-3 text-warning" />
                  <span className="text-sm font-medium">{achievement.points} баллов</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};