import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Users, Crown } from "lucide-react";

interface RoleSelectorProps {
  selectedRole: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
  onRoleChange: (role: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела') => void;
}

export const RoleSelector = ({ selectedRole, onRoleChange }: RoleSelectorProps) => {
  const roles = [
    { value: 'employee', label: 'Сотрудник', icon: Users },
    { value: 'admin', label: 'Администратор', icon: Crown },
    { value: 'финансист', label: 'Финансист', icon: Users },
    { value: 'руководитель тех отдела', label: 'Руководитель тех отдела', icon: Crown },
    { value: 'руководитель отдела продаж', label: 'Руководитель продаж', icon: Crown },
    { value: 'руководитель ИИ отдела', label: 'Руководитель ИИ', icon: Crown }
  ] as const;

  return (
    <div className="space-y-3">
      <Label>Тип аккаунта</Label>
      <div className="grid grid-cols-2 gap-2">
        {roles.map((role) => {
          const Icon = role.icon;
          return (
            <Button
              key={role.value}
              type="button"
              variant={selectedRole === role.value ? 'default' : 'outline'}
              onClick={() => onRoleChange(role.value)}
              className="h-auto py-2 px-3 flex flex-col items-center gap-1 text-xs"
            >
              <Icon className="h-4 w-4" />
              <span>{role.label}</span>
            </Button>
          );
        })}
      </div>
      <div className="flex justify-center">
        <Badge variant={selectedRole.includes('руководитель') || selectedRole === 'admin' ? 'default' : 'secondary'}>
          {roles.find(r => r.value === selectedRole)?.label || 'Сотрудник'}
        </Badge>
      </div>
    </div>
  );
};