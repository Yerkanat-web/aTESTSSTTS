import { Card, CardContent } from "@/components/ui/card";

export const TestCredentialsCard = () => {
  return (
    <Card className="mt-4 bg-muted/30 border-muted">
      <CardContent className="pt-4">
        <h4 className="text-sm font-medium mb-2">Тестовые данные:</h4>
        <div className="space-y-2 text-xs text-muted-foreground">
          <p>Для входа используйте email сотрудника из системы и пароль: <strong>Qwerty56</strong></p>
          <p>Или создайте новый аккаунт через регистрацию</p>
        </div>
      </CardContent>
    </Card>
  );
};