import { Button } from "@/components/ui/button";
import { Zap, ArrowLeft } from "lucide-react";

interface AuthHeaderProps {
  mode: 'login' | 'register';
  onBack: () => void;
}

export const AuthHeader = ({ mode, onBack }: AuthHeaderProps) => {
  return (
    <div className="text-center mb-8">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="absolute top-4 left-4 md:top-8 md:left-8"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Назад
      </Button>
      
      <div className="flex items-center justify-center space-x-3 mb-4">
        <div className="bg-gradient-primary p-3 rounded-xl shadow-glow">
          <Zap className="h-8 w-8 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Pimmi Team
          </h1>
        </div>
      </div>
      <p className="text-muted-foreground">
        {mode === 'login' ? 'Войдите в свой аккаунт' : 'Создайте новый аккаунт'}
      </p>
    </div>
  );
};