import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Loader2 } from "lucide-react";

interface LoginFormProps {
  credentials: {
    email: string;
    password: string;
  };
  showPassword: boolean;
  isLoading: boolean;
  onCredentialsChange: (credentials: { email: string; password: string; name: string; position: string; department: string; }) => void;
  onShowPasswordToggle: () => void;
  onSubmit: () => void;
}

export const LoginForm = ({
  credentials,
  showPassword,
  isLoading,
  onCredentialsChange,
  onShowPasswordToggle,
  onSubmit
}: LoginFormProps) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={credentials.email}
          onChange={(e) => onCredentialsChange({
            ...credentials,
            email: e.target.value,
            name: "",
            position: "",
            department: ""
          })}
          placeholder="Введите ваш email"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="password">Пароль</Label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? "text" : "password"}
            value={credentials.password}
            onChange={(e) => onCredentialsChange({
              ...credentials,
              password: e.target.value,
              name: "",
              position: "",
              department: ""
            })}
            placeholder="Введите пароль"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onSubmit();
              }
            }}
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="absolute right-0 top-0 h-full px-3"
            onClick={onShowPasswordToggle}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <Button 
        onClick={onSubmit}
        disabled={isLoading}
        className="w-full bg-gradient-primary text-primary-foreground shadow-elegant"
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Вход...
          </>
        ) : (
          'Войти'
        )}
      </Button>
    </div>
  );
};