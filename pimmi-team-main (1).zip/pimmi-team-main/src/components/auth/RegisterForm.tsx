
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { RoleSelector } from "./RoleSelector";

interface RegisterFormProps {
  credentials: {
    email: string;
    password: string;
    name: string;
    position: string;
    department: string;
  };
  selectedRole: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
  showPassword: boolean;
  isLoading: boolean;
  departments: string[];
  createOrg: boolean;
  orgName: string;
  orgCode: string; // новое поле
  onCredentialsChange: (credentials: { email: string; password: string; name: string; position: string; department: string; }) => void;
  onRoleChange: (role: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела') => void;
  onShowPasswordToggle: () => void;
  onCreateOrgChange: (value: boolean) => void;
  onOrgNameChange: (value: string) => void;
  onOrgCodeChange: (value: string) => void; // обработчик кода
  onSubmit: () => void;
}

export const RegisterForm = ({
  credentials,
  selectedRole,
  showPassword,
  isLoading,
  departments,
  createOrg,
  orgName,
  orgCode,
  onCredentialsChange,
  onRoleChange,
  onShowPasswordToggle,
  onCreateOrgChange,
  onOrgNameChange,
  onOrgCodeChange,
  onSubmit
}: RegisterFormProps) => {
  return (
    <div className="space-y-4">
      {/* Выбор роли */}
      <RoleSelector 
        selectedRole={selectedRole}
        onRoleChange={onRoleChange}
      />

      {/* Создание организации */}
      <div className="flex items-center justify-between">
        <Label htmlFor="create-org">Создать новую организацию</Label>
        <Switch id="create-org" checked={createOrg} onCheckedChange={onCreateOrgChange} />
      </div>
      {createOrg ? (
        <div className="space-y-2">
          <Label htmlFor="org-name">Название бизнеса *</Label>
          <Input
            id="org-name"
            value={orgName}
            onChange={(e) => onOrgNameChange(e.target.value)}
            placeholder="Например: ООО «Новая компания»"
          />
          <p className="text-xs text-muted-foreground">Вы станете владельцем и администратором этой организации.</p>
        </div>
      ) : (
        <div className="space-y-2">
          <Label htmlFor="org-code">Код организации *</Label>
          <Input
            id="org-code"
            value={orgCode}
            onChange={(e) => onOrgCodeChange(e.target.value)}
            placeholder="Например: A1B2C3D4E5"
            className="uppercase"
          />
          <p className="text-xs text-muted-foreground">Попросите этот код у администратора вашей организации.</p>
        </div>
      )}

      {/* Общие поля */}
      <div className="space-y-2">
        <Label htmlFor="reg-name">Полное имя *</Label>
        <Input
          id="reg-name"
          value={credentials.name}
          onChange={(e) => onCredentialsChange({...credentials, name: e.target.value})}
          placeholder="Введите ваше имя"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="reg-email">Email *</Label>
        <Input
          id="reg-email"
          type="email"
          value={credentials.email}
          onChange={(e) => onCredentialsChange({...credentials, email: e.target.value})}
          placeholder="Введите email"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="reg-password">Пароль *</Label>
        <div className="relative">
          <Input
            id="reg-password"
            type={showPassword ? "text" : "password"}
            value={credentials.password}
            onChange={(e) => onCredentialsChange({...credentials, password: e.target.value})}
            placeholder="Создайте пароль"
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="absolute right-0 top-0 h-full px-3"
            onClick={onShowPasswordToggle}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Поля для сотрудника и руководителей */}
      {(selectedRole === 'employee' || selectedRole.includes('руководитель') || selectedRole === 'финансист') && !createOrg && (
        <>
          <div className="space-y-2">
            <Label htmlFor="position">Должность *</Label>
            <Input
              id="position"
              value={credentials.position}
              onChange={(e) => onCredentialsChange({...credentials, position: e.target.value})}
              placeholder="Например: Разработчик"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="department">Отдел *</Label>
            <Select
              value={credentials.department}
              onValueChange={(value) => onCredentialsChange({...credentials, department: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Выберите отдел" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </>
      )}

      <Button 
        onClick={onSubmit}
        disabled={isLoading}
        className="w-full bg-gradient-primary text-primary-foreground shadow-elegant"
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Создаем аккаунт...
          </>
        ) : (
          createOrg
            ? 'Создать организацию и аккаунт администратора'
            : `Создать аккаунт ${selectedRole === 'admin' ? 'администратора' : selectedRole.includes('руководитель') ? 'руководителя' : 'сотрудника'}`
        )}
      </Button>
    </div>
  );
};
