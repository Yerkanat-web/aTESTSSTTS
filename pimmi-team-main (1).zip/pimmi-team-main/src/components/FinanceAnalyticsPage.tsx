import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, ComposedChart } from "recharts";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { ru } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, TrendingUp, TrendingDown, CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { DateRange } from "react-day-picker";

interface SalesAnalytics {
  totalSales: number;
  totalAmount: number;
  averageSaleAmount: number;
  salesByManager: {
    managerName: string;
    salesCount: number;
    totalAmount: number;
  }[];
  salesByMonth: {
    month: string;
    count: number;
    amount: number;
  }[];
  salesByType: {
    type: string;
    count: number;
    amount: number;
  }[];
}

interface TestProjectAnalytics {
  totalTestProjects: number;
  totalTestAmount: number;
  averageTestAmount: number;
  testConversions: number;
  testConversionRate: number;
  totalConvertedAmount: number;
  averageConvertedAmount: number;
  testProjectsByMonth: {
    month: string;
    monthSort: string;
    testCount: number;
    testAmount: number;
    convertedCount: number;
    convertedAmount: number;
    conversionRate: number;
  }[];
  testProjectsList: {
    id: string;
    projectName: string;
    clientName: string;
    testDate: string;
    testAmount: number;
    isConverted: boolean;
    convertedDate?: string;
    convertedAmount?: number;
    managerName: string;
  }[];
}

interface ExtensionAnalytics {
  totalExtensions: number;
  totalExtensionAmount: number;
  averageExtensionAmount: number;
  totalPrepaymentAmount: number;
  averagePrepaymentAmount: number;
  prepaymentPercentage: number;
  extensionsByMonth: {
    month: string;
    count: number;
    amount: number;
  }[];
  extensionsRatio: {
    name: string;
    value: number;
  }[];
  conversionRate: number;
}

interface FullProjectsAnalytics {
  totalFullProjects: number;
  totalAmount: number;
  averageAmount: number;
  projectsWithExtensions: number;
  projectsWithoutExtensions: number;
  extensionRate: number;
  totalExtensionAmount: number;
  averageExtensionAmount: number;
  monthlyData: {
    month: string;
    monthSort: string;
    originalProjects: number;
    originalAmount: number;
    extensionsCreated: number;
    extensionAmount: number;
  }[];
  fullProjectsList: {
    id: string;
    projectName: string;
    clientName: string;
    originalDate: string;
    originalAmount: number;
    hasExtensions: boolean;
    extensionsCount: number;
    extensionAmount: number;
    totalLTV: number;
    managerName: string;
  }[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658', '#8dd1e1'];

export const FinanceAnalyticsPage = () => {
  const [salesAnalytics, setSalesAnalytics] = useState<SalesAnalytics | null>(null);
  const [testProjectAnalytics, setTestProjectAnalytics] = useState<TestProjectAnalytics | null>(null);
  const [extensionAnalytics, setExtensionAnalytics] = useState<ExtensionAnalytics | null>(null);
  const [fullProjectsAnalytics, setFullProjectsAnalytics] = useState<FullProjectsAnalytics | null>(null);
  const [extensionsList, setExtensionsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('6months');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [activeTab, setActiveTab] = useState('sales');
  const [onetimeAnalytics, setOnetimeAnalytics] = useState<SalesAnalytics | null>(null);
  const [onetimeProjectsList, setOnetimeProjectsList] = useState<any[]>([]);
  const [extensionDialogOpen, setExtensionDialogOpen] = useState(false);
  const [selectedExtensionSequence, setSelectedExtensionSequence] = useState<number | null>(null);
  const [testProjectsSortBy, setTestProjectsSortBy] = useState<'date' | 'conversion_date'>('date');
  const [testProjectsSortOrder, setTestProjectsSortOrder] = useState<'asc' | 'desc'>('desc');
  const [fullProjectsSortBy, setFullProjectsSortBy] = useState<'date'>('date');
  const [fullProjectsSortOrder, setFullProjectsSortOrder] = useState<'asc' | 'desc'>('desc');
  const [onetimeProjectsSortOrder, setOnetimeProjectsSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    fetchAnalytics();
  }, [period, dateRange]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetchSalesAnalytics(),
        fetchTestProjectAnalytics(),
        fetchExtensionAnalytics(),
        fetchFullProjectsAnalytics(),
        fetchOnetimeAnalytics()
      ]);
    } catch (error) {
      console.error("Error fetching analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSalesAnalytics = async () => {
    const dateRangeData = getDateRange(period, dateRange);
    
    // Fetch sales data from the database
    const { data: salesData, error: salesError } = await supabase
      .from('sales_results')
      .select(`
        id, 
        employee_id, 
        sale_amount, 
        sale_date,
        project_type,
        is_extension
      `)
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate)
      .order('sale_date', { ascending: false });

    if (salesError) {
      console.error("Error fetching sales data:", salesError);
      return;
    }

    // Fetch employees data separately
    const { data: employeesData, error: employeesError } = await supabase
      .from('employees')
      .select('id, name');

    if (employeesError) {
      console.error("Error fetching employees data:", employeesError);
      return;
    }

    // Create a map for quick employee lookup
    const employeeMap = new Map(employeesData?.map(emp => [emp.id, emp.name]) || []);

    console.log("Sales data fetched:", salesData?.length, "records");
    console.log("Employees data fetched:", employeesData?.length, "records");
    console.log("Employee map:", Array.from(employeeMap.entries()));
    console.log("Sample sales with employee_id:", salesData?.slice(0, 5).map(s => ({ employee_id: s.employee_id, sale_amount: s.sale_amount })));

    // Filter out extensions
    const sales = salesData?.filter(item => !item.is_extension) || [];
    console.log("Filtered sales (non-extensions):", sales.length, "records");
    
    // Calculate total metrics
    const totalSales = sales.length;
    const totalAmount = sales.reduce((sum, item) => sum + (item.sale_amount || 0), 0);
    const averageSaleAmount = totalSales > 0 ? totalAmount / totalSales : 0;

    // Group by manager
    const managerMap = new Map();
    sales.forEach(sale => {
      const managerName = employeeMap.get(sale.employee_id) || 'Неизвестный менеджер';
      if (!managerMap.has(managerName)) {
        managerMap.set(managerName, { salesCount: 0, totalAmount: 0 });
      }
      
      const managerData = managerMap.get(managerName);
      managerData.salesCount += 1;
      managerData.totalAmount += (sale.sale_amount || 0);
    });

    const salesByManager = Array.from(managerMap.entries()).map(([managerName, data]) => ({
      managerName,
      salesCount: data.salesCount,
      totalAmount: data.totalAmount
    })).sort((a, b) => b.salesCount - a.salesCount);

    console.log("Final manager data:", salesByManager);

    // Group by month
    const monthMap = new Map();
    sales.forEach(sale => {
      const month = format(new Date(sale.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(sale.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!monthMap.has(month)) {
        monthMap.set(month, { month: monthDisplay, monthSort: month, count: 0, amount: 0 });
      }
      
      const monthData = monthMap.get(month);
      monthData.count += 1;
      monthData.amount += (sale.sale_amount || 0);
    });

    const salesByMonth = Array.from(monthMap.values())
      .sort((a, b) => a.monthSort.localeCompare(b.monthSort));

    // Group by project type
    const typeMap = new Map();
    sales.forEach(sale => {
      const type = sale.project_type || 'Не указан';
      
      if (!typeMap.has(type)) {
        typeMap.set(type, { type, count: 0, amount: 0 });
      }
      
      const typeData = typeMap.get(type);
      typeData.count += 1;
      typeData.amount += (sale.sale_amount || 0);
    });

    const salesByType = Array.from(typeMap.values());

    setSalesAnalytics({
      totalSales,
      totalAmount,
      averageSaleAmount,
      salesByManager,
      salesByMonth,
      salesByType,
    });
  };

  const fetchTestProjectAnalytics = async () => {
    const dateRangeData = getDateRange(period, dateRange);
    
    // Fetch test projects
    const { data: testProjects, error: testError } = await supabase
      .from('sales_results')
      .select(`
        id,
        employee_id,
        sale_amount,
        sale_date,
        project_name,
        client_name,
        is_test,
        project_type
      `)
      .or('is_test.eq.true,project_type.eq.Тестовый')
      .eq('is_extension', false)
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate)
      .order('sale_date', { ascending: false });

    if (testError) {
      console.error("Error fetching test projects:", testError);
      return;
    }

    // Fetch converted projects
    const { data: convertedProjects, error: convertedError } = await supabase
      .from('sales_results')
      .select(`
        id,
        employee_id,
        sale_amount,
        sale_date,
        project_name,
        client_name,
        client_type
      `)
      .eq('client_type', 'Перешел из тестового')
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate)
      .order('sale_date', { ascending: false });

    if (convertedError) {
      console.error("Error fetching converted projects:", convertedError);
      return;
    }

    // Fetch employees
    const { data: employeesData } = await supabase
      .from('employees')
      .select('id, name');

    const employeeMap = new Map(employeesData?.map(emp => [emp.id, emp.name]) || []);

    // Calculate basic metrics
    const totalTestProjects = testProjects?.length || 0;
    const totalTestAmount = testProjects?.reduce((sum, project) => sum + (project.sale_amount || 0), 0) || 0;
    const averageTestAmount = totalTestProjects > 0 ? totalTestAmount / totalTestProjects : 0;

    const testConversions = convertedProjects?.length || 0;
    const totalConvertedAmount = convertedProjects?.reduce((sum, project) => sum + (project.sale_amount || 0), 0) || 0;
    const averageConvertedAmount = testConversions > 0 ? totalConvertedAmount / testConversions : 0;
    const testConversionRate = totalTestProjects > 0 ? (testConversions / totalTestProjects) * 100 : 0;

    // Group by month for test projects
    const testMonthMap = new Map();
    testProjects?.forEach(project => {
      const month = format(new Date(project.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(project.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!testMonthMap.has(month)) {
        testMonthMap.set(month, {
          month: monthDisplay,
          monthSort: month,
          testCount: 0,
          testAmount: 0,
          convertedCount: 0,
          convertedAmount: 0,
          conversionRate: 0
        });
      }
      
      const monthData = testMonthMap.get(month);
      monthData.testCount += 1;
      monthData.testAmount += (project.sale_amount || 0);
    });

    // Add converted projects to month data
    convertedProjects?.forEach(project => {
      const month = format(new Date(project.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(project.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!testMonthMap.has(month)) {
        testMonthMap.set(month, {
          month: monthDisplay,
          monthSort: month,
          testCount: 0,
          testAmount: 0,
          convertedCount: 0,
          convertedAmount: 0,
          conversionRate: 0
        });
      }
      
      const monthData = testMonthMap.get(month);
      monthData.convertedCount += 1;
      monthData.convertedAmount += (project.sale_amount || 0);
    });

    // Calculate conversion rates by month
    const testProjectsByMonth = Array.from(testMonthMap.values()).map(monthData => ({
      ...monthData,
      conversionRate: monthData.testCount > 0 ? (monthData.convertedCount / monthData.testCount) * 100 : 0
    })).sort((a, b) => a.monthSort.localeCompare(b.monthSort));

    // Create test projects list with conversion info
    const convertedClientsMap = new Map();
    convertedProjects?.forEach(project => {
      convertedClientsMap.set(project.client_name, {
        convertedDate: project.sale_date,
        convertedAmount: project.sale_amount,
        convertedId: project.id
      });
    });

    const testProjectsList = testProjects?.map(project => {
      const converted = convertedClientsMap.get(project.client_name);
      return {
        id: project.id,
        projectName: project.project_name || 'Не указан',
        clientName: project.client_name || 'Не указан',
        testDate: project.sale_date,
        testAmount: project.sale_amount || 0,
        isConverted: !!converted,
        convertedDate: converted?.convertedDate,
        convertedAmount: converted?.convertedAmount,
        managerName: employeeMap.get(project.employee_id) || 'Неизвестный'
      };
    }) || [];

    setTestProjectAnalytics({
      totalTestProjects,
      totalTestAmount,
      averageTestAmount,
      testConversions,
      testConversionRate,
      totalConvertedAmount,
      averageConvertedAmount,
      testProjectsByMonth,
      testProjectsList
    });
  };

  const fetchExtensionAnalytics = async () => {
    const dateRangeData = getDateRange(period, dateRange);
    
    // Fetch extension data from the database
    const { data: extensionData, error: extensionError } = await supabase
      .from('sales_results')
      .select(`
        id, 
        employee_id, 
        sale_amount, 
        sale_date,
        is_extension,
        parent_project_id,
        extension_sequence,
        project_name,
        client_name,
        project_status,
        remainder,
        remainder_due_date,
        prepayment
      `)
      .eq('is_extension', true)
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate)
      .order('sale_date', { ascending: false });

    if (extensionError) {
      console.error("Error fetching extension data:", extensionError);
      return;
    }

    // Fetch employees data separately for extensions
    const { data: employeesData, error: employeesError } = await supabase
      .from('employees')
      .select('id, name');

    if (employeesError) {
      console.error("Error fetching employees data for extensions:", employeesError);
      return;
    }

    // Create a map for quick employee lookup
    const employeeMap = new Map(employeesData?.map(emp => [emp.id, emp.name]) || []);

    const extensions = extensionData || [];
    
    // Add employee names to extensions for table display
    const extensionsWithEmployees = extensions.map(ext => ({
      ...ext,
      employees: { name: employeeMap.get(ext.employee_id) || 'Неизвестный' }
    }));
    
    // Set extensions list for table display
    setExtensionsList(extensionsWithEmployees);
    
    // Calculate total metrics
    const totalExtensions = extensions.length;
    const totalExtensionAmount = extensions.reduce((sum, item) => sum + (item.sale_amount || 0), 0);
    const averageExtensionAmount = totalExtensions > 0 ? totalExtensionAmount / totalExtensions : 0;
    
    // Calculate prepayment metrics
    const totalPrepaymentAmount = extensions.reduce((sum, item) => sum + (item.prepayment || 0), 0);
    const averagePrepaymentAmount = totalExtensions > 0 ? totalPrepaymentAmount / totalExtensions : 0;
    const prepaymentPercentage = totalExtensionAmount > 0 ? (totalPrepaymentAmount / totalExtensionAmount) * 100 : 0;

    // Get unique parent projects
    const uniqueParents = new Set(extensions.map(ext => ext.parent_project_id));
    
    // Fetch all sales to calculate conversion rate
    const { data: allSales } = await supabase
      .from('sales_results')
      .select('id, is_extension')
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate);
    
    const totalProjects = allSales ? allSales.filter(sale => !sale.is_extension).length : 0;
    const conversionRate = totalProjects > 0 ? (uniqueParents.size / totalProjects) * 100 : 0;

    // Group by month
    const monthMap = new Map();
    extensions.forEach(ext => {
      const month = format(new Date(ext.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(ext.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!monthMap.has(month)) {
        monthMap.set(month, { month: monthDisplay, monthSort: month, count: 0, amount: 0 });
      }
      
      const monthData = monthMap.get(month);
      monthData.count += 1;
      monthData.amount += (ext.sale_amount || 0);
    });

    const extensionsByMonth = Array.from(monthMap.values())
      .sort((a, b) => a.monthSort.localeCompare(b.monthSort));

    // Calculate extension sequence ratio
    const sequenceMap = new Map();
    extensions.forEach(ext => {
      const sequence = `Продление ${ext.extension_sequence}`;
      if (!sequenceMap.has(sequence)) {
        sequenceMap.set(sequence, 0);
      }
      sequenceMap.set(sequence, sequenceMap.get(sequence) + 1);
    });

    const extensionsRatio = Array.from(sequenceMap.entries()).map(([name, value]) => ({
      name,
      value
    })).sort((a, b) => {
      // Sort by sequence number
      const numA = parseInt(a.name.replace('Продление ', ''));
      const numB = parseInt(b.name.replace('Продление ', ''));
      return numA - numB;
    });

    setExtensionAnalytics({
      totalExtensions,
      totalExtensionAmount,
      averageExtensionAmount,
      totalPrepaymentAmount,
      averagePrepaymentAmount,
      prepaymentPercentage,
      extensionsByMonth,
      extensionsRatio,
      conversionRate
    });
  };

  const fetchFullProjectsAnalytics = async () => {
    const dateRangeData = getDateRange(period, dateRange);
    
    // Fetch original monthly projects (not extensions)
    const { data: originalProjects, error: originalError } = await supabase
      .from('sales_results')
      .select(`
        id,
        employee_id,
        sale_amount,
        sale_date,
        project_name,
        client_name
      `)
      .eq('project_type', 'Ежемесячный')
      .eq('is_extension', false)
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate)
      .order('sale_date', { ascending: false });

    if (originalError) {
      console.error("Error fetching original projects:", originalError);
      return;
    }

    // Fetch all extensions for these projects
    const originalProjectIds = originalProjects?.map(p => p.id) || [];
    const { data: extensions, error: extensionsError } = await supabase
      .from('sales_results')
      .select(`
        id,
        parent_project_id,
        sale_amount,
        sale_date
      `)
      .eq('is_extension', true)
      .in('parent_project_id', originalProjectIds);

    if (extensionsError) {
      console.error("Error fetching extensions:", extensionsError);
      return;
    }

    // Fetch employees data
    const { data: employeesData } = await supabase
      .from('employees')
      .select('id, name');

    const employeeMap = new Map(employeesData?.map(emp => [emp.id, emp.name]) || []);

    // Calculate basic metrics
    const totalFullProjects = originalProjects?.length || 0;
    const totalAmount = originalProjects?.reduce((sum, project) => sum + (project.sale_amount || 0), 0) || 0;
    const averageAmount = totalFullProjects > 0 ? totalAmount / totalFullProjects : 0;

    // Group extensions by parent project
    const extensionsByParent = new Map();
    extensions?.forEach(ext => {
      if (!extensionsByParent.has(ext.parent_project_id)) {
        extensionsByParent.set(ext.parent_project_id, []);
      }
      extensionsByParent.get(ext.parent_project_id).push(ext);
    });

    const projectsWithExtensions = extensionsByParent.size;
    const projectsWithoutExtensions = totalFullProjects - projectsWithExtensions;
    const extensionRate = totalFullProjects > 0 ? (projectsWithExtensions / totalFullProjects) * 100 : 0;

    const totalExtensionAmount = extensions?.reduce((sum, ext) => sum + (ext.sale_amount || 0), 0) || 0;
    const averageExtensionAmount = extensions?.length > 0 ? totalExtensionAmount / extensions.length : 0;

    // Create monthly data
    const monthMap = new Map();
    originalProjects?.forEach(project => {
      const month = format(new Date(project.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(project.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!monthMap.has(month)) {
        monthMap.set(month, {
          month: monthDisplay,
          monthSort: month,
          originalProjects: 0,
          originalAmount: 0,
          extensionsCreated: 0,
          extensionAmount: 0
        });
      }
      
      const monthData = monthMap.get(month);
      monthData.originalProjects += 1;
      monthData.originalAmount += (project.sale_amount || 0);
    });

    // Add extension data to monthly data
    extensions?.forEach(ext => {
      const month = format(new Date(ext.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(ext.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!monthMap.has(month)) {
        monthMap.set(month, {
          month: monthDisplay,
          monthSort: month,
          originalProjects: 0,
          originalAmount: 0,
          extensionsCreated: 0,
          extensionAmount: 0
        });
      }
      
      const monthData = monthMap.get(month);
      monthData.extensionsCreated += 1;
      monthData.extensionAmount += (ext.sale_amount || 0);
    });

    const monthlyData = Array.from(monthMap.values())
      .sort((a, b) => a.monthSort.localeCompare(b.monthSort));

    // Create full projects list with extension info
    const fullProjectsList = originalProjects?.map(project => {
      const projectExtensions = extensionsByParent.get(project.id) || [];
      const extensionsCount = projectExtensions.length;
      const extensionAmount = projectExtensions.reduce((sum, ext) => sum + (ext.sale_amount || 0), 0);
      const totalLTV = (project.sale_amount || 0) + extensionAmount;

      return {
        id: project.id,
        projectName: project.project_name || 'Не указан',
        clientName: project.client_name || 'Не указан',
        originalDate: project.sale_date,
        originalAmount: project.sale_amount || 0,
        hasExtensions: extensionsCount > 0,
        extensionsCount,
        extensionAmount,
        totalLTV,
        managerName: employeeMap.get(project.employee_id) || 'Неизвестный'
      };
    }) || [];

    setFullProjectsAnalytics({
      totalFullProjects,
      totalAmount,
      averageAmount,
      projectsWithExtensions,
      projectsWithoutExtensions,
      extensionRate,
      totalExtensionAmount,
      averageExtensionAmount,
      monthlyData,
      fullProjectsList
    });
  };

  const fetchOnetimeAnalytics = async () => {
    console.log('fetchOnetimeAnalytics started');
    const dateRangeData = getDateRange(period, dateRange);
    console.log('Date range:', dateRangeData);
    
    // Fetch one-time projects data from the database
    const { data: salesData, error: salesError } = await supabase
      .from('sales_results')
      .select(`
        id, 
        employee_id, 
        sale_amount, 
        sale_date,
        project_type,
        is_extension,
        project_name,
        client_name
      `)
      .eq('project_type', 'Единоразовый')
      .eq('is_extension', false)
      .gte('sale_date', dateRangeData.startDate)
      .lte('sale_date', dateRangeData.endDate)
      .order('sale_date', { ascending: false });

    console.log('One-time projects query result:', { salesData, salesError, count: salesData?.length });

    if (salesError) {
      console.error("Error fetching one-time projects data:", salesError);
      return;
    }

    // Fetch employees data separately
    const { data: employeesData, error: employeesError } = await supabase
      .from('employees')
      .select('id, name');

    if (employeesError) {
      console.error("Error fetching employees data:", employeesError);
      return;
    }

    // Create a map for quick employee lookup
    const employeeMap = new Map(employeesData?.map(emp => [emp.id, emp.name]) || []);

    const sales = salesData || [];
    
    // Calculate total metrics
    const totalSales = sales.length;
    const totalAmount = sales.reduce((sum, item) => sum + (item.sale_amount || 0), 0);
    const averageSaleAmount = totalSales > 0 ? totalAmount / totalSales : 0;

    // Group by manager
    const managerMap = new Map();
    sales.forEach(sale => {
      const managerName = employeeMap.get(sale.employee_id) || 'Неизвестный менеджер';
      if (!managerMap.has(managerName)) {
        managerMap.set(managerName, { salesCount: 0, totalAmount: 0 });
      }
      
      const managerData = managerMap.get(managerName);
      managerData.salesCount += 1;
      managerData.totalAmount += (sale.sale_amount || 0);
    });

    const salesByManager = Array.from(managerMap.entries()).map(([managerName, data]) => ({
      managerName,
      salesCount: data.salesCount,
      totalAmount: data.totalAmount
    })).sort((a, b) => b.salesCount - a.salesCount);

    // Group by month
    const monthMap = new Map();
    sales.forEach(sale => {
      const month = format(new Date(sale.sale_date), 'yyyy-MM');
      const monthDisplay = format(new Date(sale.sale_date), 'LLL yyyy', { locale: ru });
      
      if (!monthMap.has(month)) {
        monthMap.set(month, { month: monthDisplay, monthSort: month, count: 0, amount: 0 });
      }
      
      const monthData = monthMap.get(month);
      monthData.count += 1;
      monthData.amount += (sale.sale_amount || 0);
    });

    const salesByMonth = Array.from(monthMap.values())
      .sort((a, b) => a.monthSort.localeCompare(b.monthSort));

    // Group by project type (all will be "Единоразовый" but keeping structure)
    const salesByType = [{
      type: 'Единоразовый',
      count: totalSales,
      amount: totalAmount
    }];

    // Create projects list
    const onetimeProjectsList = sales.map(project => ({
      id: project.id,
      projectName: project.project_name || 'Не указан',
      clientName: project.client_name || 'Не указан', 
      saleDate: project.sale_date,
      saleAmount: project.sale_amount || 0,
      managerName: employeeMap.get(project.employee_id) || 'Неизвестный'
    }));

    setOnetimeAnalytics({
      totalSales,
      totalAmount,
      averageSaleAmount,
      salesByManager,
      salesByMonth,
      salesByType,
    });
    
    setOnetimeProjectsList(onetimeProjectsList);
  };

  const getDateRange = (period: string, customRange?: DateRange) => {
    if (period === 'custom' && customRange?.from && customRange?.to) {
      return {
        startDate: format(customRange.from, 'yyyy-MM-dd'),
        endDate: format(customRange.to, 'yyyy-MM-dd')
      };
    }
    
    const endDate = format(endOfMonth(new Date()), 'yyyy-MM-dd');
    let startDate = '';
    
    switch (period) {
      case '3months':
        startDate = format(startOfMonth(subMonths(new Date(), 2)), 'yyyy-MM-dd');
        break;
      case '6months':
        startDate = format(startOfMonth(subMonths(new Date(), 5)), 'yyyy-MM-dd');
        break;
      case '12months':
        startDate = format(startOfMonth(subMonths(new Date(), 11)), 'yyyy-MM-dd');
        break;
      default:
        startDate = format(startOfMonth(subMonths(new Date(), 5)), 'yyyy-MM-dd');
    }
    
    return { startDate, endDate };
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ru-RU', { 
      style: 'currency', 
      currency: 'KZT',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    }).replace('KZT', '₸');
  };
  
  const formatPercentage = (value: number) => {
    return value.toFixed(1) + '%';
  };

  const getConversionRateColor = (rate: number) => {
    if (rate >= 15) return 'text-green-600';
    if (rate >= 10) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getConversionRateIcon = (rate: number) => {
    if (rate >= 15) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (rate >= 10) return <TrendingUp className="h-4 w-4 text-yellow-600" />;
    return <TrendingDown className="h-4 w-4 text-red-600" />;
  };

  const sortTestProjects = (projects: typeof testProjectAnalytics.testProjectsList) => {
    return [...projects].sort((a, b) => {
      let aValue: string, bValue: string;
      
      if (testProjectsSortBy === 'date') {
        aValue = a.testDate;
        bValue = b.testDate;
      } else {
        aValue = a.convertedDate || '9999-12-31';
        bValue = b.convertedDate || '9999-12-31';
      }
      
      const comparison = aValue.localeCompare(bValue);
      return testProjectsSortOrder === 'asc' ? comparison : -comparison;
    });
  };

  const sortFullProjects = (projects: typeof fullProjectsAnalytics.fullProjectsList) => {
    return [...projects].sort((a, b) => {
      const aValue = a.originalDate;
      const bValue = b.originalDate;
      
      const comparison = aValue.localeCompare(bValue);
      return fullProjectsSortOrder === 'asc' ? comparison : -comparison;
    });
  };

  return (
    <div className="container mx-auto py-6 space-y-6 animate-fade-in">
      <h1 className="text-3xl font-bold">Финансовая аналитика</h1>
      
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Выберите период" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3months">За 3 месяца</SelectItem>
              <SelectItem value="6months">За 6 месяцев</SelectItem>
              <SelectItem value="12months">За 12 месяцев</SelectItem>
              <SelectItem value="custom">Произвольный период</SelectItem>
            </SelectContent>
          </Select>
          
          {period === 'custom' && (
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[280px] justify-start text-left font-normal",
                    !dateRange && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "dd.MM.yyyy")} -{" "}
                        {format(dateRange.to, "dd.MM.yyyy")}
                      </>
                    ) : (
                      format(dateRange.from, "dd.MM.yyyy")
                    )
                  ) : (
                    <span>Выберите диапазон дат</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
          )}
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="sales">Аналитика продаж</TabsTrigger>
          <TabsTrigger value="test-projects">Тестовые проекты</TabsTrigger>
          <TabsTrigger value="extensions">Аналитика продлений</TabsTrigger>
          <TabsTrigger value="full-projects">Полноценные проекты</TabsTrigger>
          <TabsTrigger value="onetime">Единаразовый</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sales" className="space-y-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : salesAnalytics ? (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Всего продаж
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{salesAnalytics.totalSales}</div>
                    <p className="text-xs text-muted-foreground">
                      за выбранный период
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Общая сумма продаж
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(salesAnalytics.totalAmount)}</div>
                    <p className="text-xs text-muted-foreground">
                      за выбранный период
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Средняя сумма сделки
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(salesAnalytics.averageSaleAmount)}</div>
                    <p className="text-xs text-muted-foreground">
                      за выбранный период
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Sales by Month Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Динамика продаж по месяцам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={salesAnalytics.salesByMonth}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                        <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                        <Tooltip formatter={(value, name) => {
                          if (name === "count") return [`${value} продаж`, "Количество"];
                          if (name === "amount") return [formatCurrency(value as number), "Сумма"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Line yAxisId="left" type="monotone" dataKey="count" name="Количество продаж" stroke="#8884d8" activeDot={{ r: 8 }} />
                        <Line yAxisId="right" type="monotone" dataKey="amount" name="Сумма продаж" stroke="#82ca9d" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Sales by Manager Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Продажи по менеджерам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={salesAnalytics.salesByManager}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 60,
                        }}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis type="category" dataKey="managerName" width={150} />
                        <Tooltip formatter={(value, name) => {
                          if (name === "salesCount") return [`${value} продаж`, "Количество"];
                          if (name === "totalAmount") return [formatCurrency(value as number), "Сумма"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Bar dataKey="salesCount" name="Количество продаж" fill="#8884d8" />
                        <Bar dataKey="totalAmount" name="Сумма продаж" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Detailed Sales by Type Analysis */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Sales by Type Pie Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Распределение продаж по типам</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={salesAnalytics.salesByType}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="count"
                            nameKey="type"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {salesAnalytics.salesByType.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value, name, props) => {
                            if (props.dataKey === "count") return [`${value} продаж`, props.payload.type];
                            return [formatCurrency(value as number), props.payload.type];
                          }} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* Sales by Type Bar Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Сравнение по типам проектов</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={salesAnalytics.salesByType}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="type" />
                          <YAxis yAxisId="left" orientation="left" />
                          <YAxis yAxisId="right" orientation="right" />
                          <Tooltip formatter={(value, name) => {
                            if (name === "count") return [`${value} шт`, "Количество"];
                            if (name === "amount") return [formatCurrency(value as number), "Сумма"];
                            return [value, name];
                          }} />
                          <Legend />
                          <Bar yAxisId="left" dataKey="count" name="Количество" fill="#8884d8" />
                          <Bar yAxisId="right" dataKey="amount" name="Сумма" fill="#82ca9d" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Detailed Project Types Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Детальная аналитика по типам проектов</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Тип проекта</TableHead>
                          <TableHead>Количество продаж</TableHead>
                          <TableHead>Общая сумма</TableHead>
                          <TableHead>Средняя сумма</TableHead>
                          <TableHead>Доля в общем объеме</TableHead>
                          <TableHead>Доля по количеству</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {salesAnalytics.salesByType.map((typeData, index) => {
                          const averageAmount = typeData.count > 0 ? typeData.amount / typeData.count : 0;
                          const amountShare = ((typeData.amount / salesAnalytics.totalAmount) * 100);
                          const countShare = ((typeData.count / salesAnalytics.totalSales) * 100);
                          
                          return (
                            <TableRow key={typeData.type}>
                              <TableCell className="font-medium">
                                <div className="flex items-center space-x-2">
                                  <div 
                                    className="w-3 h-3 rounded-full" 
                                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                                  />
                                  <span>{typeData.type}</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline">
                                  {typeData.count}
                                </Badge>
                              </TableCell>
                              <TableCell className="font-semibold">
                                {formatCurrency(typeData.amount)}
                              </TableCell>
                              <TableCell>
                                {formatCurrency(averageAmount)}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <div className="flex-1 bg-secondary h-2 rounded-full overflow-hidden">
                                    <div 
                                      className="h-full transition-all duration-500"
                                      style={{ 
                                        width: `${amountShare}%`,
                                        backgroundColor: COLORS[index % COLORS.length]
                                      }}
                                    />
                                  </div>
                                  <span className="text-sm font-medium">
                                    {amountShare.toFixed(1)}%
                                  </span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <div className="flex-1 bg-secondary h-2 rounded-full overflow-hidden">
                                    <div 
                                      className="h-full transition-all duration-500"
                                      style={{ 
                                        width: `${countShare}%`,
                                        backgroundColor: COLORS[index % COLORS.length]
                                      }}
                                    />
                                  </div>
                                  <span className="text-sm font-medium">
                                    {countShare.toFixed(1)}%
                                  </span>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Нет данных для отображения
            </div>
          )}
        </TabsContent>

        <TabsContent value="test-projects" className="space-y-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : testProjectAnalytics ? (
            <>
              {/* Test Projects Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Тестовые проекты
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{testProjectAnalytics.totalTestProjects}</div>
                    <p className="text-xs text-muted-foreground">проектов</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Сумма тестов
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(testProjectAnalytics.totalTestAmount)}</div>
                    <p className="text-xs text-muted-foreground">общая сумма</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Конверсии
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{testProjectAnalytics.testConversions}</div>
                    <p className="text-xs text-muted-foreground">проектов</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Коэффициент конверсии
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold flex items-center gap-2 ${getConversionRateColor(testProjectAnalytics.testConversionRate)}`}>
                      <span>{formatPercentage(testProjectAnalytics.testConversionRate)}</span>
                      {getConversionRateIcon(testProjectAnalytics.testConversionRate)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {testProjectAnalytics.testConversionRate >= 15 ? 'Отличный' : 
                       testProjectAnalytics.testConversionRate >= 10 ? 'Хороший' : 'Низкий'} показатель
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Сумма конверсий
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(testProjectAnalytics.totalConvertedAmount)}</div>
                    <p className="text-xs text-muted-foreground">общая сумма</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Средняя конверсия
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(testProjectAnalytics.averageConvertedAmount)}</div>
                    <p className="text-xs text-muted-foreground">за проект</p>
                  </CardContent>
                </Card>
              </div>

              {/* Test Projects by Month Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Динамика тестовых проектов и конверсий по месяцам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart
                        data={testProjectAnalytics.testProjectsByMonth}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis yAxisId="left" orientation="left" />
                        <YAxis yAxisId="right" orientation="right" />
                        <Tooltip formatter={(value, name) => {
                          if (name === "testCount") return [`${value} тестов`, "Количество тестов"];
                          if (name === "convertedCount") return [`${value} конверсий`, "Количество конверсий"];
                          if (name === "conversionRate") return [`${(value as number).toFixed(1)}%`, "Коэффициент конверсии"];
                          if (name === "testAmount") return [formatCurrency(value as number), "Сумма тестов"];
                          if (name === "convertedAmount") return [formatCurrency(value as number), "Сумма конверсий"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Bar yAxisId="left" dataKey="testCount" name="Тестовые проекты" fill="#8884d8" />
                        <Bar yAxisId="left" dataKey="convertedCount" name="Конверсии" fill="#82ca9d" />
                        <Line yAxisId="right" type="monotone" dataKey="conversionRate" name="Коэффициент конверсии %" stroke="#ff7300" strokeWidth={3} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Test Projects Amount Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Суммы тестовых проектов и конверсий по месяцам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={testProjectAnalytics.testProjectsByMonth}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value, name) => {
                          if (name === "testAmount") return [formatCurrency(value as number), "Сумма тестов"];
                          if (name === "convertedAmount") return [formatCurrency(value as number), "Сумма конверсий"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Bar dataKey="testAmount" name="Сумма тестовых проектов" fill="#8884d8" />
                        <Bar dataKey="convertedAmount" name="Сумма конверсий" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Test Projects List Table */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle>Детальный список тестовых проектов</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Select value={testProjectsSortBy} onValueChange={(value: 'date' | 'conversion_date') => setTestProjectsSortBy(value)}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="date">По дате теста</SelectItem>
                        <SelectItem value="conversion_date">По дате конверсии</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={testProjectsSortOrder} onValueChange={(value: 'asc' | 'desc') => setTestProjectsSortOrder(value)}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="desc">Сначала новые</SelectItem>
                        <SelectItem value="asc">Сначала старые</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Проект/Клиент</TableHead>
                          <TableHead>Менеджер</TableHead>
                          <TableHead>Дата теста</TableHead>
                          <TableHead>Сумма теста</TableHead>
                          <TableHead>Статус</TableHead>
                          <TableHead>Дата конверсии</TableHead>
                          <TableHead>Сумма конверсии</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {testProjectAnalytics.testProjectsList.length > 0 ? (
                          sortTestProjects(testProjectAnalytics.testProjectsList).map((project) => (
                            <TableRow key={project.id}>
                              <TableCell>
                                <div>
                                  <div className="font-medium">{project.projectName}</div>
                                  <div className="text-sm text-muted-foreground">{project.clientName}</div>
                                </div>
                              </TableCell>
                              <TableCell>{project.managerName}</TableCell>
                              <TableCell>
                                {format(new Date(project.testDate), 'dd.MM.yyyy')}
                              </TableCell>
                              <TableCell>{formatCurrency(project.testAmount)}</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={project.isConverted ? 'default' : 'secondary'}
                                  className={project.isConverted ? 'bg-green-100 text-green-800' : ''}
                                >
                                  {project.isConverted ? 'Конвертирован' : 'Не конвертирован'}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {project.convertedDate ? 
                                  format(new Date(project.convertedDate), 'dd.MM.yyyy') : 
                                  '-'
                                }
                              </TableCell>
                              <TableCell>
                                {project.convertedAmount ? 
                                  formatCurrency(project.convertedAmount) : 
                                  '-'
                                }
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                              Нет тестовых проектов за выбранный период
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Нет данных для отображения
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="extensions" className="space-y-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : extensionAnalytics ? (
            <>
               {/* Summary Cards */}
               <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                 <Card>
                   <CardHeader className="pb-2">
                     <CardTitle className="text-sm font-medium text-muted-foreground">
                       Всего продлений
                     </CardTitle>
                   </CardHeader>
                   <CardContent>
                     <div className="text-2xl font-bold">{extensionAnalytics.totalExtensions}</div>
                     <p className="text-xs text-muted-foreground">
                       за выбранный период
                     </p>
                   </CardContent>
                 </Card>
                 <Card>
                   <CardHeader className="pb-2">
                     <CardTitle className="text-sm font-medium text-muted-foreground">
                       Общая сумма продлений
                     </CardTitle>
                   </CardHeader>
                   <CardContent>
                     <div className="text-2xl font-bold">{formatCurrency(extensionAnalytics.totalExtensionAmount)}</div>
                     <p className="text-xs text-muted-foreground">
                       за выбранный период
                     </p>
                   </CardContent>
                 </Card>
                 <Card>
                   <CardHeader className="pb-2">
                     <CardTitle className="text-sm font-medium text-muted-foreground">
                       Средняя сумма продления
                     </CardTitle>
                   </CardHeader>
                   <CardContent>
                     <div className="text-2xl font-bold">{formatCurrency(extensionAnalytics.averageExtensionAmount)}</div>
                     <p className="text-xs text-muted-foreground">
                       за выбранный период
                     </p>
                   </CardContent>
                 </Card>
                 <Card>
                   <CardHeader className="pb-2">
                     <CardTitle className="text-sm font-medium text-muted-foreground">
                       Коэффициент продления
                     </CardTitle>
                   </CardHeader>
                   <CardContent>
                     <div className="text-2xl font-bold">{formatPercentage(extensionAnalytics.conversionRate)}</div>
                     <p className="text-xs text-muted-foreground">
                       % проектов, оформивших продление
                     </p>
                   </CardContent>
                 </Card>
                 <Card>
                   <CardHeader className="pb-2">
                     <CardTitle className="text-sm font-medium text-muted-foreground">
                       Общая предоплата
                     </CardTitle>
                   </CardHeader>
                   <CardContent>
                     <div className="text-2xl font-bold">{formatCurrency(extensionAnalytics.totalPrepaymentAmount)}</div>
                     <p className="text-xs text-muted-foreground">
                       от общей суммы продлений
                     </p>
                   </CardContent>
                 </Card>
                </div>

               {/* Extensions by Sequence */}
               <Card>
                 <CardHeader>
                   <CardTitle>Распределение по месяцам продления</CardTitle>
                   <p className="text-sm text-muted-foreground">
                     Количество проектов, продленных на 1-й, 2-й месяц и т.д.
                   </p>
                 </CardHeader>
                 <CardContent>
                   <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                     {Array.from({ length: 6 }, (_, index) => {
                       const sequenceNumber = index + 1;
                       const count = extensionsList.filter(ext => ext.extension_sequence === sequenceNumber).length;
                       return (
                          <div 
                            key={sequenceNumber} 
                            className="text-center p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                            onClick={() => {
                              setSelectedExtensionSequence(sequenceNumber);
                              setExtensionDialogOpen(true);
                            }}
                          >
                            <div className="text-2xl font-bold text-primary">{count}</div>
                            <div className="text-sm text-muted-foreground">
                              {sequenceNumber}-й месяц
                            </div>
                          </div>
                       );
                     })}
                   </div>
                 </CardContent>
               </Card>

               {/* Extensions List Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Список продлений проектов</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Дата продления</TableHead>
                          <TableHead>Проект</TableHead>
                          <TableHead>Клиент</TableHead>
                          <TableHead>Менеджер</TableHead>
                          <TableHead>Номер продления</TableHead>
                          <TableHead>Сумма</TableHead>
                          <TableHead>Остаток</TableHead>
                          <TableHead>Статус</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {extensionsList.length > 0 ? (
                          extensionsList.map((extension) => (
                            <TableRow key={extension.id}>
                              <TableCell>
                                {format(new Date(extension.sale_date), 'dd.MM.yyyy')}
                              </TableCell>
                              <TableCell>{extension.project_name || 'Не указан'}</TableCell>
                              <TableCell>{extension.client_name || 'Не указан'}</TableCell>
                              <TableCell>{extension.employees?.name || 'Не указан'}</TableCell>
                              <TableCell>
                                <Badge variant="outline">
                                  {extension.extension_sequence}
                                </Badge>
                              </TableCell>
                              <TableCell>{formatCurrency(extension.sale_amount || 0)}</TableCell>
                              <TableCell>
                                {extension.remainder ? formatCurrency(extension.remainder) : '0 ₸'}
                              </TableCell>
                              <TableCell>
                                <Badge 
                                  variant={
                                    extension.project_status === 'Работаем' 
                                      ? 'default' 
                                      : extension.project_status === 'Завершили работу'
                                      ? 'secondary'
                                      : 'outline'
                                  }
                                >
                                  {extension.project_status || 'Не указан'}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                              Нет продлений за выбранный период
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Extensions by Month Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Динамика продлений по месяцам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={extensionAnalytics.extensionsByMonth}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                        <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                        <Tooltip formatter={(value, name) => {
                          if (name === "count") return [`${value} продлений`, "Количество"];
                          if (name === "amount") return [formatCurrency(value as number), "Сумма"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Line yAxisId="left" type="monotone" dataKey="count" name="Количество продлений" stroke="#8884d8" activeDot={{ r: 8 }} />
                        <Line yAxisId="right" type="monotone" dataKey="amount" name="Сумма продлений" stroke="#82ca9d" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Extensions Distribution Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Распределение по номеру продления</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={extensionAnalytics.extensionsRatio}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          nameKey="name"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {extensionAnalytics.extensionsRatio.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} продлений`, "Количество"]} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Нет данных для отображения
            </div>
          )}
        </TabsContent>

        <TabsContent value="full-projects" className="space-y-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : fullProjectsAnalytics ? (
            <>
              {/* Full Projects Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Полноценные проекты
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{fullProjectsAnalytics.totalFullProjects}</div>
                    <p className="text-xs text-muted-foreground">проектов</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Общая сумма
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(fullProjectsAnalytics.totalAmount)}</div>
                    <p className="text-xs text-muted-foreground">за период</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Средняя сумма
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(fullProjectsAnalytics.averageAmount)}</div>
                    <p className="text-xs text-muted-foreground">за проект</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      С продлениями
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{fullProjectsAnalytics.projectsWithExtensions}</div>
                    <p className="text-xs text-muted-foreground">проектов</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1">
                      Коэффициент продления
                      {getConversionRateIcon(fullProjectsAnalytics.extensionRate)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${getConversionRateColor(fullProjectsAnalytics.extensionRate)}`}>
                      {formatPercentage(fullProjectsAnalytics.extensionRate)}
                    </div>
                    <p className="text-xs text-muted-foreground">% продлений</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Средняя сумма продления
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(fullProjectsAnalytics.averageExtensionAmount)}</div>
                    <p className="text-xs text-muted-foreground">за продление</p>
                  </CardContent>
                </Card>
              </div>

              {/* Full Projects Table */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle>Список полноценных проектов</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Select value={fullProjectsSortOrder} onValueChange={(value: 'asc' | 'desc') => setFullProjectsSortOrder(value)}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="desc">Сначала новые</SelectItem>
                        <SelectItem value="asc">Сначала старые</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Дата продажи</TableHead>
                          <TableHead>Проект</TableHead>
                          <TableHead>Клиент</TableHead>
                          <TableHead>Менеджер</TableHead>
                          <TableHead>Сумма проекта</TableHead>
                          <TableHead>Продления</TableHead>
                          <TableHead>Сумма продлений</TableHead>
                          <TableHead>Общий LTV</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {fullProjectsAnalytics.fullProjectsList.length > 0 ? (
                          sortFullProjects(fullProjectsAnalytics.fullProjectsList).map((project) => (
                            <TableRow key={project.id}>
                              <TableCell>
                                {format(new Date(project.originalDate), 'dd.MM.yyyy')}
                              </TableCell>
                              <TableCell>{project.projectName}</TableCell>
                              <TableCell>{project.clientName}</TableCell>
                              <TableCell>{project.managerName}</TableCell>
                              <TableCell>{formatCurrency(project.originalAmount)}</TableCell>
                              <TableCell>
                                <Badge variant={project.hasExtensions ? "default" : "outline"}>
                                  {project.extensionsCount}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {project.hasExtensions ? formatCurrency(project.extensionAmount) : '0 ₸'}
                              </TableCell>
                              <TableCell className="font-semibold">
                                {formatCurrency(project.totalLTV)}
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                              Нет полноценных проектов за выбранный период
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Нет данных для отображения
            </div>
          )}
        </TabsContent>

        <TabsContent value="onetime" className="space-y-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : onetimeAnalytics ? (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Всего единаразовых проектов
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{onetimeAnalytics.totalSales}</div>
                    <p className="text-xs text-muted-foreground">
                      за выбранный период
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Общая сумма
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(onetimeAnalytics.totalAmount)}</div>
                    <p className="text-xs text-muted-foreground">
                      за выбранный период
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Средняя сумма проекта
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(onetimeAnalytics.averageSaleAmount)}</div>
                    <p className="text-xs text-muted-foreground">
                      за выбранный период
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Sales by Month Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Динамика единаразовых проектов по месяцам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={onetimeAnalytics.salesByMonth}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                        <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                        <Tooltip formatter={(value, name) => {
                          if (name === "count") return [`${value} проектов`, "Количество"];
                          if (name === "amount") return [formatCurrency(value as number), "Сумма"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Line yAxisId="left" type="monotone" dataKey="count" name="Количество проектов" stroke="#8884d8" activeDot={{ r: 8 }} />
                        <Line yAxisId="right" type="monotone" dataKey="amount" name="Сумма проектов" stroke="#82ca9d" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Sales by Manager Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Единаразовые проекты по менеджерам</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={onetimeAnalytics.salesByManager}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 60,
                        }}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis type="category" dataKey="managerName" width={150} />
                        <Tooltip formatter={(value, name) => {
                          if (name === "salesCount") return [`${value} проектов`, "Количество"];
                          if (name === "totalAmount") return [formatCurrency(value as number), "Сумма"];
                          return [value, name];
                        }} />
                        <Legend />
                        <Bar dataKey="salesCount" name="Количество проектов" fill="#8884d8" />
                        <Bar dataKey="totalAmount" name="Сумма проектов" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* One-time Projects List */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Список единоразовых проектов</CardTitle>
                  <div className="flex items-center gap-2">
                    <Select
                      value={onetimeProjectsSortOrder}
                      onValueChange={(value: 'asc' | 'desc') => setOnetimeProjectsSortOrder(value)}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="desc">Сначала новые</SelectItem>
                        <SelectItem value="asc">Сначала старые</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Дата</TableHead>
                          <TableHead>Проект</TableHead>
                          <TableHead>Клиент</TableHead>
                          <TableHead>Менеджер</TableHead>
                          <TableHead className="text-right">Сумма</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {onetimeProjectsList
                          .sort((a, b) => {
                            const dateA = new Date(a.saleDate);
                            const dateB = new Date(b.saleDate);
                            return onetimeProjectsSortOrder === 'desc' 
                              ? dateB.getTime() - dateA.getTime()
                              : dateA.getTime() - dateB.getTime();
                          })
                          .map((project) => (
                          <TableRow key={project.id}>
                            <TableCell>
                              {format(new Date(project.saleDate), 'dd.MM.yyyy')}
                            </TableCell>
                            <TableCell>{project.projectName}</TableCell>
                            <TableCell>{project.clientName}</TableCell>
                            <TableCell>{project.managerName}</TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(project.saleAmount)}
                            </TableCell>
                          </TableRow>
                        ))}
                        {onetimeProjectsList.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                              Нет единоразовых проектов за выбранный период
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Нет данных для отображения
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Extension Sequence Dialog */}
    <Dialog open={extensionDialogOpen} onOpenChange={setExtensionDialogOpen}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Проекты продленные на {selectedExtensionSequence}-й месяц
          </DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          {selectedExtensionSequence && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Дата продления</TableHead>
                  <TableHead>Проект</TableHead>
                  <TableHead>Клиент</TableHead>
                  <TableHead>Менеджер</TableHead>
                  <TableHead>Сумма</TableHead>
                  <TableHead>Остаток</TableHead>
                  <TableHead>Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {extensionsList
                  .filter(ext => ext.extension_sequence === selectedExtensionSequence)
                  .map((extension) => (
                    <TableRow key={extension.id}>
                      <TableCell>
                        {format(new Date(extension.sale_date), 'dd.MM.yyyy')}
                      </TableCell>
                      <TableCell>{extension.project_name || 'Не указан'}</TableCell>
                      <TableCell>{extension.client_name || 'Не указан'}</TableCell>
                      <TableCell>{extension.employees?.name || 'Не указан'}</TableCell>
                      <TableCell>{formatCurrency(extension.sale_amount || 0)}</TableCell>
                      <TableCell>
                        {extension.remainder ? formatCurrency(extension.remainder) : '0 ₸'}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={
                            extension.project_status === 'Работаем' 
                              ? 'default' 
                              : extension.project_status === 'Завершили работу'
                              ? 'secondary'
                              : 'outline'
                          }
                        >
                          {extension.project_status || 'Не указан'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                {extensionsList.filter(ext => ext.extension_sequence === selectedExtensionSequence).length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      Нет проектов для {selectedExtensionSequence}-го месяца продления
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </div>
      </DialogContent>
    </Dialog>
    </div>
  );
};

export default FinanceAnalyticsPage;
