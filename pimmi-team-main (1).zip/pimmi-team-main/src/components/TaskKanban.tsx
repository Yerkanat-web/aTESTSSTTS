import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { formatTime } from "@/utils/timeHelpers";
import { Edit, Trash2, Clock, Calendar, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

interface UnifiedTask {
  id: string;
  title: string;
  description?: string;
  priority?: string;
  status: string;
  category?: string;
  estimated_minutes?: number;
  actual_minutes?: number;
  due_date?: string;
  created_at: string;
  updated_at: string;
  completed_at?: string;
  task_type?: string;
  source: 'employee_tasks' | 'project_tasks';
}

interface TaskKanbanProps {
  tasks: UnifiedTask[];
  onUpdateStatus: (taskId: string, newStatus: string) => void;
  onEditTask: (task: UnifiedTask) => void;
  onDeleteTask: (taskId: string, taskTitle: string) => void;
}

const taskStatuses = [
  { key: 'overdue', label: 'Просроченные', color: 'bg-red-500/10 text-red-500 border-red-500/20' },
  { key: 'pending', label: 'Ожидает', color: 'bg-warning/10 text-warning border-warning/20' },
  { key: 'in_progress', label: 'В работе', color: 'bg-primary/10 text-primary border-primary/20' },
  { key: 'postponed', label: 'Отложено', color: 'bg-muted-foreground/10 text-muted-foreground border-muted-foreground/20' },
  { key: 'issues', label: 'Проблемы', color: 'bg-destructive/10 text-destructive border-destructive/20' },
  { key: 'completed', label: 'Выполнено', color: 'bg-success/10 text-success border-success/20' }
];

export const TaskKanban = ({ tasks, onUpdateStatus, onEditTask, onDeleteTask }: TaskKanbanProps) => {
  const getDifficultyColor = (priority: string) => {
    switch (priority) {
      case 'easy': return 'bg-success/10 text-success border-success/20';
      case 'medium': return 'bg-warning/10 text-warning border-warning/20';
      case 'hard': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getDifficultyLabel = (priority: string) => {
    switch (priority) {
      case 'easy': return 'Легкий';
      case 'medium': return 'Средний';
      case 'hard': return 'Трудный';
      default: return priority;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'development': return 'Разработка';
      case 'marketing': return 'Маркетинг';
      case 'hr': return 'HR';
      case 'sales': return 'Продажи';
      case 'general': return 'Общие';
      default: return category;
    }
  };

  const isTaskOverdue = (dueDate: string, status: string) => {
    if (!dueDate || status === 'completed') return false;
    const today = new Date();
    const taskDueDate = new Date(dueDate);
    today.setHours(0, 0, 0, 0);
    taskDueDate.setHours(0, 0, 0, 0);
    return taskDueDate < today;
  };

  const getTasksByStatus = (status: string) => {
    if (status === 'overdue') {
      return tasks.filter(task => 
        task.status !== 'completed' && 
        task.due_date && 
        isTaskOverdue(task.due_date, task.status)
      );
    }
    return tasks.filter(task => 
      task.status === status && 
      !(task.due_date && isTaskOverdue(task.due_date, task.status))
    );
  };

  const difficultyPoints = (priority: string) => {
    return priority === 'easy' ? 5 : priority === 'medium' ? 15 : priority === 'hard' ? 30 : 0;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-6 gap-6">
      {taskStatuses.map((status) => {
        const statusTasks = getTasksByStatus(status.key);
        
        return (
          <Card key={status.key} className="h-fit">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Badge className={status.color} variant="outline">
                    {status.label}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    ({statusTasks.length})
                  </span>
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {statusTasks.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p className="text-sm">Нет задач</p>
                </div>
              ) : (
                statusTasks.map((task) => {
                  const isOverdue = task.due_date ? isTaskOverdue(task.due_date, task.status) : false;
                  
                  return (
                    <Card 
                      key={task.id} 
                      className={cn(
                        "border transition-all hover:shadow-md",
                        isOverdue && "border-destructive/50 bg-destructive/5"
                      )}
                    >
                      <CardContent className="p-4 space-y-3">
                        {/* Title and Description */}
                        <div>
                          <h4 className="font-medium text-sm line-clamp-2">
                            {task.title}
                            {isOverdue && (
                              <AlertCircle className="inline h-4 w-4 ml-1 text-destructive" />
                            )}
                          </h4>
                          {task.description && (
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {task.description}
                            </p>
                          )}
                          {task.source === 'project_tasks' && task.task_type && (
                            <p className="text-xs text-muted-foreground">
                              Тип: {task.task_type}
                            </p>
                          )}
                        </div>

                        {/* Badges */}
                        <div className="flex flex-wrap gap-1">
                          {task.category && (
                            <Badge variant="outline" className="text-xs">
                              {getCategoryLabel(task.category)}
                            </Badge>
                          )}
                          {task.priority && (
                            <Badge className={cn(getDifficultyColor(task.priority), "text-xs")} variant="outline">
                              {getDifficultyLabel(task.priority)}
                            </Badge>
                          )}
                          {task.source === 'project_tasks' && (
                            <Badge variant="outline" className="text-xs">
                              Проект
                            </Badge>
                          )}
                        </div>

                        {/* Time and Date Info */}
                        <div className="space-y-1">
                          {task.due_date && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Calendar className="h-3 w-3" />
                              <span>
                                {format(new Date(task.due_date), 'dd.MM.yyyy', { locale: ru })}
                              </span>
                            </div>
                          )}
                          {task.actual_minutes && task.actual_minutes > 0 && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              <span>{formatTime(task.actual_minutes)}</span>
                            </div>
                          )}
                        </div>

                        {/* Points */}
                        {task.status === 'completed' && task.priority && (
                          <div className="flex justify-end">
                            <Badge variant="secondary" className="bg-primary/10 text-primary text-xs">
                              {difficultyPoints(task.priority)} баллов
                            </Badge>
                          </div>
                        )}

                        {/* Actions */}
                        <div className="flex items-center justify-between">
                          {/* Status Change */}
                          {task.status !== 'completed' && (
                            <Select
                              value={task.status}
                              onValueChange={(value) => onUpdateStatus(task.id, value)}
                            >
                              <SelectTrigger className="w-24 h-7 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">Ожидает</SelectItem>
                                <SelectItem value="in_progress">В работе</SelectItem>
                                <SelectItem value="postponed">Отложено</SelectItem>
                                <SelectItem value="issues">Проблемы</SelectItem>
                                <SelectItem value="completed">Выполнено</SelectItem>
                              </SelectContent>
                            </Select>
                          )}

                          {/* Edit and Delete */}
                          {task.source === 'employee_tasks' && (
                            <div className="flex items-center gap-1">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => onEditTask(task)}
                                className="h-7 w-7 p-0"
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => onDeleteTask(task.id, task.title)}
                                className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};