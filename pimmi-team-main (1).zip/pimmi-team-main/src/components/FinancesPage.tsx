import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, Filter, Search, Check, X, Clock, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useOrg } from "@/contexts/OrgContext";
import { scopeToOrg } from "@/integrations/supabase/org";
interface SalesResult {
  id: string;
  project_name: string | null;
  client_name: string | null;
  sale_date: string;
  sale_amount: number;
  prepayment: number | null;
  remainder: number | null;
  remainder_due_date: string | null;
  paid_full: boolean | null;
  comments: string | null;
}

interface MonthlyPayment {
  id: string;
  sales_result_id: string;
  payment_date: string;
  amount: number;
  prepayment: number;
  remainder: number;
  remainder_due_date: string | null;
  status: 'pending' | 'paid' | 'overdue';
  actual_payment_date: string | null;
  notes: string | null;
  sales_result?: {
    project_name: string | null;
    client_name: string | null;
    is_extension: boolean;
    extension_sequence: number;
    project_type: string | null;
    work_format: string[] | null;
    sale_date: string;
    description: string | null;
    remainder_due_date: string | null;
  };
}

export const FinancesPage = () => {
  const [salesData, setSalesData] = useState<SalesResult[]>([]);
  const [filteredData, setFilteredData] = useState<SalesResult[]>([]);
  const [monthlyPayments, setMonthlyPayments] = useState<MonthlyPayment[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<MonthlyPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [paymentsLoading, setPaymentsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("sales");
  const [filters, setFilters] = useState({
    dateFrom: '',
    dateTo: '',
    remainderStatus: 'all', // all, has_remainder, no_remainder
    paymentStatus: 'all' // all, current, overdue
  });
  const [paymentFilters, setPaymentFilters] = useState({
    dateFrom: '',
    dateTo: '',
    status: 'all' // all, pending, paid, overdue
  });
  const [editingPrepayment, setEditingPrepayment] = useState<string | null>(null);
  const [editingAmount, setEditingAmount] = useState<string | null>(null);
  const [editingComment, setEditingComment] = useState<string | null>(null);
  const [editingSalesComment, setEditingSalesComment] = useState<string | null>(null);
  const [editingRemainderDate, setEditingRemainderDate] = useState<string | null>(null);
  const [editingValues, setEditingValues] = useState<{ [key: string]: number | string | null }>({});
  const [postponeDialog, setPostponeDialog] = useState<{ open: boolean; itemId: string | null; newDate: Date | undefined }>({
    open: false,
    itemId: null,
    newDate: undefined
  });
  const [extensionInfoDialog, setExtensionInfoDialog] = useState<{ open: boolean; payment: MonthlyPayment | null }>({
    open: false,
    payment: null
  });
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  useEffect(() => {
    fetchSalesData();
    fetchMonthlyPayments();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [salesData, filters]);

  useEffect(() => {
    applyPaymentFilters();
  }, [monthlyPayments, paymentFilters]);

  const fetchSalesData = async () => {
    try {
      setLoading(true);
      console.log('Fetching sales data...');
      
      const { data, error } = await scopeToOrg(
        supabase
          .from('sales_results')
          .select(`
          id,
          project_name,
          client_name,
          sale_date,
          sale_amount,
          prepayment,
          remainder,
          remainder_due_date,
          paid_full,
          comments
        `)
          .eq('is_extension', false)
          .order('remainder_due_date', { ascending: true, nullsFirst: false }),
        currentOrgId
      );

      console.log('Sales data fetched:', { data, error });

      if (error) throw error;

      setSalesData(data || []);
    } catch (error) {
      console.error('Error fetching sales data:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить финансовые данные",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMonthlyPayments = async () => {
    try {
      setPaymentsLoading(true);
      console.log('Fetching monthly payments...');
      
      // First, update overdue payments
      await supabase.rpc('update_overdue_payments');
      
      const { data, error } = await scopeToOrg(
        supabase
          .from('monthly_payments')
          .select(`
          id,
          sales_result_id,
          payment_date,
          amount,
          prepayment,
          remainder,
          remainder_due_date,
          status,
          actual_payment_date,
          notes,
          sales_results!inner (
            project_name,
            client_name,
            is_extension,
            extension_sequence,
            project_type,
            work_format,
            sale_date,
            description,
            remainder_due_date
          )
        `)
          .order('payment_date', { ascending: true }),
        currentOrgId
      );

      console.log('Monthly payments fetched:', { data, error });

      if (error) throw error;

      const formattedPayments = data?.map(payment => ({
        ...payment,
        status: payment.status as 'pending' | 'paid' | 'overdue',
        sales_result: payment.sales_results
      })) || [];

      setMonthlyPayments(formattedPayments);
    } catch (error) {
      console.error('Error fetching monthly payments:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить ежемесячные платежи",
        variant: "destructive",
      });
    } finally {
      setPaymentsLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...salesData];

    // Фильтр по дате
    if (filters.dateFrom) {
      filtered = filtered.filter(item => item.sale_date >= filters.dateFrom);
    }
    if (filters.dateTo) {
      filtered = filtered.filter(item => item.sale_date <= filters.dateTo);
    }

    // Фильтр по остатку
    if (filters.remainderStatus === 'has_remainder') {
      filtered = filtered.filter(item => (item.remainder || 0) > 0);
    } else if (filters.remainderStatus === 'no_remainder') {
      filtered = filtered.filter(item => (item.remainder || 0) === 0);
    }

    // Фильтр по статусу оплаты
    if (filters.paymentStatus === 'overdue') {
      const today = new Date().toISOString().split('T')[0];
      filtered = filtered.filter(item => 
        (item.remainder || 0) > 0 && 
        item.remainder_due_date && 
        item.remainder_due_date < today
      );
    } else if (filters.paymentStatus === 'current') {
      const today = new Date().toISOString().split('T')[0];
      filtered = filtered.filter(item => 
        (item.remainder || 0) > 0 && 
        (!item.remainder_due_date || item.remainder_due_date >= today)
      );
    }

    setFilteredData(filtered);
  };

  const applyPaymentFilters = () => {
    let filtered = [...monthlyPayments];

    // Фильтр по дате
    if (paymentFilters.dateFrom) {
      filtered = filtered.filter(payment => payment.payment_date >= paymentFilters.dateFrom);
    }
    if (paymentFilters.dateTo) {
      filtered = filtered.filter(payment => payment.payment_date <= paymentFilters.dateTo);
    }

    // Фильтр по статусу
    if (paymentFilters.status !== 'all') {
      filtered = filtered.filter(payment => payment.status === paymentFilters.status);
    }

    setFilteredPayments(filtered);
  };

  const formatCurrency = (amount: number | null) => {
    if (!amount) return '0 ₸';
    return new Intl.NumberFormat('kk-KZ').format(amount) + ' ₸';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU');
  };

  const getRowClassName = (item: SalesResult) => {
    const remainder = item.remainder || 0;
    
    if (remainder === 0) {
      return "bg-green-50 border-l-4 border-l-green-500"; // 🟢 Остатка нет
    }
    
    if (remainder > 0) {
      const today = new Date().toISOString().split('T')[0];
      if (item.remainder_due_date && item.remainder_due_date < today) {
        return "bg-red-50 border-l-4 border-l-red-500"; // 🔴 Просрочен
      }
      return "bg-orange-50 border-l-4 border-l-orange-500"; // 🟠 Остаток есть, не просрочен
    }
    
    return "";
  };

  const getPaymentRowClassName = (payment: MonthlyPayment) => {
    switch (payment.status) {
      case 'paid':
        return "bg-green-50 border-l-4 border-l-green-500";
      case 'overdue':
        return "bg-red-50 border-l-4 border-l-red-500";
      case 'pending':
        return "bg-orange-50 border-l-4 border-l-orange-500";
      default:
        return "";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Оплачено</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="h-3 w-3 mr-1" />Просрочено</Badge>;
      case 'pending':
        return <Badge className="bg-orange-100 text-orange-800"><Clock className="h-3 w-3 mr-1" />Ожидает</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getExtensionStatusBadge = (payment: MonthlyPayment) => {
    if (!payment.sales_result?.is_extension) {
      return <Badge variant="outline" className="bg-blue-50 text-blue-700">Еще не ясно</Badge>;
    }
    return <Badge variant="secondary" className="bg-purple-50 text-purple-700">
      Продление {payment.sales_result.extension_sequence}
    </Badge>;
  };

  const markPaymentAsPaid = async (paymentId: string) => {
    try {
      console.log('Marking payment as paid:', paymentId);
      
      // Обновляем статус на 'paid' и устанавливаем фактическую дату
      const { error } = await supabase
        .from('monthly_payments')
        .update({ 
          status: 'paid',
          actual_payment_date: new Date().toISOString().split('T')[0]
        })
        .eq('id', paymentId);

      if (error) throw error;

      await fetchMonthlyPayments();
      toast({
        title: "Успешно",
        description: "Платеж отмечен как оплаченный",
      });
    } catch (error) {
      console.error('Error marking payment as paid:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось отметить платеж как оплаченный",
        variant: "destructive",
      });
    }
  };

  const postponePayment = async (paymentId: string, newDate: Date) => {
    try {
      const { error } = await supabase
        .from('monthly_payments')
        .update({ 
          payment_date: format(newDate, 'yyyy-MM-dd')
        })
        .eq('id', paymentId);
        
      if (error) throw error;
      
      await fetchMonthlyPayments();
      toast({
        title: "Успешно",
        description: "Дата платежа перенесена",
      });
    } catch (error) {
      console.error('Error postponing payment:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось перенести дату платежа",
        variant: "destructive",
      });
    }
  };

  const completeProject = async (paymentId: string) => {
    try {
      const { error } = await supabase
        .from('monthly_payments')
        .update({ 
          status: 'paid',
          actual_payment_date: new Date().toISOString().split('T')[0],
          notes: 'Работы завершены'
        })
        .eq('id', paymentId);
        
      if (error) throw error;
      
      await fetchMonthlyPayments();
      toast({
        title: "Успешно",
        description: "Работы по проекту завершены",
      });
    } catch (error) {
      console.error('Error completing project:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось завершить работы",
        variant: "destructive",
      });
    }
  };

  const updatePaymentAmount = async (paymentId: string, field: 'amount' | 'prepayment', value: number) => {
    try {
      const { error } = await supabase
        .from('monthly_payments')
        .update({ [field]: value })
        .eq('id', paymentId);
        
      if (error) throw error;
      
      await fetchMonthlyPayments();
      toast({
        title: "Успешно",
        description: "Сумма обновлена",
      });
    } catch (error) {
      console.error('Error updating payment amount:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить сумму",
        variant: "destructive",
      });
    }
  };

  const updatePaymentComment = async (paymentId: string, comment: string) => {
    try {
      const { error } = await supabase
        .from('monthly_payments')
        .update({ notes: comment })
        .eq('id', paymentId);
        
      if (error) throw error;
      
      await fetchMonthlyPayments();
      toast({
        title: "Успешно",
        description: "Комментарий обновлен",
      });
    } catch (error) {
      console.error('Error updating payment comment:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить комментарий",
        variant: "destructive",
      });
    }
  };

  const updateRemainderDate = async (paymentId: string, date: string | null) => {
    try {
      const { error } = await supabase
        .from('monthly_payments')
        .update({ remainder_due_date: date })
        .eq('id', paymentId);
        
      if (error) throw error;
      
      await fetchMonthlyPayments();
      toast({
        title: "Успешно",
        description: "Дата остатка обновлена",
      });
    } catch (error) {
      console.error('Error updating remainder date:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить дату остатка",
        variant: "destructive",
      });
    }
  };

  const handlePaymentAction = (paymentId: string, action: string) => {
    if (action === 'paid') {
      markPaymentAsPaid(paymentId);
    } else if (action === 'postpone') {
      setPostponeDialog({ open: true, itemId: paymentId, newDate: undefined });
    } else if (action === 'complete') {
      completeProject(paymentId);
    }
  };

  const handlePostponePayment = async () => {
    if (!postponeDialog.itemId || !postponeDialog.newDate) return;
    
    await postponePayment(postponeDialog.itemId, postponeDialog.newDate);
    setPostponeDialog({ open: false, itemId: null, newDate: undefined });
  };

  const updatePaymentStatus = async (itemId: string, status: string) => {
    try {
      console.log('Updating payment status:', { itemId, status });
      
      let updateData: any = {};
      
      if (status === 'paid_full') {
        // When marking as fully paid, set prepayment equal to sale amount
        const item = salesData.find(i => i.id === itemId);
        if (!item) return;
        
        updateData = { 
          prepayment: item.sale_amount, // This will make remainder = 0 via trigger
          paid_full: true,
          remainder_due_date: null
        };
      } else if (status === 'paid_partial') {
        updateData = { 
          paid_full: false
        };
      } else if (status === 'postponed') {
        setPostponeDialog({ open: true, itemId, newDate: undefined });
        return;
      }
      
      console.log('Update data:', updateData);
      
      const { data, error } = await supabase
        .from('sales_results')
        .update(updateData)
        .eq('id', itemId)
        .select();
        
      console.log('Update result:', { data, error });
        
      if (error) throw error;
      
      await fetchSalesData();
      toast({
        title: "Успешно",
        description: "Статус обновлен",
      });
    } catch (error) {
      console.error('Error updating payment status:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус",
        variant: "destructive",
      });
    }
  };

  const updateSalesComment = async (itemId: string, comment: string) => {
    try {
      const { error } = await supabase
        .from('sales_results')
        .update({ comments: comment })
        .eq('id', itemId);
        
      if (error) throw error;
      
      await fetchSalesData();
      toast({
        title: "Успешно",
        description: "Комментарий обновлен",
      });
    } catch (error) {
      console.error('Error updating sales comment:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить комментарий",
        variant: "destructive",
      });
    }
  };

  const updatePrepayment = async (itemId: string, newPrepayment: number) => {
    try {
      console.log('Updating prepayment:', { itemId, newPrepayment });
      
      const item = salesData.find(i => i.id === itemId);
      if (!item) {
        console.error('Item not found:', itemId);
        return;
      }
      
      const newRemainder = item.sale_amount - newPrepayment;
      console.log('Calculated remainder:', { saleAmount: item.sale_amount, newPrepayment, newRemainder });
      
      const { data, error } = await supabase
        .from('sales_results')
        .update({ 
          prepayment: newPrepayment,
          remainder: newRemainder
        })
        .eq('id', itemId)
        .select();
        
      console.log('Prepayment update result:', { data, error });
        
      if (error) throw error;
      
      // Clear editing state first
      setEditingPrepayment(null);
      setEditingValues({});
      
      // Then refresh data
      await fetchSalesData();
      
      toast({
        title: "Успешно",
        description: "Предоплата обновлена",
      });
    } catch (error) {
      console.error('Error updating prepayment:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить предоплату",
        variant: "destructive",
      });
    }
  };

  const handlePostpone = async () => {
    if (!postponeDialog.itemId || !postponeDialog.newDate) return;
    
    try {
      const { error } = await supabase
        .from('sales_results')
        .update({ 
          remainder_due_date: format(postponeDialog.newDate, 'yyyy-MM-dd')
        })
        .eq('id', postponeDialog.itemId);
        
      if (error) throw error;
      
      await fetchSalesData();
      setPostponeDialog({ open: false, itemId: null, newDate: undefined });
      toast({
        title: "Успешно",
        description: "Дата перенесена",
      });
    } catch (error) {
      console.error('Error postponing payment:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось перенести дату",
        variant: "destructive",
      });
    }
  };

  const getPaymentStatus = (item: SalesResult) => {
    const remainder = item.remainder || 0;
    
    // Check paid_full flag first, then remainder
    if (item.paid_full === true || remainder === 0) {
      return 'paid_full';
    }
    
    return 'paid_partial';
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'paid_full': return 'Полностью оплачено';
      case 'paid_partial': return 'Частично оплачено';
      case 'postponed': return 'Перенесен';
      default: return 'Частично оплачено';
    }
  };

  if (loading && paymentsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Загрузка финансовых данных...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Финансы</h1>
          <Button onClick={() => {
            fetchSalesData();
            fetchMonthlyPayments();
          }} variant="outline">
            <Search className="h-4 w-4 mr-2" />
            Обновить
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="sales">Финансовые данные</TabsTrigger>
            <TabsTrigger value="monthly">Ежемесячные платежи</TabsTrigger>
          </TabsList>

          <TabsContent value="sales" className="space-y-6">
            {/* Фильтры для продаж */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Фильтры
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Дата от</label>
                    <Input
                      type="date"
                      value={filters.dateFrom}
                      onChange={(e) => setFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Дата до</label>
                    <Input
                      type="date"
                      value={filters.dateTo}
                      onChange={(e) => setFilters(prev => ({ ...prev, dateTo: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Остаток</label>
                    <Select 
                      value={filters.remainderStatus} 
                      onValueChange={(value) => setFilters(prev => ({ ...prev, remainderStatus: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Все</SelectItem>
                        <SelectItem value="has_remainder">Есть остаток</SelectItem>
                        <SelectItem value="no_remainder">Без остатка</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Статус оплаты</label>
                    <Select 
                      value={filters.paymentStatus} 
                      onValueChange={(value) => setFilters(prev => ({ ...prev, paymentStatus: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Все</SelectItem>
                        <SelectItem value="current">Актуальные</SelectItem>
                        <SelectItem value="overdue">Просроченные</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Статистика продаж */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-blue-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Всего сделок</p>
                      <p className="text-2xl font-bold">{filteredData.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Оплачено полностью</p>
                      <p className="text-2xl font-bold">
                        {filteredData.filter(item => (item.remainder || 0) === 0).length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-orange-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">С остатком</p>
                      <p className="text-2xl font-bold">
                        {filteredData.filter(item => (item.remainder || 0) > 0).length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-red-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Просрочено</p>
                      <p className="text-2xl font-bold">
                        {filteredData.filter(item => {
                          const today = new Date().toISOString().split('T')[0];
                          return (item.remainder || 0) > 0 && 
                                 item.remainder_due_date && 
                                 item.remainder_due_date < today;
                        }).length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Таблица продаж */}
            <Card>
              <CardHeader>
                <CardTitle>Финансовые данные</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Проект</TableHead>
                        <TableHead>Клиент</TableHead>
                        <TableHead>Дата продажи</TableHead>
                        <TableHead>Общая сумма</TableHead>
                        <TableHead>Предоплата</TableHead>
                         <TableHead>Остаток</TableHead>
                         <TableHead>Срок доплаты</TableHead>
                         <TableHead>Статус</TableHead>
                         <TableHead>Комментарии</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredData.map((item) => (
                        <TableRow key={item.id} className={getRowClassName(item)}>
                          <TableCell className="font-medium">
                            {item.project_name || 'Не указан'}
                          </TableCell>
                          <TableCell>{item.client_name || 'Не указан'}</TableCell>
                          <TableCell>{formatDate(item.sale_date)}</TableCell>
                          <TableCell className="font-semibold">
                            {formatCurrency(item.sale_amount)}
                          </TableCell>
                          <TableCell>
                            {editingPrepayment === item.id ? (
                              <div className="flex items-center space-x-2">
                                <Input
                                  type="number"
                                  value={editingValues[item.id] || item.prepayment || 0}
                                  onChange={(e) => setEditingValues(prev => ({ 
                                    ...prev, 
                                    [item.id]: Number(e.target.value) 
                                  }))}
                                  className="w-24"
                                />
                                <Button
                                  size="sm"
                                  onClick={() => updatePrepayment(item.id, Number(editingValues[item.id]) || item.prepayment || 0)}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    setEditingPrepayment(null);
                                    setEditingValues({});
                                  }}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ) : (
                              <div 
                                className="cursor-pointer hover:bg-muted p-1 rounded"
                                onClick={() => {
                                  setEditingPrepayment(item.id);
                                  setEditingValues({ [item.id]: item.prepayment || 0 });
                                }}
                              >
                                {formatCurrency(item.prepayment)}
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="font-semibold">
                            {formatCurrency(item.remainder)}
                          </TableCell>
                          <TableCell>
                            {item.remainder_due_date ? formatDate(item.remainder_due_date) : '—'}
                          </TableCell>
                           <TableCell>
                             <Select
                               value={getPaymentStatus(item)}
                               onValueChange={(value) => updatePaymentStatus(item.id, value)}
                             >
                               <SelectTrigger className="w-40">
                                 <SelectValue />
                               </SelectTrigger>
                               <SelectContent>
                                 <SelectItem value="paid_partial">Частично оплачено</SelectItem>
                                 <SelectItem value="paid_full">Полностью оплачено</SelectItem>
                                 <SelectItem value="postponed">Перенесен</SelectItem>
                               </SelectContent>
                             </Select>
                           </TableCell>
                           <TableCell>
                             {editingSalesComment === item.id ? (
                               <div className="flex items-center space-x-2">
                                 <Input
                                   value={editingValues[item.id] || item.comments || ''}
                                   onChange={(e) => setEditingValues(prev => ({ 
                                     ...prev, 
                                     [item.id]: e.target.value 
                                   }))}
                                   className="w-32"
                                   placeholder="Комментарий"
                                 />
                                 <Button
                                   size="sm"
                                   onClick={() => {
                                     updateSalesComment(item.id, String(editingValues[item.id]) || item.comments || '');
                                     setEditingSalesComment(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <Check className="h-4 w-4" />
                                 </Button>
                                 <Button
                                   size="sm"
                                   variant="outline"
                                   onClick={() => {
                                     setEditingSalesComment(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <X className="h-4 w-4" />
                                 </Button>
                               </div>
                             ) : (
                               <div 
                                 className="cursor-pointer hover:bg-muted p-1 rounded text-sm"
                                 onClick={() => {
                                   setEditingSalesComment(item.id);
                                   setEditingValues({ [item.id]: item.comments || '' });
                                 }}
                               >
                                 {item.comments || 'Добавить комментарий'}
                               </div>
                             )}
                           </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {filteredData.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      Нет данных для отображения
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-6">
            {/* Фильтры для ежемесячных платежей */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Фильтры
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Дата от</label>
                    <Input
                      type="date"
                      value={paymentFilters.dateFrom}
                      onChange={(e) => setPaymentFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Дата до</label>
                    <Input
                      type="date"
                      value={paymentFilters.dateTo}
                      onChange={(e) => setPaymentFilters(prev => ({ ...prev, dateTo: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Статус</label>
                    <Select 
                      value={paymentFilters.status} 
                      onValueChange={(value) => setPaymentFilters(prev => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Все</SelectItem>
                        <SelectItem value="pending">Ожидают</SelectItem>
                        <SelectItem value="paid">Оплачены</SelectItem>
                        <SelectItem value="overdue">Просрочены</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Статистика ежемесячных платежей */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-blue-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Всего платежей</p>
                      <p className="text-2xl font-bold">{filteredPayments.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Оплачено</p>
                      <p className="text-2xl font-bold">
                        {filteredPayments.filter(payment => payment.status === 'paid').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-orange-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Ожидают</p>
                      <p className="text-2xl font-bold">
                        {filteredPayments.filter(payment => payment.status === 'pending').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-8 bg-red-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-muted-foreground">Просрочено</p>
                      <p className="text-2xl font-bold">
                        {filteredPayments.filter(payment => payment.status === 'overdue').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Таблица ежемесячных платежей */}
            <Card>
              <CardHeader>
                <CardTitle>Ежемесячные платежи</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                     <TableHeader>
                       <TableRow>
                         <TableHead>Проект</TableHead>
                         <TableHead>Клиент</TableHead>
                         <TableHead>Статус продления</TableHead>
                         <TableHead>Дата платежа</TableHead>
                         <TableHead>Сумма</TableHead>
                         <TableHead>Предоплата</TableHead>
                         <TableHead>Остаток</TableHead>
                         <TableHead>Дата остатка</TableHead>
                         <TableHead>Статус</TableHead>
                         <TableHead>Фактическая дата</TableHead>
                         <TableHead>Действия</TableHead>
                         <TableHead>Комментарии</TableHead>
                       </TableRow>
                     </TableHeader>
                    <TableBody>
                        {filteredPayments.map((payment) => (
                          <TableRow key={payment.id} className={getPaymentRowClassName(payment)}>
                            <TableCell className="font-medium">
                              {payment.sales_result?.project_name || 'Не указан'}
                            </TableCell>
                            <TableCell>{payment.sales_result?.client_name || 'Не указан'}</TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                {getExtensionStatusBadge(payment)}
                                {payment.sales_result?.is_extension && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setExtensionInfoDialog({ open: true, payment })}
                                    className="h-6 w-6 p-0"
                                  >
                                    <Info className="h-4 w-4 text-blue-600" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                           <TableCell>{formatDate(payment.payment_date)}</TableCell>
                           <TableCell>
                             {editingAmount === payment.id ? (
                               <div className="flex items-center space-x-2">
                                 <Input
                                   type="number"
                                   value={editingValues[payment.id] || payment.amount || 0}
                                   onChange={(e) => setEditingValues(prev => ({ 
                                     ...prev, 
                                     [payment.id]: Number(e.target.value) 
                                   }))}
                                   className="w-24"
                                 />
                                 <Button
                                   size="sm"
                                   onClick={() => {
                                     updatePaymentAmount(payment.id, 'amount', Number(editingValues[payment.id]) || payment.amount);
                                     setEditingAmount(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <Check className="h-4 w-4" />
                                 </Button>
                                 <Button
                                   size="sm"
                                   variant="outline"
                                   onClick={() => {
                                     setEditingAmount(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <X className="h-4 w-4" />
                                 </Button>
                               </div>
                             ) : (
                               <div 
                                 className="cursor-pointer hover:bg-muted p-1 rounded font-semibold"
                                 onClick={() => {
                                   setEditingAmount(payment.id);
                                   setEditingValues({ [payment.id]: payment.amount || 0 });
                                 }}
                               >
                                 {formatCurrency(payment.amount)}
                               </div>
                             )}
                           </TableCell>
                           <TableCell>
                             {editingPrepayment === payment.id ? (
                               <div className="flex items-center space-x-2">
                                 <Input
                                   type="number"
                                   value={editingValues[payment.id] || payment.prepayment || 0}
                                   onChange={(e) => setEditingValues(prev => ({ 
                                     ...prev, 
                                     [payment.id]: Number(e.target.value) 
                                   }))}
                                   className="w-24"
                                 />
                                 <Button
                                   size="sm"
                                   onClick={() => {
                                     updatePaymentAmount(payment.id, 'prepayment', Number(editingValues[payment.id]) || payment.prepayment);
                                     setEditingPrepayment(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <Check className="h-4 w-4" />
                                 </Button>
                                 <Button
                                   size="sm"
                                   variant="outline"
                                   onClick={() => {
                                     setEditingPrepayment(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <X className="h-4 w-4" />
                                 </Button>
                               </div>
                             ) : (
                               <div 
                                 className="cursor-pointer hover:bg-muted p-1 rounded"
                                 onClick={() => {
                                   setEditingPrepayment(payment.id);
                                   setEditingValues({ [payment.id]: payment.prepayment || 0 });
                                 }}
                               >
                                 {formatCurrency(payment.prepayment)}
                               </div>
                             )}
                           </TableCell>
                            <TableCell className="font-semibold">
                              {formatCurrency(payment.remainder)}
                            </TableCell>
                            <TableCell>
                              {editingRemainderDate === payment.id ? (
                                <div className="flex items-center space-x-2">
                                  <Popover>
                                    <PopoverTrigger asChild>
                                      <Button
                                        variant="outline"
                                        className={cn(
                                          "w-32 justify-start text-left font-normal",
                                          !editingValues[payment.id] && "text-muted-foreground"
                                        )}
                                      >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {editingValues[payment.id] ? 
                                          format(new Date(editingValues[payment.id] as string), "dd.MM.yyyy") : 
                                          "Выберите дату"
                                        }
                                      </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0">
                                      <Calendar
                                        mode="single"
                                        selected={editingValues[payment.id] ? new Date(editingValues[payment.id] as string) : undefined}
                                        onSelect={(date) => setEditingValues(prev => ({ 
                                          ...prev, 
                                          [payment.id]: date ? format(date, 'yyyy-MM-dd') : null 
                                        }))}
                                        initialFocus
                                        className="p-3 pointer-events-auto"
                                      />
                                    </PopoverContent>
                                  </Popover>
                                  <Button
                                    size="sm"
                                    onClick={() => {
                                      updateRemainderDate(payment.id, editingValues[payment.id] as string || null);
                                      setEditingRemainderDate(null);
                                      setEditingValues({});
                                    }}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingRemainderDate(null);
                                      setEditingValues({});
                                    }}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </div>
                              ) : (
                                <div 
                                  className="cursor-pointer hover:bg-muted p-1 rounded text-sm"
                                  onClick={() => {
                                    setEditingRemainderDate(payment.id);
                                    setEditingValues({ [payment.id]: payment.remainder_due_date || '' });
                                  }}
                                >
                                  {payment.remainder_due_date ? formatDate(payment.remainder_due_date) : 'Установить дату'}
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              {getStatusBadge(payment.status)}
                            </TableCell>
                           <TableCell>
                             {payment.actual_payment_date ? formatDate(payment.actual_payment_date) : '—'}
                           </TableCell>
                           <TableCell>
                             {payment.status === 'pending' || payment.status === 'overdue' ? (
                               <Select onValueChange={(value) => handlePaymentAction(payment.id, value)}>
                                 <SelectTrigger className="w-32">
                                   <SelectValue placeholder="Действие" />
                                 </SelectTrigger>
                                 <SelectContent>
                                   <SelectItem value="paid">Оплачено</SelectItem>
                                   <SelectItem value="postpone">Перенесен</SelectItem>
                                   <SelectItem value="complete">Завершили работу</SelectItem>
                                 </SelectContent>
                               </Select>
                             ) : (
                               <span className="text-muted-foreground text-sm">—</span>
                             )}
                           </TableCell>
                           <TableCell>
                             {editingComment === payment.id ? (
                               <div className="flex items-center space-x-2">
                                 <Input
                                   value={editingValues[payment.id] || payment.notes || ''}
                                   onChange={(e) => setEditingValues(prev => ({ 
                                     ...prev, 
                                     [payment.id]: e.target.value 
                                   }))}
                                   className="w-32"
                                   placeholder="Комментарий"
                                 />
                                 <Button
                                   size="sm"
                                   onClick={() => {
                                     updatePaymentComment(payment.id, String(editingValues[payment.id]) || payment.notes || '');
                                     setEditingComment(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <Check className="h-4 w-4" />
                                 </Button>
                                 <Button
                                   size="sm"
                                   variant="outline"
                                   onClick={() => {
                                     setEditingComment(null);
                                     setEditingValues({});
                                   }}
                                 >
                                   <X className="h-4 w-4" />
                                 </Button>
                               </div>
                             ) : (
                               <div 
                                 className="cursor-pointer hover:bg-muted p-1 rounded text-sm"
                                 onClick={() => {
                                   setEditingComment(payment.id);
                                   setEditingValues({ [payment.id]: payment.notes || '' });
                                 }}
                               >
                                 {payment.notes || 'Добавить комментарий'}
                               </div>
                             )}
                           </TableCell>
                         </TableRow>
                       ))}
                    </TableBody>
                  </Table>
                  {filteredPayments.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      Нет ежемесячных платежей для отображения
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialog for postponing payment */}
      <Dialog 
        open={postponeDialog.open} 
        onOpenChange={(open) => setPostponeDialog(prev => ({ ...prev, open }))}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Перенести дату платежа</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Выберите новую дату для ежемесячного платежа
            </p>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !postponeDialog.newDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {postponeDialog.newDate ? (
                    format(postponeDialog.newDate, "dd.MM.yyyy")
                  ) : (
                    <span>Выберите дату</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={postponeDialog.newDate}
                  onSelect={(date) => setPostponeDialog(prev => ({ ...prev, newDate: date }))}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                onClick={() => setPostponeDialog({ open: false, itemId: null, newDate: undefined })}
              >
                Отмена
              </Button>
              <Button
                onClick={handlePostponePayment}
                disabled={!postponeDialog.newDate}
              >
                Перенести
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog for extension info */}
      <Dialog 
        open={extensionInfoDialog.open} 
        onOpenChange={(open) => setExtensionInfoDialog(prev => ({ ...prev, open }))}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Информация о продлении проекта</DialogTitle>
          </DialogHeader>
          {extensionInfoDialog.payment?.sales_result && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Название проекта</label>
                  <p className="font-medium">{extensionInfoDialog.payment.sales_result.project_name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Номер продления</label>
                  <p className="font-medium">Продление {extensionInfoDialog.payment.sales_result.extension_sequence}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Тип проекта</label>
                  <p className="font-medium">{extensionInfoDialog.payment.sales_result.project_type || 'Не указан'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Дата начала продления</label>
                  <p className="font-medium">{formatDate(extensionInfoDialog.payment.sales_result.sale_date)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Сумма продления</label>
                  <p className="font-medium">{formatCurrency(extensionInfoDialog.payment.amount)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Предоплата</label>
                  <p className="font-medium">{formatCurrency(extensionInfoDialog.payment.prepayment)}</p>
                </div>
              </div>
              
              {extensionInfoDialog.payment.sales_result.work_format && extensionInfoDialog.payment.sales_result.work_format.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Формат работы</label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {extensionInfoDialog.payment.sales_result.work_format.map((format, index) => (
                      <Badge key={index} variant="outline">{format}</Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {extensionInfoDialog.payment.sales_result.description && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Описание продления</label>
                  <p className="text-sm mt-1 p-3 bg-muted rounded-md">
                    {extensionInfoDialog.payment.sales_result.description}
                  </p>
                </div>
              )}
              
              <div className="flex justify-end">
                <Button 
                  variant="outline"
                  onClick={() => setExtensionInfoDialog({ open: false, payment: null })}
                >
                  Закрыть
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};