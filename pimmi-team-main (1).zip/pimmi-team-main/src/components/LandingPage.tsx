import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, 
  BarChart3, 
  CheckSquare, 
  Trophy, 
  ShoppingBag, 
  Clock,
  Target,
  Users,
  Star,
  TrendingUp,
  ArrowRight
} from "lucide-react";

interface LandingPageProps {
  onLoginClick: () => void;
}

export const LandingPage = ({ onLoginClick }: LandingPageProps) => {
  const features = [
    {
      icon: BarChart3,
      title: "Интерактивный дашборд",
      description: "Отслеживайте рабочее время, статистику по категориям задач и прогресс команды",
      color: "text-primary"
    },
    {
      icon: CheckSquare,
      title: "Учет выполненных работ",
      description: "Добавляйте задачи с указанием времени, категории и уровня сложности",
      color: "text-blue"
    },
    {
      icon: Trophy,
      title: "Система достижений",
      description: "30 уникальных достижений для мотивации и признания вклада сотрудников",
      color: "text-warning"
    },
    {
      icon: ShoppingBag,
      title: "Магазин наград",
      description: "Тратьте заработанные баллы на призы и поощрения",
      color: "text-success"
    },
    {
      icon: Clock,
      title: "Трекинг времени",
      description: "Точная статистика рабочего времени и анализ продуктивности",
      color: "text-info"
    },
    {
      icon: Users,
      title: "Управление командой",
      description: "Панель администратора для контроля статистики всех сотрудников",
      color: "text-primary"
    }
  ];

  const benefits = [
    "Прозрачная система оценки работы",
    "Мотивация через баллы и достижения", 
    "Улучшение командной продуктивности",
    "Справедливое распределение нагрузки"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-blue/10">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-primary p-3 rounded-xl shadow-glow">
              <Zap className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                Pimmi Team
              </h1>
              <p className="text-sm text-muted-foreground">Платформа для управления командой</p>
            </div>
          </div>
          
          <Button 
            onClick={onLoginClick}
            className="bg-gradient-primary text-primary-foreground shadow-elegant hover:shadow-glow transition-all duration-300"
          >
            Войти в систему
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-6 bg-primary/10 text-primary border-primary/20">
            Для команды из 21 человека
          </Badge>
          
          <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Отслеживайте продуктивность
            <span className="block bg-gradient-primary bg-clip-text text-transparent">
              и мотивируйте команду
            </span>
          </h2>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Внутренняя платформа для отслеживания рабочего времени, задач и поощрения 
            активных сотрудников через систему баллов и наград.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                className="flex items-center space-x-2 bg-card/50 backdrop-blur-sm rounded-lg px-4 py-2 border border-border/50"
              >
                <Star className="h-4 w-4 text-warning" />
                <span className="text-sm font-medium">{benefit}</span>
              </div>
            ))}
          </div>

          <Button 
            onClick={onLoginClick}
            size="lg"
            className="bg-gradient-primary text-primary-foreground shadow-elegant hover:shadow-glow transition-all duration-300 text-lg px-8 py-6"
          >
            Начать работу
            <TrendingUp className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold mb-4">Возможности платформы</h3>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Комплексное решение для управления командой и повышения мотивации сотрудников
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card 
                key={index} 
                className="shadow-card border border-border/50 hover:shadow-elegant transition-all duration-300 hover:scale-105"
              >
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg bg-${feature.color.split('-')[1]}/10`}>
                      <Icon className={`h-6 w-6 ${feature.color}`} />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Stats Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-primary/10 via-blue/5 to-success/10 rounded-2xl p-8 md:p-12 border border-primary/20">
          <div className="text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">Результаты использования</h3>
            <p className="text-muted-foreground">Эффективность команды после внедрения платформы</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">+35%</div>
              <p className="text-sm text-muted-foreground">Рост продуктивности</p>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-success mb-2">30</div>
              <p className="text-sm text-muted-foreground">Видов достижений</p>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-warning mb-2">20</div>
              <p className="text-sm text-muted-foreground">Призов в магазине</p>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-info mb-2">21</div>
              <p className="text-sm text-muted-foreground">Участников команды</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-8 text-center border-t border-border/50">
        <p className="text-muted-foreground">
          © 2024 Pimmi Team. Внутренняя платформа для управления командой.
        </p>
      </footer>
    </div>
  );
};