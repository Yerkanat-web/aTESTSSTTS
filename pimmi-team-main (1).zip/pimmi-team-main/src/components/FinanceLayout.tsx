import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calculator,
  CheckSquare,
  ClipboardList,
  DollarSign,
  Home,
  LogOut,
  RefreshCw,
  ShoppingBag,
  Trophy,
  TrendingUp,
  User
} from "lucide-react";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useOrg } from "@/contexts/OrgContext";

interface FinanceLayoutProps {
  children: ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
  user: {
    name: string;
    points?: number;
    employeeId?: string;
    role: string;
    department?: string;
  };
  onLogout?: () => void;
}

export const FinanceLayout = ({ children, currentPage, onPageChange, user, onLogout }: FinanceLayoutProps) => {
  // Get real points from database
  const { points: realPoints, loading: pointsLoading, refetch: refetchPoints } = useEmployeePoints(user.employeeId);
  const { currentOrg } = useOrg();

  const handleRefreshPoints = async () => {
    await refetchPoints();
  };
  
  const navigation = [
    { id: 'dashboard', label: 'Главная', icon: Home },
    { id: 'tasks', label: 'Задачи', icon: CheckSquare },
    { id: 'project-tasks', label: 'Проектные задачи', icon: ClipboardList },
    { id: 'achievements', label: 'Достижения', icon: Trophy },
    { id: 'shop', label: 'Магазин', icon: ShoppingBag },
    { id: 'finances', label: 'Финансы', icon: Calculator },
    { id: 'analytics', label: 'Аналитика', icon: TrendingUp }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-primary p-2 rounded-lg shadow-glow">
                <TrendingUp className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                  Pimmi Finance
                </h1>
                <p className="text-sm text-muted-foreground">Панель финансиста</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground font-semibold px-3 py-1">
                  <DollarSign className="h-4 w-4 mr-1" />
                  {pointsLoading ? '...' : realPoints || 0} баллов
                </Badge>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleRefreshPoints}
                  disabled={pointsLoading}
                  className="h-8 w-8 p-0 hover:bg-secondary"
                >
                  <RefreshCw className={`${pointsLoading ? 'animate-spin' : ''} h-4 w-4`} />
                </Button>
              </div>
              <div className="hidden sm:block">
                <Badge variant="outline" className="text-xs">{currentOrg?.name || 'Main Company'}</Badge>
              </div>
              
              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">{user.name}</span>
                <Badge className="bg-purple/20 text-purple border-purple/30 text-xs">
                  Финансист
                </Badge>
              </div>
              
              <Button variant="ghost" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <aside className="w-full lg:w-64 space-y-2">
            <div className="bg-card rounded-lg p-4 shadow-card border border-border">
              <nav className="space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.id}
                      variant={currentPage === item.id ? "default" : "ghost"}
                      className={`w-full justify-start ${
                        currentPage === item.id 
                          ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                          : "hover:bg-secondary"
                      }`}
                      onClick={() => onPageChange(item.id)}
                    >
                      <Icon className="h-4 w-4 mr-3" />
                      {item.label}
                    </Button>
                  );
                })}
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};