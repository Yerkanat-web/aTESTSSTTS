import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { scopeToOrg } from "@/integrations/supabase/org";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { WORK_FORMATS, sanitizeWorkFormats } from "@/constants/workFormats";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";
import { 
  Phone, 
  TrendingUp, 
  Target, 
  DollarSign, 
  Users,
  Calendar as CalendarComponent,
  Star,
  Award,
  CheckCircle,
  Clock,
  Mail,
  MessageSquare,
  Trophy,
  Percent,
  Activity,
  Plus,
  FileText,
  RefreshCw,
  Edit,
  Trash2
} from "lucide-react";

interface SalesMetrics {
  leadsWorked: number;
  qualifiedLeads: number;
  sales: number;
  hoursToday: number;
  conversion: number;
  revenue: number;
  quota: number;
}

interface WeeklyData {
  day: string;
  leads: number;
  sales: number;
  revenue: number;
}

interface SalesTarget {
  target_amount: number;
}

interface SalesResult {
  sale_amount: number;
  sale_date: string;
  client_name: string;
  description: string;
}

export const SalesDashboard = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [newSaleOpen, setNewSaleOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [dateFilter, setDateFilter] = useState({
    from: new Date(new Date().setDate(1)), // Начало текущего месяца
    to: new Date() // Конец - сегодня
  });
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [salesMetrics, setSalesMetrics] = useState<SalesMetrics>({
    leadsWorked: 0,
    qualifiedLeads: 0,
    sales: 0,
    hoursToday: 0,
    conversion: 0,
    revenue: 0,
    quota: 0
  });
  const [weeklyData, setWeeklyData] = useState<WeeklyData[]>([]);
  const [recentSales, setRecentSales] = useState<SalesResult[]>([]);
  const [salesEmployees, setSalesEmployees] = useState<{id: string, name: string}[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  const [newSale, setNewSale] = useState({
    // Основная информация
    amount: '',
    date: new Date(),
    client: '',
    project: '',
    type: '',
    soldBy: '', // Кто продал
    
    // Информация о клиенте
    clientPhone: '',
    clientSource: '',
    clientType: '',
    
    // Информация о проекте  
    workFormat: [] as string[],
    
    // Финансовая информация
    prepayment: '',
    remainderDueDate: undefined as Date | undefined,
    
    // Тип проекта
    projectType: '' as 'ежемесячный' | 'тестовый' | 'единоразовый' | '',
    testEndsAt: undefined as Date | undefined
  });

  const [reportData, setReportData] = useState({
    date: new Date(),
    leads: '',
    qualifiedLeads: ''
  });

  const [dailyReports, setDailyReports] = useState<any[]>([]);
  const [editingReport, setEditingReport] = useState<any>(null);
  const [editingSale, setEditingSale] = useState<any>(null);
  const [editSaleOpen, setEditSaleOpen] = useState(false);

  const categoryOptions = [
    { value: 'target', label: 'Таргет' },
    { value: 'dojim_chatbot', label: 'Дожим чатбот' },
    { value: 'ai_video', label: 'ИИ Видео' },
    { value: 'ai_site', label: 'ИИ Сайт' },
    { value: 'ai_sales', label: 'ИИ Продажник' },
    { value: 'crm', label: 'CRM' }
  ];

  const clientSourceOptions = [
    { value: 'Сарафанка', label: 'Сарафанка' },
    { value: 'Таргет реклама', label: 'Таргет реклама' },
    { value: 'Ерқанат инста', label: 'Ерқанат инста' },
    { value: 'Ұлан', label: 'Ұлан' }
  ];

  const clientTypeOptions = [
    { value: 'Сразу купил', label: 'Сразу купил' },
    { value: 'Перешел из тестового', label: 'Перешел из тестового' },
    { value: 'Единоразовая услуга', label: 'Единоразовая услуга' }
  ];

  const projectStatusOptions = [
    { value: 'Работаем', label: 'Работаем' },
    { value: 'Еще не начали', label: 'Еще не начали' },
    { value: 'Закончили', label: 'Закончили' },
    { value: 'Ждём остаток', label: 'Ждём остаток' }
  ];

  const workFormatOptions = WORK_FORMATS.map((v) => ({ value: v, label: v }));

  const periodOptions = [
    { value: 'today', label: 'Сегодня' },
    { value: 'yesterday', label: 'Вчера' },
    { value: 'week', label: 'Последние 7 дней' },
    { value: 'month', label: 'За месяц' },
    { value: '6months', label: 'Последние 6 месяцев' }
  ];

  const getPeriodDates = (period: string) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    switch (period) {
      case 'today':
        return { from: today, to: today };
      case 'yesterday':
        return { from: yesterday, to: yesterday };
      case 'week':
        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 6);
        return { from: weekAgo, to: today };
      case 'month':
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        return { from: monthStart, to: today };
      case '6months':
        const sixMonthsAgo = new Date(today);
        sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
        return { from: sixMonthsAgo, to: today };
      default:
        return { from: today, to: today };
    }
  };

  const handlePeriodChange = (period: string) => {
    setSelectedPeriod(period);
    const dates = getPeriodDates(period);
    setDateFilter(dates);
  };

  useEffect(() => {
    fetchSalesData();
  }, [dateFilter]);

  useEffect(() => {
    // Устанавливаем период по умолчанию
    handlePeriodChange('month');
  }, []);

  const fetchSalesData = async () => {
    try {
      setLoading(true);

      // Получаем текущего пользователя
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      // Получаем информацию о сотруднике
      const { data: employee } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!employee) {
        setLoading(false);
        return;
      }

      // Получаем всех сотрудников отдела продаж и админов
      const { data: salesEmployeesData } = await scopeToOrg(
        supabase
          .from('employees')
          .select('id, name')
          .or('department.eq.отдел продаж,role.eq.admin')
          .eq('status', 'active'),
        currentOrgId
      );

      if (salesEmployeesData) {
        setSalesEmployees(salesEmployeesData);
      }

      // Получаем план продаж на текущий месяц
      const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
      const { data: target } = await supabase
        .from('sales_targets')
        .select('target_amount')
        .eq('employee_id', employee.id)
        .eq('target_period', currentMonth)
        .single();

      // Получаем продажи за выбранный период
      const { data: salesInPeriod } = await scopeToOrg(
        supabase
          .from('sales_results')
          .select('*')
          .eq('employee_id', employee.id)
          .gte('sale_date', dateFilter.from.toISOString().split('T')[0])
          .lte('sale_date', dateFilter.to.toISOString().split('T')[0])
          .order('sale_date', { ascending: false }),
        currentOrgId
      );

      console.log('📊 Fetched sales data:', { 
        totalSales: salesInPeriod?.length || 0, 
        salesData: salesInPeriod 
      });

      // Получаем отчеты за выбранный период
      const { data: reports } = await supabase
        .from('daily_reports')
        .select('*')
        .eq('employee_id', employee.id)
        .gte('report_date', dateFilter.from.toISOString().split('T')[0])
        .lte('report_date', dateFilter.to.toISOString().split('T')[0])
        .order('report_date', { ascending: false});

      // Получаем часы работы за сегодня
      const today = new Date();
      const todayStart = new Date(today);
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date(today);
      todayEnd.setHours(23, 59, 59, 999);

      const { data: todayHours } = await supabase
        .from('work_time_logs')
        .select('hours_worked')
        .eq('employee_id', employee.id)
        .gte('start_time', todayStart.toISOString())
        .lte('start_time', todayEnd.toISOString());

      const sales = salesInPeriod || [];
      const reportsList = reports || [];
      const hoursToday = (todayHours || []).reduce((sum, log) => sum + (log.hours_worked || 0), 0);

      // Рассчитываем метрики на основе отчетов и продаж
      const totalLeads = reportsList.reduce((sum, report) => sum + (report.leads_count || 0), 0);
      const totalQualifiedLeads = reportsList.reduce((sum, report) => sum + (report.qualified_leads_count || 0), 0);
      
      // Все данные по продажам берем только из sales_results
      const totalRevenue = sales.reduce((sum, sale) => sum + Number(sale.sale_amount), 0);
      const quota = target?.target_amount || 500000;
      const salesCount = sales.length;
      
      const conversion = totalLeads > 0 ? (salesCount / totalLeads) * 100 : 0;

      setSalesMetrics({
        leadsWorked: totalLeads || 0,
        qualifiedLeads: totalQualifiedLeads || 0,
        sales: salesCount,
        hoursToday: hoursToday || 0,
        conversion: Number(conversion.toFixed(1)),
        revenue: totalRevenue,
        quota
      });

      setDailyReports(reportsList);
      
      console.log('Sales metrics updated:', {
        leadsWorked: totalLeads || 0,
        qualifiedLeads: totalQualifiedLeads || 0,
        sales: salesCount,
        revenue: totalRevenue,
        reportsCount: reportsList.length
      });

      // Формируем данные для графика
      const daysDiff = Math.ceil((dateFilter.to.getTime() - dateFilter.from.getTime()) / (1000 * 60 * 60 * 24));
      const weekData = [];
      const maxDays = Math.min(daysDiff, 7); // Максимум 7 дней для графика
      
      for (let i = maxDays - 1; i >= 0; i--) {
        const date = new Date(dateFilter.to);
        date.setDate(date.getDate() - i);
        const dayStart = new Date(date);
        dayStart.setHours(0, 0, 0, 0);
        const dayEnd = new Date(date);
        dayEnd.setHours(23, 59, 59, 999);

        const daySales = sales.filter(sale => {
          const saleDate = new Date(sale.sale_date);
          return saleDate >= dayStart && saleDate <= dayEnd;
        });

        const dayRevenue = daySales.reduce((sum, sale) => sum + Number(sale.sale_amount), 0);

        weekData.push({
          day: date.toLocaleDateString('ru-RU', { weekday: 'short' }),
          leads: reportsList.filter(r => {
            const reportDate = new Date(r.report_date);
            return reportDate >= dayStart && reportDate <= dayEnd;
          }).reduce((sum, r) => sum + (r.leads_count || 0), 0),
          sales: daySales.length,
          revenue: dayRevenue
        });
      }

      setWeeklyData(weekData);
      setRecentSales(sales.slice(0, 10)); // Последние 10 продаж

      console.log('📋 Recent sales updated:', { 
        recentSalesCount: sales.slice(0, 10).length, 
        recentSales: sales.slice(0, 10) 
      });

    } catch (error) {
      console.error('Error fetching sales data:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные продаж",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSale = async () => {
    console.log('💾 Начинаем сохранение продажи:', newSale);
    
    // Валидация данных
    if (!newSale.amount || !newSale.client || !newSale.project || !newSale.type || !newSale.soldBy) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(newSale.amount) <= 0) {
      toast({
        title: "Ошибка",  
        description: "Сумма должна быть больше 0",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('❌ Пользователь не найден');
        return;
      }

      const { data: employee } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!employee) {
        console.log('❌ Сотрудник не найден');
        return;
      }

      console.log('👤 Сотрудник найден:', employee.id);

      const saleData = {
        employee_id: employee.id,
        sale_amount: parseFloat(newSale.amount),
        sale_date: newSale.date.toISOString().split('T')[0],
        client_name: newSale.client,
        project_name: newSale.project,
        description: `${newSale.project} - ${newSale.type}`,
        
        // Информация о клиенте
        client_phone: newSale.clientPhone || null,
        client_source: (newSale.clientSource && clientSourceOptions.find(s => s.value === newSale.clientSource)?.value) as any || null,
        client_type: (newSale.clientType && clientTypeOptions.find(t => t.value === newSale.clientType)?.value) as any || null,
        
        // Информация о проекте
        work_format: sanitizeWorkFormats(newSale.workFormat),
        project_type: newSale.projectType === 'ежемесячный' ? 'Ежемесячный' : 
                     newSale.projectType === 'тестовый' ? 'Тестовый' : 
                     newSale.projectType === 'единоразовый' ? 'Единоразовый' : null,
        
        // Финансовая информация
        prepayment: newSale.prepayment ? parseFloat(newSale.prepayment) : null,
        remainder: newSale.prepayment ? parseFloat(newSale.amount) - parseFloat(newSale.prepayment) : parseFloat(newSale.amount),
        remainder_due_date: newSale.remainderDueDate ? newSale.remainderDueDate.toISOString().split('T')[0] : null,
        paid_full: newSale.projectType === 'единоразовый',
        
        // Тестовые продажи
        is_test: newSale.projectType === 'тестовый',
        test_ends_at: newSale.testEndsAt ? newSale.testEndsAt.toISOString().split('T')[0] : null
      };

      console.log('📊 Данные для сохранения:', saleData);

      const { data: savedSale, error } = await supabase
        .from('sales_results')
        .insert(withOrg(saleData as any, currentOrgId))
        .select()
        .single();

      if (error) {
        console.error('❌ Ошибка БД:', error);
        throw error;
      }

      console.log('✅ Продажа успешно сохранена');

      // Автоматически создаем project_account если формат работы содержит "Дожим чатбот" или "CRM"
      if (savedSale && newSale.workFormat && 
          (newSale.workFormat.includes('Дожим чатбот') || newSale.workFormat.includes('CRM'))) {
        
        console.log('🤖 Автоматическое создание project_account для:', savedSale.id);
        
        const serviceType = newSale.workFormat.includes('Дожим чатбот') ? 'Дожим чатбот' : 'CRM';
        
        const { error: accountError } = await supabase
          .from('project_accounts')
          .insert(withOrg({
            sales_result_id: savedSale.id,
            service_type: serviceType,
            login: '',
            password: '',
            subscription_end_date: null
          } as any, currentOrgId));

        if (accountError) {
          console.error('❌ Ошибка создания project_account:', accountError);
          // Не прерываем выполнение, только логируем ошибку
        } else {
          console.log('✅ Project account автоматически создан');
        }
      }

      toast({
        title: "Успешно",
        description: "Продажа добавлена",
      });

      setNewSaleOpen(false);
      setNewSale({
        // Основная информация
        amount: '',
        date: new Date(),
        client: '',
        project: '',
        type: '',
        soldBy: '', // Кто продал
        
        // Информация о клиенте
        clientPhone: '',
        clientSource: '',
        clientType: '',
        
        // Информация о проекте  
        workFormat: [],
        
        // Финансовая информация
        prepayment: '',
        remainderDueDate: undefined,
        
        // Тип проекта
        projectType: '',
        testEndsAt: undefined
      });
      
      // Обновляем данные
      await fetchSalesData();
    } catch (error) {
      console.error('❌ Error saving sale:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить продажу: " + (error.message || 'Неизвестная ошибка'),
        variant: "destructive",
      });
    }
  };

  const handleSaveReport = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: employee } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!employee) return;

      const { error } = await supabase
        .from('daily_reports')
        .insert(withOrg({
          employee_id: employee.id,
          report_date: reportData.date.toISOString().split('T')[0],
          leads_count: parseInt(reportData.leads) || 0,
          qualified_leads_count: parseInt(reportData.qualifiedLeads) || 0
        } as any, currentOrgId));

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Отчет добавлен",
      });

      setReportOpen(false);
      setReportData({
        date: new Date(),
        leads: '',
        qualifiedLeads: ''
      });
      
      // Принудительно обновляем данные
      setLoading(true);
      await fetchSalesData();
      setLoading(false);
    } catch (error) {
      console.error('Error saving report:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить отчет",
        variant: "destructive",
      });
    }
  };

  const qualityData = [
    { name: 'Квал лиды', value: salesMetrics.qualifiedLeads, color: 'hsl(var(--primary))' },
    { name: 'Неквал лиды', value: salesMetrics.leadsWorked - salesMetrics.qualifiedLeads, color: 'hsl(var(--muted))' }
  ];

  const handleEditReport = (report: any) => {
    setEditingReport(report);
    setReportData({
      date: new Date(report.report_date),
      leads: report.leads_count.toString(),
      qualifiedLeads: report.qualified_leads_count.toString()
    });
    setReportOpen(true);
  };

  const handleDeleteReport = async (reportId: string) => {
    try {
      const { error } = await supabase
        .from('daily_reports')
        .delete()
        .eq('id', reportId);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Отчет удален",
      });

      // Принудительно обновляем данные
      setLoading(true);
      await fetchSalesData();
      setLoading(false);
    } catch (error) {
      console.error('Error deleting report:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить отчет",
        variant: "destructive",
      });
    }
  };

  const handleUpdateReport = async () => {
    try {
      const { error } = await supabase
        .from('daily_reports')
        .update({
          report_date: reportData.date.toISOString().split('T')[0],
          leads_count: parseInt(reportData.leads) || 0,
          qualified_leads_count: parseInt(reportData.qualifiedLeads) || 0
        })
        .eq('id', editingReport.id);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Отчет обновлен",
      });

      setReportOpen(false);
      setEditingReport(null);
      setReportData({
        date: new Date(),
        leads: '',
        qualifiedLeads: ''
      });
      
      // Принудительно обновляем данные
      setLoading(true);
      await fetchSalesData();
      setLoading(false);
    } catch (error) {
      console.error('Error updating report:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить отчет",
        variant: "destructive",
      });
    }
  };

  const handleEditSale = (sale: any) => {
    setEditingSale(sale);
    
    // Преобразуем данные продажи в формат для редактирования
    setNewSale({
      amount: sale.sale_amount.toString(),
      date: new Date(sale.sale_date),
      client: sale.client_name || '',
      project: sale.project_name || '',
      type: 'existing', // По умолчанию
      soldBy: '', // Поле больше не используется в БД
      clientPhone: sale.client_phone || '',
      clientSource: sale.client_source || '',
      clientType: sale.client_type || '',
      workFormat: sale.work_format || [],
      prepayment: sale.prepayment ? sale.prepayment.toString() : '',
      remainderDueDate: sale.remainder_due_date ? new Date(sale.remainder_due_date) : undefined,
      projectType: sale.project_type ? 
        (sale.project_type === 'Тестовый' ? 'тестовый' : 
         sale.project_type === 'Единоразовый' ? 'единоразовый' : 
         sale.project_type === 'Ежемесячный' ? 'ежемесячный' : '') : '',
      testEndsAt: sale.test_ends_at ? new Date(sale.test_ends_at) : undefined
    });
    
    setEditSaleOpen(true);
  };

  const handleUpdateSale = async () => {
    if (!editingSale) return;

    // Валидация данных
    if (!newSale.amount || !newSale.client || !newSale.project) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(newSale.amount) <= 0) {
      toast({
        title: "Ошибка",  
        description: "Сумма должна быть больше 0",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedSaleData = {
        sale_amount: parseFloat(newSale.amount),
        sale_date: newSale.date.toISOString().split('T')[0],
        client_name: newSale.client,
        project_name: newSale.project,
        description: `${newSale.project} - ${newSale.type}`,
        
        // Информация о клиенте
        client_phone: newSale.clientPhone || null,
        client_source: (newSale.clientSource && clientSourceOptions.find(s => s.value === newSale.clientSource)?.value) as any || null,
        client_type: (newSale.clientType && clientTypeOptions.find(t => t.value === newSale.clientType)?.value) as any || null,
        
        // Информация о проекте
        work_format: sanitizeWorkFormats(newSale.workFormat),
        project_type: newSale.projectType === 'ежемесячный' ? 'Ежемесячный' : 
                     newSale.projectType === 'тестовый' ? 'Тестовый' : 
                     newSale.projectType === 'единоразовый' ? 'Единоразовый' : null,
        
        // Финансовая информация
        prepayment: newSale.prepayment ? parseFloat(newSale.prepayment) : null,
        remainder: newSale.prepayment ? parseFloat(newSale.amount) - parseFloat(newSale.prepayment) : parseFloat(newSale.amount),
        remainder_due_date: newSale.remainderDueDate ? newSale.remainderDueDate.toISOString().split('T')[0] : null,
        paid_full: newSale.projectType === 'единоразовый',
        
        // Тестовые продажи
        is_test: newSale.projectType === 'тестовый',
        test_ends_at: newSale.testEndsAt ? newSale.testEndsAt.toISOString().split('T')[0] : null
      };

      const { error } = await supabase
        .from('sales_results')
        .update(updatedSaleData)
        .eq('id', editingSale.id);

      console.log('🔄 Update result:', { error, updatedData: updatedSaleData, saleId: editingSale.id });

      if (error) throw error;

      console.log('✅ Sale updated successfully in database');

      toast({
        title: "Успешно",
        description: "Продажа обновлена",
      });

      setEditSaleOpen(false);
      setEditingSale(null);
      setNewSale({
        amount: '',
        date: new Date(),
        client: '',
        project: '',
        type: '',
        soldBy: '', // Кто продал
        clientPhone: '',
        clientSource: '',
        clientType: '',
        workFormat: [],
        prepayment: '',
        remainderDueDate: undefined,
        projectType: '',
        testEndsAt: undefined
      });
      
      console.log('🔄 Refreshing sales data after update...');
      // Обновляем данные
      await fetchSalesData();
      console.log('✅ Sales data refreshed');
      
      // Принудительно обновляем список последних продаж
      const { data: updatedSales } = await supabase
        .from('sales_results')
        .select('*')
        .eq('employee_id', (await supabase
          .from('employees')
          .select('id')
          .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
          .single()).data?.id)
        .gte('sale_date', dateFilter.from.toISOString().split('T')[0])
        .lte('sale_date', dateFilter.to.toISOString().split('T')[0])
        .order('sale_date', { ascending: false });
      
      if (updatedSales) {
        setRecentSales(updatedSales.slice(0, 10));
        console.log('🔄 Force updated recent sales:', updatedSales.slice(0, 10));
      }
    } catch (error) {
      console.error('Error updating sale:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить продажу: " + (error.message || 'Неизвестная ошибка'),
        variant: "destructive",
      });
    }
  };

  const handleDeleteSale = async (sale: any) => {
    // Подтверждение удаления
    const confirmed = window.confirm(`Вы уверены, что хотите удалить продажу "${sale.client_name}" на сумму ${(Number(sale.sale_amount) / 1000).toFixed(0)}K тг?`);
    
    if (!confirmed) return;

    try {
      console.log('🗑️ Удаляем продажу:', sale.id);

      const { error } = await supabase
        .from('sales_results')
        .delete()
        .eq('id', sale.id);

      if (error) throw error;

      console.log('✅ Продажа успешно удалена из базы данных');

      toast({
        title: "Успешно",
        description: "Продажа удалена",
      });

      // Обновляем данные
      console.log('🔄 Обновляем данные после удаления...');
      await fetchSalesData();
      console.log('✅ Данные обновлены после удаления');

    } catch (error) {
      console.error('❌ Ошибка при удалении продажи:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить продажу: " + (error?.message || 'Неизвестная ошибка'),
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Панель продаж
          </h2>
          <p className="text-muted-foreground mt-1">
            Отслеживайте свои продажи и достижения
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Фильтр по периоду */}
          <div className="flex items-center space-x-2">
            <Label className="text-sm">Период:</Label>
            <Select value={selectedPeriod} onValueChange={handlePeriodChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Выберите период" />
              </SelectTrigger>
              <SelectContent>
                {periodOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button onClick={fetchSalesData} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить
          </Button>
          
          <Dialog open={reportOpen} onOpenChange={setReportOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <FileText className="h-4 w-4 mr-2" />
                Добавить отчет
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingReport ? 'Редактировать отчет' : 'Добавить ежедневный отчет'}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Дата отчета</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !reportData.date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {reportData.date ? format(reportData.date, "dd.MM.yyyy") : "Выберите дату"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={reportData.date}
                        onSelect={(date) => date && setReportData({...reportData, date})}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div>
                  <Label htmlFor="leads">Количество лидов</Label>
                  <Input
                    id="leads"
                    type="number"
                    value={reportData.leads}
                    onChange={(e) => setReportData({...reportData, leads: e.target.value})}
                    placeholder="0"
                  />
                </div>
                
                <div>
                  <Label htmlFor="qualifiedLeads">Количество квалифицированных лидов</Label>
                  <Input
                    id="qualifiedLeads"
                    type="number"
                    value={reportData.qualifiedLeads}
                    onChange={(e) => setReportData({...reportData, qualifiedLeads: e.target.value})}
                    placeholder="0"
                  />
                </div>
                
                <Button onClick={editingReport ? handleUpdateReport : handleSaveReport} className="w-full">
                  {editingReport ? 'Обновить отчет' : 'Сохранить отчет'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={newSaleOpen} onOpenChange={setNewSaleOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-primary">
                <Plus className="h-4 w-4 mr-2" />
                Новая продажа
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Добавить продажу</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Основная информация */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Основная информация</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="amount">Сумма (тг) *</Label>
                      <Input
                        id="amount"
                        type="number"
                        value={newSale.amount}
                        onChange={(e) => setNewSale({...newSale, amount: e.target.value})}
                        placeholder="100000"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="client">Клиент *</Label>
                      <Input
                        id="client"
                        value={newSale.client}
                        onChange={(e) => setNewSale({...newSale, client: e.target.value})}
                        placeholder="Название компании"
                      />
                    </div>

                    <div>
                      <Label htmlFor="project">Проект *</Label>
                      <Input
                        id="project"
                        value={newSale.project}
                        onChange={(e) => setNewSale({...newSale, project: e.target.value})}
                        placeholder="Описание проекта"
                      />
                    </div>

                    <div>
                      <Label htmlFor="type">Тип продажи *</Label>
                      <Select value={newSale.type} onValueChange={(value) => setNewSale({...newSale, type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тип" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">Новый клиент</SelectItem>
                          <SelectItem value="existing">Существующий клиент</SelectItem>
                          <SelectItem value="upsell">Допродажа</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="soldBy">Кто продал *</Label>
                      <Select value={newSale.soldBy} onValueChange={(value) => setNewSale({...newSale, soldBy: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите сотрудника" />
                        </SelectTrigger>
                        <SelectContent>
                          {salesEmployees.map((emp) => (
                            <SelectItem key={emp.id} value={emp.name}>
                              {emp.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Дата *</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !newSale.date && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {newSale.date ? format(newSale.date, "dd.MM.yyyy") : "Выберите дату"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={newSale.date}
                            onSelect={(date) => date && setNewSale({...newSale, date})}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>

                {/* Информация о клиенте */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Информация о клиенте</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clientPhone">Телефон клиента</Label>
                      <Input
                        id="clientPhone"
                        value={newSale.clientPhone}
                        onChange={(e) => setNewSale({...newSale, clientPhone: e.target.value})}
                        placeholder="+7 (777) 123-45-67"
                      />
                    </div>

                    <div>
                      <Label htmlFor="clientSource">Источник клиента</Label>
                      <Select value={newSale.clientSource} onValueChange={(value) => setNewSale({...newSale, clientSource: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите источник" />
                        </SelectTrigger>
                        <SelectContent>
                          {clientSourceOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="clientType">Тип клиента</Label>
                      <Select value={newSale.clientType} onValueChange={(value) => setNewSale({...newSale, clientType: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тип клиента" />
                        </SelectTrigger>
                        <SelectContent>
                          {clientTypeOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Информация о проекте */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Информация о проекте</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="projectType">Тип проекта</Label>
                      <Select value={newSale.projectType} onValueChange={(value) => setNewSale({...newSale, projectType: value as 'ежемесячный' | 'тестовый' | 'единоразовый'})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тип проекта" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ежемесячный">Ежемесячный</SelectItem>
                          <SelectItem value="тестовый">Тестовый</SelectItem>
                          <SelectItem value="единоразовый">Единоразовый</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {newSale.projectType === 'тестовый' && (
                      <div>
                        <Label>Тест заканчивается</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !newSale.testEndsAt && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {newSale.testEndsAt ? format(newSale.testEndsAt, "dd.MM.yyyy") : "Выберите дату"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={newSale.testEndsAt}
                              onSelect={(date) => setNewSale({...newSale, testEndsAt: date})}
                              initialFocus
                              className="pointer-events-auto"
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label>Формат работы</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {workFormatOptions.map((option) => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`work-${option.value}`}
                            checked={newSale.workFormat?.includes(option.value) || false}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setNewSale({
                                  ...newSale,
                                  workFormat: [...newSale.workFormat, option.value]
                                });
                              } else {
                                setNewSale({
                                  ...newSale,
                                  workFormat: newSale.workFormat.filter(w => w !== option.value)
                                });
                              }
                            }}
                          />
                          <Label htmlFor={`work-${option.value}`} className="text-sm">
                            {option.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Финансовая информация */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Финансовая информация</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="prepayment">Предоплата (тг)</Label>
                      <Input
                        id="prepayment"
                        type="number"
                        value={newSale.prepayment}
                        onChange={(e) => setNewSale({...newSale, prepayment: e.target.value})}
                        placeholder="50000"
                      />
                    </div>

                    <div>
                      <Label>Дата платежа остатка</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !newSale.remainderDueDate && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {newSale.remainderDueDate ? format(newSale.remainderDueDate, "dd.MM.yyyy") : "Выберите дату"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={newSale.remainderDueDate}
                            onSelect={(date) => setNewSale({...newSale, remainderDueDate: date})}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  {newSale.prepayment && parseFloat(newSale.prepayment) > 0 && (
                    <div className="p-3 bg-muted/30 rounded-lg">
                      <p className="text-sm">
                        <strong>Остаток к доплате:</strong> {' '}
                        {newSale.amount && parseFloat(newSale.amount) > 0 
                          ? (parseFloat(newSale.amount) - parseFloat(newSale.prepayment || '0')).toLocaleString() 
                          : '0'} тг
                      </p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 mt-6">
                <Button variant="outline" onClick={() => setNewSaleOpen(false)}>
                  Отмена
                </Button>
                <Button onClick={handleSaveSale} className="bg-gradient-primary">
                  Сохранить продажу
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Edit Sale Dialog */}
          <Dialog open={editSaleOpen} onOpenChange={setEditSaleOpen}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Редактировать продажу</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Основная информация */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Основная информация</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="amount">Сумма (тг)</Label>
                      <Input
                        id="amount"
                        type="number"
                        value={newSale.amount}
                        onChange={(e) => setNewSale({...newSale, amount: e.target.value})}
                        placeholder="100000"
                      />
                    </div>

                    <div>
                      <Label htmlFor="client">Клиент</Label>
                      <Input
                        id="client"
                        value={newSale.client}
                        onChange={(e) => setNewSale({...newSale, client: e.target.value})}
                        placeholder="Имя клиента"
                      />
                    </div>

                    <div>
                      <Label htmlFor="project">Проект</Label>
                      <Input
                        id="project"
                        value={newSale.project}
                        onChange={(e) => setNewSale({...newSale, project: e.target.value})}
                        placeholder="Название проекта"
                      />
                    </div>

                    <div>
                      <Label>Дата продажи</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !newSale.date && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {newSale.date ? format(newSale.date, "dd.MM.yyyy") : "Выберите дату"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={newSale.date}
                            onSelect={(date) => date && setNewSale({...newSale, date})}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>

                {/* Информация о клиенте */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Информация о клиенте</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clientPhone">Телефон клиента</Label>
                      <Input
                        id="clientPhone"
                        value={newSale.clientPhone}
                        onChange={(e) => setNewSale({...newSale, clientPhone: e.target.value})}
                        placeholder="+7 (777) 123-45-67"
                      />
                    </div>

                    <div>
                      <Label htmlFor="clientSource">Источник клиента</Label>
                      <Select value={newSale.clientSource} onValueChange={(value) => setNewSale({...newSale, clientSource: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите источник" />
                        </SelectTrigger>
                        <SelectContent>
                          {clientSourceOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="clientType">Тип клиента</Label>
                      <Select value={newSale.clientType} onValueChange={(value) => setNewSale({...newSale, clientType: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тип клиента" />
                        </SelectTrigger>
                        <SelectContent>
                          {clientTypeOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Информация о проекте */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Информация о проекте</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="projectType">Тип проекта</Label>
                      <Select value={newSale.projectType} onValueChange={(value) => setNewSale({...newSale, projectType: value as 'ежемесячный' | 'тестовый' | 'единоразовый'})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тип проекта" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ежемесячный">Ежемесячный</SelectItem>
                          <SelectItem value="тестовый">Тестовый</SelectItem>
                          <SelectItem value="единоразовый">Единоразовый</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {newSale.projectType === 'тестовый' && (
                      <div>
                        <Label>Тест заканчивается</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !newSale.testEndsAt && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {newSale.testEndsAt ? format(newSale.testEndsAt, "dd.MM.yyyy") : "Выберите дату"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={newSale.testEndsAt}
                              onSelect={(date) => setNewSale({...newSale, testEndsAt: date})}
                              initialFocus
                              className="pointer-events-auto"
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label>Формат работы</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {workFormatOptions.map((option) => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`edit-work-${option.value}`}
                            checked={newSale.workFormat?.includes(option.value) || false}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setNewSale({
                                  ...newSale,
                                  workFormat: [...newSale.workFormat, option.value]
                                });
                              } else {
                                setNewSale({
                                  ...newSale,
                                  workFormat: newSale.workFormat.filter(w => w !== option.value)
                                });
                              }
                            }}
                          />
                          <Label htmlFor={`edit-work-${option.value}`} className="text-sm">
                            {option.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Финансовая информация */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Финансовая информация</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="prepayment">Предоплата (тг)</Label>
                      <Input
                        id="prepayment"
                        type="number"
                        value={newSale.prepayment}
                        onChange={(e) => setNewSale({...newSale, prepayment: e.target.value})}
                        placeholder="50000"
                      />
                    </div>

                    <div>
                      <Label>Дата платежа остатка</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !newSale.remainderDueDate && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {newSale.remainderDueDate ? format(newSale.remainderDueDate, "dd.MM.yyyy") : "Выберите дату"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={newSale.remainderDueDate}
                            onSelect={(date) => setNewSale({...newSale, remainderDueDate: date})}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  {newSale.prepayment && parseFloat(newSale.prepayment) > 0 && (
                    <div className="p-3 bg-muted/30 rounded-lg">
                      <p className="text-sm">
                        <strong>Остаток к доплате:</strong> {' '}
                        {newSale.amount && parseFloat(newSale.amount) > 0 
                          ? (parseFloat(newSale.amount) - parseFloat(newSale.prepayment || '0')).toLocaleString() 
                          : '0'} тг
                      </p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 mt-6">
                <Button variant="outline" onClick={() => setEditSaleOpen(false)}>
                  Отмена
                </Button>
                <Button onClick={handleUpdateSale} className="bg-gradient-primary">
                  Сохранить изменения
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue to-blue-600 text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-foreground/80 text-sm font-medium">Выручка</p>
                <p className="text-3xl font-bold">{(salesMetrics.revenue / 1000).toFixed(0)}K тг</p>
                <p className="text-xs text-blue-foreground/60 mt-1">
                  из {(salesMetrics.quota / 1000).toFixed(0)}K плана
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-blue-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green to-emerald-500 text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-foreground/80 text-sm font-medium">Продажи</p>
                <p className="text-3xl font-bold">{salesMetrics.sales}</p>
                <p className="text-xs text-green-foreground/60 mt-1">сделки закрыты</p>
              </div>
              <Trophy className="h-8 w-8 text-green-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-violet-600 text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-foreground/80 text-sm font-medium">Конверсия</p>
                <p className="text-3xl font-bold">{salesMetrics.conversion}%</p>
                <p className="text-xs text-purple-foreground/60 mt-1">лиды в продажи</p>
              </div>
              <Percent className="h-8 w-8 text-purple-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-red-500 text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-foreground/80 text-sm font-medium">Лидов всего</p>
                <p className="text-3xl font-bold">{salesMetrics.leadsWorked}</p>
                <p className="text-xs text-orange-foreground/60 mt-1">лидов обработано</p>
              </div>
              <Users className="h-8 w-8 text-orange-foreground/60" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress to Goal */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Прогресс к цели
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Выполнено: {(salesMetrics.revenue / 1000).toFixed(0)}K тг</span>
              <span>Цель: {(salesMetrics.quota / 1000).toFixed(0)}K тг</span>
            </div>
            <Progress 
              value={(salesMetrics.revenue / salesMetrics.quota) * 100} 
              className="w-full h-3"
            />
            <p className="text-xs text-muted-foreground">
              {((salesMetrics.revenue / salesMetrics.quota) * 100).toFixed(1)}% от цели
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Sales Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Продажи за неделю
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyData}>
                <XAxis dataKey="day" />
                <YAxis />
                <Bar dataKey="sales" fill="hsl(var(--primary))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Quality Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Percent className="h-5 w-5" />
              Качество лидов
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={qualityData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                  >
                    {qualityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-primary">
                  {salesMetrics.leadsWorked > 0 ? ((salesMetrics.qualifiedLeads / salesMetrics.leadsWorked) * 100).toFixed(1) : 0}%
                </p>
                <p className="text-sm text-muted-foreground">Квалифицированные</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-muted-foreground">
                  {salesMetrics.leadsWorked > 0 ? (((salesMetrics.leadsWorked - salesMetrics.qualifiedLeads) / salesMetrics.leadsWorked) * 100).toFixed(1) : 0}%
                </p>
                <p className="text-sm text-muted-foreground">Неквалифицированные</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Sales */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Последние продажи
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentSales.length > 0 ? (
              recentSales.map((sale, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <DollarSign className="h-4 w-4 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="font-medium">{sale.client_name}</p>
                      <p className="text-sm text-muted-foreground">{sale.description}</p>
                    </div>
                  </div>
                   <div className="flex items-center space-x-2">
                     <div className="text-right">
                       <p className="font-bold text-success">
                         {(Number(sale.sale_amount) / 1000).toFixed(0)}K тг
                       </p>
                       <p className="text-xs text-muted-foreground">
                         {new Date(sale.sale_date).toLocaleDateString('ru-RU')}
                       </p>
                     </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditSale(sale)}
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteSale(sale)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                   </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Пока нет продаж</p>
                <p className="text-sm">Добавьте первую продажу!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Последние отчеты
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {dailyReports.length > 0 ? (
              dailyReports.map((report, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <FileText className="h-4 w-4 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="font-medium">
                        {new Date(report.report_date).toLocaleDateString('ru-RU')}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Лиды: {report.leads_count}, Квал: {report.qualified_leads_count}
                      </p>
                      {report.project_name && (
                        <p className="text-sm text-muted-foreground">
                          Проект: {report.project_name}
                        </p>
                      )}
                      {report.categories && report.categories.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {report.categories.map((category: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {categoryOptions.find(c => c.value === category)?.label || category}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="text-right">
                      {report.sale_amount > 0 && (
                        <p className="font-bold text-success">
                          {(Number(report.sale_amount) / 1000).toFixed(0)}K тг
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditReport(report)}
                      className="text-blue-600 hover:bg-blue-50"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Пока нет отчетов</p>
                <p className="text-sm">Добавьте первый отчет!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};