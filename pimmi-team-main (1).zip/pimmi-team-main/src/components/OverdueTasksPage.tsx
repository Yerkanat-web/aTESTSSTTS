import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { AlertTriangle, Clock, User, Building2, Calendar as CalendarIcon, AlertCircle, PlayCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useOrg } from "@/contexts/OrgContext";
import { scopeToOrg } from "@/integrations/supabase/org";

interface EmployeeOverdueStats {
  employee_id: string;
  employee_name: string;
  overdue_count: number;
}

interface OverdueTask {
  id: string;
  task_name: string;
  assignee_name: string;
  client_name: string;
  due_date: string;
  days_overdue: number;
}

interface IssueTask {
  id: string;
  task_name: string;
  assignee_name: string;
  client_name: string;
  due_date: string;
  status: string;
}

interface InProgressTask {
  id: string;
  task_name: string;
  assignee_name: string;
  client_name: string;
  due_date: string;
  status: string;
}

interface PostponedTask {
  id: string;
  task_name: string;
  assignee_name: string;
  client_name: string;
  due_date: string;
  status: string;
}

export const OverdueTasksPage = () => {
  const [employeeStats, setEmployeeStats] = useState<EmployeeOverdueStats[]>([]);
  const [overdueTasks, setOverdueTasks] = useState<OverdueTask[]>([]);
  const [issueTasks, setIssueTasks] = useState<IssueTask[]>([]);
  const [inProgressTasks, setInProgressTasks] = useState<InProgressTask[]>([]);
  const [postponedTasks, setPostponedTasks] = useState<PostponedTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState<string | null>(null);
  const [newDeadline, setNewDeadline] = useState<Date | undefined>(undefined);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [debugInfo, setDebugInfo] = useState<any>(null);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  const getTaskStatusDisplay = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Завершена';
      case 'in_progress':
        return 'В работе';
      case 'pending':
        return 'Ожидает';
      case 'postponed':
        return 'Перенесен';
      case 'issues':
        return 'Проблемы с задачей';
      default:
        return 'Ожидает';
    }
  };

  const getTaskStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-success/20 text-success border-success/30';
      case 'in_progress':
        return 'bg-info/20 text-info border-info/30';
      case 'pending':
        return 'bg-muted/20 text-muted-foreground border-muted/30';
      case 'postponed':
        return 'bg-warning/20 text-warning border-warning/30';
      case 'issues':
        return 'bg-destructive/20 text-destructive border-destructive/30';
      default:
        return 'bg-muted/20 text-muted-foreground border-muted/30';
    }
  };

  useEffect(() => {
    fetchCurrentUserRole();
  }, []);

  useEffect(() => {
    if (currentUserRole) {
      fetchOverdueData();
    }
  }, [currentUserRole]);

  const fetchCurrentUserRole = async () => {
    try {
      setAuthError(null);
      
      // Получаем сессию
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      const debugData = {
        sessionExists: !!session,
        sessionError: sessionError?.message,
        userId: session?.user?.id,
        userEmail: session?.user?.email,
        timestamp: new Date().toISOString()
      };
      
      console.log("🔍 OverdueTasksPage Debug Info:", debugData);
      setDebugInfo(debugData);

      if (sessionError) {
        console.error("Session error:", sessionError);
        setAuthError(`Ошибка сессии: ${sessionError.message}`);
        return;
      }

      if (!session?.user) {
        console.error("No authenticated user found");
        setAuthError("Пользователь не аутентифицирован");
        return;
      }

      const { data: employee, error } = await supabase
        .from("employees")
        .select("role, department, name, id")
        .eq("user_id", session.user.id)
        .single();

      if (error) {
        console.error("Error fetching user role:", error);
        setAuthError(`Ошибка получения роли: ${error.message}`);
        return;
      }

      console.log("✅ OverdueTasksPage - user role:", employee?.role);
      setCurrentUserRole(employee?.role || null);
    } catch (error) {
      console.error("Error fetching current user role:", error);
      setAuthError(`Критическая ошибка: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const fetchOverdueData = async () => {
    try {
      console.log("📊 Fetching overdue data for role:", currentUserRole);
      setAuthError(null);
      
      // Проверяем аутентификацию перед запросами
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        throw new Error("Пользователь не аутентифицирован для получения данных");
      }
      
      console.log("🔐 Session verified, user ID:", session.user.id);
      
      // Fetch employee overdue stats from both project_tasks and employee_tasks
      const [
        { data: projectStatsData, error: projectStatsError },
        { data: employeeStatsData, error: employeeStatsError }
      ] = await Promise.all([
        supabase
          .from('project_tasks')
          .select(`
            assignee_id,
            employees!project_tasks_assignee_id_fkey(name, department, role)
          `)
          .eq('status', 'pending')
          .lt('due_date', new Date().toISOString().split('T')[0])
          .not('assignee_id', 'is', null),
        
        supabase
          .from('employee_tasks')
          .select(`
            employee_id,
            employees!fk_employee_tasks_employee(name, department, role)
          `)
          .eq('status', 'pending')
          .lt('due_date', new Date().toISOString().split('T')[0])
      ]);

      if (projectStatsError) throw projectStatsError;
      if (employeeStatsError) throw employeeStatsError;

      console.log("Project stats data received:", projectStatsData?.length);
      console.log("Employee stats data received:", employeeStatsData?.length);

      // Group by employee and count
      const statsMap = new Map<string, { name: string; count: number }>();
      
      // Process project tasks
      projectStatsData?.forEach((task: any) => {
        const employeeId = task.assignee_id;
        const employeeName = task.employees?.name || 'Неизвестный сотрудник';
        const employeeDepartment = task.employees?.department;
        const employeeRole = task.employees?.role;
        
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return; // Пропускаем задачи сотрудников не из тех отдела
          }
        }
        
        if (statsMap.has(employeeId)) {
          statsMap.get(employeeId)!.count++;
        } else {
          statsMap.set(employeeId, { name: employeeName, count: 1 });
        }
      });

      // Process employee tasks
      employeeStatsData?.forEach((task: any) => {
        const employeeId = task.employee_id;
        const employeeName = task.employees?.name || 'Неизвестный сотрудник';
        const employeeDepartment = task.employees?.department;
        const employeeRole = task.employees?.role;
        
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return; // Пропускаем задачи сотрудников не из тех отдела
          }
        }
        
        if (statsMap.has(employeeId)) {
          statsMap.get(employeeId)!.count++;
        } else {
          statsMap.set(employeeId, { name: employeeName, count: 1 });
        }
      });

      const employeeStatsArray: EmployeeOverdueStats[] = Array.from(statsMap.entries()).map(([id, data]) => ({
        employee_id: id,
        employee_name: data.name,
        overdue_count: data.count
      })).sort((a, b) => b.overdue_count - a.overdue_count);

      console.log("Employee stats prepared:", employeeStatsArray.length);
      setEmployeeStats(employeeStatsArray);

      // Fetch detailed overdue tasks from both tables
      const [
        { data: projectTasksData, error: projectTasksError },
        { data: employeeTasksData, error: employeeTasksError }
      ] = await Promise.all([
        supabase
          .from('project_tasks')
          .select(`
            id,
            task_name,
            due_date,
            assignee_id,
            employees!project_tasks_assignee_id_fkey(name, department, role),
            sales_results(client_name)
          `)
          .eq('status', 'pending')
          .lt('due_date', new Date().toISOString().split('T')[0])
          .not('assignee_id', 'is', null)
          .order('due_date', { ascending: true }),
        
        supabase
          .from('employee_tasks')
          .select(`
            id,
            title,
            due_date,
            employee_id,
            employees!fk_employee_tasks_employee(name, department, role)
          `)
          .eq('status', 'pending')
          .lt('due_date', new Date().toISOString().split('T')[0])
          .order('due_date', { ascending: true })
      ]);

      if (projectTasksError) throw projectTasksError;
      if (employeeTasksError) throw employeeTasksError;

      console.log("Project overdue tasks data received:", projectTasksData?.length);
      console.log("Employee overdue tasks data received:", employeeTasksData?.length);

      const today = new Date();
      
      // Process project tasks
      const projectOverdueTasks: OverdueTask[] = projectTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => {
        const dueDate = new Date(task.due_date);
        const timeDiff = today.getTime() - dueDate.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

        return {
          id: task.id,
          task_name: task.task_name,
          assignee_name: task.employees?.name || 'Неизвестный сотрудник',
          client_name: task.sales_results?.client_name || 'Компания не указана',
          due_date: task.due_date,
          days_overdue: daysDiff
        };
      }) || [];

      // Process employee tasks
      const employeeOverdueTasks: OverdueTask[] = employeeTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => {
        const dueDate = new Date(task.due_date);
        const timeDiff = today.getTime() - dueDate.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

        return {
          id: task.id,
          task_name: task.title,
          assignee_name: task.employees?.name || 'Неизвестный сотрудник',
          client_name: 'Личная задача',
          due_date: task.due_date,
          days_overdue: daysDiff
        };
      }) || [];

      // Combine and sort by due date
      const overdueTasksArray = [...projectOverdueTasks, ...employeeOverdueTasks]
        .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());

      console.log("Overdue tasks prepared:", overdueTasksArray.length);
      setOverdueTasks(overdueTasksArray);

      // Fetch tasks with issues from both tables
      const [
        { data: projectIssueTasksData, error: projectIssueTasksError },
        { data: employeeIssueTasksData, error: employeeIssueTasksError }
      ] = await Promise.all([
        supabase
          .from('project_tasks')
          .select(`
            id,
            task_name,
            due_date,
            status,
            assignee_id,
            employees!project_tasks_assignee_id_fkey(name, department, role),
            sales_results(client_name)
          `)
          .eq('status', 'issues')
          .not('assignee_id', 'is', null)
          .order('due_date', { ascending: true }),
        
        supabase
          .from('employee_tasks')
          .select(`
            id,
            title,
            due_date,
            status,
            employee_id,
            employees!fk_employee_tasks_employee(name, department, role)
          `)
          .eq('status', 'issues')
          .order('due_date', { ascending: true })
      ]);

      if (projectIssueTasksError) throw projectIssueTasksError;
      if (employeeIssueTasksError) throw employeeIssueTasksError;

      // Process project issue tasks
      const projectIssueTasks: IssueTask[] = projectIssueTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => ({
        id: task.id,
        task_name: task.task_name,
        assignee_name: task.employees?.name || 'Неизвестный сотрудник',
        client_name: task.sales_results?.client_name || 'Компания не указана',
        due_date: task.due_date,
        status: task.status
      })) || [];

      // Process employee issue tasks
      const employeeIssueTasks: IssueTask[] = employeeIssueTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => ({
        id: task.id,
        task_name: task.title,
        assignee_name: task.employees?.name || 'Неизвестный сотрудник',
        client_name: 'Личная задача',
        due_date: task.due_date,
        status: task.status
      })) || [];

      const issueTasksArray = [...projectIssueTasks, ...employeeIssueTasks]
        .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());

      setIssueTasks(issueTasksArray);

      // Fetch tasks in progress from both tables
      const [
        { data: projectInProgressTasksData, error: projectInProgressTasksError },
        { data: employeeInProgressTasksData, error: employeeInProgressTasksError }
      ] = await Promise.all([
        supabase
          .from('project_tasks')
          .select(`
            id,
            task_name,
            due_date,
            status,
            assignee_id,
            employees!project_tasks_assignee_id_fkey(name, department, role),
            sales_results(client_name)
          `)
          .eq('status', 'in_progress')
          .not('assignee_id', 'is', null)
          .order('due_date', { ascending: true }),
        
        supabase
          .from('employee_tasks')
          .select(`
            id,
            title,
            due_date,
            status,
            employee_id,
            employees!fk_employee_tasks_employee(name, department, role)
          `)
          .eq('status', 'in_progress')
          .order('due_date', { ascending: true })
      ]);

      if (projectInProgressTasksError) throw projectInProgressTasksError;
      if (employeeInProgressTasksError) throw employeeInProgressTasksError;

      // Process project in progress tasks
      const projectInProgressTasks: InProgressTask[] = projectInProgressTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => ({
        id: task.id,
        task_name: task.task_name,
        assignee_name: task.employees?.name || 'Неизвестный сотрудник',
        client_name: task.sales_results?.client_name || 'Компания не указана',
        due_date: task.due_date,
        status: task.status
      })) || [];

      // Process employee in progress tasks
      const employeeInProgressTasks: InProgressTask[] = employeeInProgressTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => ({
        id: task.id,
        task_name: task.title,
        assignee_name: task.employees?.name || 'Неизвестный сотрудник',
        client_name: 'Личная задача',
        due_date: task.due_date,
        status: task.status
      })) || [];

      const inProgressTasksArray = [...projectInProgressTasks, ...employeeInProgressTasks]
        .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());

      setInProgressTasks(inProgressTasksArray);

      // Fetch postponed tasks from both tables
      const [
        { data: projectPostponedTasksData, error: projectPostponedTasksError },
        { data: employeePostponedTasksData, error: employeePostponedTasksError }
      ] = await Promise.all([
        supabase
          .from('project_tasks')
          .select(`
            id,
            task_name,
            due_date,
            status,
            assignee_id,
            employees!project_tasks_assignee_id_fkey(name, department, role),
            sales_results(client_name)
          `)
          .eq('status', 'postponed')
          .not('assignee_id', 'is', null)
          .order('due_date', { ascending: true }),
        
        supabase
          .from('employee_tasks')
          .select(`
            id,
            title,
            due_date,
            status,
            employee_id,
            employees!fk_employee_tasks_employee(name, department, role)
          `)
          .eq('status', 'postponed')
          .order('due_date', { ascending: true })
      ]);

      if (projectPostponedTasksError) throw projectPostponedTasksError;
      if (employeePostponedTasksError) throw employeePostponedTasksError;

      // Process project postponed tasks
      const projectPostponedTasks: PostponedTask[] = projectPostponedTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => ({
        id: task.id,
        task_name: task.task_name,
        assignee_name: task.employees?.name || 'Неизвестный сотрудник',
        client_name: task.sales_results?.client_name || 'Компания не указана',
        due_date: task.due_date,
        status: task.status
      })) || [];

      // Process employee postponed tasks
      const employeePostponedTasks: PostponedTask[] = employeePostponedTasksData?.filter((task: any) => {
        // Фильтрация для руководителей тех отдела
        if (currentUserRole === 'руководитель тех отдела') {
          const employeeDepartment = task.employees?.department;
          const employeeRole = task.employees?.role;
          if (employeeDepartment !== 'тех отдел' && employeeRole !== 'руководитель тех отдела') {
            return false;
          }
        }
        return true;
      }).map((task: any) => ({
        id: task.id,
        task_name: task.title,
        assignee_name: task.employees?.name || 'Неизвестный сотрудник',
        client_name: 'Личная задача',
        due_date: task.due_date,
        status: task.status
      })) || [];

      const postponedTasksArray = [...projectPostponedTasks, ...employeePostponedTasks]
        .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());

      setPostponedTasks(postponedTasksArray);
    } catch (error) {
      console.error('❌ Error fetching overdue data:', error);
      setAuthError(`Ошибка загрузки данных: ${error instanceof Error ? error.message : 'Unknown error'}`);
      
      toast({
        title: "Ошибка загрузки данных",
        description: "Не удалось загрузить данные мониторинга. Проверьте подключение и права доступа.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePostponeTask = async () => {
    if (!selectedTask || !newDeadline) return;

    try {
      const formattedDate = format(newDeadline, 'yyyy-MM-dd');
      
      const { error } = await supabase
        .from('project_tasks')
        .update({ 
          due_date: formattedDate,
          status: 'pending' // Возвращаем статус в pending при переносе
        })
        .eq('id', selectedTask);

      if (error) throw error;

      toast({
        title: "Задача перенесена",
        description: `Новый дедлайн: ${formatDate(formattedDate)}`,
      });

      setIsDialogOpen(false);
      setSelectedTask(null);
      setNewDeadline(undefined);
      fetchOverdueData(); // Обновляем данные
    } catch (error) {
      console.error('Error postponing task:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось перенести задачу",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          <h1 className="text-2xl font-bold">Мониторинг задач</h1>
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p>Загрузка данных мониторинга...</p>
              {debugInfo && (
                <details className="mt-4 text-left bg-muted p-4 rounded-lg">
                  <summary className="cursor-pointer text-sm text-muted-foreground">Информация о сессии</summary>
                  <pre className="text-xs mt-2 overflow-auto">
                    {JSON.stringify(debugInfo, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Показываем ошибку аутентификации
  if (authError) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          <h1 className="text-2xl font-bold">Мониторинг задач</h1>
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-destructive" />
              <h3 className="text-lg font-semibold mb-2">Ошибка доступа</h3>
              <p className="text-muted-foreground mb-4">{authError}</p>
              <div className="space-y-2">
                <Button onClick={() => window.location.reload()} variant="default">
                  Обновить страницу
                </Button>
                <Button onClick={() => supabase.auth.signOut()} variant="outline">
                  Выйти из системы
                </Button>
              </div>
              {debugInfo && (
                <details className="mt-4 text-left bg-muted p-4 rounded-lg">
                  <summary className="cursor-pointer text-sm text-muted-foreground">Техническая информация</summary>
                  <pre className="text-xs mt-2 overflow-auto">
                    {JSON.stringify(debugInfo, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-2">
        <AlertTriangle className="h-6 w-6 text-destructive" />
        <h1 className="text-2xl font-bold">
          {currentUserRole === 'руководитель тех отдела' ? 'Мониторинг задач (все отделы)' : 'Мониторинг задач'}
        </h1>
        <Badge variant="destructive">{overdueTasks.length} просрочено</Badge>
        <Badge variant="secondary">{issueTasks.length} проблем</Badge>
        <Badge variant="outline">{inProgressTasks.length} в работе</Badge>
        <Badge className="bg-warning/20 text-warning border-warning/30">{postponedTasks.length} перенесено</Badge>
      </div>

      {/* Employee Rating */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            {currentUserRole === 'руководитель тех отдела' ? 'Рейтинг всех сотрудников по просрочкам' : 'Рейтинг сотрудников по просрочкам'}
          </CardTitle>
          <CardDescription>
            {currentUserRole === 'руководитель тех отдела' ? 
              'Все сотрудники с наибольшим количеством просроченных задач' :
              'Сотрудники с наибольшим количеством просроченных задач'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {employeeStats.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              Просроченных задач не найдено 🎉
            </div>
          ) : (
            <div className="space-y-3">
              {employeeStats.map((employee, index) => (
                <div
                  key={employee.employee_id}
                  className="flex items-center justify-between p-3 rounded-lg border border-border bg-card"
                >
                  <div className="flex items-center space-x-3">
                    <div className={`
                      w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold
                      ${index === 0 ? 'bg-destructive text-destructive-foreground' : 
                        index === 1 ? 'bg-warning text-warning-foreground' : 
                        index === 2 ? 'bg-muted text-muted-foreground' : 
                        'bg-secondary text-secondary-foreground'}
                    `}>
                      {index + 1}
                    </div>
                    <span className="font-medium">{employee.employee_name}</span>
                  </div>
                  <Badge variant="destructive">
                    {employee.overdue_count} задач
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Overdue Tasks List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Просроченные задачи
          </CardTitle>
          <CardDescription>
            Задачи, которые не выполнены в срок
          </CardDescription>
        </CardHeader>
        <CardContent>
          {overdueTasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Просроченных задач нет! 🎉</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ответственный</TableHead>
                  <TableHead>Задача</TableHead>
                  <TableHead>Компания</TableHead>
                  <TableHead>Дедлайн</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Просрочка</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {overdueTasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {task.assignee_name}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {task.task_name}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {task.client_name}
                      </div>
                    </TableCell>
                    <TableCell>
                      {formatDate(task.due_date)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={getTaskStatusColor('pending')}
                      >
                        {getTaskStatusDisplay('pending')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="destructive"
                        className={`
                          ${task.days_overdue > 7 ? 'bg-destructive' : 
                            task.days_overdue > 3 ? 'bg-warning' : 
                            'bg-muted'}
                        `}
                      >
                        {task.days_overdue} {task.days_overdue === 1 ? 'день' : 
                         task.days_overdue < 5 ? 'дня' : 'дней'}
                       </Badge>
                     </TableCell>
                   </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Issues Tasks List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Проблемы с задачами
          </CardTitle>
          <CardDescription>
            Задачи, которые требуют внимания
          </CardDescription>
        </CardHeader>
        <CardContent>
          {issueTasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Проблемных задач нет! 🎉</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ответственный</TableHead>
                  <TableHead>Задача</TableHead>
                  <TableHead>Компания</TableHead>
                  <TableHead>Дедлайн</TableHead>
                  <TableHead>Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {issueTasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {task.assignee_name}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {task.task_name}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {task.client_name}
                      </div>
                    </TableCell>
                    <TableCell>
                      {formatDate(task.due_date)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={getTaskStatusColor(task.status)}
                      >
                        {getTaskStatusDisplay(task.status)}
                       </Badge>
                     </TableCell>
                   </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* In Progress Tasks List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlayCircle className="h-5 w-5" />
            Задачи в работе
          </CardTitle>
          <CardDescription>
            Задачи, которые находятся в процессе выполнения
          </CardDescription>
        </CardHeader>
        <CardContent>
          {inProgressTasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <PlayCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Задач в работе нет!</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ответственный</TableHead>
                  <TableHead>Задача</TableHead>
                  <TableHead>Компания</TableHead>
                  <TableHead>Дедлайн</TableHead>
                  <TableHead>Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inProgressTasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {task.assignee_name}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {task.task_name}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {task.client_name}
                      </div>
                    </TableCell>
                    <TableCell>
                      {formatDate(task.due_date)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={getTaskStatusColor(task.status)}
                      >
                        {getTaskStatusDisplay(task.status)}
                       </Badge>
                     </TableCell>
                   </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Postponed Tasks List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Перенесенные задачи
          </CardTitle>
          <CardDescription>
            Задачи, которые были перенесены на другую дату
          </CardDescription>
        </CardHeader>
        <CardContent>
          {postponedTasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Перенесенных задач нет! 🎉</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ответственный</TableHead>
                  <TableHead>Задача</TableHead>
                  <TableHead>Компания</TableHead>
                  <TableHead>Дедлайн</TableHead>
                  <TableHead>Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {postponedTasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {task.assignee_name}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {task.task_name}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {task.client_name}
                      </div>
                    </TableCell>
                    <TableCell>
                      {formatDate(task.due_date)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={getTaskStatusColor(task.status)}
                      >
                        {getTaskStatusDisplay(task.status)}
                       </Badge>
                     </TableCell>
                   </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Postpone Task Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Перенести задачу</DialogTitle>
            <DialogDescription>
              Выберите новую дату дедлайна для задачи
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="deadline" className="text-right">
                Новый дедлайн
              </Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newDeadline && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newDeadline ? format(newDeadline, "dd.MM.yyyy") : "Выберите дату"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={newDeadline}
                      onSelect={setNewDeadline}
                      disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Отмена
            </Button>
            <Button onClick={handlePostponeTask} disabled={!newDeadline}>
              Перенести задачу
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};