import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, Search, Filter, Calendar, User, Activity, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

interface ActivityLog {
  id: string;
  employee_id: string;
  employee_name: string;
  employee_email: string;
  department: string;
  position: string;
  action_type: string;
  action_description: string;
  target_type: string | null;
  target_id: string | null;
  metadata: any;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
}

export const AdminActivityLogs = () => {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [departments, setDepartments] = useState<string[]>([]);
  const [actionTypes, setActionTypes] = useState<string[]>([]);
  const { toast } = useToast();

  const itemsPerPage = 50;

  useEffect(() => {
    fetchLogs();
    fetchFilterOptions();
  }, [currentPage, searchTerm, filterType, filterDepartment]);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('employee_activity_logs_view')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage - 1);

      // Применяем фильтры
      if (searchTerm) {
        query = query.or(`employee_name.ilike.%${searchTerm}%,action_description.ilike.%${searchTerm}%,employee_email.ilike.%${searchTerm}%`);
      }

      if (filterType !== "all") {
        query = query.eq('action_type', filterType);
      }

      if (filterDepartment !== "all") {
        query = query.eq('department', filterDepartment);
      }

      const { data, error, count } = await query;

      if (error) throw error;

      setLogs(data || []);
      setTotalCount(count || 0);
    } catch (error) {
      console.error('Error fetching activity logs:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить логи активности",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchFilterOptions = async () => {
    try {
      // Получаем уникальные отделы
      const { data: deptData, error: deptError } = await supabase
        .from('employee_activity_logs_view')
        .select('department')
        .not('department', 'is', null);

      if (deptError) throw deptError;

      const uniqueDepartments = [...new Set(deptData?.map(item => item.department))];
      setDepartments(uniqueDepartments);

      // Получаем уникальные типы действий
      const { data: actionData, error: actionError } = await supabase
        .from('employee_activity_logs_view')
        .select('action_type')
        .not('action_type', 'is', null);

      if (actionError) throw actionError;

      const uniqueActionTypes = [...new Set(actionData?.map(item => item.action_type))];
      setActionTypes(uniqueActionTypes);
    } catch (error) {
      console.error('Error fetching filter options:', error);
    }
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilterType("all");
    setFilterDepartment("all");
    setCurrentPage(1);
  };

  const getActionTypeVariant = (actionType: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      'login': 'default',
      'logout': 'secondary',
      'create': 'default',
      'update': 'secondary',
      'delete': 'destructive',
      'view': 'outline',
      'download': 'outline',
      'upload': 'default'
    };
    return variants[actionType] || 'outline';
  };

  const getActionIcon = (actionType: string) => {
    const icons: Record<string, React.ComponentType<any>> = {
      'login': User,
      'logout': User,
      'create': FileText,
      'update': FileText,
      'delete': FileText,
      'view': Activity,
      'download': Activity,
      'upload': Activity
    };
    const IconComponent = icons[actionType] || Activity;
    return <IconComponent className="h-4 w-4" />;
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "dd.MM.yyyy HH:mm", { locale: ru });
  };

  const totalPages = Math.ceil(totalCount / itemsPerPage);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Логи активности сотрудников
          </CardTitle>
          <CardDescription>
            Просмотр всех действий сотрудников в системе. Всего записей: {totalCount}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Фильтры */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по имени, email или описанию действия..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Тип действия" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все действия</SelectItem>
                {actionTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Отдел" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все отделы</SelectItem>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={resetFilters}>
              <Filter className="h-4 w-4 mr-2" />
              Сбросить
            </Button>
          </div>

          {/* Таблица логов */}
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[130px]">Дата</TableHead>
                      <TableHead>Сотрудник</TableHead>
                      <TableHead>Отдел</TableHead>
                      <TableHead>Действие</TableHead>
                      <TableHead>Описание</TableHead>
                      <TableHead className="w-[100px]">IP</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          Логи не найдены
                        </TableCell>
                      </TableRow>
                    ) : (
                      logs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="text-sm">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3 text-muted-foreground" />
                              {formatDate(log.created_at)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="font-medium">{log.employee_name}</div>
                              <div className="text-sm text-muted-foreground">{log.employee_email}</div>
                              <div className="text-xs text-muted-foreground">{log.position}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{log.department}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={getActionTypeVariant(log.action_type)} className="flex items-center gap-1 w-fit">
                              {getActionIcon(log.action_type)}
                              {log.action_type}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-[300px]">
                            <div className="truncate" title={log.action_description}>
                              {log.action_description}
                            </div>
                            {log.target_type && (
                              <div className="text-xs text-muted-foreground mt-1">
                                Объект: {log.target_type}
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {log.ip_address || "—"}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Пагинация */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Показано {((currentPage - 1) * itemsPerPage) + 1}-{Math.min(currentPage * itemsPerPage, totalCount)} из {totalCount}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(1)}
                    >
                      Первая
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => prev - 1)}
                    >
                      Назад
                    </Button>
                    <span className="text-sm">
                      Страница {currentPage} из {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(prev => prev + 1)}
                    >
                      Вперед
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(totalPages)}
                    >
                      Последняя
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};