
import { ReactNode, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  LayoutDashboard, 
  Users, 
  Brain, 
  LogOut,
  Zap,
  BarChart3,
  Settings,
  Briefcase,
  AlertTriangle,
  CheckSquare,
  Trophy,
  ShoppingBag,
  ChevronDown,
  ChevronRight,
  ShieldCheck
} from "lucide-react";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useAllEmployeeStats } from "@/hooks/useEmployeeStats";
import { useAllEmployeePoints } from "@/hooks/useEmployeePoints";
import { useOrg } from "@/contexts/OrgContext";
 
interface AdminLayoutProps {
  children: ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
  user: {
    name: string;
    points?: number;
    employeeId?: string;
    role: 'admin' | 'employee' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
  };
  onLogout?: () => void;
}

export const AdminLayout = ({ children, currentPage, onPageChange, user, onLogout }: AdminLayoutProps) => {
  const [workSectionOpen, setWorkSectionOpen] = useState(true);
  const [managementSectionOpen, setManagementSectionOpen] = useState(false);
  // Get real admin points from database
  const { points: realPoints, loading: pointsLoading } = useEmployeePoints(user.employeeId);
  const { currentOrg } = useOrg();
  
  // Get real team stats with department filtering
  const departmentFilter = (() => {
    if (user.role === 'руководитель тех отдела') {
      return 'тех отдел';
    } else if (user.role === 'руководитель ИИ отдела') {
      return 'креатив отдел';
    }
    return undefined; // Admin sees all
  })();
  
  const { stats: allEmployeeStats } = useAllEmployeeStats(departmentFilter);
  const { pointsData: allPointsData } = useAllEmployeePoints();
  
  // Filter stats based on user role (for admin only, to exclude sales)
  const filteredStats = (() => {
    if (user.role === 'admin') {
      // Admin sees all departments except sales
      return allEmployeeStats.filter(emp => 
        emp.department?.toLowerCase() !== 'отдел продаж'
      );
    }
    // Department leads already get filtered data from the hook
    return allEmployeeStats;
  })();
  
  const filteredPointsData = allPointsData.filter(p => 
    filteredStats.some(emp => emp.id === p.employee_id)
  );
  
  const teamStats = {
    totalEmployees: filteredStats.length,
    activeEmployees: filteredStats.filter(emp => emp.status === 'active').length,
    averageEfficiency: filteredStats.length > 0 
      ? Math.round(filteredStats.reduce((sum, emp) => sum + (emp.efficiency || 0), 0) / filteredStats.length)
      : 0,
    totalPoints: filteredPointsData.reduce((sum, emp) => sum + emp.total_points, 0)
  };
  
  // Navigation based on user role
  const navigation = (() => {
    if (user.role === 'admin') {
      return {
        main: [
          { id: 'admin-dashboard', label: 'Дашборд команды', icon: LayoutDashboard }
        ],
        management: [
          { id: 'sales-management', label: 'Отдел продаж', icon: BarChart3 },
          { id: 'projects-management', label: 'Управление проектами', icon: Briefcase },
          { id: 'overdue-tasks', label: 'Просрочки', icon: AlertTriangle },
          { id: 'cases-management', label: 'Кейсы', icon: Users },
          { id: 'roles-access', label: 'Роли и права', icon: ShieldCheck },
          { id: 'achievements-management', label: 'Достижения', icon: Trophy },
          { id: 'shop', label: 'Магазин', icon: ShoppingBag },
          { id: 'ai-analysis', label: 'ИИ Анализ', icon: Brain },
          { id: 'settings', label: 'Настройки', icon: Settings }
        ]
      };
    } else if (user.role === 'руководитель тех отдела') {
      return {
        main: [
          { id: 'admin-dashboard', label: 'Команда', icon: LayoutDashboard },
          { id: 'dashboard', label: 'Мой дашборд', icon: LayoutDashboard }
        ],
        work: [
          { id: 'tasks', label: 'Сделанные работы', icon: CheckSquare },
          { id: 'project-tasks', label: 'Задачи', icon: Zap },
          { id: 'achievements', label: 'Достижения', icon: Trophy },
          { id: 'shop', label: 'Магазин', icon: ShoppingBag }
        ],
        management: [
          { id: 'projects-management', label: 'Управление проектами', icon: Briefcase },
          { id: 'overdue-tasks', label: 'Просрочки', icon: AlertTriangle },
          { id: 'cases-management', label: 'Кейсы', icon: Users },
          { id: 'roles-access', label: 'Роли и права', icon: ShieldCheck },
          { id: 'ai-analysis', label: 'ИИ Анализ', icon: Brain },
          { id: 'settings', label: 'Настройки', icon: Settings }
        ]
      };
    } else if (user.role === 'руководитель ИИ отдела') {
      return {
        main: [
          { id: 'admin-dashboard', label: 'Команда', icon: LayoutDashboard },
          { id: 'dashboard', label: 'Мой дашборд', icon: LayoutDashboard }
        ],
        work: [
          { id: 'tasks', label: 'Сделанные работы', icon: CheckSquare },
          { id: 'project-tasks', label: 'Задачи', icon: Zap },
          { id: 'achievements', label: 'Достижения', icon: Trophy },
          { id: 'shop', label: 'Магазин', icon: ShoppingBag }
        ],
        management: [
          { id: 'projects-management', label: 'Управление проектами', icon: Briefcase },
          { id: 'overdue-tasks', label: 'Просрочки', icon: AlertTriangle },
          { id: 'cases-management', label: 'Кейсы', icon: Users },
          { id: 'roles-access', label: 'Роли и права', icon: ShieldCheck },
          { id: 'ai-analysis', label: 'ИИ Анализ', icon: Brain },
          { id: 'settings', label: 'Настройки', icon: Settings }
        ]
      };
    }
    
    return {
      main: [
        { id: 'admin-dashboard', label: 'Дашборд команды', icon: LayoutDashboard }
      ]
    };
  })();

  useEffect(() => {
    if (navigation.work?.some(item => item.id === currentPage)) {
      setWorkSectionOpen(true);
    }
    if (navigation.management?.some(item => item.id === currentPage)) {
      setManagementSectionOpen(true);
    }
  }, [currentPage]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-primary p-2 rounded-lg shadow-glow">
                <Zap className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                  Pimmi Team
                </h1>
                <p className="text-sm text-muted-foreground">Панель руководителя</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground font-semibold px-3 py-1">
                {pointsLoading ? '...' : realPoints || 0} баллов
              </Badge>
              <div className="hidden sm:block">
                <Badge variant="outline" className="text-xs">{currentOrg?.name || 'Main Company'}</Badge>
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">{user.name}</span>
                  <Badge className="bg-warning/20 text-warning border-warning/30 text-xs">
                    Руководитель
                  </Badge>
                </div>
              </div>
              
              <Button variant="ghost" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <aside className="w-full lg:w-64 space-y-2">
            <div className="bg-card rounded-lg p-4 shadow-card border border-border">
              <nav className="space-y-3">
                {/* Main Navigation */}
                <div className="space-y-1">
                  {navigation.main?.map((item) => {
                    const Icon = item.icon;
                    return (
                      <Button
                        key={item.id}
                        variant={currentPage === item.id ? "default" : "ghost"}
                        className={`w-full justify-start ${
                          currentPage === item.id 
                            ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                            : "hover:bg-secondary"
                        }`}
                        onClick={() => onPageChange(item.id)}
                      >
                        <Icon className="h-4 w-4 mr-3" />
                        {item.label}
                      </Button>
                    );
                  })}
                </div>

                {/* Work Section */}
                {navigation.work && (
                  <Collapsible open={workSectionOpen} onOpenChange={setWorkSectionOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between text-sm text-muted-foreground hover:text-foreground">
                        <span>Моя работа</span>
                        {workSectionOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-1 mt-1">
                      {navigation.work.map((item) => {
                        const Icon = item.icon;
                        return (
                          <Button
                            key={item.id}
                            variant={currentPage === item.id ? "default" : "ghost"}
                            size="sm"
                            className={`w-full justify-start ml-2 ${
                              currentPage === item.id 
                                ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                                : "hover:bg-secondary"
                            }`}
                            onClick={() => onPageChange(item.id)}
                          >
                            <Icon className="h-3 w-3 mr-2" />
                            {item.label}
                          </Button>
                        );
                      })}
                    </CollapsibleContent>
                  </Collapsible>
                )}

                {/* Management Section */}
                {navigation.management && (
                  <Collapsible open={managementSectionOpen} onOpenChange={setManagementSectionOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between text-sm text-muted-foreground hover:text-foreground">
                        <span>Управление</span>
                        {managementSectionOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-1 mt-1">
                      {navigation.management.map((item) => {
                        const Icon = item.icon;
                        return (
                          <Button
                            key={item.id}
                            variant={currentPage === item.id ? "default" : "ghost"}
                            size="sm"
                            className={`w-full justify-start ml-2 ${
                              currentPage === item.id 
                                ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                                : "hover:bg-secondary"
                            }`}
                            onClick={() => onPageChange(item.id)}
                          >
                            <Icon className="h-3 w-3 mr-2" />
                            {item.label}
                          </Button>
                        );
                      })}
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </nav>
            </div>

            {/* Quick Stats */}
            <div className="bg-card rounded-lg p-4 shadow-card border border-border">
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                Быстрая статистика
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Команда:</span>
                  <span className="font-medium">{teamStats.totalEmployees} человек</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Активных:</span>
                  <span className="font-medium text-success">{teamStats.activeEmployees}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Эффективность:</span>
                  <span className="font-medium text-primary">{teamStats.averageEfficiency}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Общие баллы:</span>
                  <span className="font-medium text-warning">{teamStats.totalPoints.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};
