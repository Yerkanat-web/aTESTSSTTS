import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, ArrowRight, Building2, Edit, Plus, Calendar, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { EditExtensionDialog } from "./EditExtensionDialog";

interface ExtensionData {
  id: string;
  project_name: string | null;
  client_name: string | null;
  manager_name: string;
  sale_date: string;
  sale_amount: number;
  prepayment: number | null;
  remainder: number | null;
  project_status: string | null;
  extension_sequence: number;
  original_project_name: string | null;
  original_manager_name: string | null;
  work_format: string[] | null;
  description: string | null;
  paid_until: string | null;
  parent_project_id: string | null;
}

export const ProjectExtensionsPage = () => {
  const [extensions, setExtensions] = useState<ExtensionData[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedExtension, setSelectedExtension] = useState<ExtensionData | null>(null);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  const fetchExtensions = async () => {
    try {
      setLoading(true);
      console.log("Fetching project extensions...");
      
      const { data, error } = await supabase
        .from("sales_results")
        .select(`
          id,
          project_name,
          client_name,
          sale_date,
          sale_amount,
          prepayment,
          remainder,
          project_status,
          extension_sequence,
          description,
          work_format,
          paid_until,
          parent_project_id,
          employees!fk_sales_results_employee(name),
          parent_project:sales_results!parent_project_id(
            project_name,
            employees!fk_sales_results_employee(name)
          )
        `)
        .eq("is_extension", true)
        .order("sale_date", { ascending: false });

      if (error) {
        console.error("Error fetching extensions:", error);
        throw error;
      }

      console.log("Extensions data:", data);

      // Transform data
      const transformedExtensions: ExtensionData[] = (data || []).map((ext: any) => ({
        id: ext.id,
        project_name: ext.project_name,
        client_name: ext.client_name,
        manager_name: ext.employees?.name || "Не указан",
        sale_date: ext.sale_date,
        sale_amount: ext.sale_amount,
        prepayment: ext.prepayment,
        remainder: ext.remainder,
        project_status: ext.project_status,
        extension_sequence: ext.extension_sequence,
        original_project_name: ext.parent_project?.project_name || null,
        original_manager_name: ext.parent_project?.employees?.name || null,
        work_format: ext.work_format,
        description: ext.description,
        paid_until: ext.paid_until,
        parent_project_id: ext.parent_project_id,
      }));

      setExtensions(transformedExtensions);
    } catch (error: any) {
      console.error("Error:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить продления проектов",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExtensions();
    
    // Подписка на изменения в таблице sales_results (для всех проектов)
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'sales_results'
        },
        (payload) => {
          console.log('Sales results data changed, refreshing extensions...', payload);
          fetchExtensions();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getStatusBadge = (status: string | null) => {
    const statusConfig = {
      "Работаем": { variant: "default" as const, className: "bg-blue-500" },
      "Еще не начали": { variant: "secondary" as const, className: "bg-gray-500" },
      "Закончили": { variant: "default" as const, className: "bg-green-500" },
      "Ждём остаток": { variant: "default" as const, className: "bg-yellow-500" },
      "Завершили работу": { variant: "default" as const, className: "bg-green-600" },
      "Пауза": { variant: "default" as const, className: "bg-orange-500" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || { 
      variant: "outline" as const, 
      className: "bg-gray-400" 
    };

    return (
      <Badge variant={config.variant} className={config.className}>
        {status || "Не указан"}
      </Badge>
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ru-RU").format(amount) + " ₸";
  };

  const handleExtendProject = async (extension: ExtensionData) => {
    if (!extension.parent_project_id) {
      toast({
        title: "Ошибка",
        description: "Не удается найти исходный проект для продления",
        variant: "destructive",
      });
      return;
    }

    try {
      // Получаем данные исходного проекта
      const { data: originalProject, error: originalError } = await supabase
        .from("sales_results")
        .select(`
          *,
          employees!fk_sales_results_employee(id, name)
        `)
        .eq("id", extension.parent_project_id)
        .single();

      if (originalError || !originalProject) {
        throw new Error("Не удалось найти исходный проект");
      }

      // Получаем ID администратора
      const { data: adminEmployee, error: adminError } = await supabase
        .from("employees")
        .select("id")
        .eq("email", "admin@demo.kz")
        .eq("role", "admin")
        .single();

      if (adminError || !adminEmployee) {
        throw new Error("Не удалось найти администратора");
      }

      // Определяем следующий номер продления
      const { data: extensions, error: extensionsError } = await supabase
        .from("sales_results")
        .select("extension_sequence")
        .eq("parent_project_id", extension.parent_project_id)
        .order("extension_sequence", { ascending: false })
        .limit(1);

      if (extensionsError) {
        throw extensionsError;
      }

      const nextSequence = extensions.length > 0 ? extensions[0].extension_sequence + 1 : 1;

      // Вычисляем дату нового продления (на месяц вперед от текущего продления)
      const currentDate = new Date(extension.sale_date);
      const newDate = new Date(currentDate);
      newDate.setMonth(newDate.getMonth() + 1);

      // Создаем новое продление с назначением на администратора
      const { error: insertError } = await supabase
        .from("sales_results")
        .insert(withOrg({
          employee_id: adminEmployee.id, // Назначаем на администратора
          sale_amount: extension.sale_amount, // Та же сумма
          sale_date: newDate.toISOString().split('T')[0],
          project_name: `${originalProject.project_name} (Продление ${nextSequence})`,
          client_name: extension.client_name,
          project_status: "Еще не начали",
          project_type: originalProject.project_type,
          work_format: extension.work_format,
          is_extension: true,
          extension_sequence: nextSequence,
          parent_project_id: extension.parent_project_id,
          original_employee_id: originalProject.employee_id,
          description: `Продление проекта "${originalProject.project_name}" до ${format(new Date(newDate.getTime() + 30 * 24 * 60 * 60 * 1000), "dd.MM.yyyy", { locale: ru })}`
        } as any, currentOrgId));

      if (insertError) {
        throw insertError;
      }

      toast({
        title: "Успех",
        description: `Продление проекта создано успешно (Продление ${nextSequence})`,
      });

      fetchExtensions();
    } catch (error: any) {
      console.error("Error extending project:", error);
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать продление проекта",
        variant: "destructive",
      });
    }
  };

  const deleteExtension = async (extensionId: string, extensionName: string) => {
    const confirmDelete = window.confirm(
      `Вы уверены, что хотите удалить продление проекта "${extensionName || 'Без названия'}"?\n\nЭто также удалит все связанные задачи, ежемесячные платежи и аккаунты. Это действие нельзя отменить.`
    );
    
    if (!confirmDelete) return;

    try {
      console.log(`Deleting extension: ${extensionId}`);
      
      // Удаляем все связанные данные продления
      // 1. Удаляем задачи проекта
      const { error: tasksError } = await supabase
        .from("project_tasks")
        .delete()
        .eq("sales_result_id", extensionId);

      if (tasksError) {
        console.error("Error deleting project tasks:", tasksError);
        throw tasksError;
      }
      
      // 2. Удаляем ежемесячные платежи
      const { error: paymentsError } = await supabase
        .from("monthly_payments")
        .delete()
        .eq("sales_result_id", extensionId);

      if (paymentsError) {
        console.error("Error deleting monthly payments:", paymentsError);
        throw paymentsError;
      }
      
      // 3. Удаляем аккаунты проектов
      const { error: accountsError } = await supabase
        .from("project_accounts")
        .delete()
        .eq("sales_result_id", extensionId);

      if (accountsError) {
        console.error("Error deleting project accounts:", accountsError);
        throw accountsError;
      }
      
      // 4. Наконец, удаляем само продление
      const { error: extensionError } = await supabase
        .from("sales_results")
        .delete()
        .eq("id", extensionId);

      if (extensionError) {
        console.error("Error deleting extension:", extensionError);
        throw extensionError;
      }

      // Обновляем локальное состояние
      setExtensions(prevExtensions => 
        prevExtensions.filter(extension => extension.id !== extensionId)
      );

      toast({
        title: "Успешно",
        description: "Продление проекта и все связанные данные удалены",
      });

    } catch (error) {
      console.error("Error deleting extension:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить продление проекта",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Building2 className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Продления проектов</h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowRight className="h-5 w-5" />
            Все продления ({extensions.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {extensions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Продлений проектов пока нет</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Проект (продление)</TableHead>
                    <TableHead>Клиент</TableHead>
                    <TableHead>Исходный проект</TableHead>
                    <TableHead>Менеджер</TableHead>
                    <TableHead>№ продления</TableHead>
                    <TableHead>Дата продления</TableHead>
                    <TableHead>Дата окончания</TableHead>
                    <TableHead>Сумма</TableHead>
                    <TableHead>Предоплата</TableHead>
                    <TableHead>Остаток</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Формат работы</TableHead>
                    <TableHead>Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {extensions.map((extension) => (
                    <TableRow key={extension.id}>
                      <TableCell className="font-medium">
                        <div>
                          <div className="font-semibold">{extension.project_name}</div>
                          {extension.description && (
                            <div className="text-sm text-muted-foreground mt-1">
                              {extension.description}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{extension.client_name || "Не указан"}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{extension.original_project_name || "Не указан"}</div>
                          {extension.original_manager_name && (
                            <div className="text-sm text-muted-foreground">
                              Менеджер: {extension.original_manager_name}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{extension.manager_name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">#{extension.extension_sequence}</Badge>
                      </TableCell>
                      <TableCell>
                        {format(new Date(extension.sale_date), "dd MMMM yyyy", { locale: ru })}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {extension.paid_until ? 
                            format(new Date(extension.paid_until), "dd MMMM yyyy", { locale: ru }) : 
                            <span className="text-muted-foreground">Не указана</span>
                          }
                        </div>
                      </TableCell>
                      <TableCell className="font-semibold">
                        {formatCurrency(extension.sale_amount)}
                      </TableCell>
                      <TableCell className="font-medium">
                        {extension.prepayment ? formatCurrency(extension.prepayment) : "0 ₸"}
                      </TableCell>
                      <TableCell className={`font-medium ${extension.remainder && extension.remainder > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                        {extension.remainder ? formatCurrency(extension.remainder) : "0 ₸"}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(extension.project_status)}
                      </TableCell>
                      <TableCell>
                        {extension.work_format && extension.work_format.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {extension.work_format.map((format, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {format}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">Не указан</span>
                        )}
                      </TableCell>
                       <TableCell>
                         <div className="flex gap-2">
                           <Button
                             variant="outline"
                             size="sm"
                             onClick={() => {
                               setSelectedExtension(extension);
                               setIsEditDialogOpen(true);
                             }}
                             className="hover-scale"
                             title="Редактировать продление"
                           >
                             <Edit className="h-4 w-4" />
                           </Button>
                           <Button
                             variant="outline"
                             size="sm"
                             onClick={() => handleExtendProject(extension)}
                             className="hover-scale text-green-600 hover:text-green-700"
                             title="Продлить на еще один месяц"
                           >
                             <Plus className="h-4 w-4" />
                           </Button>
                           <Button
                             variant="outline"
                             size="sm"  
                             onClick={() => deleteExtension(extension.id, extension.project_name || "")}
                             className="hover-scale text-red-600 hover:text-red-700 border-red-200 hover:border-red-300"
                             title="Удалить продление"
                           >
                             <Trash2 className="h-4 w-4" />
                           </Button>
                         </div>
                       </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <EditExtensionDialog
        isOpen={isEditDialogOpen}
        onClose={() => {
          setIsEditDialogOpen(false);
          setSelectedExtension(null);
        }}
        extension={selectedExtension ? {
          ...selectedExtension,
          paid_until: selectedExtension.paid_until
        } : null}
        onExtensionUpdated={() => {
          fetchExtensions();
        }}
      />
    </div>
  );
};
