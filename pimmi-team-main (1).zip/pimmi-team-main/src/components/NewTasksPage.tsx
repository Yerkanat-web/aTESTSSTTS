import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Clock, CheckCircle, Plus, FileText, Target, Award, Upload, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { logger } from "@/utils/logger";
import { useTasksWithAttachments, type TaskWithAttachments } from "@/hooks/useTasksWithAttachments";
import { useFileUpload } from "@/hooks/useFileUpload";
import { useTaskCategories } from "@/hooks/useTaskCategories";
import { formatTime, parseTimeToMinutes } from "@/utils/timeHelpers";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";

interface Employee {
  id: string;
  name: string;
  role: string;
}

export default function NewTasksPage() {
  const [loading, setLoading] = useState(true);
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);
  const { toast } = useToast();

  // Form states
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("");
  const [category, setCategory] = useState("");
  const [estimatedHours, setEstimatedHours] = useState("");
  const [estimatedMinutes, setEstimatedMinutes] = useState("");
  const [actualHours, setActualHours] = useState("");
  const [actualMinutes, setActualMinutes] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Custom hooks
  const { points, loading: pointsLoading, recalculate: recalculatePoints, refetch: refetchPoints } = useEmployeePoints(currentEmployee?.id);
  const { tasks, loading: tasksLoading, refetch: refetchTasks } = useTasksWithAttachments(currentEmployee?.id);
  const { uploadFile, uploading } = useFileUpload();
  const { categories, loading: categoriesLoading } = useTaskCategories();
  const { currentOrgId } = useOrg();
  
  logger.debug('NewTasksPage rendered', { 
    employeeId: currentEmployee?.id, 
    points, 
    loading: pointsLoading,
    categoriesCount: categories.length,
    categoriesLoading,
    categories: categories
  });

  useEffect(() => {
    fetchCurrentEmployee();
  }, []);

  const fetchCurrentEmployee = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: employee, error } = await supabase
        .from('employees')
        .select('id, name, role')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;
      setCurrentEmployee(employee);
    } catch (error) {
      logger.error('Error fetching current employee', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Проверяем текущую сессию пользователя
    logger.info('🔍 Checking authentication before task creation');
    
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError) {
      logger.error('❌ Session error:', sessionError);
      toast({
        title: "Ошибка аутентификации",
        description: "Проблема с сессией пользователя. Попробуйте перезайти.",
        variant: "destructive",
      });
      return;
    }

    if (!session || !session.user) {
      logger.error('❌ No active session found');
      toast({
        title: "Не авторизован",
        description: "Сессия истекла. Пожалуйста, войдите заново.",
        variant: "destructive",
      });
      return;
    }

    if (!currentEmployee) {
      logger.error('❌ Current employee not found', undefined, { 
        data: {
          sessionUserId: session.user.id,
          sessionUserEmail: session.user.email
        }
      });
      toast({
        title: "Ошибка",
        description: "Информация о сотруднике не найдена. Попробуйте обновить страницу.",
        variant: "destructive",
      });
      return;
    }

    logger.info('✅ Authentication check passed', {
      data: {
        userId: session.user.id,
        userEmail: session.user.email,
        employeeId: currentEmployee.id,
        employeeName: currentEmployee.name,
        employeeRole: currentEmployee.role
      }
    });

    logger.debug('Starting task submission', {
      employee: currentEmployee.id,
      title,
      hasFile: !!selectedFile,
      fileSize: selectedFile?.size,
      fileName: selectedFile?.name
    });

    try {
      const estimatedHoursTotal = parseInt(estimatedHours || "0") + parseInt(estimatedMinutes || "0") / 60;
      const actualHoursTotal = parseInt(actualHours || "0") + parseInt(actualMinutes || "0") / 60;

      const taskData = {
        employee_id: currentEmployee.id,
        title,
        description,
        priority,
        category,
        estimated_minutes: parseTimeToMinutes(parseInt(estimatedHours || "0"), parseInt(estimatedMinutes || "0")),
        actual_minutes: parseTimeToMinutes(parseInt(actualHours || "0"), parseInt(actualMinutes || "0")),
        status: 'completed'
      };

      logger.info('📝 Creating task in employee_tasks table', { 
        data: {
          taskData,
          currentAuthUserId: session.user.id 
        }
      });
      
      // Create task
      const { data: task, error: taskError } = await supabase
        .from('employee_tasks')
        .insert(withOrg(taskData as any, currentOrgId))
        .select()
        .single();

      if (taskError) {
        logger.error('Task creation failed', taskError);
        throw taskError;
      }

      logger.debug('Task created successfully', { taskId: task.id });

      // Handle file upload if there's a selected file
      let fileUploadSuccess = true;
      if (selectedFile && task) {
        logger.debug('Starting file upload');
        const uploadResult = await uploadFile(selectedFile, task.id, currentEmployee.id);
        
        if (!uploadResult) {
          logger.error('File upload failed');
          fileUploadSuccess = false;
          
          toast({
            title: "Частичная ошибка",
            description: "Задача создана, но файл не загружен. Проверьте консоль для деталей.",
            variant: "destructive",
          });
          
          // Don't return here - we still want to refresh the data
          // because the task was created successfully
        } else {
          logger.debug('File uploaded successfully', { fileName: uploadResult.file_name });
        }
      }

      // Only show full success if everything worked
      if (fileUploadSuccess) {
        toast({
          title: "Success",
          description: selectedFile ? "Task and file added successfully!" : "Task added successfully!",
        });
        
        // Reset form only on complete success
        logger.debug('Resetting form after successful task creation');
        setTitle("");
        setDescription("");
        setPriority("");
        setCategory("");
        setEstimatedHours("");
        setEstimatedMinutes("");
        setActualHours("");
        setActualMinutes("");
        setSelectedFile(null);
      }

      // Always refresh tasks and recalculate points since task was created
      logger.debug('Refreshing data after task creation');
      refetchTasks();
      // Trigger point recalculation since we added a completed task
      await recalculatePoints();
      await refetchPoints();
      
    } catch (error) {
      logger.error('Error adding task', error);
      toast({
        title: "Error",
        description: `Failed to add task: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  };

  const totalTasks = tasks.length;
  const totalTimeSpent = tasks.reduce((total, task) => total + (task.actual_minutes || 0), 0);
  const earnedPoints = points;

  if (loading || tasksLoading || pointsLoading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  const getPriorityVariant = (priority: string | null) => {
    switch (priority) {
      case 'easy': return 'secondary';
      case 'medium': return 'default';
      case 'hard': return 'destructive';
      default: return 'outline';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'easy': return 'Легкий';
      case 'medium': return 'Средний';
      case 'hard': return 'Трудный';
      default: return priority;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tasks</h1>
          <p className="text-muted-foreground">Track your completed work and manage tasks</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tasks</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTasks}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Time Spent</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatTime(totalTimeSpent)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Points Earned</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{earnedPoints}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completion</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">100%</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="add" className="space-y-4">
        <TabsList>
          <TabsTrigger value="add">Add Task</TabsTrigger>
          <TabsTrigger value="list">Task List</TabsTrigger>
        </TabsList>

        <TabsContent value="add" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Add New Task</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="title" className="text-sm font-medium">
                      Task Title
                    </label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Enter task title"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="priority" className="text-sm font-medium">
                      Сложность работы
                    </label>
                    <Select 
                      value={priority} 
                      onValueChange={(value) => {
                        logger.debug('Priority changed', { priority: value });
                        setPriority(value);
                      }} 
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите сложность" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Легкий (5 баллов)</SelectItem>
                        <SelectItem value="medium">Средний (15 баллов)</SelectItem>
                        <SelectItem value="hard">Трудный (30 баллов)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">
                    Description
                  </label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe the task..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="category" className="text-sm font-medium">
                      Category
                      {categoriesLoading && (
                        <span className="text-xs text-muted-foreground ml-2">(загрузка...)</span>
                      )}
                    </label>
                    <Select 
                      value={category} 
                      onValueChange={setCategory} 
                      required
                      disabled={categoriesLoading}
                    >
                      <SelectTrigger>
                        <SelectValue 
                          placeholder={categoriesLoading ? "Загрузка категорий..." : "Выберите категорию"} 
                        />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.length === 0 && !categoriesLoading ? (
                          <SelectItem value="" disabled>
                            Категории не найдены
                          </SelectItem>
                        ) : (
                          categories.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    {!categoriesLoading && categories.length === 0 && (
                      <p className="text-xs text-destructive">
                        Ошибка загрузки категорий. Обновите страницу.
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Estimated Time</label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        value={estimatedHours}
                        onChange={(e) => setEstimatedHours(e.target.value)}
                        placeholder="Hours"
                        min="0"
                      />
                      <Input
                        type="number"
                        value={estimatedMinutes}
                        onChange={(e) => setEstimatedMinutes(e.target.value)}
                        placeholder="Minutes"
                        min="0"
                        max="59"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Actual Time</label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        value={actualHours}
                        onChange={(e) => setActualHours(e.target.value)}
                        placeholder="Hours"
                        min="0"
                        required
                      />
                      <Input
                        type="number"
                        value={actualMinutes}
                        onChange={(e) => setActualMinutes(e.target.value)}
                        placeholder="Minutes"
                        min="0"
                        max="59"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="file" className="text-sm font-medium">
                      Attachment
                    </label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="file"
                        onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                        className="cursor-pointer"
                      />
                      {selectedFile && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedFile(null)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={uploading}>
                  {uploading ? (
                    <>
                      <Upload className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Task
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Task List</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Estimated</TableHead>
                    <TableHead>Actual</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Attachments</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">{task.title}</TableCell>
                      <TableCell>
                        <Badge variant={getPriorityVariant(task.priority)}>
                          {getPriorityLabel(task.priority || '')}
                        </Badge>
                      </TableCell>
                      <TableCell>{task.category}</TableCell>
                       <TableCell>{formatTime(task.estimated_minutes)}</TableCell>
                       <TableCell>{formatTime(task.actual_minutes)}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {task.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {task.attachments && task.attachments.length > 0 && (
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4" />
                            <span className="text-sm">
                              {task.attachments[0].file_name}
                              {task.attachment_count > 1 && ` (+${task.attachment_count - 1} more)`}
                            </span>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {new Date(task.created_at).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}