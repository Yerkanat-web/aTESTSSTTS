import React, { useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Check, Minus, ShieldCheck } from "lucide-react";

interface RolesAccessPageProps {
  user: {
    role: 'admin' | 'employee' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
  } | null;
}

const rolesOrder = [
  { key: 'admin', label: 'Админ' },
  { key: 'руководитель тех отдела', label: 'Руководитель тех' },
  { key: 'руководитель отдела продаж', label: 'Руководитель продаж' },
  { key: 'руководитель ИИ отдела', label: 'Руководитель ИИ' },
  { key: 'финансист', label: 'Финансист' },
  { key: 'employee', label: 'Сотрудник' },
] as const;

const resources = [
  { key: 'employees', label: 'Сотрудники' },
  { key: 'employee_tasks', label: 'Задачи сотрудника' },
  { key: 'project_tasks', label: 'Проектные задачи' },
  { key: 'sales_results', label: 'Продажи' },
  { key: 'monthly_payments', label: 'Ежемесячные платежи' },
  { key: 'project_cases', label: 'Кейсы' },
  { key: 'project_categories', label: 'Категории проектов' },
] as const;

// Permissions matrix summarized from RLS policies (view/create/update/delete)
const matrix: Record<(typeof rolesOrder)[number]['key'], Record<(typeof resources)[number]['key'], [boolean, boolean, boolean, boolean]>> = {
  admin: {
    employees: [true, true, true, true],
    employee_tasks: [true, true, true, true],
    project_tasks: [true, true, true, true],
    sales_results: [true, true, true, true],
    monthly_payments: [true, true, true, true],
    project_cases: [true, true, true, true],
    project_categories: [true, true, true, true],
  },
  'руководитель тех отдела': {
    employees: [true, false, false, false],
    employee_tasks: [true, true, true, true],
    project_tasks: [true, true, true, true],
    sales_results: [true, true, true, true],
    monthly_payments: [false, false, true, true],
    project_cases: [true, true, true, false],
    project_categories: [true, false, false, false],
  },
  'руководитель отдела продаж': {
    employees: [true, false, false, false],
    employee_tasks: [true, true, true, true],
    project_tasks: [true, true, false, false],
    sales_results: [true, true, false, false],
    monthly_payments: [false, true, false, false],
    project_cases: [true, true, true, false],
    project_categories: [true, false, false, false],
  },
  'руководитель ИИ отдела': {
    employees: [true, false, false, false],
    employee_tasks: [true, true, true, true],
    project_tasks: [true, true, false, false],
    sales_results: [true, true, false, false],
    monthly_payments: [false, false, false, false],
    project_cases: [true, true, true, false],
    project_categories: [true, false, false, false],
  },
  финансист: {
    employees: [true, false, false, false],
    employee_tasks: [true, false, false, false],
    project_tasks: [false, false, false, false],
    sales_results: [true, false, true, false],
    monthly_payments: [true, true, true, true],
    project_cases: [false, false, false, false],
    project_categories: [false, false, false, false],
  },
  employee: {
    employees: [true, true, false, false],
    employee_tasks: [true, true, true, true],
    project_tasks: [true, true, true, false],
    sales_results: [true, true, true, true],
    monthly_payments: [true, false, false, false],
    project_cases: [false, true, false, false],
    project_categories: [false, false, false, false],
  },
};

const Cell = ({ allowed }: { allowed: boolean }) => (
  <div className={`flex items-center justify-center ${allowed ? 'text-success' : 'text-muted-foreground'}`}>
    {allowed ? <Check className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
  </div>
);

export const RolesAccessPage: React.FC<RolesAccessPageProps> = ({ user }) => {
  useEffect(() => {
    document.title = 'Roles & Access – Pimmi Team';
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', 'Roles and access matrix for admins and managers in Pimmi Team.');
    } else {
      const m = document.createElement('meta');
      m.setAttribute('name', 'description');
      m.setAttribute('content', 'Roles and access matrix for admins and managers in Pimmi Team.');
      document.head.appendChild(m);
    }
    const canonicalId = 'roles-access-canonical';
    let link = document.querySelector(`#${canonicalId}`) as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.id = canonicalId;
      link.rel = 'canonical';
      document.head.appendChild(link);
    }
    link.href = window.location.href;
  }, []);

  const role = user?.role ?? 'employee';
  const isAllowed = role === 'admin' || role.startsWith('руководитель');

  if (!isAllowed) {
    return (
      <Card className="p-6">
        <h1 className="text-2xl font-bold mb-2">Access denied</h1>
        <p className="text-muted-foreground">This page is available only to admins and department leads.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <header className="flex items-center gap-3">
        <div className="bg-gradient-primary p-2 rounded-lg shadow-glow">
          <ShieldCheck className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Roles & Access</h1>
          <p className="text-sm text-muted-foreground">Сводная матрица прав доступа по ролям</p>
        </div>
      </header>

      <Card className="p-4">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Роль</TableHead>
                {resources.map((r) => (
                  <TableHead key={r.key}>{r.label}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {rolesOrder.map(({ key, label }) => (
                <TableRow key={key} className={`${key === role ? 'bg-secondary/40' : ''}`}>
                  <TableCell className="whitespace-nowrap font-medium">
                    <div className="flex items-center gap-2">
                      <Badge variant={key === role ? 'default' : 'secondary'}>{label}</Badge>
                    </div>
                  </TableCell>
                  {resources.map((res) => {
                    const [v, c, u, d] = matrix[key][res.key];
                    return (
                      <TableCell key={res.key}>
                        <div className="grid grid-cols-4 gap-1 text-xs">
                          <div className="flex flex-col items-center"><span className="text-muted-foreground">V</span><Cell allowed={v} /></div>
                          <div className="flex flex-col items-center"><span className="text-muted-foreground">C</span><Cell allowed={c} /></div>
                          <div className="flex flex-col items-center"><span className="text-muted-foreground">U</span><Cell allowed={u} /></div>
                          <div className="flex flex-col items-center"><span className="text-muted-foreground">D</span><Cell allowed={d} /></div>
                        </div>
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      <Card className="p-4 space-y-2">
        <h2 className="text-lg font-semibold">Примечания</h2>
        <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
          <li>Руководитель тех отдела видит всех сотрудников; другие руководители — только свой отдел.</li>
          <li>Сотрудники видят и управляют только своими данными согласно RLS.</li>
          <li>Финансист управляет платежами и может обновлять продажи.</li>
        </ul>
      </Card>
    </div>
  );
};

export default RolesAccessPage;
