import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, Plus, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";

interface ProjectStartDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: {
    id: string;
    project_name: string;
    work_format: string[];
  } | null;
  employees: Array<{
    id: string;
    name: string;
    department: string;
  }>;
  onSuccess: () => void;
}

interface TaskAssignment {
  id: string;
  task_name: string;
  task_type: string;
  assignee_id: string;
  due_date: Date | null;
  description: string;
  priority: "easy" | "medium" | "hard";
}

export const ProjectStartDialog = ({ 
  open, 
  onOpenChange, 
  project,
  employees,
  onSuccess 
}: ProjectStartDialogProps) => {
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [tasks, setTasks] = useState<TaskAssignment[]>([
    {
      id: crypto.randomUUID(),
      task_name: "",
      task_type: "development",
      assignee_id: "",
      due_date: null,
      description: "",
      priority: "medium"
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  const handleAddTask = () => {
    setTasks([...tasks, {
      id: crypto.randomUUID(),
      task_name: "",
      task_type: "development",
      assignee_id: "",
      due_date: null,
      description: "",
      priority: "medium"
    }]);
  };

  const handleRemoveTask = (taskId: string) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };

  const handleTaskChange = (taskId: string, field: keyof TaskAssignment, value: any) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, [field]: value } : task
    ));
  };

  const handleStart = async () => {
    // Предотвращаем повторное сохранение
    if (isLoading) return;

    if (!project || !startDate || !endDate) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive"
      });
      return;
    }

    // Проверяем что все задачи заполнены
    const incompleteTasks = tasks.filter(task => 
      !task.task_name || !task.assignee_id
    );

    if (incompleteTasks.length > 0) {
      toast({
        title: "Ошибка",
        description: "Заполните название и ответственного для всех задач",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      // Обновляем статус проекта на "Работаем"
      const { error: updateError } = await supabase
        .from("sales_results")
        .update({ 
          project_status: "Работаем"
        })
        .eq("id", project.id);

      if (updateError) throw updateError;

      // Создаем задачи проекта
      const projectTasks = tasks.map(task => ({
        sales_result_id: project.id,
        task_name: task.task_name,
        task_type: task.task_type,
        assignee_id: task.assignee_id,
        due_date: task.due_date?.toISOString().split('T')[0] || null,
        description: task.description,
        priority: task.priority,
        status: "pending"
      }));

      const { error: tasksError } = await supabase
        .from("project_tasks")
        .insert(projectTasks.map((t) => withOrg(t as any, currentOrgId)));

      if (tasksError) throw tasksError;

      toast({
        title: "Успешно",
        description: "Проект запущен и задачи созданы"
      });

      onSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error("Error starting project:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось запустить проект",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const taskTypes = [
    { value: "development", label: "Разработка" },
    { value: "design", label: "Дизайн" },
    { value: "content", label: "Контент" },
    { value: "seo", label: "SEO" },
    { value: "testing", label: "Тестирование" },
    { value: "deployment", label: "Деплой" },
    { value: "other", label: "Другое" }
  ];

  const priorityOptions = [
    { value: "easy", label: "Легкая" },
    { value: "medium", label: "Средняя" },
    { value: "hard", label: "Сложная" }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Запуск проекта: {project?.project_name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Даты проекта */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Дата старта *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon />
                    {startDate ? format(startDate, "dd.MM.yyyy") : "Выберите дату"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Дата окончания *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon />
                    {endDate ? format(endDate, "dd.MM.yyyy") : "Выберите дату"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Задачи проекта */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Задачи проекта</Label>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={handleAddTask}
              >
                <Plus className="h-4 w-4 mr-2" />
                Добавить задачу
              </Button>
            </div>

            <div className="space-y-4 max-h-[400px] overflow-y-auto">
              {tasks.map((task) => (
                <div key={task.id} className="border rounded-lg p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Задача #{tasks.indexOf(task) + 1}</h4>
                    {tasks.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveTask(task.id)}
                        className="text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Название задачи *</Label>
                      <Input
                        value={task.task_name}
                        onChange={(e) => handleTaskChange(task.id, "task_name", e.target.value)}
                        placeholder="Введите название задачи"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Тип задачи</Label>
                      <Select
                        value={task.task_type}
                        onValueChange={(value) => handleTaskChange(task.id, "task_type", value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {taskTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Ответственный *</Label>
                      <Select
                        value={task.assignee_id}
                        onValueChange={(value) => handleTaskChange(task.id, "assignee_id", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите сотрудника" />
                        </SelectTrigger>
                        <SelectContent>
                          {employees.map((employee) => (
                            <SelectItem key={employee.id} value={employee.id}>
                              {employee.name} ({employee.department})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Приоритет</Label>
                      <Select
                        value={task.priority}
                        onValueChange={(value: "easy" | "medium" | "hard") => 
                          handleTaskChange(task.id, "priority", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {priorityOptions.map((priority) => (
                            <SelectItem key={priority.value} value={priority.value}>
                              {priority.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Дедлайн</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !task.due_date && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon />
                            {task.due_date ? format(task.due_date, "dd.MM.yyyy") : "Выберите дату"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={task.due_date || undefined}
                            onSelect={(date) => handleTaskChange(task.id, "due_date", date)}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="space-y-2 col-span-2">
                      <Label>Описание</Label>
                      <Textarea
                        value={task.description}
                        onChange={(e) => handleTaskChange(task.id, "description", e.target.value)}
                        placeholder="Описание задачи"
                        rows={2}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Формат работы */}
          {project?.work_format && project.work_format.length > 0 && (
            <div className="space-y-2">
              <Label>Формат работы</Label>
              <div className="flex flex-wrap gap-2">
                {project.work_format.map((format) => (
                  <span
                    key={format}
                    className="px-2 py-1 bg-secondary text-secondary-foreground rounded-md text-sm"
                  >
                    {format}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Кнопки */}
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Отмена
            </Button>
            <Button 
              onClick={handleStart}
              disabled={isLoading}
            >
              {isLoading ? "Запуск..." : "Запустить проект"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};