import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { withOrg, scopeToOrg } from "@/integrations/supabase/org";
import { useOrg } from "@/contexts/OrgContext";
import { Plus, Pencil, Trash2, RefreshCw, Trophy } from "lucide-react";

interface TemplateForm {
  id?: string;
  name: string;
  description?: string;
  category: string;
  rarity: "common" | "rare" | "epic" | "legendary";
  points: number;
  target_group: "sales" | "general";
  condition_type: "task_count" | "task_streak" | "points_total" | "category_tasks" | "sales_count" | "sales_amount" | "leads_count" | "qualified_leads_count" | "reports_count";
  condition_value: number;
  condition_data?: any;
  is_active: boolean;
  sort_order: number;
}

export const AdminAchievementsManager = () => {
  const { currentOrgId } = useOrg();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [templates, setTemplates] = useState<TemplateForm[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<TemplateForm | null>(null);

  const emptyForm: TemplateForm = useMemo(() => ({
    name: "",
    description: "",
    category: "Общее",
    rarity: "common",
    points: 0,
    target_group: "general",
    condition_type: "task_count",
    condition_value: 1,
    condition_data: undefined,
    is_active: true,
    sort_order: 0,
  }), []);

  const [form, setForm] = useState<TemplateForm>(emptyForm);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const { data, error } = await scopeToOrg(
        (supabase as any)
          .from("achievement_templates")
          .select("id, name, description, category, rarity, points, target_group, condition_type, condition_value, condition_data, is_active, sort_order")
          .order("is_active", { ascending: false })
          .order("sort_order", { ascending: true })
          .order("name", { ascending: true }),
        currentOrgId
      );
      if (error) throw error;
      setTemplates((data as any[]) as TemplateForm[]);
    } catch (e: any) {
      console.error(e);
      toast({ title: "Ошибка", description: "Не удалось загрузить шаблоны достижений" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
  }, [currentOrgId]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (tpl: TemplateForm) => {
    setEditing(tpl);
    setForm({ ...tpl });
    setOpen(true);
  };

  const saveTemplate = async () => {
    try {
      setLoading(true);
      if (editing?.id) {
        const { error } = await (supabase as any)
          .from("achievement_templates")
          .update(withOrg({
            name: form.name,
            description: form.description,
            category: form.category,
            rarity: form.rarity,
            points: form.points,
            target_group: form.target_group,
            condition_type: form.condition_type,
            condition_value: form.condition_value,
            condition_data: form.condition_type === "category_tasks" ? form.condition_data : null,
            is_active: form.is_active,
            sort_order: form.sort_order,
          }, currentOrgId))
          .eq("id", editing.id);
        if (error) throw error;
        toast({ title: "Сохранено", description: "Шаблон обновлен" });
      } else {
        const { error } = await (supabase as any)
          .from("achievement_templates")
          .insert(withOrg({
            name: form.name,
            description: form.description,
            category: form.category,
            rarity: form.rarity,
            points: form.points,
            target_group: form.target_group,
            condition_type: form.condition_type,
            condition_value: form.condition_value,
            condition_data: form.condition_type === "category_tasks" ? form.condition_data : null,
            is_active: form.is_active,
            sort_order: form.sort_order,
          }, currentOrgId));
        if (error) throw error;
        toast({ title: "Создано", description: "Шаблон добавлен" });
      }
      setOpen(false);
      setEditing(null);
      setForm(emptyForm);
      await loadTemplates();
    } catch (e: any) {
      console.error(e);
      toast({ title: "Ошибка", description: e.message || "Не удалось сохранить шаблон" });
    } finally {
      setLoading(false);
    }
  };

  const removeTemplate = async (id: string) => {
    if (!confirm("Удалить шаблон достижения?")) return;
    try {
      setLoading(true);
      const { error } = await (supabase as any)
        .from("achievement_templates")
        .delete()
        .eq("id", id);
      if (error) throw error;
      toast({ title: "Удалено", description: "Шаблон удален" });
      loadTemplates();
    } catch (e: any) {
      console.error(e);
      toast({ title: "Ошибка", description: e.message || "Не удалось удалить" });
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (tpl: TemplateForm) => {
    try {
      const { error } = await (supabase as any)
        .from("achievement_templates")
        .update({ is_active: !tpl.is_active })
        .eq("id", tpl.id);
      if (error) throw error;
      loadTemplates();
    } catch (e) {
      console.error(e);
      toast({ title: "Ошибка", description: "Не удалось изменить статус" });
    }
  };

  const recalcAll = async () => {
    try {
      setLoading(true);
      // Пересчитываем баллы и продажи по всем активным сотрудникам
      const { data: employees, error } = await (supabase as any)
        .from("employees")
        .select("id")
        .eq("status", "active");
      if (error) throw error;
      for (const e of employees || []) {
        await (supabase as any).rpc("check_sales_achievements", { emp_id: e.id });
        await (supabase as any).rpc("check_task_achievements", { emp_id: e.id });
        await (supabase as any).rpc("calculate_employee_points", { emp_id: e.id });
      }
      toast({ title: "Готово", description: "Пересчет выполнен" });
    } catch (e: any) {
      console.error(e);
      toast({ title: "Ошибка", description: e.message || "Не удалось пересчитать" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Trophy className="h-6 w-6 text-primary" />
            Достижения — управление правилами
          </h2>
          <p className="text-muted-foreground mt-1">Создавайте и редактируйте правила начисления достижений</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={recalcAll} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Пересчитать всем
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={openCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Новое правило
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editing ? "Редактировать правило" : "Новое правило"}</DialogTitle>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
                <div className="grid gap-2">
                  <Label htmlFor="name">Название</Label>
                  <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="category">Категория</Label>
                  <Input id="category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
                </div>
                <div className="grid gap-2">
                  <Label>Редкость</Label>
                  <Select value={form.rarity} onValueChange={(v: any) => setForm({ ...form, rarity: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="common">Обычное</SelectItem>
                      <SelectItem value="rare">Редкое</SelectItem>
                      <SelectItem value="epic">Эпическое</SelectItem>
                      <SelectItem value="legendary">Легендарное</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="points">Баллы</Label>
                  <Input id="points" type="number" value={form.points}
                         onChange={(e) => setForm({ ...form, points: Number(e.target.value) })} />
                </div>
                <div className="md:col-span-2 grid gap-2">
                  <Label htmlFor="description">Описание</Label>
                  <Input id="description" value={form.description}
                         onChange={(e) => setForm({ ...form, description: e.target.value })} />
                </div>
                <div className="grid gap-2">
                  <Label>Группа</Label>
                  <Select value={form.target_group} onValueChange={(v: any) => setForm({ ...form, target_group: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sales">Отдел продаж</SelectItem>
                      <SelectItem value="general">Другие</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Тип условия</Label>
                  <Select value={form.condition_type} onValueChange={(v: any) => setForm({ ...form, condition_type: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите" />
                    </SelectTrigger>
                    <SelectContent>
                      {form.target_group === 'sales' ? (
                        <>
                          <SelectItem value="sales_count">Количество продаж</SelectItem>
                          <SelectItem value="sales_amount">Сумма продаж</SelectItem>
                          <SelectItem value="leads_count">Лиды</SelectItem>
                          <SelectItem value="qualified_leads_count">Квал. лиды</SelectItem>
                          <SelectItem value="reports_count">Отчеты</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="task_count">Количество задач</SelectItem>
                          <SelectItem value="points_total">Сумма баллов</SelectItem>
                          <SelectItem value="task_streak">Серия дней</SelectItem>
                          <SelectItem value="category_tasks">Задачи по категории</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="value">Значение</Label>
                  <Input id="value" type="number" value={form.condition_value}
                         onChange={(e) => setForm({ ...form, condition_value: Number(e.target.value) })} />
                </div>

                {form.target_group === 'general' && form.condition_type === "category_tasks" && (
                  <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label>Приоритет</Label>
                      <Select value={form.condition_data?.priority || "easy"}
                              onValueChange={(v: any) => setForm({ ...form, condition_data: { ...(form.condition_data || {}), priority: v } })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="easy">Легкий</SelectItem>
                          <SelectItem value="medium">Средний</SelectItem>
                          <SelectItem value="hard">Сложный</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center justify-between border rounded-md p-3">
                      <div>
                        <Label className="mb-1">Подряд в один день</Label>
                        <p className="text-xs text-muted-foreground">Требовать выполнить за один день</p>
                      </div>
                      <Switch checked={!!form.condition_data?.consecutive}
                              onCheckedChange={(v) => setForm({ ...form, condition_data: { ...(form.condition_data || {}), consecutive: v } })} />
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between border rounded-md p-3 md:col-span-2">
                  <div className="space-y-1">
                    <Label>Активно</Label>
                    <p className="text-xs text-muted-foreground">Неактивные правила скрыты из приложения</p>
                  </div>
                  <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
                </div>

                <div className="grid gap-2 md:col-span-2">
                  <Label htmlFor="order">Порядок сортировки</Label>
                  <Input id="order" type="number" value={form.sort_order}
                         onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })} />
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Отмена</Button>
                <Button onClick={saveTemplate} disabled={loading}>{editing ? "Сохранить" : "Создать"}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* List */}
      <Card className="shadow-card border border-border">
        <CardHeader>
          <CardTitle>Правила ({templates.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Статус</TableHead>
                  <TableHead>Название</TableHead>
                  <TableHead>Категория</TableHead>
                  <TableHead>Тип условия</TableHead>
                  <TableHead>Значение</TableHead>
                  <TableHead>Баллы</TableHead>
                  <TableHead>Редкость</TableHead>
                  <TableHead className="text-right">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {templates.map((tpl) => (
                  <TableRow key={tpl.id} className="align-top">
                    <TableCell>
                      <Switch checked={tpl.is_active} onCheckedChange={() => toggleActive(tpl)} />
                    </TableCell>
                    <TableCell className="max-w-[220px]">
                      <div className="font-medium truncate">{tpl.name}</div>
                      {tpl.description && (
                        <div className="text-xs text-muted-foreground truncate">{tpl.description}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{tpl.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{tpl.condition_type}</Badge>
                    </TableCell>
                    <TableCell>
                      {tpl.condition_value}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1"><span>{tpl.points}</span></div>
                    </TableCell>
                    <TableCell>
                      <Badge className={
                        tpl.rarity === "legendary" ? "bg-gradient-gold text-gold-foreground" :
                        tpl.rarity === "epic" ? "bg-purple-500/10 text-purple-500" :
                        tpl.rarity === "rare" ? "bg-blue/10 text-blue" :
                        "bg-muted text-muted-foreground"
                      }>
                        {tpl.rarity}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button size="icon" variant="outline" onClick={() => openEdit(tpl)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="destructive" onClick={() => removeTemplate(tpl.id!)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {!templates.length && (
            <div className="text-center py-10 text-muted-foreground">Пока нет правил. Создайте первое правило.</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
