import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useTaskCategories } from "@/hooks/useTaskCategories";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useAchievements } from "@/hooks/useAchievements";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";
import { Plus, Clock, Calendar, Target, Zap, CalendarIcon, RefreshCw, CheckCircle, AlertCircle, Loader, Edit, Trash2, Paperclip } from "lucide-react";
import { formatTime, parseTimeToMinutes, formatTimeForInput } from "@/utils/timeHelpers";
import { TaskKanban } from "./TaskKanban";

// Унифицированный интерфейс для задач из обеих таблиц
interface UnifiedTask {
  id: string;
  title: string;
  description?: string;
  priority?: string;
  status: string;
  category?: string;
  estimated_minutes?: number;
  actual_minutes?: number;
  due_date?: string;
  created_at: string;
  updated_at: string;
  completed_at?: string;
  task_type?: string; // только для project_tasks
  source: 'employee_tasks' | 'project_tasks'; // источник данных
}

// Старый интерфейс для обратной совместимости
interface WorkEntry {
  id: string;
  title: string;
  description: string;
  priority: string;
  status: string;
  category: string;
  estimated_minutes: number;
  actual_minutes: number;
  due_date: string;
  created_at: string;
  updated_at: string;
  completed_at: string;
}

interface WorkStats {
  total: number;
  completed: number;
  pending: number;
  in_progress: number;
  totalMinutes: number;
}

export const TasksPage = () => {
  const { currentOrgId } = useOrg();
  const [workEntries, setWorkEntries] = useState<UnifiedTask[]>([]);
  const [currentEmployeeId, setCurrentEmployeeId] = useState<string | undefined>(undefined);
  const [stats, setStats] = useState<WorkStats>({
    total: 0,
    completed: 0,
    pending: 0,
    in_progress: 0,
    totalMinutes: 0
  });
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<UnifiedTask | null>(null);
  const { toast } = useToast();
  
  // Use employee points hook for unified point management
  const { points, loading: pointsLoading, refetch: refetchPoints, recalculate } = useEmployeePoints(currentEmployeeId);
  
  // Use achievements hook for automatic checking
  const { checkAchievements } = useAchievements(currentEmployeeId);

  const [newWorkEntry, setNewWorkEntry] = useState<{
    title: string;
    description: string;
    priority: string; // легкий, средний, трудный
    category: string;
    estimated_hours: number;
    estimated_minutes: number;
    actual_hours: number;
    actual_minutes: number;
    due_date: Date | undefined;
  }>({
    title: "",
    description: "",
    priority: "medium", // средний по умолчанию
    category: "general",
    estimated_hours: 1,
    estimated_minutes: 0,
    actual_hours: 0,
    actual_minutes: 0,
    due_date: undefined
  });

  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  
  // Use task categories hook
  const { categories, loading: categoriesLoading } = useTaskCategories();

  useEffect(() => {
    fetchWorkEntries();
  }, []);

  const fetchWorkEntries = async () => {
    try {
      setLoading(true);

      // Получаем текущего пользователя
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('No user found');
        setLoading(false);
        return;
      }
      console.log('User found:', user.id);

      // Получаем информацию о сотруднике
      const { data: employee } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      console.log('Employee data:', employee);

      if (!employee) {
        console.log('No employee found for user');
        setLoading(false);
        return;
      }

      // Set employee ID for points hook
      setCurrentEmployeeId(employee.id);

      // Параллельно загружаем данные из обеих таблиц
      const [employeeTasksResult, projectTasksResult] = await Promise.all([
        supabase
          .from('employee_tasks')
          .select('*')
          .eq('employee_id', employee.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('project_tasks')
          .select('*')
          .eq('assignee_id', employee.id)
          .order('created_at', { ascending: false })
      ]);

      if (employeeTasksResult.error) throw employeeTasksResult.error;
      if (projectTasksResult.error) throw projectTasksResult.error;

      console.log('Employee tasks data:', employeeTasksResult.data);
      console.log('Project tasks data:', projectTasksResult.data);

      // Преобразуем данные из employee_tasks в единый формат
      const employeeTasks: UnifiedTask[] = (employeeTasksResult.data || []).map(task => ({
        id: task.id,
        title: task.title,
        description: task.description || undefined,
        priority: task.priority || undefined,
        status: task.status || 'pending',
        category: task.category || undefined,
        estimated_minutes: task.estimated_minutes || undefined,
        actual_minutes: task.actual_minutes || undefined,
        due_date: task.due_date || undefined,
        created_at: task.created_at,
        updated_at: task.updated_at,
        completed_at: task.completed_at || undefined,
        source: 'employee_tasks' as const
      }));

      // Преобразуем данные из project_tasks в единый формат
      const projectTasks: UnifiedTask[] = (projectTasksResult.data || []).map(task => ({
        id: task.id,
        title: task.task_name, // task_name -> title
        description: task.description || undefined,
        priority: task.priority || undefined,
        status: task.status || 'pending',
        category: task.category || undefined,
        estimated_minutes: task.estimated_minutes || undefined,
        actual_minutes: task.actual_minutes || undefined,
        due_date: task.due_date || undefined,
        created_at: task.created_at,
        updated_at: task.updated_at,
        completed_at: task.completed_at || undefined,
        task_type: task.task_type || undefined,
        source: 'project_tasks' as const
      }));

      // Объединяем и сортируем по дате создания
      const allTasks = [...employeeTasks, ...projectTasks].sort(
        (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );

      console.log('All unified tasks:', allTasks);
      console.log('Total tasks count:', allTasks.length);

      setWorkEntries(allTasks);

      // Рассчитываем статистику для всех задач
      const completed = allTasks.filter(entry => entry.status === 'completed').length;
      const pending = allTasks.filter(entry => entry.status === 'pending').length;
      const in_progress = allTasks.filter(entry => entry.status === 'in_progress').length;
      
      // Считаем время для всех задач (теперь и у project_tasks есть actual_minutes)
      const totalMinutes = allTasks.reduce((sum, entry) => sum + (entry.actual_minutes || 0), 0);

      setStats({
        total: allTasks.length,
        completed,
        pending,
        in_progress,
        totalMinutes
      });

    } catch (error) {
      console.error('Error fetching work entries:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить записи о работе",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateWorkEntry = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: employee } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!employee) return;

      // Создаем задачу
      const { data: taskData, error: taskError } = await supabase
        .from('employee_tasks')
        .insert(withOrg({
          employee_id: employee.id,
          title: newWorkEntry.title,
          description: newWorkEntry.description,
          priority: newWorkEntry.priority,
          category: newWorkEntry.category,
          estimated_minutes: parseTimeToMinutes(newWorkEntry.estimated_hours, newWorkEntry.estimated_minutes),
          actual_minutes: parseTimeToMinutes(newWorkEntry.actual_hours, newWorkEntry.actual_minutes),
          due_date: newWorkEntry.due_date ? 
            `${newWorkEntry.due_date.getFullYear()}-${String(newWorkEntry.due_date.getMonth() + 1).padStart(2, '0')}-${String(newWorkEntry.due_date.getDate()).padStart(2, '0')}` 
            : null,
          status: 'completed' // сразу помечаем как выполненную работу
        } as any, currentOrgId))
        .select()
        .single();

      if (taskError) throw taskError;

      // Если есть прикрепленный файл, сохраняем его в базу данных
      if (attachedFile && taskData) {
        // Конвертируем файл в base64 для хранения в базе данных
        const fileReader = new FileReader();
        const fileBase64 = await new Promise<string>((resolve) => {
          fileReader.onload = () => resolve(fileReader.result as string);
          fileReader.readAsDataURL(attachedFile);
        });
        
        const { error: attachmentError } = await supabase
          .from('task_attachments')
          .insert({
            task_id: taskData.id,
            employee_id: employee.id,
            file_name: attachedFile.name,
            file_size: attachedFile.size,
            content_type: attachedFile.type,
            file_content: fileBase64,
            file_path: null // так как храним в базе данных
          });

        if (attachmentError) {
          console.error('Error saving file attachment:', attachmentError);
          // Не показываем ошибку пользователю, если файл не сохранился
        }
      }

      toast({
        title: "Успешно",
        description: "Запись о работе создана",
      });

      setIsDialogOpen(false);
      setNewWorkEntry({
        title: "",
        description: "",
        priority: "medium",
        category: "general",
        estimated_hours: 1,
        estimated_minutes: 0,
        actual_hours: 0,
        actual_minutes: 0,
        due_date: undefined
      });
      setAttachedFile(null);

      // Обновляем список записей и пересчитываем баллы
      await fetchWorkEntries();
      await recalculate();
      await refetchPoints();
    } catch (error) {
      console.error('Error creating work entry:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось создать запись о работе",
        variant: "destructive",
      });
    }
  };

  const handleUpdateEntryStatus = async (entryId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('employee_tasks')
        .update({ status: newStatus })
        .eq('id', entryId);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Статус записи обновлен",
      });

      // Обновляем список записей и пересчитываем баллы
      await fetchWorkEntries();
      await recalculate();
      await refetchPoints();
      
      // Проверяем достижения после завершения задачи
      if (newStatus === 'completed') {
        await checkAchievements();
      }
    } catch (error) {
      console.error('Error updating entry:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить запись",
        variant: "destructive",
      });
    }
  };

  const handleEditEntry = (entry: UnifiedTask) => {
    // Редактирование доступно только для employee_tasks
    if (entry.source !== 'employee_tasks') {
      toast({
        title: "Ошибка",
        description: "Редактирование доступно только для задач сотрудника",
        variant: "destructive",
      });
      return;
    }
    
    setEditingEntry(entry);
    const { hours: estimatedHours, minutes: estimatedMinutes } = formatTimeForInput(entry.estimated_minutes || 0);
    const { hours: actualHours, minutes: actualMinutes } = formatTimeForInput(entry.actual_minutes || 0);
    
    setNewWorkEntry({
      title: entry.title,
      description: entry.description || "",
      priority: entry.priority || "medium",
      category: entry.category || "general",
      estimated_hours: parseInt(estimatedHours) || 1,
      estimated_minutes: parseInt(estimatedMinutes) || 0,
      actual_hours: parseInt(actualHours) || 0,
      actual_minutes: parseInt(actualMinutes) || 0,
      due_date: entry.due_date ? new Date(entry.due_date) : undefined
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdateEntry = async () => {
    if (!editingEntry) return;

    try {
      const { error } = await supabase
        .from('employee_tasks')
        .update({
          title: newWorkEntry.title,
          description: newWorkEntry.description,
          priority: newWorkEntry.priority,
          category: newWorkEntry.category,
          estimated_minutes: parseTimeToMinutes(newWorkEntry.estimated_hours, newWorkEntry.estimated_minutes),
          actual_minutes: parseTimeToMinutes(newWorkEntry.actual_hours, newWorkEntry.actual_minutes),
          due_date: newWorkEntry.due_date ? 
            `${newWorkEntry.due_date.getFullYear()}-${String(newWorkEntry.due_date.getMonth() + 1).padStart(2, '0')}-${String(newWorkEntry.due_date.getDate()).padStart(2, '0')}` 
            : null
        })
        .eq('id', editingEntry.id);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Запись о работе обновлена",
      });

      setIsEditDialogOpen(false);
      setEditingEntry(null);
      setNewWorkEntry({
        title: "",
        description: "",
        priority: "medium",
        category: "general",
        estimated_hours: 1,
        estimated_minutes: 0,
        actual_hours: 0,
        actual_minutes: 0,
        due_date: undefined
      });

      await fetchWorkEntries();
      await recalculate();
      await refetchPoints();
    } catch (error) {
      console.error('Error updating entry:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить запись о работе",
        variant: "destructive",
      });
    }
  };

  const handleDeleteEntry = async (entryId: string, entryTitle: string) => {
    if (!confirm(`Вы уверены, что хотите удалить запись "${entryTitle}"?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('employee_tasks')
        .delete()
        .eq('id', entryId);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Запись о работе удалена",
      });

      await fetchWorkEntries();
      await recalculate();
      await refetchPoints();
    } catch (error) {
      console.error('Error deleting entry:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить запись о работе",
        variant: "destructive",
      });
    }
  };

  const getDifficultyColor = (priority: string) => {
    switch (priority) {
      case 'easy': return 'bg-success/10 text-success border-success/20';
      case 'medium': return 'bg-warning/10 text-warning border-warning/20';
      case 'hard': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getDifficultyLabel = (priority: string) => {
    switch (priority) {
      case 'easy': return 'Легкий';
      case 'medium': return 'Средний';
      case 'hard': return 'Трудный';
      default: return priority;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-success/10 text-success border-success/20';
      case 'in_progress': return 'bg-primary/10 text-primary border-primary/20';
      case 'pending': return 'bg-warning/10 text-warning border-warning/20';
      case 'cancelled': return 'bg-muted text-muted-foreground border-muted/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Выполнено';
      case 'in_progress': return 'В работе';
      case 'pending': return 'Ожидает';
      case 'cancelled': return 'Отменено';
      default: return status;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'development': return 'Разработка';
      case 'marketing': return 'Маркетинг';
      case 'hr': return 'HR';
      case 'sales': return 'Продажи';
      case 'general': return 'Общие';
      default: return category;
    }
  };

  const isTaskOverdue = (dueDate: string, status: string) => {
    if (!dueDate || status === 'completed') return false;
    const today = new Date();
    const taskDueDate = new Date(dueDate);
    today.setHours(0, 0, 0, 0);
    taskDueDate.setHours(0, 0, 0, 0);
    return taskDueDate < today;
  };

  if (loading || pointsLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Задачи</h2>
          <p className="text-muted-foreground mt-1">
            Управляйте своими задачами и контролируйте время
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button onClick={fetchWorkEntries} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить
          </Button>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-primary">
                <Plus className="h-4 w-4 mr-2" />
                Новая работа
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Добавить выполненную работу</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Название работы</Label>
                  <Input
                    id="title"
                    value={newWorkEntry.title}
                    onChange={(e) => setNewWorkEntry({...newWorkEntry, title: e.target.value})}
                    placeholder="Название выполненной работы"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Описание</Label>
                  <Textarea
                    id="description"
                    value={newWorkEntry.description}
                    onChange={(e) => setNewWorkEntry({...newWorkEntry, description: e.target.value})}
                    placeholder="Описание выполненной работы"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="priority">Сложность работы</Label>
                    <Select 
                      value={newWorkEntry.priority} 
                      onValueChange={(value) => {
                        console.log('🎯 TasksPage - Priority changed to:', value);
                        setNewWorkEntry({...newWorkEntry, priority: value});
                      }}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите сложность" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Легкий (5 баллов)</SelectItem>
                        <SelectItem value="medium">Средний (15 баллов)</SelectItem>
                        <SelectItem value="hard">Трудный (30 баллов)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="category">Категория</Label>
                    <Select value={newWorkEntry.category} onValueChange={(value) => setNewWorkEntry({...newWorkEntry, category: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите категорию" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Потраченное время</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor="actual-hours" className="text-xs">Часы</Label>
                        <Input
                          id="actual-hours"
                          type="number"
                          min="0"
                          max="24"
                          value={newWorkEntry.actual_hours}
                          onChange={(e) => setNewWorkEntry({...newWorkEntry, actual_hours: parseInt(e.target.value) || 0})}
                          placeholder="Часы"
                        />
                      </div>
                      <div>
                        <Label htmlFor="actual-minutes" className="text-xs">Минуты</Label>
                        <Input
                          id="actual-minutes"
                          type="number"
                          min="0"
                          max="59"
                          value={newWorkEntry.actual_minutes}
                          onChange={(e) => {
                            setNewWorkEntry({...newWorkEntry, actual_minutes: parseInt(e.target.value) || 0});
                          }}
                          placeholder="Минуты"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label>Дата выполнения</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newWorkEntry.due_date && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newWorkEntry.due_date ? format(newWorkEntry.due_date, "dd.MM.yyyy", { locale: ru }) : "Выберите дату"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <CalendarComponent
                          mode="single"
                          selected={newWorkEntry.due_date}
                          onSelect={(date) => setNewWorkEntry({...newWorkEntry, due_date: date})}
                          initialFocus
                          className={cn("p-3 pointer-events-auto")}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div>
                  <Label htmlFor="file-attachment">Прикрепить файл</Label>
                  <div className="space-y-2">
                    <Input
                      id="file-attachment"
                      type="file"
                      onChange={(e) => setAttachedFile(e.target.files?.[0] || null)}
                      accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
                    />
                    {attachedFile && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Paperclip className="h-4 w-4" />
                        <span>{attachedFile.name}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setAttachedFile(null)}
                          className="h-6 w-6 p-0"
                        >
                          ✕
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
                
                <Button onClick={handleCreateWorkEntry} className="w-full">
                  Добавить работу
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Edit Work Entry Dialog */}
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Редактировать запись о работе</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-title">Название работы</Label>
                  <Input
                    id="edit-title"
                    value={newWorkEntry.title}
                    onChange={(e) => setNewWorkEntry({...newWorkEntry, title: e.target.value})}
                    placeholder="Название работы"
                  />
                </div>

                <div>
                  <Label htmlFor="edit-description">Описание</Label>
                  <Textarea
                    id="edit-description"
                    value={newWorkEntry.description}
                    onChange={(e) => setNewWorkEntry({...newWorkEntry, description: e.target.value})}
                    placeholder="Описание работы"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit-priority">Сложность работы</Label>
                    <Select 
                      value={newWorkEntry.priority} 
                      onValueChange={(value) => {
                        console.log('✏️ TasksPage Edit - Priority changed to:', value);
                        setNewWorkEntry({...newWorkEntry, priority: value});
                      }}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите сложность" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Легкий (5 баллов)</SelectItem>
                        <SelectItem value="medium">Средний (15 баллов)</SelectItem>
                        <SelectItem value="hard">Трудный (30 баллов)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="edit-category">Категория</Label>
                    <Select value={newWorkEntry.category} onValueChange={(value) => setNewWorkEntry({...newWorkEntry, category: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите категорию" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Потраченное время</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor="edit-actual-hours" className="text-xs">Часы</Label>
                        <Input
                          id="edit-actual-hours"
                          type="number"
                          min="0"
                          max="24"
                          value={newWorkEntry.actual_hours}
                          onChange={(e) => setNewWorkEntry({...newWorkEntry, actual_hours: parseInt(e.target.value) || 0})}
                          placeholder="Часы"
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit-actual-minutes" className="text-xs">Минуты</Label>
                        <Input
                          id="edit-actual-minutes"
                          type="number"
                          min="0"
                          max="59"
                          value={newWorkEntry.actual_minutes}
                          onChange={(e) => {
                            const minutes = parseInt(e.target.value) || 0;
                            setNewWorkEntry({...newWorkEntry, actual_minutes: minutes});
                          }}
                          placeholder="Минуты"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label>Дата выполнения</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newWorkEntry.due_date && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newWorkEntry.due_date ? format(newWorkEntry.due_date, "dd.MM.yyyy", { locale: ru }) : "Выберите дату"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <CalendarComponent
                          mode="single"
                          selected={newWorkEntry.due_date}
                          onSelect={(date) => setNewWorkEntry({...newWorkEntry, due_date: date})}
                          initialFocus
                          className={cn("p-3 pointer-events-auto")}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button onClick={handleUpdateEntry} className="flex-1">
                    Сохранить изменения
                  </Button>
                  <Button onClick={() => setIsEditDialogOpen(false)} variant="outline" className="flex-1">
                    Отмена
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue to-primary text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-foreground/80 text-sm font-medium">Всего работ</p>
                <p className="text-3xl font-bold">{stats.total}</p>
              </div>
              <Target className="h-8 w-8 text-blue-foreground/60" />
            </div>
          </CardContent>
        </Card>


        <Card className="bg-gradient-gold text-gold-foreground border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gold-foreground/80 text-sm font-medium">Время работы</p>
                <p className="text-3xl font-bold">{formatTime(stats.totalMinutes)}</p>
              </div>
              <Clock className="h-8 w-8 text-gold-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-primary text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-primary-foreground/80 text-sm font-medium">Баллы</p>
                <p className="text-3xl font-bold">{pointsLoading ? '...' : points}</p>
              </div>
              <Zap className="h-8 w-8 text-primary-foreground/60" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Completed Tasks List */}
      <div>
        <div className="mb-6">
          <h3 className="text-xl font-semibold">Выполненные задачи</h3>
          <p className="text-muted-foreground text-sm">
            Список всех завершенных работ
          </p>
        </div>
        
        {!loading ? (
          <Card>
            <CardContent className="p-0">
              {workEntries.filter(task => task.status === 'completed').length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Нет выполненных задач</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Название</TableHead>
                      <TableHead>Сложность</TableHead>
                      <TableHead>Категория</TableHead>
                      <TableHead>Время</TableHead>
                      <TableHead>Дата завершения</TableHead>
                      <TableHead>Источник</TableHead>
                      <TableHead>Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {workEntries
                      .filter(task => task.status === 'completed')
                      .map((task) => (
                        <TableRow key={task.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{task.title}</div>
                              {task.description && (
                                <div className="text-sm text-muted-foreground truncate max-w-xs">
                                  {task.description}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {task.priority && (
                              <Badge variant="outline" className={getDifficultyColor(task.priority)}>
                                {task.priority === 'easy' ? 'Легкий' : 
                                 task.priority === 'medium' ? 'Средний' : 
                                 task.priority === 'hard' ? 'Трудный' : task.priority}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {task.category && (
                              <Badge variant="secondary">
                                {task.category}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {task.actual_minutes ? formatTime(task.actual_minutes) : '-'}
                          </TableCell>
                          <TableCell>
                            {task.completed_at ? 
                              format(new Date(task.completed_at), "dd.MM.yyyy", { locale: ru }) : 
                              format(new Date(task.updated_at), "dd.MM.yyyy", { locale: ru })
                            }
                          </TableCell>
                          <TableCell>
                            <Badge variant={task.source === 'employee_tasks' ? 'default' : 'outline'}>
                              {task.source === 'employee_tasks' ? 'Личные' : 'Проектные'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {task.source === 'employee_tasks' && (
                              <div className="flex gap-2">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleEditEntry(task)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleDeleteEntry(task.id, task.title)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Loader className="h-8 w-8 mx-auto mb-4 animate-spin" />
            <p className="text-lg">Загрузка задач...</p>
          </div>
        )}
      </div>
    </div>
  );
};