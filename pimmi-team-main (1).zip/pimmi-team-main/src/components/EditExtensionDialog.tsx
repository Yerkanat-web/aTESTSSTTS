
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface EditExtensionDialogProps {
  isOpen: boolean;
  onClose: () => void;
  extension: {
    id: string;
    project_name: string | null;
    sale_date: string;
    sale_amount: number;
    prepayment: number | null;
    remainder: number | null;
    project_status: string | null;
    work_format: string[] | null;
    description: string | null;
    paid_until: string | null;
  } | null;
  onExtensionUpdated: () => void;
}

export function EditExtensionDialog({
  isOpen,
  onClose,
  extension,
  onExtensionUpdated,
}: EditExtensionDialogProps) {
  const [workFormats, setWorkFormats] = useState<string[]>([]);
  const [projectName, setProjectName] = useState("");
  const [startDate, setStartDate] = useState<Date>();
  const [paidUntil, setPaidUntil] = useState<Date>();
  const [saleAmount, setSaleAmount] = useState("");
  const [prepayment, setPrepayment] = useState("");
  const [remainder, setRemainder] = useState("");
  const [remainderDueDate, setRemainderDueDate] = useState<Date>();
  const [projectStatus, setProjectStatus] = useState("");
  const [workFormat, setWorkFormat] = useState<string[]>([]);
  const [description, setDescription] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Fetch work formats when dialog opens
  useEffect(() => {
    const fetchWorkFormats = async () => {
      try {
        const { data, error } = await supabase
          .from("sales_results")
          .select("work_format")
          .not("work_format", "is", null);

        if (error) throw error;

        // Extract unique work formats
        const allFormats = new Set<string>();
        data?.forEach(item => {
          if (item.work_format && Array.isArray(item.work_format)) {
            item.work_format.forEach(format => allFormats.add(format));
          }
        });
        setWorkFormats(Array.from(allFormats).sort());
      } catch (error) {
        console.error("Error fetching work formats:", error);
      }
    };

    if (isOpen) {
      fetchWorkFormats();
    }
  }, [isOpen]);

  // Populate form when extension changes
  useEffect(() => {
    if (extension) {
      setProjectName(extension.project_name || "");
      setStartDate(new Date(extension.sale_date));
      setPaidUntil(extension.paid_until ? new Date(extension.paid_until) : undefined);
      setSaleAmount(extension.sale_amount.toString());
      setPrepayment(extension.prepayment?.toString() || "0");
      setRemainder(extension.remainder?.toString() || "0");
      setProjectStatus(extension.project_status || "");
      setWorkFormat(extension.work_format || []);
      setDescription(extension.description || "");
      
      // Try to get remainder due date from sales_results table
      if (extension.id) {
        fetchRemainderDueDate(extension.id);
      }
    }
  }, [extension]);

  const fetchRemainderDueDate = async (extensionId: string) => {
    try {
      const { data, error } = await supabase
        .from("sales_results")
        .select("remainder_due_date")
        .eq("id", extensionId)
        .maybeSingle();

      if (error) throw error;

      if (data?.remainder_due_date) {
        setRemainderDueDate(new Date(data.remainder_due_date));
      }
    } catch (error) {
      console.error("Error fetching remainder due date:", error);
    }
  };

  const handleSubmit = async () => {
    // Предотвращаем повторное сохранение
    if (isLoading) return;

    if (!extension || !startDate || !saleAmount || !projectName.trim()) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    const saleAmountNum = parseFloat(saleAmount);
    const prepaymentNum = prepayment ? parseFloat(prepayment) : 0;
    const remainderNum = saleAmountNum - prepaymentNum;

    if (remainderNum > 0 && !remainderDueDate) {
      toast({
        title: "Ошибка",
        description: "При наличии остатка укажите дату оплаты остатка",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const updateData: any = {
        project_name: projectName.trim(),
        sale_date: format(startDate, "yyyy-MM-dd"),
        paid_until: paidUntil ? format(paidUntil, "yyyy-MM-dd") : null,
        sale_amount: saleAmountNum,
        prepayment: prepaymentNum,
        remainder: remainderNum,
        remainder_due_date: remainderNum > 0 ? format(remainderDueDate!, "yyyy-MM-dd") : null,
        work_format: workFormat.length > 0 ? workFormat : null,
        description: description.trim() || null,
      };

      // Only include project_status if it's not empty
      if (projectStatus) {
        updateData.project_status = projectStatus;
      }

      const { error } = await supabase
        .from("sales_results")
        .update(updateData)
        .eq("id", extension.id);

      if (error) throw error;

      toast({
        title: "Успешно!",
        description: "Продление проекта обновлено",
      });

      onExtensionUpdated();
      onClose();
      resetForm();
    } catch (error: any) {
      console.error("Error updating extension:", error);
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить продление проекта",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setProjectName("");
    setStartDate(undefined);
    setPaidUntil(undefined);
    setSaleAmount("");
    setPrepayment("");
    setRemainder("");
    setRemainderDueDate(undefined);
    setProjectStatus("");
    setWorkFormat([]);
    setDescription("");
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ru-RU").format(amount) + " ₸";
  };

  if (!extension) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Редактировать продление проекта</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Project name */}
          <div>
            <Label htmlFor="projectName">Название проекта *</Label>
            <Input
              id="projectName"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="Введите название проекта"
            />
          </div>

          {/* Work format */}
          <div>
            <Label>Формат работы</Label>
            <Select 
              value={workFormat[0] || ""} 
              onValueChange={(value) => setWorkFormat(value ? [value] : [])}
            >
              <SelectTrigger>
                <SelectValue placeholder="Выберите формат работы" />
              </SelectTrigger>
              <SelectContent>
                {workFormats.map((format) => (
                  <SelectItem key={format} value={format}>
                    {format}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Start date */}
          <div>
            <Label>Дата продления *</Label>
            <div className="flex gap-2">
              <Input
                type="date"
                value={startDate ? format(startDate, "yyyy-MM-dd") : ""}
                onChange={(e) => {
                  if (e.target.value) {
                    setStartDate(new Date(e.target.value));
                  } else {
                    setStartDate(undefined);
                  }
                }}
                className="flex-1"
              />
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="shrink-0"
                  >
                    <CalendarIcon className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* End date */}
          <div>
            <Label>Дата окончания работы</Label>
            <div className="flex gap-2">
              <Input
                type="date"
                value={paidUntil ? format(paidUntil, "yyyy-MM-dd") : ""}
                onChange={(e) => {
                  if (e.target.value) {
                    setPaidUntil(new Date(e.target.value));
                  } else {
                    setPaidUntil(undefined);
                  }
                }}
                className="flex-1"
              />
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="shrink-0"
                  >
                    <CalendarIcon className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={paidUntil}
                    onSelect={setPaidUntil}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Financial fields */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="saleAmount">Сумма продления (тенге) *</Label>
              <Input
                id="saleAmount"
                type="number"
                value={saleAmount}
                onChange={(e) => {
                  setSaleAmount(e.target.value);
                  // Auto-calculate remainder
                  const amount = parseFloat(e.target.value) || 0;
                  const prep = parseFloat(prepayment) || 0;
                  setRemainder((amount - prep).toString());
                }}
                placeholder="Введите сумму"
              />
            </div>

            <div>
              <Label htmlFor="prepayment">Предоплата (тенге)</Label>
              <Input
                id="prepayment"
                type="number"
                value={prepayment}
                onChange={(e) => {
                  setPrepayment(e.target.value);
                  // Auto-calculate remainder
                  const amount = parseFloat(saleAmount) || 0;
                  const prep = parseFloat(e.target.value) || 0;
                  setRemainder((amount - prep).toString());
                }}
                placeholder="0"
              />
            </div>
          </div>

          {/* Remainder */}
          <div>
            <Label htmlFor="remainder">Остаток (автоматически)</Label>
            <Input
              id="remainder"
              type="number"
              value={remainder}
              readOnly
              className="bg-muted"
            />
            {parseFloat(remainder) > 0 && (
              <p className="text-sm text-muted-foreground mt-1">
                К доплате: {formatCurrency(parseFloat(remainder))}
              </p>
            )}
          </div>

          {/* Remainder due date */}
          {parseFloat(remainder) > 0 && (
            <div>
              <Label>Дата оплаты остатка *</Label>
              <div className="flex gap-2">
                <Input
                  type="date"
                  value={remainderDueDate ? format(remainderDueDate, "yyyy-MM-dd") : ""}
                  onChange={(e) => {
                    if (e.target.value) {
                      setRemainderDueDate(new Date(e.target.value));
                    } else {
                      setRemainderDueDate(undefined);
                    }
                  }}
                  className="flex-1"
                />
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="icon"
                      className="shrink-0"
                    >
                      <CalendarIcon className="h-4 w-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={remainderDueDate}
                      onSelect={setRemainderDueDate}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          )}

          {/* Project status */}
          <div>
            <Label>Статус проекта</Label>
            <Select value={projectStatus} onValueChange={setProjectStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Выберите статус" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Не указан">Не указан</SelectItem>
                <SelectItem value="Работаем">Работаем</SelectItem>
                <SelectItem value="Завершили работу">Завершили работу</SelectItem>
                <SelectItem value="Пауза">Пауза</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Описание</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Дополнительная информация о продлении"
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              Отмена
            </Button>
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? "Сохранение..." : "Сохранить изменения"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
