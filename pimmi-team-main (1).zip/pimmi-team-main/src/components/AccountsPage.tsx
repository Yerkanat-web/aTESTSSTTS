import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Save, Eye, EyeOff, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg, scopeToOrg } from "@/integrations/supabase/org";
interface ProjectAccount {
  id: string;
  client_phone: string | null;
  client_name: string | null;
  work_format: string[] | null;
  project_type: string | null;
  sale_date: string;
  description: string | null;
  service_type: string | null;
  login: string | null;
  password: string | null;
  subscription_end_date: string | null;
  account_id: string | null;
}

export const AccountsPage = () => {
  const [accounts, setAccounts] = useState<ProjectAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingAccount, setEditingAccount] = useState<string | null>(null);
  const [showPasswords, setShowPasswords] = useState<{ [key: string]: boolean }>({});
  const { currentOrgId } = useOrg();

  const serviceOptions = [
    "Wappi тест",
    "Wappi полн",
    "Amocrm тест", 
    "Amocrm полн"
  ];

  useEffect(() => {
    fetchAccounts();
  }, []);

  const fetchAccounts = async () => {
    try {
      setLoading(true);
      
      const { data: salesData, error: salesError } = await scopeToOrg(
        supabase
          .from('sales_results')
          .select('*')
          .order('created_at', { ascending: false }),
        currentOrgId
      );
      if (salesError) {
        throw salesError;
      }

      // Фильтруем проекты с нужными work_format
      const filteredProjects = salesData?.filter(item => {
        return item.work_format && (
          item.work_format.includes('Дожим чатбот') || 
          item.work_format.includes('CRM')
        );
      }) || [];

      // Получаем аккаунты для этих проектов
      const projectIds = filteredProjects.map(p => p.id);
      const { data: accountsData, error: accountsError } = await scopeToOrg(
        supabase
          .from('project_accounts')
          .select('*')
          .in('sales_result_id', projectIds),
        currentOrgId
      );
      if (accountsError) {
        throw accountsError;
      }

      // Создаем карту аккаунтов для быстрого поиска
      const accountsMap = new Map();
      accountsData?.forEach(account => {
        accountsMap.set(account.sales_result_id, account);
      });

      // Создаем записи аккаунтов для проектов без них
      const projectsNeedingAccounts = filteredProjects.filter(project => 
        !accountsMap.has(project.id)
      );

      for (const project of projectsNeedingAccounts) {
        const { data: newAccount, error: createError } = await supabase
          .from('project_accounts')
          .insert(withOrg({
            sales_result_id: project.id,
            service_type: null,
            login: null,
            password: null,
            subscription_end_date: null
          } as any, currentOrgId))
          .select()
          .single();

        if (!createError && newAccount) {
          accountsMap.set(project.id, newAccount);
        }
      }

      // Преобразуем данные для отображения
      const transformedData = filteredProjects.map(item => {
        const account = accountsMap.get(item.id);
        return {
          id: item.id,
          client_phone: item.client_phone,
          client_name: item.client_name,
          work_format: item.work_format,
          project_type: item.project_type,
          sale_date: item.sale_date,
          description: item.description,
          service_type: account?.service_type || null,
          login: account?.login || null,
          password: account?.password || null,
          subscription_end_date: account?.subscription_end_date || null,
          account_id: account?.id || null,
        };
      });

      setAccounts(transformedData);
    } catch (error) {
      console.error('Error fetching accounts:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить аккаунты",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateAccount = async (accountId: string, field: string, value: any) => {
    try {
      const account = accounts.find(acc => acc.id === accountId);
      
      // Поля, которые относятся к project_accounts
      const projectAccountFields = ['service_type', 'login', 'password', 'subscription_end_date'];
      
      if (projectAccountFields.includes(field)) {
        if (account?.account_id) {
          // Обновляем существующую запись
          const { error } = await supabase
            .from('project_accounts')
            .update({ [field]: value })
            .eq('id', account.account_id);

          if (error) throw error;
        } else {
          // Создаем новую запись
          const { data, error } = await supabase
            .from('project_accounts')
            .insert(withOrg({
              sales_result_id: accountId,
              [field]: value
            } as any, currentOrgId))
            .select()
            .single();

          if (error) throw error;

          // Обновляем локальное состояние с новым account_id
          setAccounts(prev => prev.map(acc => 
            acc.id === accountId ? { ...acc, account_id: data.id } : acc
          ));
        }
      } else {
        // Обновляем поля в sales_results
        const { error } = await supabase
          .from('sales_results')
          .update({ [field]: value })
          .eq('id', accountId);

        if (error) throw error;
      }

      // Обновляем локальное состояние
      setAccounts(prev => prev.map(account => 
        account.id === accountId ? { ...account, [field]: value } : account
      ));

      toast({
        title: "Успешно",
        description: "Данные обновлены",
      });
    } catch (error) {
      console.error('Error updating account:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить данные",
        variant: "destructive",
      });
    }
  };

  const togglePasswordVisibility = (accountId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [accountId]: !prev[accountId]
    }));
  };

  const filteredAccounts = accounts.filter(account =>
    account.client_phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.project_type?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Загрузка аккаунтов...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Аккаунты проектов</span>
            <Badge variant="secondary">{filteredAccounts.length} проектов</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Поиск */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Поиск по телефону, компании или типу проекта..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Таблица */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Телефон</TableHead>
                  <TableHead>Компания</TableHead>
                  <TableHead>Услуги</TableHead>
                  <TableHead>Тип проекта</TableHead>
                  <TableHead>Сервис</TableHead>
                  <TableHead>Логин</TableHead>
                  <TableHead>Пароль</TableHead>
                  <TableHead>Подписка до</TableHead>
                  <TableHead>Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAccounts.map((account) => (
                  <TableRow key={account.id}>
                    <TableCell className="font-mono">
                      {account.client_phone || '-'}
                    </TableCell>
                    <TableCell>
                      {account.client_name || '-'}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {account.work_format?.map((service, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        )) || '-'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {account.project_type || '-'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {editingAccount === account.id ? (
                        <Select
                          value={account.service_type || ""}
                          onValueChange={(value) => updateAccount(account.id, 'service_type', value)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue placeholder="Выбрать" />
                          </SelectTrigger>
                          <SelectContent>
                            {serviceOptions.map((option) => (
                              <SelectItem key={option} value={option}>
                                {option}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant={account.service_type ? "default" : "outline"}>
                          {account.service_type || 'Не указан'}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {editingAccount === account.id ? (
                        <Input
                          value={account.login || ""}
                          onChange={(e) => updateAccount(account.id, 'login', e.target.value)}
                          placeholder="Логин"
                          className="w-24"
                        />
                      ) : (
                        <span className="font-mono text-sm">
                          {account.login || '-'}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {editingAccount === account.id ? (
                          <Input
                            type="text"
                            value={account.password || ""}
                            onChange={(e) => updateAccount(account.id, 'password', e.target.value)}
                            placeholder="Пароль"
                            className="w-24"
                          />
                        ) : (
                          <>
                            <span className="font-mono text-sm">
                              {account.password ? 
                                (showPasswords[account.id] ? account.password : '••••••••') 
                                : '-'
                              }
                            </span>
                            {account.password && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => togglePasswordVisibility(account.id)}
                                className="h-6 w-6 p-0"
                              >
                                {showPasswords[account.id] ? 
                                  <EyeOff className="h-3 w-3" /> : 
                                  <Eye className="h-3 w-3" />
                                }
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {editingAccount === account.id ? (
                        <Input
                          type="date"
                          value={account.subscription_end_date || ""}
                          onChange={(e) => updateAccount(account.id, 'subscription_end_date', e.target.value)}
                          className="w-36"
                        />
                      ) : (
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">
                            {account.subscription_end_date ? 
                              new Date(account.subscription_end_date).toLocaleDateString('ru-RU') : 
                              '-'
                            }
                          </span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant={editingAccount === account.id ? "default" : "ghost"}
                        size="sm"
                        onClick={() => {
                          if (editingAccount === account.id) {
                            setEditingAccount(null);
                          } else {
                            setEditingAccount(account.id);
                          }
                        }}
                      >
                        {editingAccount === account.id ? (
                          <>
                            <Save className="h-4 w-4 mr-1" />
                            Готово
                          </>
                        ) : (
                          'Редактировать'
                        )}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredAccounts.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {searchTerm ? 
                "Не найдено проектов по вашему запросу" : 
                "Нет проектов с услугами 'Дожим чатбот' или 'CRM'"
              }
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};