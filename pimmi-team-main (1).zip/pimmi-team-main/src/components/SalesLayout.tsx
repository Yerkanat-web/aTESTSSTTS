import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Users, 
  Phone, 
  Calendar,
  Target,
  Trophy, 
  ShoppingBag, 
  LogOut,
  Zap,
  DollarSign,
  BookOpen,
  Calculator,
  RefreshCw,
  FolderOpen,
  ShieldCheck
} from "lucide-react";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useOrg } from "@/contexts/OrgContext";
 
interface SalesLayoutProps {
  children: ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
  user: {
    name: string;
    points?: number;
    employeeId?: string;
    role: 'admin' | 'employee' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
    department?: string;
  };
  onLogout?: () => void;
}

export const SalesLayout = ({ children, currentPage, onPageChange, user, onLogout }: SalesLayoutProps) => {
  // Get real points from database
  const { points: realPoints, loading: pointsLoading, refetch: refetchPoints } = useEmployeePoints(user.employeeId);
  const { currentOrg } = useOrg();

  const handleRefreshPoints = async () => {
    await refetchPoints();
  };
  
  // Navigation based on user role
  const navigation = (() => {
    const baseNavigation = [
      { id: 'sales-dashboard', label: 'Дашборд продаж', icon: BarChart3 },
      { id: 'sales-knowledge', label: 'База знаний', icon: BookOpen },
      { id: 'sales-cases', label: 'Кейсы', icon: FolderOpen },
      { id: 'achievements', label: 'Достижения', icon: Trophy },
      { id: 'shop', label: 'Магазин', icon: ShoppingBag }
    ];
    
    if (user.role === 'руководитель отдела продаж') {
      return [
        ...baseNavigation,
        { id: 'sales-management', label: 'Управление отделом', icon: Users },
        { id: 'roles-access', label: 'Роли и права', icon: ShieldCheck }
      ];
    }
    
    return baseNavigation;
  })();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-primary p-2 rounded-lg shadow-glow">
                <DollarSign className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                  Pimmi Sales
                </h1>
                <p className="text-sm text-muted-foreground">Панель отдела продаж</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground font-semibold px-3 py-1">
                  <Zap className="h-4 w-4 mr-1" />
                  {pointsLoading ? '...' : realPoints || 0} баллов
                </Badge>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleRefreshPoints}
                  disabled={pointsLoading}
                  className="h-8 w-8 p-0 hover:bg-secondary"
                >
                  <RefreshCw className={`h-4 w-4 ${pointsLoading ? 'animate-spin' : ''}`} />
                </Button>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">{user.name}</span>
                  <Badge className="bg-blue/20 text-blue border-blue/30 text-xs">
                    Отдел продаж
                  </Badge>
                </div>
              </div>
              
              <Button variant="ghost" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <aside className="w-full lg:w-64 space-y-2">
            <div className="bg-card rounded-lg p-4 shadow-card border border-border">
              <nav className="space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.id}
                      variant={currentPage === item.id ? "default" : "ghost"}
                      className={`w-full justify-start ${
                        currentPage === item.id 
                          ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                          : "hover:bg-secondary"
                      }`}
                      onClick={() => onPageChange(item.id)}
                    >
                      <Icon className="h-4 w-4 mr-3" />
                      {item.label}
                    </Button>
                  );
                })}
              </nav>
            </div>

          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};