import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, FileText, CheckCircle, AlertCircle, Download, Plus, Trash2, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg } from "@/integrations/supabase/org";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SalesRow {
  // Основная информация
  sale_amount: number;
  sale_date: string;
  client_name: string;
  project_name: string;
  sale_type?: string; // "new", "existing", "upsell"
  employee_id?: string; // ID выбранного продавца
  
  // Информация о клиенте
  client_phone?: string;
  client_source?: string; // "Сарафанка", "Таргет реклама", "Ерқанат инста", "Ұлан"
  client_type?: string; // "Сразу купил", "Перешел из тестового", "Единоразовая услуга"
  
  // Информация о проекте
  project_type?: string; // "Ежемесячный", "Тестовый", "Единоразовый"
  work_format?: string[]; // ["таргет", "Дожим чатбот", "креатив", "ИИ видео", "ИИ сайт", "ИИ продажник", "CRM"]
  test_ends_at?: string; // Дата окончания теста (только для тестовых проектов)
  
  // Финансовая информация
  prepayment?: number;
  remainder?: number;
  remainder_due_date?: string;
  paid_full?: boolean; // Для единоразовых проектов
  
  // Продления (для совместимости со старой структурой)
  is_extension?: string;
  extension_sequence?: number;
  parent_project_name?: string;
  extensions?: SalesExtension[];
  
  // Дополнительная информация
  description?: string;
}

interface SalesExtension {
  sale_amount: number;
  sale_date: string;
  prepayment?: number;
  remainder_due_date?: string;
}

interface Employee {
  id: string;
  name: string;
  department: string;
  role: string;
}

export const SalesImport = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [parsedSales, setParsedSales] = useState<SalesRow[]>([]);
  const [manualSales, setManualSales] = useState<SalesRow[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const { currentOrgId } = useOrg();
  const [currentSale, setCurrentSale] = useState<SalesRow>({
    // Основная информация
    sale_amount: 0,
    sale_date: '',
    client_name: '',
    project_name: '',
    sale_type: 'new',
    employee_id: '',
    
    // Информация о клиенте
    client_phone: '',
    client_source: '',
    client_type: '',
    
    // Информация о проекте
    project_type: 'Единоразовый',
    work_format: [],
    
    // Финансовая информация
    prepayment: 0,
    extensions: [],
  });
  const [currentExtension, setCurrentExtension] = useState<SalesExtension>({
    sale_amount: 0,
    sale_date: '',
    prepayment: 0,
  });
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [results, setResults] = useState<{
    success: number;
    errors: { row: number; error: string }[];
  } | null>(null);
  const { toast } = useToast();

  // Загружаем сотрудников при монтировании компонента
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        console.log('Загружаем сотрудников отдела продаж и администраторов...');
        const { data, error } = await supabase
          .from('employees')
          .select('id, name, department, role')
          .eq('status', 'active')
          .or('department.eq.отдел продаж,role.eq.admin')
          .order('name');

        if (error) throw error;
        console.log('Загружены сотрудники:', data);
        setEmployees(data || []);
      } catch (error) {
        console.error('Ошибка загрузки сотрудников:', error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить список сотрудников",
          variant: "destructive",
        });
      }
    };

    fetchEmployees();
  }, [toast]);

  const downloadTemplate = () => {
    const template = `sale_amount	sale_date	client_name	project_name	sale_type	employee_name	client_phone	client_source	client_type	project_type	work_format	prepayment	remainder_due_date	test_ends_at	description
150000	2024-01-15	Иван Иванов	Сайт для магазина	new	Ерканат Мухамедов	+77001234567	Сарафанка	Сразу купил	Ежемесячный	таргет,креатив	50000	2024-02-15		Разработка корпоративного сайта
80000	2024-01-20	Мария Петрова	SMM ведение	existing	Арай Акмырзаева	+77009876543	Таргет реклама	Единоразовая услуга	Единоразовый	таргет,Дожим чатбот	30000			Ведение социальных сетей
200000	2024-01-25	Компания ТОО Успех	Реклама в Google	new	Ерканат Мухамедов	+77001111111	Ерқанат инста	Сразу купил	Тестовый	таргет	100000		2024-02-25	Настройка контекстной рекламы`;

    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'template_sales_import.csv';
    link.click();
  };

  const parseDate = (dateStr: string): string => {
    if (!dateStr) return '';
    
    // Если дата уже в формате YYYY-MM-DD, возвращаем как есть
    if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return dateStr;
    }
    
    // Если дата в формате DD.MM.YYYY
    if (dateStr.match(/^\d{2}\.\d{2}\.\d{4}$/)) {
      const [day, month, year] = dateStr.split('.');
      return `${year}-${month}-${day}`;
    }
    
    // Если дата в формате D.M.YYYY или DD.M.YYYY или D.MM.YYYY
    if (dateStr.match(/^\d{1,2}\.\d{1,2}\.\d{4}$/)) {
      const [day, month, year] = dateStr.split('.');
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    
    console.warn('Неизвестный формат даты:', dateStr);
    return dateStr;
  };

  const parseCSV = (text: string): SalesRow[] => {
    console.log('CSV text length:', text.length);
    console.log('CSV first 500 chars:', text.substring(0, 500));
    
    const lines = text.split('\n').filter(line => line.trim());
    console.log('Lines count:', lines.length);
    
    if (lines.length < 2) {
      console.log('Not enough lines in CSV');
      return [];
    }
    
    // Проверяем разделитель - запятая или табуляция
    const separator = lines[0].includes('\t') ? '\t' : ',';
    console.log('Using separator:', separator === '\t' ? 'TAB' : 'COMMA');
    
    const headers = lines[0].split(separator).map(h => h.trim());
    console.log('Headers found:', headers);
    console.log('Headers count:', headers.length);
    console.log('Expected headers:', ['sale_amount', 'sale_date', 'client_name', 'project_name', 'sale_type', 'employee_name', 'client_phone', 'client_source', 'client_type', 'project_type', 'work_format', 'prepayment', 'remainder_due_date', 'test_ends_at', 'description']);
    
    const allSales: SalesRow[] = [];
    
    lines.slice(1).forEach((line, lineIndex) => {
      console.log(`Processing line ${lineIndex + 2}:`, line);
      const values = line.split(separator).map(v => v.trim().replace(/[""]/g, ''));
      console.log('Values:', values);
      
      // Парсим данные согласно ПРАВИЛЬНОМУ формату CSV:
      // 0: sale_amount, 1: sale_date, 2: client_name, 3: project_name, 4: sale_type, 5: employee_name,
      // 6: client_phone, 7: client_source, 8: client_type, 9: project_type, 10: work_format,
      // 11: prepayment, 12: remainder_due_date, 13: test_ends_at, 14: description
      console.log('Parsing values:', values.map((v, i) => `${i}: ${v}`).join(', '));
      
      const sale: SalesRow = {
        sale_amount: values[0] ? Number(values[0].replace(/\s/g, '')) : 0,
        sale_date: parseDate(values[1] || ''),
        client_name: values[2] || '',
        project_name: values[3] || '',
        sale_type: values[4] || 'new',
        
        // Находим сотрудника по имени (если указано)
        employee_id: '', // Будет найден позже по имени
        
        // Информация о клиенте - ПРОВЕРЯЕМ ЧТО ЭТО ПРАВИЛЬНЫЕ ПОЛЯ
        client_phone: values[6] || '',
        client_source: values[7] || '',
        client_type: values[8] || '',
        
        // Информация о проекте
        project_type: values[9] || 'Единоразовый',
        work_format: (() => {
          const workFormatStr = values[10] || '';
          console.log(`Row ${lineIndex + 2} work_format raw:`, workFormatStr);
          const workFormatArray = workFormatStr ? workFormatStr.split(',').map(f => f.trim()).filter(f => f) : [];
          console.log(`Row ${lineIndex + 2} work_format parsed:`, workFormatArray);
          return workFormatArray;
        })(),
        
        // Финансовая информация
        prepayment: values[11] ? Number(values[11].replace(/\s/g, '')) : 0,
        // ВАЖНО: remainder_due_date должна быть ДАТОЙ, не числом!
        remainder_due_date: (() => {
          const val = values[12];
          // Проверяем что это реально дата, а не число
          if (!val || /^\d+$/.test(val.trim())) return ''; // Если только числа - это не дата
          return parseDate(val);
        })(),
        test_ends_at: (() => {
          const val = values[13];
          // Проверяем что это реально дата, а не число  
          if (!val || /^\d+$/.test(val.trim())) return ''; // Если только числа - это не дата
          return parseDate(val);
        })(),
        description: values[14] || values[3] || '', // Используем project_name как fallback
      };
      
      // Рассчитываем остаток
      sale.remainder = sale.sale_amount - (sale.prepayment || 0);
      sale.paid_full = sale.project_type === 'Единоразовый' && sale.remainder <= 0;
      
      // Если предоплата равна полной сумме, очищаем дату оплаты остатка
      if (sale.prepayment >= sale.sale_amount) {
        sale.remainder_due_date = '';
      }
      
      console.log('Parsed sale:', sale);
      
      if (sale.client_name && sale.project_name && sale.sale_amount && sale.sale_date) {
        // Добавляем employee_name для поиска ID
        (sale as any).employee_name = values[5] || '';
        allSales.push(sale);
        console.log('Added sale');
      } else {
        console.log('Skipped sale - missing required fields');
      }
    });
    
    console.log('Total sales found:', allSales.length);
    return allSales;
  };

  const handleFileLoad = async () => {
    if (!file) {
      toast({
        title: "Ошибка",
        description: "Выберите файл для загрузки",
        variant: "destructive",
      });
      return;
    }

    try {
      const text = await file.text();
      const salesData = parseCSV(text);

      if (salesData.length === 0) {
        throw new Error('Файл пустой или неправильного формата');
      }

      setParsedSales(salesData);
      toast({
        title: "Файл загружен",
        description: `Найдено ${salesData.length} продаж для импорта`,
      });

    } catch (error) {
      console.error('Ошибка чтения файла:', error);
      toast({
        title: "Ошибка чтения файла",
        description: error instanceof Error ? error.message : 'Неизвестная ошибка',
        variant: "destructive",
      });
    }
  };

  const addManualSale = () => {
    if (!currentSale.client_name || !currentSale.project_name || !currentSale.sale_amount || !currentSale.sale_date || !currentSale.employee_id) {
      toast({
        title: "Ошибка",
        description: "Заполните обязательные поля: Продавец, Клиент, Проект, Сумма, Дата",
        variant: "destructive",
      });
      return;
    }

    if (editingIndex !== null) {
      // Редактирование существующей продажи
      const updatedSales = [...manualSales];
      updatedSales[editingIndex] = { ...currentSale };
      setManualSales(updatedSales);
      setEditingIndex(null);
      toast({
        title: "Продажа обновлена",
        description: "Изменения сохранены",
      });
    } else {
      // Добавление новой продажи
      setManualSales([...manualSales, { ...currentSale }]);
      toast({
        title: "Продажа добавлена",
        description: "Продажа добавлена в список",
      });
    }

    // Сброс формы
    setCurrentSale({
      sale_amount: 0,
      sale_date: '',
      client_name: '',
      project_name: '',
      sale_type: 'new',
      employee_id: '',
      client_phone: '',
      client_source: '',
      client_type: '',
      project_type: 'Единоразовый',
      work_format: [],
      prepayment: 0,
      extensions: [],
    });
  };

  const editManualSale = (index: number) => {
    setCurrentSale({ ...manualSales[index] });
    setEditingIndex(index);
  };

  const deleteManualSale = (index: number) => {
    const updatedSales = manualSales.filter((_, i) => i !== index);
    setManualSales(updatedSales);
    if (editingIndex === index) {
      setEditingIndex(null);
      setCurrentSale({
        client_name: '',
        project_name: '',
        sale_amount: 0,
        sale_date: '',
        project_type: 'Одноразовый',
        client_phone: '',
        prepayment: 0,
        extensions: [],
        employee_id: '',
      });
    }
    toast({
      title: "Продажа удалена",
      description: "Продажа удалена из списка",
    });
  };

  const addExtension = () => {
    if (!currentExtension.sale_amount || !currentExtension.sale_date) {
      toast({
        title: "Ошибка",
        description: "Заполните сумму и дату продления",
        variant: "destructive",
      });
      return;
    }

    setCurrentSale({
      ...currentSale,
      extensions: [...(currentSale.extensions || []), { ...currentExtension }]
    });

    setCurrentExtension({
      sale_amount: 0,
      sale_date: '',
      prepayment: 0,
    });

    toast({
      title: "Продление добавлено",
      description: "Продление добавлено к проекту",
    });
  };

  const removeExtension = (index: number) => {
    const updatedExtensions = currentSale.extensions?.filter((_, i) => i !== index) || [];
    setCurrentSale({
      ...currentSale,
      extensions: updatedExtensions
    });
  };

  const cancelEdit = () => {
    setEditingIndex(null);
    setCurrentSale({
      client_name: '',
      project_name: '',
      sale_amount: 0,
      sale_date: '',
      project_type: 'Одноразовый',
      client_phone: '',
      prepayment: 0,
      extensions: [],
      employee_id: '',
    });
    setCurrentExtension({
      sale_amount: 0,
      sale_date: '',
      prepayment: 0,
    });
  };

  const saveAllManualSales = async () => {
    if (manualSales.length === 0) {
      toast({
        title: "Ошибка",
        description: "Нет продаж для сохранения",
        variant: "destructive",
      });
      return;
    }

    await handleSaveSales(manualSales);
  };

  const handleSaveSales = async (salesToSave: SalesRow[] = parsedSales) => {
    if (salesToSave.length === 0) {
      toast({
        title: "Ошибка",
        description: "Нет данных для сохранения",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    setProgress(0);
    setResults(null);

    try {
      // Получаем текущего пользователя
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Пользователь не авторизован');
      }

      // Получаем ID текущего сотрудника (добавляющего)
      const { data: currentEmployee } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!currentEmployee) {
        throw new Error('Сотрудник не найден');
      }

      const results = {
        success: 0,
        errors: [] as { row: number; error: string }[]
      };

      // Загружаем продажи по одной
      let processedCount = 0;
      const totalItems = salesToSave.reduce((acc, sale) => acc + 1 + (sale.extensions?.length || 0), 0);

      for (let i = 0; i < salesToSave.length; i++) {
        const sale = salesToSave[i];
        
        try {
          // Валидация обязательных полей
          if (!sale.client_name || !sale.project_name || !sale.sale_amount || !sale.sale_date) {
            throw new Error('Заполните обязательные поля: client_name, project_name, sale_amount, sale_date');
          }

          // Находим ID сотрудника по имени если указано employee_name
          let salesEmployeeId = sale.employee_id;
          if (!salesEmployeeId && (sale as any).employee_name) {
            const foundEmployee = employees.find(emp => emp.name === (sale as any).employee_name);
            if (foundEmployee) {
              salesEmployeeId = foundEmployee.id;
            }
          }
          
          // Если ID продавца не найден, используем текущего пользователя
          if (!salesEmployeeId) {
            salesEmployeeId = currentEmployee.id;
          }

          // Определяем является ли это продлением
          const isExtension = sale.is_extension && (sale.is_extension.toLowerCase() === 'да' || sale.is_extension.toLowerCase() === 'yes');
          let parentProjectId = null;

          // Если это продление, найдем родительский проект
          if (isExtension && sale.parent_project_name) {
            const { data: parentProject } = await supabase
              .from('sales_results')
              .select('id')
              .eq('project_name', sale.parent_project_name)
              .eq('is_extension', false)
              .single();

            if (!parentProject) {
              throw new Error(`Родительский проект "${sale.parent_project_name}" не найден`);
            }
            parentProjectId = parentProject.id;
          }

          console.log('Processing sale data:', sale);
          
          const saleData = {
            employee_id: salesEmployeeId,
            client_name: sale.client_name,
            project_name: sale.project_name,
            sale_amount: sale.sale_amount,
            sale_date: sale.sale_date,
            description: sale.description || `${sale.project_name} - ${sale.sale_type || 'new'}`,
            
            // Информация о клиенте
            client_phone: sale.client_phone || null,
            client_source: sale.client_source as any || null,
            client_type: sale.client_type as any || null,
            
            // Информация о проекте
            project_type: sale.project_type || (isExtension ? 'Ежемесячный' : 'Единоразовый'),
            work_format: sale.work_format && sale.work_format.length > 0 ? sale.work_format : null,
            
            // Финансовая информация
            prepayment: sale.prepayment || 0,
            remainder: sale.remainder || (sale.sale_amount - (sale.prepayment || 0)),
            // ВАЖНО: Проверяем что remainder_due_date это дата, а не число!
            remainder_due_date: sale.remainder_due_date && !isNaN(Date.parse(sale.remainder_due_date)) 
              ? sale.remainder_due_date 
              : null,
            paid_full: sale.paid_full || (sale.project_type === 'Единоразовый'),
            
            // Тестовые продажи
            is_test: sale.project_type === 'Тестовый',
            // ВАЖНО: Проверяем что test_ends_at это дата, а не число!
            test_ends_at: sale.test_ends_at && !isNaN(Date.parse(sale.test_ends_at)) 
              ? sale.test_ends_at 
              : null,
            
            // Продления
            is_extension: isExtension,
            extension_sequence: sale.extension_sequence || 0,
            parent_project_id: parentProjectId
          };
          
          console.log('Final sale data being sent to DB:', saleData);

          const { data: insertedSale, error } = await supabase
            .from('sales_results')
            .insert(withOrg(saleData as any, currentOrgId))
            .select('id')
            .single();

          if (error) throw error;

          results.success++;
          processedCount++;

          // Добавляем продления для этого проекта
          if (sale.extensions && sale.extensions.length > 0) {
            for (let j = 0; j < sale.extensions.length; j++) {
              const extension = sale.extensions[j];
              
              try {
                const extensionData = {
                  employee_id: salesEmployeeId, // Тот же продавец для продлений
                  client_name: sale.client_name,
                  project_name: `${sale.project_name} - Продление ${j + 1}`,
                  sale_amount: extension.sale_amount,
                  sale_date: extension.sale_date,
                  project_type: 'Ежемесячный',
                  client_phone: sale.client_phone,
                  prepayment: extension.prepayment || 0,
                  remainder_due_date: extension.remainder_due_date || null,
                  is_extension: true,
                  extension_sequence: j + 1,
                  parent_project_id: insertedSale.id
                };

                const { error: extensionError } = await supabase
                  .from('sales_results')
                  .insert(withOrg(extensionData as any, currentOrgId));

                if (extensionError) throw extensionError;

                results.success++;
                processedCount++;
              } catch (extensionError) {
                console.error(`Ошибка в продлении ${j + 1} проекта "${sale.project_name}":`, extensionError);
                results.errors.push({
                  row: i + 2,
                  error: `Продление ${j + 1}: ${extensionError instanceof Error ? extensionError.message : 'Неизвестная ошибка'}`
                });
                processedCount++;
              }

              // Обновляем прогресс
              setProgress(Math.round((processedCount / totalItems) * 100));
            }
          }

        } catch (error) {
          console.error(`Ошибка в строке ${i + 2}:`, error);
          results.errors.push({
            row: i + 2,
            error: error instanceof Error ? error.message : 'Неизвестная ошибка'
          });
          processedCount++;
        }

        // Обновляем прогресс после основной продажи
        if (!sale.extensions || sale.extensions.length === 0) {
          setProgress(Math.round((processedCount / totalItems) * 100));
        }
      }

      setResults(results);

      if (results.success > 0 && salesToSave === manualSales) {
        // Очищаем список ручных продаж после успешного сохранения
        setManualSales([]);
      }

      toast({
        title: "Импорт завершен",
        description: `Успешно загружено: ${results.success}, ошибок: ${results.errors.length}`,
        variant: results.errors.length === 0 ? "default" : "destructive",
      });

    } catch (error) {
      console.error('Ошибка импорта:', error);
      toast({
        title: "Ошибка импорта",
        description: error instanceof Error ? error.message : 'Неизвестная ошибка',
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Импорт продаж
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="csv" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="csv">Импорт из CSV</TabsTrigger>
              <TabsTrigger value="manual">Ручной ввод</TabsTrigger>
            </TabsList>
            
            <TabsContent value="csv" className="space-y-6">
              {/* Инструкции */}
              <Alert>
                <FileText className="h-4 w-4" />
                <AlertDescription>
                  Загрузите CSV файл с вашими продажами и продлениями. Используйте шаблон ниже для правильного формата данных.
                  <br /><br />
                  <strong>Обязательные поля:</strong> client_name, project_name, sale_amount, sale_date
                  <br />
                  <strong>Формат даты:</strong> YYYY-MM-DD (например: 2024-01-15)
                  <br />
                  <strong>Продления:</strong> is_extension = "да", extension_sequence = номер продления, parent_project_name = название оригинального проекта
                </AlertDescription>
              </Alert>

              {/* Скачать шаблон */}
              <div>
                <Button 
                  variant="outline" 
                  onClick={downloadTemplate}
                  className="w-full sm:w-auto"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Скачать шаблон CSV
                </Button>
              </div>

              {/* Выбор файла */}
              <div className="space-y-2">
                <Label htmlFor="file">Выберите CSV файл</Label>
                <Input
                  id="file"
                  type="file"
                  accept=".csv,.txt"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  disabled={isUploading}
                />
              </div>

              {/* Прогресс загрузки */}
              {isUploading && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Загрузка продаж...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              )}

              {/* Кнопка загрузки файла */}
              <Button 
                onClick={handleFileLoad}
                disabled={!file}
                className="w-full"
              >
                <Upload className="h-4 w-4 mr-2" />
                Загрузить и проверить файл
              </Button>

              {/* Предпросмотр продаж */}
              {parsedSales.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Найденные продажи ({parsedSales.length})</h3>
                  <div className="max-h-96 overflow-y-auto border rounded-lg">
                    <table className="w-full text-sm">
                      <thead className="bg-muted">
                        <tr>
                          <th className="text-left p-2 border-b">Клиент</th>
                          <th className="text-left p-2 border-b">Проект</th>
                          <th className="text-left p-2 border-b">Сумма</th>
                          <th className="text-left p-2 border-b">Дата</th>
                          <th className="text-left p-2 border-b">Тип</th>
                          <th className="text-left p-2 border-b">Продление</th>
                        </tr>
                      </thead>
                      <tbody>
                        {parsedSales.map((sale, index) => (
                          <tr key={index} className="border-b">
                            <td className="p-2">{sale.client_name}</td>
                            <td className="p-2">{sale.project_name}</td>
                            <td className="p-2">{sale.sale_amount.toLocaleString()} ₸</td>
                            <td className="p-2">{sale.sale_date}</td>
                            <td className="p-2">{sale.project_type || 'Одноразовый'}</td>
                            <td className="p-2">
                              {sale.is_extension === 'да' ? `№${sale.extension_sequence}` : 'Нет'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Кнопка сохранения */}
                  <Button 
                    onClick={() => handleSaveSales(parsedSales)}
                    disabled={isUploading}
                    className="w-full"
                    variant="default"
                  >
                    {isUploading ? (
                      <>Сохраняем...</>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Сохранить продажи в системе
                      </>
                    )}
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="manual" className="space-y-6">
              {/* Форма добавления продажи */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">
                    {editingIndex !== null ? 'Редактировать продажу' : 'Добавить новую продажу'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="employee_id">Кто продал? *</Label>
                      <Select
                        value={currentSale.employee_id}
                        onValueChange={(value) => {
                          console.log('Выбран продавец:', value);
                          setCurrentSale({...currentSale, employee_id: value});
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите продавца" />
                        </SelectTrigger>
                        <SelectContent className="bg-background border shadow-md z-50">
                          {employees.length === 0 ? (
                            <SelectItem value="no-employees" disabled>
                              Нет доступных продавцов
                            </SelectItem>
                          ) : (
                            employees.map((employee) => (
                              <SelectItem key={employee.id} value={employee.id}>
                                {employee.name} {employee.role === 'admin' ? '(Администратор)' : `(${employee.department})`}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      {employees.length === 0 && (
                        <p className="text-sm text-muted-foreground">
                          Загрузка сотрудников отдела продаж и администраторов...
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="client_name">Клиент *</Label>
                      <Input
                        id="client_name"
                        value={currentSale.client_name}
                        onChange={(e) => setCurrentSale({...currentSale, client_name: e.target.value})}
                        placeholder="Имя клиента"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="project_name">Название проекта *</Label>
                      <Input
                        id="project_name"
                        value={currentSale.project_name}
                        onChange={(e) => setCurrentSale({...currentSale, project_name: e.target.value})}
                        placeholder="Название проекта"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="sale_amount">Сумма сделки *</Label>
                      <Input
                        id="sale_amount"
                        type="number"
                        value={currentSale.sale_amount || ''}
                        onChange={(e) => setCurrentSale({...currentSale, sale_amount: Number(e.target.value)})}
                        placeholder="150000"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="sale_date">Дата продажи *</Label>
                      <Input
                        id="sale_date"
                        type="date"
                        value={currentSale.sale_date}
                        onChange={(e) => setCurrentSale({...currentSale, sale_date: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="project_type">Тип проекта</Label>
                      <Select
                        value={currentSale.project_type}
                        onValueChange={(value) => setCurrentSale({...currentSale, project_type: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Единоразовый">Единоразовый</SelectItem>
                          <SelectItem value="Ежемесячный">Ежемесячный</SelectItem>
                          <SelectItem value="Тестовый">Тестовый</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="client_phone">Телефон клиента</Label>
                      <Input
                        id="client_phone"
                        value={currentSale.client_phone || ''}
                        onChange={(e) => setCurrentSale({...currentSale, client_phone: e.target.value})}
                        placeholder="+77001234567"
                      />
                    </div>
                    
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="prepayment">Предоплата</Label>
                      <Input
                        id="prepayment"
                        type="number"
                        value={currentSale.prepayment || ''}
                        onChange={(e) => setCurrentSale({...currentSale, prepayment: Number(e.target.value)})}
                        placeholder="50000"
                      />
                    </div>
                  </div>

                  {/* Секция продлений */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Продления проекта</h4>
                    
                    {/* Форма добавления продления */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-3">
                      <div className="space-y-2">
                        <Label htmlFor="ext_amount">Сумма продления</Label>
                        <Input
                          id="ext_amount"
                          type="number"
                          value={currentExtension.sale_amount || ''}
                          onChange={(e) => setCurrentExtension({...currentExtension, sale_amount: Number(e.target.value)})}
                          placeholder="120000"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ext_date">Дата продления</Label>
                        <Input
                          id="ext_date"
                          type="date"
                          value={currentExtension.sale_date}
                          onChange={(e) => setCurrentExtension({...currentExtension, sale_date: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ext_prepayment">Предоплата</Label>
                        <Input
                          id="ext_prepayment"
                          type="number"
                          value={currentExtension.prepayment || ''}
                          onChange={(e) => setCurrentExtension({...currentExtension, prepayment: Number(e.target.value)})}
                          placeholder="40000"
                        />
                      </div>
                      <div className="flex items-end">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={addExtension}
                          className="w-full"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Добавить
                        </Button>
                      </div>
                    </div>

                    {/* Список добавленных продлений */}
                    {currentSale.extensions && currentSale.extensions.length > 0 && (
                      <div className="space-y-2">
                        <Label>Добавленные продления:</Label>
                        {currentSale.extensions.map((extension, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <div className="text-sm">
                              <span className="font-medium">Продление {index + 1}:</span>{' '}
                              {extension.sale_amount.toLocaleString()} тенге на {extension.sale_date}
                              {extension.prepayment && extension.prepayment > 0 && (
                                <span className="text-muted-foreground"> (предоплата: {extension.prepayment.toLocaleString()})</span>
                              )}
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeExtension(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button onClick={addManualSale} className="flex-1">
                      <Plus className="h-4 w-4 mr-2" />
                      {editingIndex !== null ? 'Сохранить изменения' : 'Добавить продажу'}
                    </Button>
                    {editingIndex !== null && (
                      <Button variant="outline" onClick={cancelEdit}>
                        Отмена
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Список добавленных продаж */}
              {manualSales.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Добавленные продажи ({manualSales.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                     <div className="space-y-4">
                       {manualSales.map((sale, index) => (
                         <div key={index} className="border rounded-lg p-4">
                           <div className="flex items-center justify-between mb-3">
                             <div className="flex-1">
                               <div className="font-medium">{sale.project_name}</div>
                               <div className="text-sm text-muted-foreground">
                                 {sale.client_name} • {sale.sale_amount.toLocaleString()} тенге • {sale.sale_date}
                                 {sale.project_type && ` • ${sale.project_type}`}
                                 {sale.employee_id && (
                                   <span> • Продавец: {employees.find(emp => emp.id === sale.employee_id)?.name || 'Неизвестно'}</span>
                                 )}
                               </div>
                             </div>
                             <div className="flex gap-2">
                               <Button
                                 variant="ghost"
                                 size="sm"
                                 onClick={() => editManualSale(index)}
                               >
                                 <Edit className="h-4 w-4" />
                               </Button>
                               <Button
                                 variant="ghost"
                                 size="sm"
                                 onClick={() => deleteManualSale(index)}
                               >
                                 <Trash2 className="h-4 w-4" />
                               </Button>
                             </div>
                           </div>
                           
                           {/* Показываем продления если есть */}
                           {sale.extensions && sale.extensions.length > 0 && (
                             <div className="mt-3 pt-3 border-t">
                               <div className="text-sm font-medium text-muted-foreground mb-2">
                                 Продления ({sale.extensions.length}):
                               </div>
                               <div className="space-y-1">
                                 {sale.extensions.map((extension, extIndex) => (
                                   <div key={extIndex} className="text-sm text-muted-foreground pl-4">
                                     • Продление {extIndex + 1}: {extension.sale_amount.toLocaleString()} тенге на {extension.sale_date}
                                     {extension.prepayment && extension.prepayment > 0 && (
                                       <span> (предоплата: {extension.prepayment.toLocaleString()})</span>
                                     )}
                                   </div>
                                 ))}
                               </div>
                             </div>
                           )}
                         </div>
                       ))}

                      <Button 
                        onClick={saveAllManualSales}
                        disabled={isUploading}
                        className="w-full"
                      >
                        {isUploading ? (
                          <>Сохраняем...</>
                        ) : (
                          <>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Сохранить все продажи в системе
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          {/* Результаты */}
          {results && (
            <div className="space-y-4 mt-6">
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Успешно загружено: {results.success}</span>
              </div>

              {results.errors.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <span>Ошибок: {results.errors.length}</span>
                  </div>
                  
                  <div className="max-h-48 overflow-y-auto bg-red-50 p-3 rounded-md">
                    {results.errors.map((error, index) => (
                      <div key={index} className="text-sm text-red-700">
                        Строка {error.row}: {error.error}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};