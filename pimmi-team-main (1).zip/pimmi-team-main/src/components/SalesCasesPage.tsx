import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Search, Eye, Filter, X, ZoomIn, ImageIcon, Plus, Trash2, Edit, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useOrg } from "@/contexts/OrgContext";
import { scopeToOrg } from "@/integrations/supabase/org";

interface ProjectCase {
  id: string;
  project_name: string;
  category: string;
  services: string[];
  point_a_description: string;
  our_work_description: string;
  point_b_description: string;
  result_screenshots: string[];
  instagram_url?: string;
  created_at: string;
}

interface Category {
  id: string;
  name: string;
  created_at: string;
}

const serviceColors: Record<string, string> = {
  'таргет': 'bg-blue/20 text-blue border-blue/30',
  'чатбот': 'bg-green/20 text-green border-green/30',
  'срм': 'bg-purple/20 text-purple border-purple/30',
  'видео': 'bg-red/20 text-red border-red/30',
  'сайт': 'bg-orange/20 text-orange border-orange/30'
};

const services = ['Все услуги', 'таргет', 'чатбот', 'срм', 'видео', 'сайт'];

export const SalesCasesPage = () => {
  const [cases, setCases] = useState<ProjectCase[]>([]);
  const [filteredCases, setFilteredCases] = useState<ProjectCase[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Все категории');
  const [selectedService, setSelectedService] = useState('Все услуги');
  const [selectedCase, setSelectedCase] = useState<ProjectCase | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const [signedScreenshots, setSignedScreenshots] = useState<string[]>([]);
  
  // Client message generator states
  const [clientIndustry, setClientIndustry] = useState('');
  const [managerContext, setManagerContext] = useState('');
  const [generatedMessage, setGeneratedMessage] = useState('');
  const [isGeneratingMessage, setIsGeneratingMessage] = useState(false);
  const [messageError, setMessageError] = useState('');
  
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  useEffect(() => {
    fetchCases();
    fetchCategories();
  }, []);

  useEffect(() => {
    filterCases();
  }, [cases, searchTerm, selectedCategory, selectedService]);

  const fetchCases = async () => {
    try {
      setLoading(true);
      const { data, error } = await scopeToOrg(
        supabase
          .from('project_cases')
          .select('*')
          .eq('is_active', true)
          .order('created_at', { ascending: false }),
        currentOrgId
      );

      if (error) throw error;
      setCases(data || []);
    } catch (error) {
      console.error('Error fetching cases:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить кейсы",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await scopeToOrg(
        supabase
          .from('project_categories')
          .select('*')
          .order('name'),
        currentOrgId
      );

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const filterCases = () => {
    let filtered = cases;

    if (searchTerm) {
      filtered = filtered.filter(case_ =>
        case_.project_name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory !== 'Все категории') {
      filtered = filtered.filter(case_ => case_.category === selectedCategory);
    }

    if (selectedService !== 'Все услуги') {
      filtered = filtered.filter(case_ => 
        case_.services.includes(selectedService)
      );
    }

    setFilteredCases(filtered);
  };

  // Generate signed URLs for case screenshots when opening modal
  useEffect(() => {
    const run = async () => {
      if (!selectedCase || !selectedCase.result_screenshots) { setSignedScreenshots([]); return; }
      const derivePathFromUrl = (url: string): string | null => {
        const patterns = [
          '/object/public/task-attachments/',
          '/object/sign/task-attachments/',
          '/object/authenticated/task-attachments/',
          '/object/task-attachments/'
        ];
        for (const p of patterns) {
          const idx = url.indexOf(p);
          if (idx !== -1) return url.substring(idx + p.length);
        }
        if (!url.startsWith('http')) return url; // likely already a path
        return null;
      };
      const arr = await Promise.all(
        selectedCase.result_screenshots
          .filter(s => s && s.trim() !== '')
          .map(async (item) => {
            try {
              const path = derivePathFromUrl(item) || item;
              if (path.startsWith('http')) return item;
              const { data, error } = await supabase.storage.from('task-attachments').createSignedUrl(path, 3600);
              return !error && data?.signedUrl ? data.signedUrl : item;
            } catch { return item; }
          })
      );
      setSignedScreenshots(arr);
    };
    if (isModalOpen) run(); else setSignedScreenshots([]);
  }, [selectedCase, isModalOpen]);
  
  const handleCaseClick = (case_: ProjectCase) => {
    setSelectedCase(case_);
    setIsModalOpen(true);
    // Reset message generator states when opening new case
    setClientIndustry('');
    setManagerContext('');
    setGeneratedMessage('');
    setMessageError('');
  };


  const generateClientMessage = async () => {
    if (!selectedCase || !clientIndustry.trim()) return;
    
    setIsGeneratingMessage(true);
    setMessageError('');
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-client-message', {
        body: {
          clientIndustry: clientIndustry.trim(),
          managerContext: managerContext.trim(),
          caseData: {
            project_name: selectedCase.project_name,
            category: selectedCase.category,
            services: selectedCase.services,
            point_a_description: selectedCase.point_a_description,
            point_b_description: selectedCase.point_b_description,
            our_work_description: selectedCase.our_work_description,
            instagram_url: selectedCase.instagram_url,
          }
        }
      });

      if (error) {
        throw new Error(error.message);
      }

      if (!data?.message) {
        throw new Error('Не удалось сгенерировать сообщение');
      }

      setGeneratedMessage(data.message);
      toast({
        title: "Успешно!",
        description: "Сообщение для клиента сгенерировано",
      });
    } catch (error) {
      console.error('Error generating client message:', error);
      setMessageError(error instanceof Error ? error.message : 'Произошла неизвестная ошибка');
      toast({
        title: "Ошибка",
        description: "Не удалось сгенерировать сообщение",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingMessage(false);
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('Все категории');
    setSelectedService('Все услуги');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Загрузка кейсов...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Кейсы проектов
          </h1>
          <p className="text-muted-foreground">
            Примеры наших успешных работ для презентации клиентам
          </p>
        </div>
        <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground">
          {filteredCases.length} кейсов
        </Badge>
      </div>


      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Фильтры и поиск
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Поиск по названию проекта..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <select 
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
            >
              <option value="Все категории">Все категории</option>
              {categories.map(category => (
                <option key={category.id} value={category.name}>{category.name}</option>
              ))}
            </select>
            <select 
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
            >
              {services.map(service => (
                <option key={service} value={service}>{service}</option>
              ))}
            </select>
            {(searchTerm || selectedCategory !== 'Все категории' || selectedService !== 'Все услуги') && (
              <Button variant="outline" onClick={clearFilters}>
                <X className="h-4 w-4 mr-2" />
                Очистить
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Cases Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCases.map((case_) => (
          <Card key={case_.id} className="cursor-pointer hover:shadow-elegant transition-shadow">
            <CardHeader>
              <CardTitle className="text-lg">{case_.project_name}</CardTitle>
              <CardDescription>{case_.category}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {case_.services.map((service) => (
                  <Badge
                    key={service}
                    className={serviceColors[service] || 'bg-gray/20 text-gray border-gray/30'}
                  >
                    {service}
                  </Badge>
                ))}
              </div>
              <p className="text-sm text-muted-foreground line-clamp-3">
                {case_.point_a_description}
              </p>
              <Button 
                className="w-full" 
                variant="outline"
                onClick={() => handleCaseClick(case_)}
              >
                <Eye className="h-4 w-4 mr-2" />
                Подробнее
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCases.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground text-lg">
            Кейсы не найдены
          </p>
          <p className="text-muted-foreground text-sm mt-2">
            Попробуйте изменить параметры поиска или фильтры
          </p>
        </div>
      )}

      {/* Case Details Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedCase && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedCase.project_name}</DialogTitle>
                <DialogDescription className="text-base">
                  {selectedCase.category} • {selectedCase.services.join(', ')}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6" id="case-content">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-red-600">
                    📍 Точка А - Начальное состояние
                  </h3>
                  <p className="text-muted-foreground">{selectedCase.point_a_description}</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-blue-600">
                    🔧 Что мы сделали
                  </h3>
                  <p className="text-muted-foreground">{selectedCase.our_work_description}</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-green-600">
                    🎯 Точка Б - Достигнутый результат
                  </h3>
                  <p className="text-muted-foreground">{selectedCase.point_b_description}</p>
                </div>

                {/* Instagram Link */}
                {selectedCase.instagram_url && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3 text-purple-600">
                      📱 Instagram проекта
                    </h3>
                    <a 
                      href={selectedCase.instagram_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-primary hover:underline text-base flex items-center gap-2"
                    >
                      <span>{selectedCase.instagram_url}</span>
                      <span className="text-xs">↗</span>
                    </a>
                  </div>
                )}

                {selectedCase.result_screenshots && selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '').length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3">
                      📊 Скриншоты результатов
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {selectedCase.result_screenshots
                        .filter(screenshot => screenshot && screenshot.trim() !== '')
                        .map((screenshot, index) => (
                        <div 
                          key={index} 
                          className="relative group cursor-pointer border border-border rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                          onClick={() => setSelectedImageIndex(index)}
                        >
                          <img
                            src={signedScreenshots[index] || screenshot}
                            alt={`Скриншот ${index + 1}`}
                            className="w-full h-48 object-cover"
                          />
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <ZoomIn className="h-8 w-8 text-white" />
                          </div>
                          <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                            Скриншот {index + 1}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Client Message Generator */}
                <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30 rounded-lg border border-border">
                  <h3 className="text-lg font-semibold mb-4 text-blue-600 dark:text-blue-400 flex items-center gap-2">
                    💬 Генератор сообщений для клиентов
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Создайте персонализированное коммерческое предложение на основе этого кейса
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Сфера деятельности клиента *
                      </label>
                      <input
                        type="text"
                        value={clientIndustry}
                        onChange={(e) => setClientIndustry(e.target.value)}
                        placeholder="Например: магазин одежды, ресторан, салон красоты..."
                        className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Дополнительный контекст от менеджера
                      </label>
                      <textarea
                        value={managerContext}
                        onChange={(e) => setManagerContext(e.target.value)}
                        placeholder="Например: клиент заинтересован в продвижении в Instagram, бюджет около 200,000 тенге..."
                        rows={3}
                        className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                      />
                    </div>
                    
                    <div className="flex gap-3">
                      <Button
                        onClick={generateClientMessage}
                        disabled={isGeneratingMessage || !clientIndustry.trim()}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700"
                      >
                        {isGeneratingMessage ? (
                          <>
                            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                            Генерирую...
                          </>
                        ) : (
                          <>
                            ✨ Сгенерировать сообщение
                          </>
                        )}
                      </Button>
                      
                      {generatedMessage && (
                        <Button
                           onClick={() => {
                             navigator.clipboard.writeText(generatedMessage);
                             toast({
                               title: "Скопировано!",
                               description: "Сообщение скопировано в буфер обмена",
                             });
                           }}
                          variant="outline"
                          className="border-blue-300 text-blue-600 hover:bg-blue-50 dark:border-blue-600 dark:text-blue-400 dark:hover:bg-blue-950/30"
                        >
                          📋 Копировать
                        </Button>
                      )}
                    </div>
                    
                    {generatedMessage && (
                      <div className="mt-4 p-4 bg-white dark:bg-gray-900 rounded-lg border border-border">
                        <h4 className="font-medium mb-2 text-green-600 dark:text-green-400">
                          ✅ Сгенерированное сообщение:
                        </h4>
                        <div className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">
                          {generatedMessage}
                        </div>
                      </div>
                    )}
                    
                    {messageError && (
                      <div className="mt-4 p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-800">
                        <h4 className="font-medium mb-2 text-red-600 dark:text-red-400">
                          ❌ Ошибка генерации:
                        </h4>
                        <div className="text-sm text-red-600 dark:text-red-400">
                          {messageError}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end pt-4 border-t border-border">
                <Button variant="outline" onClick={() => setIsModalOpen(false)}>
                  Закрыть
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Image Lightbox */}
      {selectedImageIndex !== null && selectedCase && selectedCase.result_screenshots && selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '').length > 0 && (
        <Dialog open={true} onOpenChange={() => setSelectedImageIndex(null)}>
          <DialogContent className="max-w-5xl max-h-[95vh] p-2">
            <DialogHeader className="pb-2">
              <DialogTitle className="text-center">
                Скриншот {selectedImageIndex + 1} из {selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '').length}
              </DialogTitle>
            </DialogHeader>
            <div className="relative flex items-center justify-center">
              <img
                src={(signedScreenshots[selectedImageIndex] || selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '')[selectedImageIndex])}
                alt={`Скриншот ${selectedImageIndex + 1}`}
                className="max-w-full max-h-[80vh] object-contain rounded-lg"
              />
            </div>
            <div className="flex justify-center space-x-2 pt-2">
              {selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '').length > 1 && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const validScreenshots = selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '');
                      setSelectedImageIndex(selectedImageIndex > 0 ? selectedImageIndex - 1 : validScreenshots.length - 1);
                    }}
                  >
                    ← Предыдущий
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const validScreenshots = selectedCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '');
                      setSelectedImageIndex(selectedImageIndex < validScreenshots.length - 1 ? selectedImageIndex + 1 : 0);
                    }}
                  >
                    Следующий →
                  </Button>
                </>
              )}
              <Button variant="outline" size="sm" onClick={() => setSelectedImageIndex(null)}>
                Закрыть
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};