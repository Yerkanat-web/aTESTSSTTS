import { useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2, Users } from "lucide-react";
import { useChangeResponsible } from "@/hooks/useChangeResponsible";
import { TaskAssignmentItem } from "./TaskAssignmentItem";

interface ProjectData {
  id: string;
  project_name: string | null;
  client_name: string | null;
  work_format: string[] | null;
  employee_id: string;
  manager_name: string;
}

interface ChangeResponsibleDialogProps {
  isOpen: boolean;
  onClose: () => void;
  project: ProjectData | null;
  onSuccess: () => void;
}

export const ChangeResponsibleDialog = ({ isOpen, onClose, project, onSuccess }: ChangeResponsibleDialogProps) => {
  const {
    employees,
    projectTasks,
    taskAssignments,
    loading,
    saving,
    fetchData,
    saveChanges,
    updateTaskAssignment,
    resetAssignments
  } = useChangeResponsible(project);

  const handleSaveChanges = async () => {
    const success = await saveChanges();
    if (success) {
      onSuccess();
      onClose();
    }
  };

  useEffect(() => {
    if (isOpen && project) {
      fetchData();
    }
  }, [isOpen, project, fetchData]);

  useEffect(() => {
    if (!isOpen) {
      resetAssignments();
    }
  }, [isOpen]);

  if (!project) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Исполнители по проекту
          </DialogTitle>
          <DialogDescription>
            Назначьте исполнителей для задач проекта "{project.project_name || project.client_name}"
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Форматы работы */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Форматы работы:</Label>
            <div className="flex flex-wrap gap-1">
              {project.work_format?.map((format, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {format}
                </Badge>
              )) || <span className="text-sm text-muted-foreground">Не указаны</span>}
            </div>
          </div>

          {/* Список задач с исполнителями */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Задачи проекта:</Label>
            {loading ? (
              <div className="flex items-center justify-center p-4">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="ml-2 text-sm">Загрузка данных...</span>
              </div>
            ) : projectTasks.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground">
                Задач по этому проекту пока нет
              </div>
            ) : (
              <div className="space-y-3">
                {projectTasks.map((task) => (
                  <TaskAssignmentItem
                    key={task.id}
                    task={task}
                    employees={employees}
                    currentAssigneeId={taskAssignments[task.id]}
                    onAssignmentChange={updateTaskAssignment}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>
            Отмена
          </Button>
          <Button
            onClick={handleSaveChanges}
            disabled={saving || Object.keys(taskAssignments).length === 0}
          >
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Сохраняем...
              </>
            ) : (
              "Сохранить изменения"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};