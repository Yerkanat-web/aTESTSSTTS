import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LabelList } from 'recharts';
import { 
  Clock, 
  TrendingUp, 
  Target, 
  Trophy, 
  Star,
  ChevronRight,
  Calendar,
  Zap,
  BarChart3,
  RefreshCw,
  BrainCircuit,
  Sparkles,
  Building,
  User,
  FileText,
  AlertCircle,
  CheckCircle,
  X,
  Shield,
  Heart,
  HelpCircle,
  Download,
  Play,
  Lightbulb,
  Settings,
  TrendingUp as TrendingUpIcon,
  Bot,
  Zap as ZapIcon
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isToday, parseISO, startOfDay, endOfDay, subDays, differenceInHours } from "date-fns";
import { ru } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useEmployeeStats } from "@/hooks/useEmployeeStats";
import { useTaskCategories } from "@/hooks/useTaskCategories";
import { logger } from "@/utils/logger";
import { formatTime } from "@/utils/timeHelpers";

interface DashboardStats {
  yesterdayHours: number;
  weeklyAverage: number;
  totalPoints: number;
  achievements: number;
  totalTasks: number;
  completedTasks: number;
}

interface TaskCategory {
  name: string;
  hours: number;
  percentage: number;
  count: number;
}

interface WeeklyData {
  day: string;
  hours: number;
  date: string;
  tasks: number;
}

interface Achievement {
  id: string;
  achievement_name: string;
  description: string;
  points: number;
  earned_at: string;
}

interface DashboardProps {
  onPageChange?: (page: string) => void;
}

interface BusinessAnalysisData {
  businessName: string;
  businessDescription: string;
}

interface AnalysisResult {
  avatarName: string;
  detailedDescription: string;
  alternatives: string;
  problemsWithoutProduct: string;
  mainMotivation: string;
  decisionFactors: string;
  stopFactors: string;
  fears: string;
  needs: string;
  convincingFacts: string;
  companyQuestions: string;
}

interface PlanResult {
  "🔥 Главный оффер для рекламы": string;
  "🎬 Идеи креативов": string;
  "🤖 Скрипт чат-бота": string;
  "📈 Структура автоворонки": string;
  "⚙️ Что автоматизировать": string;
  "🚀 Точка масштабирования": string;
}

export const Dashboard = ({ onPageChange }: DashboardProps) => {
  const [employeeId, setEmployeeId] = useState<string | null>(null);
  const [userDepartment, setUserDepartment] = useState<string>('');
  const [stats, setStats] = useState<DashboardStats>({
    yesterdayHours: 0,
    weeklyAverage: 0,
    totalPoints: 0,
    achievements: 0,
    totalTasks: 0,
    completedTasks: 0
  });
  const [taskCategories, setTaskCategories] = useState<TaskCategory[]>([]);
  const [weeklyData, setWeeklyData] = useState<WeeklyData[]>([]);
  const [recentAchievements, setRecentAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [analysisData, setAnalysisData] = useState<BusinessAnalysisData>({
    businessName: '',
    businessDescription: ''
  });
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [planResult, setPlanResult] = useState<PlanResult | null>(null);
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const { toast } = useToast();
  
  // Use new hooks for points and stats
  const { points: dbPoints, loading: pointsLoading } = useEmployeePoints(employeeId || undefined);
  const { stats: employeeStats, loading: statsLoading } = useEmployeeStats(employeeId || undefined);
  const { categories: taskCategoriesFromSettings } = useTaskCategories();
  
  logger.debug('Dashboard data state', { employeeId, dbPoints, loading: pointsLoading });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Update stats when points change
  useEffect(() => {
    if (dbPoints !== undefined && !pointsLoading) {
      setStats(prev => ({ ...prev, totalPoints: dbPoints }));
    }
  }, [dbPoints, pointsLoading]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Получаем текущего пользователя
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      // Получаем информацию о сотруднике
      logger.debug('Getting current user data', { userId: user.id, email: user.email });
      const { data: employee, error: employeeError } = await supabase
        .from('employees')
        .select('id, name, email, department')
        .eq('user_id', user.id)
        .single();

      logger.debug('Employee data loaded', { employee, error: employeeError });

      if (!employee) {
        logger.warn('Employee not found for user', { userId: user.id });
        setLoading(false);
        return;
      }

      // Set employee ID for hooks
      setEmployeeId(employee.id);
      setUserDepartment(employee.department);

      // Параллельно загружаем все данные
      const [
        timeLogsResult,
        tasksResult,
        achievementsResult,
        salesResult
      ] = await Promise.all([
        // Логи рабочего времени за последнюю неделю
        supabase
          .from('work_time_logs')
          .select('*')
          .eq('employee_id', employee.id)
          .gte('start_time', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()),
        
        // Задачи сотрудника
        supabase
          .from('employee_tasks')
          .select('*')
          .eq('employee_id', employee.id),
        
        // Достижения сотрудника
        supabase
          .from('employee_achievements')
          .select('*')
          .eq('employee_id', employee.id)
          .order('earned_at', { ascending: false })
          .limit(4),
        
        // Продажи сотрудника (если есть)
        supabase
          .from('sales_results')
          .select('*')
          .eq('employee_id', employee.id)
      ]);

      // Обрабатываем логи времени
      const timeLogs = timeLogsResult.data || [];
      const tasks = tasksResult.data || [];
      const achievements = achievementsResult.data || [];
      const sales = salesResult.data || [];

      // Рассчитываем статистику
      logger.debug('Dashboard data loaded from DB', {
        timeLogs: timeLogs.length,
        tasks: tasks.length,
        achievements: achievements.length
      });
      
      // Группируем данные по дням для правильного расчета
      const dayGroups = timeLogs.reduce((acc, log) => {
        const logDate = new Date(log.start_time);
        const dayKey = logDate.toDateString();
        if (!acc[dayKey]) {
          acc[dayKey] = [];
        }
        acc[dayKey].push(log);
        return acc;
      }, {} as Record<string, any[]>);

      logger.debug('Time logs grouped by day', Object.keys(dayGroups).map(day => ({
        day,
        hours: dayGroups[day].reduce((sum, log) => sum + (Number(log.hours_worked) || 0), 0)
      })));
      
      // Часы из work_time_logs
      const timeLogHours = timeLogs.reduce((sum, log) => sum + (Number(log.hours_worked) || 0), 0);
      
      // Часы из выполненных задач (если нет данных в work_time_logs)
      const taskMinutes = tasks
        .filter(task => task.status === 'completed')
        .reduce((sum, task) => sum + (Number(task.actual_minutes) || 0), 0);
      
      const totalHours = timeLogHours + (taskMinutes / 60);
      logger.debug('Hours calculation', { timeLogHours, taskMinutes, totalHours });
      
      // Логика для "вчера" - вчерашний день
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStart = new Date(yesterday);
      yesterdayStart.setHours(0, 0, 0, 0);
      const yesterdayEnd = new Date(yesterday);
      yesterdayEnd.setHours(23, 59, 59, 999);

      // Часы из work_time_logs за вчера
      const yesterdayTimeLogHours = timeLogs
        .filter(log => {
          const logDate = new Date(log.start_time);
          return logDate >= yesterdayStart && logDate <= yesterdayEnd;
        })
        .reduce((sum, log) => sum + (Number(log.hours_worked) || 0), 0);

      // Часы из выполненных задач за вчера (используем due_date - дату выполнения)
      const yesterdayTaskHours = tasks
        .filter(task => {
          if (task.status !== 'completed' || !task.due_date) return false;
          const taskDate = new Date(task.due_date);
          return taskDate >= yesterdayStart && taskDate <= yesterdayEnd;
        })
        .reduce((sum, task) => sum + ((Number(task.actual_minutes) || 0) / 60), 0);

      const yesterdayHours = yesterdayTimeLogHours + yesterdayTaskHours;

      logger.debug('Yesterday hours calculation', {
        date: yesterday.toDateString(),
        timeLogHours: yesterdayTimeLogHours,
        taskHours: yesterdayTaskHours,
        total: yesterdayHours,
        taskCount: tasks.filter(task => {
          if (task.status !== 'completed' || !task.due_date) return false;
          const taskDate = new Date(task.due_date);
          return taskDate >= yesterdayStart && taskDate <= yesterdayEnd;
        }).length
      });

      // Исправленный расчет недельного среднего
      // Берем дни с работой только из дат выполнения задач (due_date)
      const taskDayGroups = tasks
        .filter(task => task.status === 'completed' && task.due_date)
        .reduce((acc, task) => {
          const taskDate = new Date(task.due_date);
          const dayKey = taskDate.toDateString();
          if (!acc[dayKey]) {
            acc[dayKey] = 0;
          }
          acc[dayKey] += (Number(task.actual_minutes) || 0) / 60;
          return acc;
        }, {} as Record<string, number>);

      // Дни с работой считаем только из дат выполнения задач
      const daysWithWork = Object.keys(taskDayGroups).length;
      const weeklyAverage = daysWithWork > 0 ? totalHours / daysWithWork : 0;
      logger.debug('Weekly average calculation', { daysWithWork, weeklyAverage });

      // Рассчитываем баллы на основе выполненных задач
      const completedTasks = tasks.filter(task => task.status === 'completed');
      logger.debug('Completed tasks', completedTasks.map(t => ({ priority: t.priority, status: t.status })));
      
      const priorityPoints = {
        'easy': 5,
        'medium': 15,
        'hard': 30
      };

      const totalPoints = completedTasks.reduce((sum, task) => {
        const points = priorityPoints[task.priority as keyof typeof priorityPoints] || 10;
        return sum + points;
      }, 0);
      logger.debug('Total points from tasks', { totalPoints });

      setStats({
        yesterdayHours: Number(yesterdayHours.toFixed(1)),
        weeklyAverage: Number(weeklyAverage.toFixed(1)),
        totalPoints: dbPoints !== undefined ? dbPoints : 0, // Use database points with proper check
        achievements: achievements.length,
        totalTasks: tasks.length,
        completedTasks: completedTasks.length
      });

      // Группируем задачи по категориям с использованием настроек системы
      const categoryGroups = tasks.reduce((acc, task) => {
        const category = task.category || 'general';
        if (!acc[category]) {
          acc[category] = { count: 0, hours: 0 };
        }
        acc[category].count += 1;
        acc[category].hours += (task.actual_minutes || 0) / 60;
        return acc;
      }, {} as Record<string, { count: number; hours: number }>);

      const totalTaskHours = Object.values(categoryGroups).reduce((sum, cat) => sum + cat.hours, 0);

      const categories = Object.entries(categoryGroups).map(([key, data]) => ({
        name: key,
        hours: data.hours,
        count: data.count,
        percentage: totalTaskHours > 0 ? (data.hours / totalTaskHours) * 100 : 0
      }));

      logger.debug('Task categories calculated', { categories });

      setTaskCategories(categories);

      // Формируем данные по дням недели на основе дат выполнения задач
      const weekData = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dayKey = date.toDateString();
        
        // Берем задачи по дате выполнения (due_date)
        const dayTasks = tasks.filter(task => {
          if (task.status !== 'completed' || !task.due_date) return false;
          const taskDate = new Date(task.due_date);
          return taskDate.toDateString() === dayKey;
        });

        // Считаем часы из задач с этой датой выполнения
        const dayHours = dayTasks.reduce((sum, task) => sum + ((Number(task.actual_minutes) || 0) / 60), 0);

        weekData.push({
          day: date.toLocaleDateString('ru-RU', { weekday: 'short' }),
          hours: Number(dayHours.toFixed(1)),
          date: date.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' }),
          tasks: dayTasks.length
        });
      }

      logger.debug('Weekly chart data', { weekData });

      setWeeklyData(weekData);
      setRecentAchievements(achievements);

    } catch (error) {
      logger.error('Error fetching dashboard data', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные дашборда",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBusinessAnalysis = async () => {
    if (!analysisData.businessName || !analysisData.businessDescription) {
      toast({
        title: "Ошибка",
        description: "Заполните все поля для анализа",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    try {
      const { data, error } = await supabase.functions.invoke('business-analysis', {
        body: {
          businessName: analysisData.businessName,
          businessDescription: analysisData.businessDescription
        }
      });

      if (error) throw error;

      setAnalysisResult(data.analysis);
      toast({
        title: "Анализ готов",
        description: "ИИ анализ успешно сгенерирован",
      });
    } catch (error) {
      console.error('Error generating analysis:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сгенерировать анализ",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGeneratePlan = async () => {
    if (!analysisResult) {
      toast({
        title: "Ошибка",
        description: "Сначала нужно сгенерировать анализ",
        variant: "destructive",
      });
      return;
    }

    setIsGeneratingPlan(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-plan', {
        body: {
          analysisResult: analysisResult
        }
      });

      if (error) throw error;

      setPlanResult(data.plan);
      toast({
        title: "План готов",
        description: "План маркетинга успешно сгенерирован",
      });
    } catch (error) {
      console.error('Error generating plan:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сгенерировать план",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  const handleRefreshAnalysis = async () => {
    if (!analysisData.businessName || !analysisData.businessDescription) {
      toast({
        title: "Ошибка",
        description: "Заполните все поля для анализа",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    try {
      const { data, error } = await supabase.functions.invoke('business-analysis', {
        body: {
          businessName: analysisData.businessName,
          businessDescription: analysisData.businessDescription
        }
      });

      if (error) throw error;

      setAnalysisResult(data.analysis);
      toast({
        title: "Анализ обновлен",
        description: "ИИ анализ успешно обновлен",
      });
    } catch (error) {
      console.error('Error refreshing analysis:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить анализ",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRefreshPlan = async () => {
    if (!analysisResult) {
      toast({
        title: "Ошибка",
        description: "Сначала нужно сгенерировать анализ",
        variant: "destructive",
      });
      return;
    }

    setIsGeneratingPlan(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-plan', {
        body: {
          analysisResult: analysisResult
        }
      });

      if (error) throw error;

      setPlanResult(data.plan);
      toast({
        title: "План обновлен",
        description: "План маркетинга успешно обновлен",
      });
    } catch (error) {
      console.error('Error refreshing plan:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить план",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  const formatPlanContent = (content: string): string => {
    return content
      // Убираем символы # из заголовков
      .replace(/#{1,6}\s*/g, '')
      // Убираем markdown символы жирного текста
      .replace(/\*\*(.*?)\*\*/g, '$1')
      // Убираем markdown символы курсива
      .replace(/\*(.*?)\*/g, '$1')
      // Убираем лишние пробелы в начале строк
      .replace(/^\s+/gm, '')
      // Форматируем списки - убираем markdown символы
      .replace(/^[\-\*\+]\s+/gm, '• ')
      // Убираем backticks для inline кода
      .replace(/`([^`]+)`/g, '$1')
      // Добавляем дополнительные переносы строк между пунктами для лучшей читабельности
      .replace(/\n/g, '\n\n')
      // Убираем более чем 3 переноса подряд
      .replace(/\n{4,}/g, '\n\n\n')
      .trim();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Добро пожаловать!</h2>
          <p className="text-muted-foreground mt-1">Вот ваша статистика и прогресс</p>
        </div>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{new Date().toLocaleDateString('ru-RU', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue to-primary text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-foreground/80 text-sm font-medium">Вчера</p>
                <p className="text-3xl font-bold">{formatTime(stats.yesterdayHours * 60)}</p>
              </div>
              <Clock className="h-8 w-8 text-blue-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green to-emerald-500 text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-foreground/80 text-sm font-medium">Среднее за неделю</p>
                <p className="text-3xl font-bold">{formatTime(stats.weeklyAverage * 60)}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-gold text-gold-foreground border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gold-foreground/80 text-sm font-medium">Общие баллы</p>
                <p className="text-3xl font-bold">{pointsLoading ? '...' : (dbPoints !== undefined ? dbPoints : stats.totalPoints)}</p>
              </div>
              <Zap className="h-8 w-8 text-gold-foreground/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-primary text-white border-0 shadow-elegant">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-primary-foreground/80 text-sm font-medium">Задачи</p>
                <p className="text-3xl font-bold">{stats.completedTasks}/{stats.totalTasks}</p>
              </div>
              <Trophy className="h-8 w-8 text-primary-foreground/60" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Work Hours Chart */}
        <Card className="shadow-card border border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Рабочие часы за неделю
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyData}>
                <XAxis 
                  dataKey="day" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <Bar 
                  dataKey="hours" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]}
                >
                  <LabelList 
                    dataKey="hours" 
                    position="top" 
                    style={{ 
                      fontSize: '12px', 
                      fill: 'hsl(var(--muted-foreground))', 
                      fontWeight: 'bold' 
                    }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Task Categories Chart */}
        <Card className="shadow-card border border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Категории задач
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {taskCategories.length > 0 ? (
              taskCategories.map((category) => (
                <div key={category.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{category.name}</span>
                     <div className="text-sm text-muted-foreground">
                       <span className="font-semibold text-primary">{formatTime(Math.round(category.hours * 60))}</span>
                       <span className="ml-1">({category.count} задач)</span>
                     </div>
                  </div>
                  <Progress 
                    value={category.percentage} 
                    className="h-2"
                  />
                  <div className="text-xs text-muted-foreground text-right">
                    {Math.round(category.percentage)}%
                  </div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4">Нет данных о задачах</p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-1 gap-6">
        {/* Recent Achievements */}
        <Card className="shadow-card border border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-warning" />
              Последние достижения ({stats.achievements})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentAchievements.length > 0 ? (
              recentAchievements.map((achievement) => (
                <div 
                  key={achievement.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-success/10 border-success/20"
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">🏆</span>
                    <div>
                      <p className="font-medium text-foreground">
                        {achievement.achievement_name}
                      </p>
                      <p className="text-xs text-muted-foreground">{achievement.description}</p>
                      <p className="text-xs text-success">
                        Получено: {new Date(achievement.earned_at).toLocaleDateString('ru-RU')}
                      </p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="bg-success/20 text-success">
                    +{achievement.points} баллов
                  </Badge>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Пока нет достижений</p>
                <p className="text-sm">Выполняйте задачи чтобы получить первые награды!</p>
              </div>
            )}
            
            <div className="pt-2 border-t border-border">
              <button 
                onClick={() => onPageChange?.('achievements')}
                className="flex items-center justify-between w-full p-2 text-sm text-primary hover:bg-primary/5 rounded-lg transition-colors"
              >
                <span>Посмотреть все достижения</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Business Analysis Section - Only for Tech Department */}
      {userDepartment === 'тех отдел' && (
        <Card className="shadow-card border border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BrainCircuit className="h-5 w-5 text-primary" />
              Анализ бизнеса
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="businessName">Название бизнеса</Label>
                <Input
                  id="businessName"
                  value={analysisData.businessName}
                  onChange={(e) => setAnalysisData(prev => ({ ...prev, businessName: e.target.value }))}
                  placeholder="Введите название бизнеса"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="businessDescription">Чем занимается бизнес</Label>
                <Textarea
                  id="businessDescription"
                  value={analysisData.businessDescription}
                  onChange={(e) => setAnalysisData(prev => ({ ...prev, businessDescription: e.target.value }))}
                  placeholder="Опишите деятельность бизнеса"
                  className="min-h-[100px]"
                />
              </div>
            </div>

            <Button 
              onClick={handleBusinessAnalysis}
              disabled={isAnalyzing}
              className="w-full"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Генерируется анализ...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Сгенерировать анализ
                </>
              )}
            </Button>

            {analysisResult && (
              <div className="mt-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Building className="h-4 w-4" />
                    Результат анализа
                  </h3>
                </div>
                
                <div className="rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[200px]">Аспект</TableHead>
                        <TableHead>Описание</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-blue-500" />
                            Имя аватара
                          </div>
                        </TableCell>
                        <TableCell>{analysisResult.avatarName}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-green-500" />
                            Подробное описание
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.detailedDescription}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Target className="h-4 w-4 text-orange-500" />
                            Альтернативы
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.alternatives}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-red-500" />
                            Проблемы без продукта
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.problemsWithoutProduct}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Zap className="h-4 w-4 text-yellow-500" />
                            Главная мотивация
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.mainMotivation}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            Факторы принятия решения
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.decisionFactors}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <X className="h-4 w-4 text-red-500" />
                            Стоп-факторы
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.stopFactors}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-purple-500" />
                            Страхи
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.fears}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Heart className="h-4 w-4 text-pink-500" />
                            Потребности
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.needs}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Star className="h-4 w-4 text-amber-500" />
                            Убеждающие факты
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.convincingFacts}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <HelpCircle className="h-4 w-4 text-indigo-500" />
                            Вопросы к компании
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-pre-wrap">{analysisResult.companyQuestions}</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
                
                {/* Generate Plan Button */}
                <div className="flex justify-center">
                  <Button 
                    onClick={handleGeneratePlan}
                    disabled={isGeneratingPlan}
                    className="w-full max-w-md"
                    variant="outline"
                  >
                    {isGeneratingPlan ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Генерируется план...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Сгенерировать план
                      </>
                    )}
                  </Button>
                </div>
                
                {/* Plan Result */}
                {planResult && (
                  <div className="mt-6 space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold flex items-center gap-2">
                        <Lightbulb className="h-4 w-4" />
                        Маркетинговый план
                      </h3>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {Object.entries(planResult).map(([title, content]) => (
                        <Card key={title} className="shadow-card border border-border">
                          <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                              {title === "🔥 Главный оффер для рекламы" && <ZapIcon className="h-5 w-5 text-orange-500" />}
                              {title === "🎬 Идеи креативов" && <Sparkles className="h-5 w-5 text-purple-500" />}
                              {title === "🤖 Скрипт чат-бота" && <Bot className="h-5 w-5 text-blue-500" />}
                              {title === "📈 Структура автоворонки" && <TrendingUpIcon className="h-5 w-5 text-green-500" />}
                              {title === "⚙️ Что автоматизировать" && <Settings className="h-5 w-5 text-gray-500" />}
                              {title === "🚀 Точка масштабирования" && <Target className="h-5 w-5 text-red-500" />}
                              {title}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="whitespace-pre-wrap text-sm leading-relaxed">
                              {formatPlanContent(content)}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};