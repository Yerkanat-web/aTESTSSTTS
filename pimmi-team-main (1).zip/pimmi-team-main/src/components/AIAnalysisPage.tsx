import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Target, 
  Users,
  Zap,
  BarChart3,
  Award,
  Lightbulb,
  RefreshCw,
  Calendar as CalendarIcon,
  Loader2,
  Database,
  AlertCircle
} from "lucide-react";
import { openAIService, type AnalysisResult, type EmployeeAnalysis, type TeamInsights } from "@/services/openai-service";
import { useTeamAnalysisData } from "@/hooks/useTeamAnalysisData";
import { supabase } from "@/integrations/supabase/client";

export const AIAnalysisPage = () => {
  const { toast } = useToast();
  const { employees, loading: dataLoading, error: dataError, hasMinimalData, refetch } = useTeamAnalysisData();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastAnalysis, setLastAnalysis] = useState(new Date());
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<string>("30");
  const [customStartDate, setCustomStartDate] = useState<Date>();
  const [customEndDate, setCustomEndDate] = useState<Date>();
  const [isCustomPeriod, setIsCustomPeriod] = useState(false);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  const [currentUserDepartment, setCurrentUserDepartment] = useState<string | null>(null);

  // Initialize with cached analysis if available
  useState(() => {
    const cached = openAIService.getCachedAnalysis();
    if (cached) {
      setAnalysisResult(cached);
      setLastAnalysis(new Date(cached.analysisDate));
    }
  });

  // Получаем роль текущего пользователя для корректного отображения заголовка
  useState(() => {
    const fetchUserRole = async () => {
      try {
        const { data: currentUser } = await supabase.auth.getUser();
        if (!currentUser.user) return;

        const { data: employee } = await supabase
          .from("employees")
          .select("role, department")
          .eq("user_id", currentUser.user.id)
          .single();

        if (employee) {
          setCurrentUserRole(employee.role);
          setCurrentUserDepartment(employee.department);
        }
      } catch (error) {
        console.error("Error fetching user role:", error);
      }
    };

    fetchUserRole();
  });

  const runAnalysis = async () => {
    // Проверяем достаточность данных
    if (!hasMinimalData) {
      toast({
        title: "Недостаточно данных",
        description: "Для качественного анализа необходимо больше данных о работе сотрудников. Добавьте задачи, отчеты или достижения.",
        variant: "destructive"
      });
      return;
    }

    // Test connection first
    const isConnected = await openAIService.testConnection();
    if (!isConnected) {
      toast({
        title: "Ошибка",
        description: "OpenAI API недоступен. Проверьте настройки в Supabase.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      let periodDays: number;
      if (isCustomPeriod && customStartDate && customEndDate) {
        const diffTime = Math.abs(customEndDate.getTime() - customStartDate.getTime());
        periodDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      } else {
        periodDays = parseInt(selectedPeriod);
      }

      // Преобразуем данные в нужный формат для анализа
      const employeesForAnalysis = employees.map((emp, index) => ({
        id: index + 1, // Для совместимости с существующим API
        name: emp.name,
        role: emp.role,
        department: emp.department,
        tasks: emp.tasks,
        completedTasks: emp.completedTasks,
        points: emp.points,
        activeHours: emp.activeHours,
        efficiency: emp.efficiency
      }));

      console.log('🔄 Отправляем данные на анализ:', employeesForAnalysis);

      const analysisRequest = {
        employees: employeesForAnalysis,
        periodDays,
        startDate: isCustomPeriod ? customStartDate?.toISOString() : undefined,
        endDate: isCustomPeriod ? customEndDate?.toISOString() : undefined
      };

      const result = await openAIService.analyzeTeam(analysisRequest);
      setAnalysisResult(result);
      setLastAnalysis(new Date());
      
      toast({
        title: "Анализ завершен",
        description: "ИИ анализ команды успешно выполнен"
      });
    } catch (error) {
      console.error('Analysis error:', error);
      toast({
        title: "Ошибка анализа",
        description: error instanceof Error ? error.message : "Произошла ошибка при анализе",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-success" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-destructive" />;
      case 'stable':
        return <Target className="h-4 w-4 text-warning" />;
    }
  };

  const getRiskBadge = (risk: 'low' | 'medium' | 'high') => {
    switch (risk) {
      case 'low':
        return <Badge className="bg-success/20 text-success border-success/30">Низкий риск</Badge>;
      case 'medium':
        return <Badge className="bg-warning/20 text-warning border-warning/30">Средний риск</Badge>;
      case 'high':
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30">Высокий риск</Badge>;
    }
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 90) return "text-success";
    if (score >= 80) return "text-warning";
    return "text-destructive";
  };

  // Показать ошибку загрузки данных
  if (dataError) {
    return (
      <div className="space-y-6">
        <Card className="p-8 text-center border-destructive/50 bg-destructive/5">
          <AlertCircle className="h-12 w-12 mx-auto text-destructive mb-4" />
          <p className="text-lg font-medium mb-2">Ошибка загрузки данных</p>
          <p className="text-muted-foreground mb-4">{dataError}</p>
          <Button onClick={refetch} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Повторить
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-3">
            <Brain className="h-8 w-8 text-primary" />
            {currentUserRole === 'руководитель тех отдела' ? 'ИИ Анализ технического отдела' : 'ИИ Анализ команды'}
          </h2>
          <p className="text-muted-foreground mt-1">
            {currentUserRole === 'руководитель тех отдела' 
              ? 'Автоматический анализ производительности сотрудников технического отдела и рекомендации для улучшения'
              : 'Автоматический анализ производительности и рекомендации для улучшения'
            }
          </p>
          <div className="flex items-center gap-2 mt-2">
            <Database className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {currentUserRole === 'руководитель тех отдела' 
                ? `Сотрудников тех. отдела: ${dataLoading ? '...' : employees.length}`
                : `Сотрудников в системе: ${dataLoading ? '...' : employees.length}`
              }
              {!hasMinimalData && employees.length > 0 && (
                <Badge variant="outline" className="ml-2 text-warning border-warning/30">
                  Недостаточно данных для анализа
                </Badge>
              )}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">Период анализа:</label>
            <Select 
              value={isCustomPeriod ? "custom" : selectedPeriod} 
              onValueChange={(value) => {
                if (value === "custom") {
                  setIsCustomPeriod(true);
                } else {
                  setIsCustomPeriod(false);
                  setSelectedPeriod(value);
                }
              }}
            >
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 дней</SelectItem>
                <SelectItem value="30">30 дней</SelectItem>
                <SelectItem value="90">90 дней</SelectItem>
                <SelectItem value="365">365 дней</SelectItem>
                <SelectItem value="custom">Произвольный</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isCustomPeriod && (
            <div className="flex items-center gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-32">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {customStartDate ? format(customStartDate, "dd.MM", { locale: ru }) : "От"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={customStartDate}
                    onSelect={setCustomStartDate}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              
              <span className="text-sm">—</span>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-32">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {customEndDate ? format(customEndDate, "dd.MM", { locale: ru }) : "До"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={customEndDate}
                    onSelect={setCustomEndDate}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          )}

          <Button 
            onClick={runAnalysis}
            disabled={dataLoading || isAnalyzing || !hasMinimalData || (isCustomPeriod && (!customStartDate || !customEndDate))}
            className="bg-gradient-primary text-primary-foreground shadow-elegant"
          >
            {dataLoading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Загрузка данных...
              </>
            ) : isAnalyzing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Анализируем...
              </>
            ) : (
              <>
                <Brain className="h-4 w-4 mr-2" />
                Запустить анализ
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="text-sm text-muted-foreground">
        Последний анализ: {lastAnalysis.toLocaleDateString('ru-RU')} в {lastAnalysis.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
        {analysisResult && ` | Период: ${analysisResult.period}`}
      </div>

      {/* Team Overview */}
      {analysisResult ? (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card className="bg-gradient-to-br from-primary/10 to-blue/10 border-primary/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Здоровье команды</p>
                  <p className="text-2xl font-bold text-primary">{analysisResult.teamInsights.overallHealth}%</p>
                </div>
                <CheckCircle className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-success/10 to-green/10 border-success/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Эффективность</p>
                  <p className="text-2xl font-bold text-success">{analysisResult.teamInsights.teamEfficiency}%</p>
                </div>
                <Zap className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-warning/10 to-gold/10 border-warning/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Баланс нагрузки</p>
                  <p className="text-2xl font-bold text-warning">{analysisResult.teamInsights.workloadBalance}%</p>
                </div>
                <BarChart3 className="h-8 w-8 text-warning" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-info/10 to-blue/10 border-info/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Тренд продуктивности</p>
                  <div className="flex items-center space-x-2">
                    {getTrendIcon(analysisResult.teamInsights.productivityTrend)}
                    <span className="text-xl font-bold text-info">
                      {analysisResult.teamInsights.productivityTrend === 'up' ? 'Рост' : 
                       analysisResult.teamInsights.productivityTrend === 'down' ? 'Спад' : 'Стабильно'}
                    </span>
                  </div>
                </div>
                <TrendingUp className="h-8 w-8 text-info" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-destructive/10 to-red-500/10 border-destructive/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Риск выгорания</p>
                  <p className="text-2xl font-bold text-destructive">{analysisResult.teamInsights.burnoutRisk}%</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
        </div>
      ) : !hasMinimalData ? (
        <Card className="p-8 text-center border-dashed border-2 bg-warning/5">
          <AlertTriangle className="h-12 w-12 mx-auto text-warning mb-4" />
          <p className="text-lg font-medium mb-2">Недостаточно данных для анализа</p>
          <p className="text-muted-foreground mb-4">
            Для качественного ИИ анализа необходимо больше активности в системе:
          </p>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>• Создайте и выполните задачи</p>
            <p>• Добавьте отчеты о продажах</p>
            <p>• Зафиксируйте рабочие часы</p>
            <p>• Получите достижения</p>
          </div>
          <Button onClick={refetch} variant="outline" className="mt-4">
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить данные
          </Button>
        </Card>
      ) : (
        <Card className="p-8 text-center border-dashed border-2">
          <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-lg font-medium mb-2">Анализ не выполнен</p>
          <p className="text-muted-foreground">Нажмите "Запустить анализ" для получения ИИ анализа команды</p>
        </Card>
      )}

      {/* Employee Analyses */}
      <Card className="shadow-card border border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Индивидуальный анализ сотрудников
          </CardTitle>
        </CardHeader>
        <CardContent>
          {analysisResult ? (
            <div className="space-y-6">
              {analysisResult.employeeAnalyses.map((analysis) => (
              <Card key={analysis.id} className="border border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">{analysis.name}</h3>
                      <p className="text-sm text-muted-foreground">{analysis.role}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className={`text-2xl font-bold ${getPerformanceColor(analysis.performanceScore)}`}>
                          {analysis.performanceScore}
                        </p>
                        <p className="text-xs text-muted-foreground">Производительность</p>
                      </div>
                      {getRiskBadge(analysis.riskLevel)}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Trends */}
                    <div>
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <BarChart3 className="h-4 w-4" />
                        Тренды
                      </h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Продуктивность:</span>
                          {getTrendIcon(analysis.trends.productivity)}
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Эффективность:</span>
                          {getTrendIcon(analysis.trends.efficiency)}
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Нагрузка:</span>
                          <Badge variant="outline" className={
                            analysis.trends.workload === 'high' ? 'text-destructive border-destructive/30' :
                            analysis.trends.workload === 'low' ? 'text-warning border-warning/30' :
                            'text-success border-success/30'
                          }>
                            {analysis.trends.workload === 'high' ? 'Высокая' :
                             analysis.trends.workload === 'low' ? 'Низкая' : 'Нормальная'}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    {/* Strengths */}
                    <div>
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Award className="h-4 w-4 text-success" />
                        Сильные стороны
                      </h4>
                      <ul className="space-y-1">
                        {analysis.strengths.map((strength, index) => (
                          <li key={index} className="text-sm flex items-start gap-2">
                            <CheckCircle className="h-3 w-3 text-success mt-0.5 flex-shrink-0" />
                            {strength}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Improvements */}
                    <div>
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Target className="h-4 w-4 text-warning" />
                        Области роста
                      </h4>
                      <ul className="space-y-1">
                        {analysis.improvements.map((improvement, index) => (
                          <li key={index} className="text-sm flex items-start gap-2">
                            <AlertTriangle className="h-3 w-3 text-warning mt-0.5 flex-shrink-0" />
                            {improvement}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Recommendations */}
                  <div className="mt-6 pt-4 border-t border-border">
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <Lightbulb className="h-4 w-4 text-primary" />
                      Рекомендации ИИ
                    </h4>
                    <div className="space-y-2">
                      {analysis.recommendations.map((recommendation, index) => (
                        <div key={index} className="flex items-start gap-2 p-3 bg-primary/5 rounded-lg border border-primary/10">
                          <Brain className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                          <p className="text-sm">{recommendation}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Запустите анализ для просмотра детальной информации о сотрудниках</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};