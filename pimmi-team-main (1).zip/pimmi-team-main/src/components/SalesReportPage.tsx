import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { 
  Phone, 
  PhoneCall, 
  PhoneMissed, 
  Clock, 
  TrendingUp, 
  Users,
  BarChart3,
  Calendar,
  RefreshCw
} from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { SingleDatePicker } from "@/components/filters/SingleDatePicker";

interface SalesEmployee {
  id: string;
  name: string;
  email: string;
  position: string;
  status: string;
  user_id: string | null;
  sipuni_user_id: string | null;
}

interface CallStats {
  user_id: string;
  date: string;
  incoming_calls: number;
  outgoing_calls: number;
  missed_calls: number;
  total_duration: number;
}

export const SalesReportPage = () => {
  const [salesEmployees, setSalesEmployees] = useState<SalesEmployee[]>([]);
  const [callStats, setCallStats] = useState<CallStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  const fetchSalesEmployees = async () => {
  const { data, error } = await supabase
      .from('employees')
      .select('id, name, email, position, status, user_id, sipuni_user_id')
      .eq('department', 'отдел продаж')
      .eq('status', 'active');

    if (error) {
      console.error('Error fetching sales employees:', error);
      return;
    }

    setSalesEmployees(data || []);
  };

  const fetchCallStats = async () => {
    const { data, error } = await supabase
      .from('call_statistics')
      .select('*')
      .eq('date', format(selectedDate, 'yyyy-MM-dd'));
  

    if (error) {
      console.error('Error fetching call stats:', error);
      return;
    }

    setCallStats(data || []);
  };

  const refreshData = async () => {
    setLoading(true);
    await Promise.all([fetchSalesEmployees(), fetchCallStats()]);
    setLoading(false);
  };

  useEffect(() => {
    refreshData();
  }, [selectedDate]);

  const getEmployeeStats = (employee: SalesEmployee) => {
    if (!employee.user_id) return null;
    return callStats.find(stat => stat.user_id === employee.user_id);
  };

  const getEmployeeSipuniStatus = (employee: SalesEmployee) => {
    return employee.sipuni_user_id ? 'configured' : 'not_configured';
  };

  const getTotalStats = () => {
    return callStats.reduce((acc, stat) => ({
      incoming: acc.incoming + (stat.incoming_calls || 0),
      outgoing: acc.outgoing + (stat.outgoing_calls || 0),
      missed: acc.missed + (stat.missed_calls || 0),
      duration: acc.duration + (stat.total_duration || 0)
    }), { incoming: 0, outgoing: 0, missed: 0, duration: 0 });
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}ч ${minutes}м`;
  };

  const totalStats = getTotalStats();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Отчет по отделу продаж
          </h1>
          <p className="text-muted-foreground">
            Статистика звонков и активность сотрудников
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <SingleDatePicker
            date={selectedDate}
            onChange={(d) => d && setSelectedDate(d)}
          />
          <Button onClick={refreshData} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить
          </Button>
        </div>
      </div>

      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Сотрудников</p>
                <p className="text-2xl font-bold">{salesEmployees.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-success/10 rounded-lg">
                <PhoneCall className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Всего звонков</p>
                <p className="text-2xl font-bold">{totalStats.incoming + totalStats.outgoing}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-destructive/10 rounded-lg">
                <PhoneMissed className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Пропущенных</p>
                <p className="text-2xl font-bold">{totalStats.missed}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-warning/10 rounded-lg">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Общее время</p>
                <p className="text-2xl font-bold">{formatDuration(totalStats.duration)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Employees List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Статистика по сотрудникам на {format(new Date(selectedDate), 'd MMMM yyyy', { locale: ru })}
          </CardTitle>
          <CardDescription>
            Детальная информация по звонкам каждого сотрудника
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {salesEmployees.map((employee) => {
              const stats = getEmployeeStats(employee);
              
              return (
                <div
                  key={employee.id}
                  className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg border border-border"
                >
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarFallback className="bg-gradient-primary text-primary-foreground">
                        {employee.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <h3 className="font-semibold">{employee.name}</h3>
                      <p className="text-sm text-muted-foreground">{employee.position}</p>
                      <p className="text-xs text-muted-foreground">{employee.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {stats ? (
                      <>
                        <div className="text-center">
                          <div className="flex items-center gap-1 text-success">
                            <Phone className="h-4 w-4" />
                            <span className="font-medium">{(stats.incoming_calls || 0) + (stats.outgoing_calls || 0)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">звонков</p>
                        </div>

                        <div className="text-center">
                          <div className="flex items-center gap-1 text-destructive">
                            <PhoneMissed className="h-4 w-4" />
                            <span className="font-medium">{stats.missed_calls || 0}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">пропущен</p>
                        </div>

                        <div className="text-center">
                          <div className="flex items-center gap-1 text-warning">
                            <Clock className="h-4 w-4" />
                            <span className="font-medium">{formatDuration(stats.total_duration || 0)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">времени</p>
                        </div>

                        {getEmployeeSipuniStatus(employee) === 'configured' ? (
                          <Badge variant="secondary" className="bg-success/20 text-success border-success/30">
                            Sipuni настроен
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-warning border-warning/30">
                            Sipuni не настроен
                          </Badge>
                        )}
                      </>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-muted-foreground">
                          Нет данных
                        </Badge>
                        {getEmployeeSipuniStatus(employee) === 'not_configured' && (
                          <Badge variant="outline" className="text-warning border-warning/30">
                            Sipuni не настроен
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {salesEmployees.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Сотрудники отдела продаж не найдены</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};