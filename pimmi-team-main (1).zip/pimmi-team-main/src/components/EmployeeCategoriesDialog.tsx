import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface Employee {
  id: string;
  name: string;
  email: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  employee: Employee;
}

export const EmployeeCategoriesDialog = ({ open, onOpenChange, employee }: Props) => {
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryDescription, setNewCategoryDescription] = useState('');
  const [addingCategory, setAddingCategory] = useState(false);

  const loadEmployeeCategories = async () => {
    if (!employee.id) return;
    
    setLoading(true);
    try {
      const response = await fetch(`https://nsnaucwxgidofohozayb.supabase.co/rest/v1/task_categories?employee_id=eq.${employee.id}&order=name`, {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5zbmF1Y3d4Z2lkb2ZvaG96YXliIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg0MzM1NDYsImV4cCI6MjA2NDAwOTU0Nn0.TtmtaWxWVYumvXcB7fzQpQS4gIMBvL5_2omvhuhtSR4',
          'Authorization': `Bearer ${JSON.parse(localStorage.getItem('sb-nsnaucwxgidofohozayb-auth-token') || '{}').access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }

      const data = await response.json();
      setCategories(data || []);
    } catch (error) {
      console.error('Ошибка загрузки категорий:', error);
      toast.error("Не удалось загрузить категории сотрудника");
    }
    setLoading(false);
  };

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) {
      toast.error("Введите название категории");
      return;
    }

    setAddingCategory(true);
    try {
      const response = await fetch('https://nsnaucwxgidofohozayb.supabase.co/rest/v1/task_categories', {
        method: 'POST',
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5zbmF1Y3d4Z2lkb2ZvaG96YXliIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg0MzM1NDYsImV4cCI6MjA2NDAwOTU0Nn0.TtmtaWxWVYumvXcB7fzQpQS4gIMBvL5_2omvhuhtSR4',
          'Authorization': `Bearer ${JSON.parse(localStorage.getItem('sb-nsnaucwxgidofohozayb-auth-token') || '{}').access_token}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          name: newCategoryName.trim(),
          description: newCategoryDescription.trim() || null,
          employee_id: employee.id
        })
      });

      if (!response.ok) {
        throw new Error('Failed to add category');
      }

      const data = await response.json();
      const newCategory = Array.isArray(data) ? data[0] : data;
      
      if (newCategory) {
        setCategories(prev => [...prev, newCategory]);
        setNewCategoryName('');
        setNewCategoryDescription('');
        toast.success("Категория добавлена");
      }
    } catch (error) {
      console.error('Ошибка добавления категории:', error);
      toast.error("Не удалось добавить категорию");
    }
    setAddingCategory(false);
  };

  const handleDeleteCategory = async (categoryId: string) => {
    try {
      const response = await fetch(`https://nsnaucwxgidofohozayb.supabase.co/rest/v1/task_categories?id=eq.${categoryId}`, {
        method: 'DELETE',
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5zbmF1Y3d4Z2lkb2ZvaG96YXliIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg0MzM1NDYsImV4cCI6MjA2NDAwOTU0Nn0.TtmtaWxWVYumvXcB7fzQpQS4gIMBvL5_2omvhuhtSR4',
          'Authorization': `Bearer ${JSON.parse(localStorage.getItem('sb-nsnaucwxgidofohozayb-auth-token') || '{}').access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete category');
      }

      setCategories(prev => prev.filter(cat => cat.id !== categoryId));
      toast.success("Категория удалена");
    } catch (error) {
      console.error('Ошибка удаления категории:', error);
      toast.error("Не удалось удалить категорию");
    }
  };

  useEffect(() => {
    if (open && employee.id) {
      loadEmployeeCategories();
    }
  }, [open, employee.id]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Категории задач сотрудника</DialogTitle>
          <DialogDescription>
            Индивидуальные категории для {employee.name}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Существующие категории</h4>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <RefreshCw className="h-6 w-6 animate-spin" />
              </div>
            ) : categories.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                У сотрудника пока нет индивидуальных категорий
              </div>
            ) : (
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{category.name}</Badge>
                      </div>
                      {category.description && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {category.description}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteCategory(category.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-4 border-t pt-4">
            <h4 className="text-sm font-medium">Добавить новую категорию</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="categoryName">Название категории</Label>
                <Input
                  id="categoryName"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="Введите название"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddCategory()}
                />
              </div>
              <div>
                <Label htmlFor="categoryDescription">Описание (опционально)</Label>
                <Input
                  id="categoryDescription"
                  value={newCategoryDescription}
                  onChange={(e) => setNewCategoryDescription(e.target.value)}
                  placeholder="Введите описание"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddCategory()}
                />
              </div>
            </div>
            <Button
              onClick={handleAddCategory}
              disabled={addingCategory || !newCategoryName.trim()}
              className="w-full"
            >
              {addingCategory ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Plus className="mr-2 h-4 w-4" />
              )}
              Добавить категорию
            </Button>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Закрыть
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};