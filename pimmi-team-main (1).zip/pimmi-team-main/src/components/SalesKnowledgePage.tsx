import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Clock, ChevronRight, Play } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Course {
  id: string;
  title: string;
  description: string | null;
  level: string | null;
  duration_hours: number | null;
  lessons: Lesson[];
}

interface Lesson {
  id: string;
  title: string;
  content: string | null;
  duration_minutes: number | null;
  order_index: number;
}

export const SalesKnowledgePage = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const { data: coursesData, error: coursesError } = await supabase
        .from('courses')
        .select('*')
        .order('created_at', { ascending: false });

      if (coursesError) throw coursesError;

      if (coursesData) {
        const coursesWithLessons = await Promise.all(
          coursesData.map(async (course) => {
            const { data: lessonsData, error: lessonsError } = await supabase
              .from('lessons')
              .select('*')
              .eq('course_id', course.id)
              .order('order_index', { ascending: true });

            if (lessonsError) {
              console.error('Error fetching lessons:', lessonsError);
              return { ...course, lessons: [] };
            }

            return { ...course, lessons: lessonsData || [] };
          })
        );

        setCourses(coursesWithLessons);
      }
    } catch (error: any) {
      console.error('Error fetching courses:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить курсы",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSelectLesson = (course: Course, lesson: Lesson) => {
    setSelectedCourse(course);
    setSelectedLesson(lesson);
  };

  const handleBackToCourses = () => {
    setSelectedCourse(null);
    setSelectedLesson(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Загрузка курсов...</p>
        </div>
      </div>
    );
  }

  // Отображение урока
  if (selectedLesson && selectedCourse) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={handleBackToCourses}>
            ← Назад к курсам
          </Button>
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            {selectedLesson.duration_minutes} мин
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-2xl">{selectedLesson.title}</CardTitle>
                <CardDescription className="text-base mt-2">
                  Курс: {selectedCourse.title}
                </CardDescription>
              </div>
              <Badge variant="outline">
                Урок {selectedLesson.order_index}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none">
              <div className="whitespace-pre-line text-foreground leading-relaxed">
                {selectedLesson.content}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Отображение списка курсов
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
          База знаний
        </h1>
        <p className="text-muted-foreground">
          Изучайте материалы для повышения профессиональных навыков
        </p>
      </div>

      {courses.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Курсы не найдены</h3>
            <p className="text-muted-foreground">
              Курсы появятся здесь после их добавления администратором.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {courses.map((course) => (
            <Card key={course.id} className="hover:shadow-card-hover transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{course.title}</CardTitle>
                    <CardDescription className="mt-2">
                      {course.description}
                    </CardDescription>
                  </div>
                  <div className="flex flex-col items-end space-y-2">
                    {course.level && (
                      <Badge variant="secondary">
                        {course.level === 'beginner' ? 'Начальный' : 
                         course.level === 'intermediate' ? 'Средний' : 
                         course.level === 'advanced' ? 'Продвинутый' : course.level}
                      </Badge>
                    )}
                    {course.duration_hours && (
                      <Badge variant="outline">
                        <Clock className="h-3 w-3 mr-1" />
                        {course.duration_hours}ч
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                {course.lessons.length > 0 ? (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm text-muted-foreground mb-3">
                      УРОКИ ({course.lessons.length})
                    </h4>
                    {course.lessons.map((lesson) => (
                      <Button
                        key={lesson.id}
                        variant="ghost"
                        className="w-full justify-between h-auto p-3 hover:bg-secondary"
                        onClick={() => handleSelectLesson(course, lesson)}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="bg-primary/10 p-2 rounded-full">
                            <Play className="h-3 w-3 text-primary" />
                          </div>
                          <div className="text-left">
                            <p className="font-medium">{lesson.title}</p>
                            {lesson.duration_minutes && (
                              <p className="text-xs text-muted-foreground">
                                {lesson.duration_minutes} минут
                              </p>
                            )}
                          </div>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">
                    Уроки для этого курса не добавлены
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};