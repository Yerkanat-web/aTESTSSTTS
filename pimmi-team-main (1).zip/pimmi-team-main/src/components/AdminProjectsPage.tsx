import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Database } from "@/integrations/supabase/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Briefcase, Users, UserCheck, ListTodo, RefreshCw, PlayCircle, ArrowRight, RotateCcw, Edit, Plus, Trash2 } from "lucide-react";
import { ProjectAssignmentDialog } from "./ProjectAssignmentDialog";
import { ChangeResponsibleDialog } from "./ChangeResponsibleDialog";
import { ProjectTasksDialog } from "./ProjectTasksDialog";
import { ProjectExtensionDialog } from "./ProjectExtensionDialog";
import { ProjectStartDialog } from "./ProjectStartDialog";
import { ProjectExtensionsPage } from "./ProjectExtensionsPage";
import { EditSaleDialog } from "./EditSaleDialog";
import { AddSaleDialog } from "./AddSaleDialog";

type ProjectStatus = Database["public"]["Enums"]["project_status_enum"];

interface ProjectData {
  id: string;
  project_name: string | null;
  client_name: string | null;
  manager_name: string;
  employee_id: string;
  work_format: string[] | null;
  project_status: ProjectStatus | null;
  sale_date: string;
  sale_amount: number;
  client_type: string | null;
  project_type: string | null;
  tasks_generated: boolean | null;
  actual_tasks_count?: number;
}

export const AdminProjectsPage = () => {
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [projectTasks, setProjectTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<ProjectData | null>(null);
  const [isAssignmentDialogOpen, setIsAssignmentDialogOpen] = useState(false);
  const [isChangeResponsibleDialogOpen, setIsChangeResponsibleDialogOpen] = useState(false);
  const [selectedProjectForChange, setSelectedProjectForChange] = useState<ProjectData | null>(null);
  const [updatingProjectId, setUpdatingProjectId] = useState<string | null>(null);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  const [isProjectTasksDialogOpen, setIsProjectTasksDialogOpen] = useState(false);
  const [selectedProjectForTasks, setSelectedProjectForTasks] = useState<ProjectData | null>(null);
  const [isExtensionDialogOpen, setIsExtensionDialogOpen] = useState(false);
  const [selectedProjectForExtension, setSelectedProjectForExtension] = useState<ProjectData | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [isStartDialogOpen, setIsStartDialogOpen] = useState(false);
  const [selectedProjectForStart, setSelectedProjectForStart] = useState<ProjectData | null>(null);
  const [employees, setEmployees] = useState<Array<{id: string; name: string; department: string}>>([]);
  const [isEditSaleDialogOpen, setIsEditSaleDialogOpen] = useState(false);
  const [selectedProjectForEdit, setSelectedProjectForEdit] = useState<ProjectData | null>(null);
  const [isAddSaleDialogOpen, setIsAddSaleDialogOpen] = useState(false);
  const { toast } = useToast();

  const fetchProjects = async () => {
    try {
      setLoading(true);
      console.log("Fetching projects from sales_results...");
      
      // Get all active employees (not just sales department)
      const { data: allEmployees, error: employeesError } = await supabase
        .from("employees")
        .select("id, name, department, role")
        .eq("status", "active");

      if (employeesError) {
        console.error("Error fetching employees:", employeesError);
        throw employeesError;
      }

      console.log("Active employees found:", allEmployees?.length || 0);

      if (!allEmployees || allEmployees.length === 0) {
        console.log("No active employees found");
        setProjects([]);
        return;
      }

      const employeeIds = allEmployees.map(emp => emp.id);
      
      // Now get sales results for all employees
      const { data, error } = await supabase
        .from("sales_results")
        .select(`
          id,
          project_name,
          client_name,
          work_format,
          project_status,
          sale_date,
          sale_amount,
          employee_id,
          client_type,
          project_type,
          tasks_generated,
          employees!fk_sales_results_employee(name)
        `)
        .in("employee_id", employeeIds)
        .eq("is_extension", false)
        .order("sale_date", { ascending: false });

      if (error) {
        console.error("Error fetching sales results:", error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить проекты",
          variant: "destructive",
        });
        return;
      }

      console.log("Sales results found:", data?.length || 0);

      // Получаем количество реальных задач для каждого проекта
      const projectsWithTaskCounts = await Promise.all(
        (data || []).map(async (item: any) => {
          const { count } = await supabase
            .from('project_tasks')
            .select('*', { count: 'exact', head: true })
            .eq('sales_result_id', item.id);

          return {
            id: item.id,
            project_name: item.project_name,
            client_name: item.client_name,
            manager_name: item.employees?.name || "Неизвестен",
            employee_id: item.employee_id,
            work_format: item.work_format,
            project_status: item.project_status,
            sale_date: item.sale_date,
            sale_amount: item.sale_amount,
            client_type: item.client_type,
            project_type: item.project_type,
            tasks_generated: item.tasks_generated,
            actual_tasks_count: count || 0,
          };
        })
      );

      console.log("Projects with task counts:", projectsWithTaskCounts);
      setProjects(projectsWithTaskCounts);
    } catch (error) {
      console.error("Error in fetchProjects:", error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при загрузке данных",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
    fetchEmployees();
    fetchCurrentUserRole();
  }, []);

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from("employees")
        .select("id, name, department")
        .eq("status", "active");

      if (error) throw error;
      setEmployees(data || []);
    } catch (error) {
      console.error("Error fetching employees:", error);
    }
  };

  const fetchCurrentUserRole = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("employees")
        .select("role")
        .eq("user_id", user.id)
        .single();

      if (error) {
        console.error("Error fetching user role:", error);
        return;
      }

      setCurrentUserRole(data?.role || null);
    } catch (error) {
      console.error("Error fetching current user role:", error);
    }
  };

  const updateProjectStatus = async (projectId: string, newStatus: ProjectStatus) => {
    setUpdatingProjectId(projectId);
    try {
      console.log(`Updating project ${projectId} status to: ${newStatus}`);
      
      // Если статус "Завершили работу" или "Пауза", удаляем все незавершенные задачи
      if (newStatus === "Завершили работу" || newStatus === "Пауза") {
        console.log(`Deleting incomplete tasks for ${newStatus === "Пауза" ? "paused" : "completed"} project...`);
        
        const { error: deleteError } = await supabase
          .from("project_tasks")
          .delete()
          .eq("sales_result_id", projectId)
          .in("status", ["pending", "in_progress", "issues", "postponed"]);

        if (deleteError) {
          console.error("Error deleting tasks:", deleteError);
          throw deleteError;
        }
        
        console.log("Successfully deleted incomplete tasks");
      }

      // Обновляем статус проекта
      const { error: updateError } = await supabase
        .from("sales_results")
        .update({ project_status: newStatus })
        .eq("id", projectId);

      if (updateError) {
        console.error("Error updating project status:", updateError);
        throw updateError;
      }

      console.log("Successfully updated project status");
      
      // Обновляем локальное состояние
      setProjects(prevProjects => 
        prevProjects.map(project => 
          project.id === projectId 
            ? { ...project, project_status: newStatus }
            : project
        )
      );

      const statusMessage = newStatus === "Завершили работу" 
        ? "Проект завершен, незавершенные задачи удалены"
        : newStatus === "Пауза"
        ? "Проект поставлен на паузу, незавершенные задачи удалены"
        : "Статус проекта обновлен";

      toast({
        title: "Успешно",
        description: statusMessage,
      });

    } catch (error) {
      console.error("Error updating project:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус проекта",
        variant: "destructive",
      });
    } finally {
      setUpdatingProjectId(null);
    }
  };

  const regenerateTasks = async (projectId: string) => {
    try {
      console.log(`Regenerating tasks for project: ${projectId}`);
      
      // Сбрасываем флаг генерации задач
      const { error: resetError } = await supabase
        .from("sales_results")
        .update({ tasks_generated: false })
        .eq("id", projectId);

      if (resetError) {
        console.error("Error resetting tasks_generated flag:", resetError);
        throw resetError;
      }

      // Обновляем локальное состояние
      setProjects(prevProjects => 
        prevProjects.map(project => 
          project.id === projectId 
            ? { ...project, tasks_generated: false, actual_tasks_count: 0 }
            : project
        )
      );

      toast({
        title: "Успешно",
        description: "Проект готов к повторной генерации задач",
      });

      // Перезагружаем данные
      fetchProjects();

    } catch (error) {
      console.error("Error regenerating tasks:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось подготовить проект к повторной генерации задач",
        variant: "destructive",
      });
    }
  };

  const deleteProject = async (projectId: string, projectName: string) => {
    const confirmDelete = window.confirm(
      `Вы уверены, что хотите удалить проект "${projectName || 'Без названия'}"?\n\nЭто также удалит все связанные задачи, ежемесячные платежи и аккаунты проектов. Это действие нельзя отменить.`
    );
    
    if (!confirmDelete) return;

    try {
      console.log(`Deleting project: ${projectId}`);
      
      // Удаляем все связанные данные проекта
      // 1. Удаляем задачи проекта
      const { error: tasksError } = await supabase
        .from("project_tasks")
        .delete()
        .eq("sales_result_id", projectId);

      if (tasksError) {
        console.error("Error deleting project tasks:", tasksError);
        throw tasksError;
      }
      
      // 2. Удаляем ежемесячные платежи
      const { error: paymentsError } = await supabase
        .from("monthly_payments")
        .delete()
        .eq("sales_result_id", projectId);

      if (paymentsError) {
        console.error("Error deleting monthly payments:", paymentsError);
        throw paymentsError;
      }
      
      // 3. Удаляем аккаунты проектов
      const { error: accountsError } = await supabase
        .from("project_accounts")
        .delete()
        .eq("sales_result_id", projectId);

      if (accountsError) {
        console.error("Error deleting project accounts:", accountsError);
        throw accountsError;
      }
      
      // 4. Удаляем продления проекта
      const { error: extensionsError } = await supabase
        .from("sales_results")
        .delete()
        .eq("parent_project_id", projectId);

      if (extensionsError) {
        console.error("Error deleting project extensions:", extensionsError);
        throw extensionsError;
      }
      
      // 5. Наконец, удаляем сам проект
      const { error: projectError } = await supabase
        .from("sales_results")
        .delete()
        .eq("id", projectId);

      if (projectError) {
        console.error("Error deleting project:", projectError);
        throw projectError;
      }

      // Обновляем локальное состояние
      setProjects(prevProjects => 
        prevProjects.filter(project => project.id !== projectId)
      );

      toast({
        title: "Успешно",
        description: "Проект и все связанные данные удалены",
      });

    } catch (error) {
      console.error("Error deleting project:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить проект",
        variant: "destructive",
      });
    }
  };

  const getStatusVariant = (status: string | null) => {
    switch (status) {
      case "Работаем":
        return "default";
      case "Завершили работу":
      case "Закончили":
        return "outline";
      case "Еще не начали":
        return "secondary";
      case "Пауза":
        return "secondary";
      case "Не указан":
      default:
        return "secondary";
    }
  };

  const formatWorkFormat = (formats: string[] | null) => {
    if (!formats || formats.length === 0) return "Не указано";
    return formats.join(", ");
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU");
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("ru-RU").format(amount) + " ₸";
  };

  // Функция сортировки проектов по статусу (всегда "Не указан" вверху)
  const sortProjectsByStatus = (projects: ProjectData[]) => {
    const statusOrder = {
      "Не указан": 0,
      "Работаем": 1,
      "Пауза": 2,
      "Завершили работу": 3,
      "Закончили": 3
    };

    return [...projects].sort((a, b) => {
      const statusA = a.project_status || "Не указан";
      const statusB = b.project_status || "Не указан";
      return (statusOrder[statusA as keyof typeof statusOrder] || 99) - 
             (statusOrder[statusB as keyof typeof statusOrder] || 99);
    });
  };

  // Функция фильтрации проектов
  const filterProjects = (projects: ProjectData[]) => {
    let filtered = projects;

    if (statusFilter !== "all") {
      filtered = filtered.filter(project => 
        (project.project_status || "Не указан") === statusFilter
      );
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter(project => 
        (project.project_type || "Не указан") === typeFilter
      );
    }

    return filtered;
  };

  // Функция получения цвета фона строки по статусу
  const getRowBackgroundClass = (status: string | null) => {
    switch (status) {
      case "Работаем":
        return "bg-green-50 hover:bg-green-100 dark:bg-green-950/30 dark:hover:bg-green-950/50";
      case "Завершили работу":
      case "Закончили":
        return "bg-gray-50 hover:bg-gray-100 dark:bg-gray-900/30 dark:hover:bg-gray-900/50";
      case "Еще не начали":
        return "bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/30 dark:hover:bg-blue-950/50";
      case "Пауза":
        return "bg-orange-50 hover:bg-orange-100 dark:bg-orange-950/30 dark:hover:bg-orange-950/50";
      case "Не указан":
      default:
        return "bg-yellow-50 hover:bg-yellow-100 dark:bg-yellow-950/30 dark:hover:bg-yellow-950/50";
    }
  };

  // Получаем уникальные типы проектов для фильтра
  const uniqueProjectTypes = Array.from(new Set(
    projects.map(p => p.project_type || "Не указан")
  )).sort();

  // Применяем фильтрацию и сортировку
  const filteredAndSortedProjects = sortProjectsByStatus(filterProjects(projects));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Briefcase className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Управление проектами</h2>
      </div>

      <Tabs defaultValue="projects" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="projects" className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            Основные проекты
            <Badge variant="secondary" className="ml-2">
              {filteredAndSortedProjects.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="extensions" className="flex items-center gap-2">
            <ArrowRight className="h-4 w-4" />
            Продления
          </TabsTrigger>
        </TabsList>

        <TabsContent value="projects" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Все проекты компании
                {/* Кнопка добавления продажи для руководителей тех отдела */}
                {currentUserRole === "руководитель тех отдела" && (
                  <Button
                    onClick={() => setIsAddSaleDialogOpen(true)}
                    className="ml-auto"
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Добавить продажу
                  </Button>
                )}
              </CardTitle>
              
              {/* Фильтры */}
              <div className="flex gap-4 mt-4">
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">Статус проекта</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Все статусы" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все статусы</SelectItem>
                      <SelectItem value="Не указан">Не указан</SelectItem>
                      <SelectItem value="Работаем">Работаем</SelectItem>
                      <SelectItem value="Завершили работу">Завершили работу</SelectItem>
                      <SelectItem value="Пауза">Пауза</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">Тип проекта</label>
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Все типы" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все типы</SelectItem>
                      {uniqueProjectTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Название проекта</TableHead>
                      <TableHead>Имя клиента</TableHead>
                      <TableHead>Менеджер</TableHead>
                      <TableHead>Тип проекта</TableHead>
                      <TableHead>Формат работы</TableHead>
                      <TableHead>Статус проекта</TableHead>
                      <TableHead>Дата продажи</TableHead>
                      <TableHead>Сумма</TableHead>
                      <TableHead>Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAndSortedProjects.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                          Проекты не найдены
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredAndSortedProjects.map((project) => (
                        <TableRow key={project.id} className={getRowBackgroundClass(project.project_status)}>
                          <TableCell className="font-medium">
                            {project.project_name || "Без названия"}
                          </TableCell>
                          <TableCell>
                            {project.client_name || "Не указан"}
                          </TableCell>
                          <TableCell>
                            {project.manager_name}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {project.project_type || "Не указан"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <span className="text-sm">
                              {formatWorkFormat(project.work_format)}
                            </span>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={project.project_status || "Не указан"}
                              onValueChange={(newStatus) => updateProjectStatus(project.id, newStatus as ProjectStatus)}
                              disabled={updatingProjectId === project.id}
                            >
                              <SelectTrigger className="w-40">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-popover border shadow-md z-50">
                                <SelectItem value="Не указан">Не указан</SelectItem>
                                <SelectItem value="Работаем">Работаем</SelectItem>
                                <SelectItem value="Завершили работу">Завершили работу</SelectItem>
                                <SelectItem value="Пауза">Пауза</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            {formatDate(project.sale_date)}
                          </TableCell>
                          <TableCell className="font-medium">
                            {formatAmount(project.sale_amount)}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {project.tasks_generated ? (
                                <>
                                  <div className="text-sm text-muted-foreground px-3 py-2">
                                    {project.actual_tasks_count && project.actual_tasks_count > 0 
                                      ? `Задачи: ${project.actual_tasks_count}`
                                      : "Задачи удалены"}
                                  </div>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedProjectForTasks(project);
                                      setIsProjectTasksDialogOpen(true);
                                    }}
                                    className="hover-scale"
                                    title="Задачи проекта"
                                  >
                                    <ListTodo className="h-4 w-4" />
                                  </Button>
                                  {/* Кнопка "Сгенерировать задачи заново" для проектов с удаленными задачами */}
                                  {(!project.actual_tasks_count || project.actual_tasks_count === 0) && (
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => regenerateTasks(project.id)}
                                      className="hover-scale text-blue-600 hover:text-blue-700"
                                      title="Сгенерировать задачи заново"
                                    >
                                      <RotateCcw className="h-4 w-4" />
                                    </Button>
                                  )}
                                </>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedProject(project);
                                    setIsAssignmentDialogOpen(true);
                                  }}
                                  className="hover-scale"
                                  title="Назначить исполнителей"
                                >
                                  <Users className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedProjectForChange(project);
                                  setIsChangeResponsibleDialogOpen(true);
                                }}
                                className="hover-scale"
                                title="Сменить ответственного"
                              >
                                <UserCheck className="h-4 w-4" />
                              </Button>
                              
                              {/* Кнопка редактирования продажи для руководителей тех отдела */}
                              {currentUserRole === "руководитель тех отдела" && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedProjectForEdit(project);
                                    setIsEditSaleDialogOpen(true);
                                  }}
                                  className="hover-scale"
                                  title="Редактировать продажу"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                              )}
                              
                              {/* Extend button - show for active or completed projects */}
                              {(project.project_status === "Работаем" || project.project_status === "Завершили работу") && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedProjectForExtension(project);
                                    setIsExtensionDialogOpen(true);
                                  }}
                                  className="hover-scale"
                                  title="Продлить проект"
                                >
                                  <RefreshCw className="h-4 w-4" />
                                </Button>
                              )}

                              {/* Start button - show for paused projects */}
                              {project.project_status === "Пауза" && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedProjectForStart(project);
                                    setIsStartDialogOpen(true);
                                  }}
                                  className="hover-scale"
                                  title="Запустить проект"
                                >
                                  <PlayCircle className="h-4 w-4" />
                                </Button>
                              )}
                              
                              {/* Delete button - show for tech department heads */}
                              {currentUserRole === "руководитель тех отдела" && (
                                <Button
                                  variant="outline"
                                  size="sm"  
                                  onClick={() => deleteProject(project.id, project.project_name || "")}
                                  className="hover-scale text-red-600 hover:text-red-700 border-red-200 hover:border-red-300"
                                  title="Удалить проект"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="extensions">
          <ProjectExtensionsPage />
        </TabsContent>
      </Tabs>

      <ProjectAssignmentDialog
        isOpen={isAssignmentDialogOpen}
        onClose={() => {
          setIsAssignmentDialogOpen(false);
          setSelectedProject(null);
        }}
        project={selectedProject}
        onSuccess={() => {
          fetchProjects();
        }}
      />

      <ChangeResponsibleDialog
        isOpen={isChangeResponsibleDialogOpen}
        onClose={() => {
          setIsChangeResponsibleDialogOpen(false);
          setSelectedProjectForChange(null);
        }}
        project={selectedProjectForChange}
        onSuccess={() => {
          fetchProjects();
        }}
      />

      <ProjectTasksDialog
        isOpen={isProjectTasksDialogOpen}
        onOpenChange={(open) => {
          setIsProjectTasksDialogOpen(open);
          if (!open) {
            setSelectedProjectForTasks(null);
          }
        }}
        projectId={selectedProjectForTasks?.id || ""}
        projectName={selectedProjectForTasks?.project_name || ""}
      />

      <ProjectExtensionDialog
        isOpen={isExtensionDialogOpen}
        onClose={() => {
          setIsExtensionDialogOpen(false);
          setSelectedProjectForExtension(null);
        }}
        project={selectedProjectForExtension}
        onExtensionCreated={() => {
          fetchProjects();
        }}
      />

      <ProjectStartDialog
        open={isStartDialogOpen}
        onOpenChange={(open) => {
          setIsStartDialogOpen(open);
          if (!open) {
            setSelectedProjectForStart(null);
          }
        }}
        project={selectedProjectForStart}
        employees={employees}
        onSuccess={() => {
          fetchProjects();
        }}
      />

      <EditSaleDialog
        isOpen={isEditSaleDialogOpen}
        onClose={() => {
          setIsEditSaleDialogOpen(false);
          setSelectedProjectForEdit(null);
        }}
        projectId={selectedProjectForEdit?.id || ""}
        onSaleUpdated={() => {
          console.log('🔄 Перезагружаем проекты после обновления продажи');
          fetchProjects();
        }}
      />

      <AddSaleDialog
        isOpen={isAddSaleDialogOpen}
        onClose={() => {
          setIsAddSaleDialogOpen(false);
        }}
        onSaleAdded={() => {
          fetchProjects();
        }}
      />
    </div>
  );
};
