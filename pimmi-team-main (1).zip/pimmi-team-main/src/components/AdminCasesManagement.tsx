import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useOrg } from "@/contexts/OrgContext";
import { withOrg, scopeToOrg } from "@/integrations/supabase/org";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  Upload, 
  X,
  FileImage,
  Settings,
  CheckCircle
} from "lucide-react";

interface ProjectCase {
  id: string;
  project_name: string;
  category: string;
  services: string[];
  point_a_description: string | null;
  our_work_description: string | null;
  point_b_description: string | null;
  result_screenshots: string[] | null;
  instagram_url?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface Category {
  id: string;
  name: string;
  created_at: string;
}

const SERVICES = [
  'Инста таргет',
  'Тикток таргет',
  'Дожим чатбот',
  'ИИ чатбот',
  'Сайт',
  'Видео',
  'СРМ'
];

export const AdminCasesManagement = () => {
  const [cases, setCases] = useState<ProjectCase[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCase, setEditingCase] = useState<ProjectCase | null>(null);
  const [formData, setFormData] = useState({
    project_name: '',
    category: '',
    services: [] as string[],
    point_a_description: '',
    our_work_description: '',
    point_b_description: '',
    instagram_url: '',
    is_active: true
  });
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const [categoryAction, setCategoryAction] = useState<'add' | 'edit' | 'delete'>('add');
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const { toast } = useToast();
  const { currentOrgId } = useOrg();

  useEffect(() => {
    fetchCases();
    fetchCategories();
  }, []);

  const fetchCases = async () => {
    try {
      setLoading(true);
      const { data, error } = await scopeToOrg(
        supabase
          .from('project_cases')
          .select('*')
          .order('created_at', { ascending: false }),
        currentOrgId
      );

      if (error) throw error;
      setCases(data || []);
    } catch (error) {
      console.error('Ошибка загрузки кейсов:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить кейсы",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await scopeToOrg(
        supabase
          .from('project_categories')
          .select('*')
          .order('name'),
        currentOrgId
      );

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleCategoryAction = async () => {
    try {
      if (categoryAction === 'add' && newCategoryName.trim()) {
        const { error } = await supabase
          .from('project_categories')
          .insert(withOrg({ name: newCategoryName.trim() } as any, currentOrgId));
        if (error) throw error;
        toast({ title: "Успешно!", description: "Категория добавлена" });
      } else if (categoryAction === 'edit' && editingCategory && newCategoryName.trim()) {
        const { error } = await supabase
          .from('project_categories')
          .update({ name: newCategoryName.trim() })
          .eq('id', editingCategory.id);
        if (error) throw error;
        toast({ title: "Успешно!", description: "Категория обновлена" });
      } else if (categoryAction === 'delete' && editingCategory) {
        const { error } = await supabase
          .from('project_categories')
          .delete()
          .eq('id', editingCategory.id);
        if (error) throw error;
        toast({ title: "Успешно!", description: "Категория удалена" });
      }
      
      fetchCategories();
      setShowCategoryDialog(false);
      setNewCategoryName('');
      setEditingCategory(null);
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось выполнить операцию",
        variant: "destructive",
      });
    }
  };

  const openCreateDialog = () => {
    setEditingCase(null);
    setFormData({
      project_name: '',
      category: '',
      services: [],
      point_a_description: '',
      our_work_description: '',
      point_b_description: '',
      instagram_url: '',
      is_active: true
    });
    setUploadedFiles([]);
    setIsDialogOpen(true);
  };

  const openEditDialog = (projectCase: ProjectCase) => {
    setEditingCase(projectCase);
    setFormData({
      project_name: projectCase.project_name,
      category: projectCase.category,
      services: projectCase.services,
      point_a_description: projectCase.point_a_description || '',
      our_work_description: projectCase.our_work_description || '',
      point_b_description: projectCase.point_b_description || '',
      instagram_url: projectCase.instagram_url || '',
      is_active: projectCase.is_active
    });
    setUploadedFiles([]);
    setIsDialogOpen(true);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length !== files.length) {
      toast({
        title: "Внимание",
        description: "Загружены только изображения",
        variant: "destructive"
      });
    }
    
    setUploadedFiles(prev => [...prev, ...imageFiles]);
  };

  const handlePaste = async (event: React.ClipboardEvent) => {
    const items = event.clipboardData.items;
    const imageFiles: File[] = [];
    
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.indexOf('image') !== -1) {
        const file = item.getAsFile();
        if (file) {
          // Создаем новый файл с понятным именем
          const timestamp = new Date().toLocaleString('ru-RU').replace(/[^\d]/g, '');
          const newFile = new File([file], `screenshot_${timestamp}.png`, { type: file.type });
          imageFiles.push(newFile);
        }
      }
    }
    
    if (imageFiles.length > 0) {
      setUploadedFiles(prev => [...prev, ...imageFiles]);
      toast({
        title: "Успешно",
        description: `Добавлено ${imageFiles.length} изображений из буфера обмена`
      });
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadImagesToStorage = async (files: File[]): Promise<string[]> => {
    const paths: string[] = [];
    
    for (const file of files) {
      const fileName = `${Date.now()}-${file.name}`;
      const storagePath = `cases/${fileName}`;
      const { error } = await supabase.storage
        .from('task-attachments')
        .upload(storagePath, file);

      if (error) {
        console.error('Ошибка загрузки файла:', error);
        continue;
      }

      // Store storage paths, we'll generate signed URLs when displaying
      paths.push(storagePath);
    }
    
    return paths;
  };

  const handleSubmit = async () => {
    if (!formData.project_name.trim() || !formData.category) {
      toast({
        title: "Ошибка",
        description: "Заполните обязательные поля",
        variant: "destructive"
      });
      return;
    }

    try {
      let resultScreenshots: string[] = [];
      
      if (uploadedFiles.length > 0) {
        resultScreenshots = await uploadImagesToStorage(uploadedFiles);
      }

      const caseData = {
        project_name: formData.project_name,
        category: formData.category,
        services: formData.services,
        point_a_description: formData.point_a_description || null,
        our_work_description: formData.our_work_description || null,
        point_b_description: formData.point_b_description || null,
        instagram_url: formData.instagram_url || null,
        result_screenshots: resultScreenshots.length > 0 ? resultScreenshots : null,
        is_active: formData.is_active
      };

      if (editingCase) {
        // Обновляем существующий кейс
        const existingScreenshots = editingCase.result_screenshots || [];
        const updatedScreenshots = [...existingScreenshots, ...resultScreenshots];
        
        const { error } = await supabase
          .from('project_cases')
          .update({
            ...caseData,
            result_screenshots: updatedScreenshots.length > 0 ? updatedScreenshots : null
          })
          .eq('id', editingCase.id);

        if (error) throw error;
        
        toast({
          title: "Успешно",
          description: "Кейс обновлен"
        });
      } else {
        // Создаем новый кейс
        const { error } = await supabase
          .from('project_cases')
          .insert([withOrg(caseData as any, currentOrgId)]);

        if (error) throw error;
        
        toast({
          title: "Успешно",
          description: "Кейс создан"
        });
      }

      setIsDialogOpen(false);
      fetchCases();
    } catch (error) {
      console.error('Ошибка сохранения кейса:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить кейс",
        variant: "destructive"
      });
    }
  };

  const toggleCaseStatus = async (caseId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('project_cases')
        .update({ is_active: isActive })
        .eq('id', caseId);

      if (error) throw error;
      
      toast({
        title: "Успешно",
        description: `Кейс ${isActive ? 'активирован' : 'деактивирован'}`
      });
      
      fetchCases();
    } catch (error) {
      console.error('Ошибка обновления статуса:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус кейса",
        variant: "destructive"
      });
    }
  };

  const deleteCase = async (caseId: string) => {
    if (!confirm('Вы уверены, что хотите удалить этот кейс?')) return;

    try {
      const { error } = await supabase
        .from('project_cases')
        .delete()
        .eq('id', caseId);

      if (error) throw error;
      
      toast({
        title: "Успешно",
        description: "Кейс удален"
      });
      
      fetchCases();
    } catch (error) {
      console.error('Ошибка удаления кейса:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить кейс",
        variant: "destructive"
      });
    }
  };

  const handleServiceToggle = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Settings className="h-8 w-8 text-primary" />
            Управление кейсами
          </h2>
          <p className="text-muted-foreground mt-1">
            Создание и редактирование портфолио проектов
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog} className="bg-gradient-primary hover:bg-gradient-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Добавить кейс
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingCase ? 'Редактировать кейс' : 'Добавить новый кейс'}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="project_name">Название проекта *</Label>
                  <Input
                    id="project_name"
                    value={formData.project_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, project_name: e.target.value }))}
                    placeholder="Название проекта"
                  />
                </div>
                
                <div>
                  <Label htmlFor="category">Категория *</Label>
                  <Select 
                    value={formData.category} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите категорию" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category.id} value={category.name}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>Услуги</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {SERVICES.map(service => (
                    <div key={service} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={service}
                        checked={formData.services.includes(service)}
                        onChange={() => handleServiceToggle(service)}
                        className="rounded"
                      />
                      <Label htmlFor={service} className="text-sm">{service}</Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <Label htmlFor="point_a">Описание исходной ситуации</Label>
                <Textarea
                  id="point_a"
                  value={formData.point_a_description}
                  onChange={(e) => setFormData(prev => ({ ...prev, point_a_description: e.target.value }))}
                  placeholder="Какая была ситуация до начала проекта..."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="our_work">Описание нашей работы</Label>
                <Textarea
                  id="our_work"
                  value={formData.our_work_description}
                  onChange={(e) => setFormData(prev => ({ ...prev, our_work_description: e.target.value }))}
                  placeholder="Что мы делали в рамках проекта..."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="point_b">Результат проекта</Label>
                <Textarea
                  id="point_b"
                  value={formData.point_b_description}
                  onChange={(e) => setFormData(prev => ({ ...prev, point_b_description: e.target.value }))}
                  placeholder="Какие результаты были достигнуты..."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="instagram_url">Instagram аккаунт</Label>
                <Input
                  id="instagram_url"
                  type="url"
                  value={formData.instagram_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, instagram_url: e.target.value }))}
                  placeholder="Ссылка на Instagram проекта"
                />
              </div>
              
              <div>
                <Label htmlFor="screenshots">Скриншоты результатов</Label>
                <div className="mt-2">
                  <input
                    type="file"
                    id="screenshots"
                    multiple
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <div className="space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('screenshots')?.click()}
                      className="w-full"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Загрузить файлы
                    </Button>
                  </div>
                  
                  {uploadedFiles.length > 0 && (
                    <div className="mt-2 space-y-2">
                      {uploadedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between bg-muted p-2 rounded">
                          <div className="flex items-center gap-2">
                            <FileImage className="h-4 w-4" />
                            <span className="text-sm">{file.name}</span>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
                />
                <Label htmlFor="is_active">Активный кейс</Label>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Отмена
                </Button>
                <Button onClick={handleSubmit} className="bg-gradient-primary">
                  {editingCase ? 'Обновить' : 'Создать'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Categories Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Управление категориями ({categories.length} категорий)
            </div>
            <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
              <DialogTrigger asChild>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => {
                    setCategoryAction('add');
                    setNewCategoryName('');
                    setEditingCategory(null);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить категорию
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {categoryAction === 'add' && 'Добавить категорию'}
                    {categoryAction === 'edit' && 'Редактировать категорию'}
                    {categoryAction === 'delete' && 'Удалить категорию'}
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {categoryAction !== 'delete' && (
                    <div>
                      <Label htmlFor="category-name">Название категории</Label>
                      <Input
                        id="category-name"
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        placeholder="Введите название категории"
                      />
                    </div>
                  )}
                  {categoryAction === 'delete' && editingCategory && (
                    <p>Вы уверены, что хотите удалить категорию "{editingCategory.name}"?</p>
                  )}
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowCategoryDialog(false)}>
                      Отмена
                    </Button>
                    <Button onClick={handleCategoryAction}>
                      {categoryAction === 'add' && 'Добавить'}
                      {categoryAction === 'edit' && 'Сохранить'}
                      {categoryAction === 'delete' && 'Удалить'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {categories.length > 0 ? (
              categories.map((category) => (
                <div key={category.id} className="flex items-center gap-1 bg-muted/50 rounded-lg px-3 py-1">
                  <span className="text-sm">{category.name}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-5 w-5 p-0"
                    onClick={() => {
                      setCategoryAction('edit');
                      setEditingCategory(category);
                      setNewCategoryName(category.name);
                      setShowCategoryDialog(true);
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-5 w-5 p-0 text-destructive"
                    onClick={() => {
                      setCategoryAction('delete');
                      setEditingCategory(category);
                      setShowCategoryDialog(true);
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">Категории не созданы</p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Список кейсов ({cases.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Загрузка...</div>
          ) : cases.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Кейсы не найдены. Создайте первый кейс.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Проект</TableHead>
                  <TableHead>Категория</TableHead>
                  <TableHead>Услуги</TableHead>
                  <TableHead>Фото</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Дата создания</TableHead>
                  <TableHead>Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cases.map((projectCase) => (
                  <TableRow key={projectCase.id}>
                    <TableCell className="font-medium">
                      {projectCase.project_name}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{projectCase.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {projectCase.services.slice(0, 2).map((service, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                        {projectCase.services.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{projectCase.services.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {projectCase.result_screenshots && 
                         projectCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '').length > 0 ? (
                          <>
                            <div className="flex -space-x-2">
                              {projectCase.result_screenshots
                                .filter(screenshot => screenshot && screenshot.trim() !== '')
                                .slice(0, 3)
                                .map((screenshot, index) => (
                                <img
                                  key={index}
                                  src={screenshot}
                                  alt={`Preview ${index + 1}`}
                                  className="w-8 h-8 rounded border-2 border-background object-cover"
                                />
                              ))}
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {projectCase.result_screenshots.filter(screenshot => screenshot && screenshot.trim() !== '').length} фото
                            </span>
                          </>
                        ) : (
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <FileImage className="h-4 w-4" />
                            <span className="text-xs">Нет фото</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={projectCase.is_active}
                          onCheckedChange={(checked) => toggleCaseStatus(projectCase.id, checked)}
                        />
                        <span className="text-sm">
                          {projectCase.is_active ? 'Активен' : 'Неактивен'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {new Date(projectCase.created_at).toLocaleDateString('ru-RU')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openEditDialog(projectCase)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteCase(projectCase.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};