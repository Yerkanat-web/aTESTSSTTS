import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format, isEqual, startOfDay, isWithinInterval } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { formatTime } from "@/utils/timeHelpers";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell, LabelList } from 'recharts';
import { 
  Users, 
  Clock, 
  TrendingUp, 
  Target, 
  Trophy, 
  Zap,
  BarChart3,
  CalendarIcon,
  Filter,
  Eye,
  Star,
  Award,
  AlertTriangle,
  Activity,
  Heart,
  X
} from "lucide-react";
import { useAllEmployeeStats } from "@/hooks/useEmployeeStats";
import { useAllEmployeePoints } from "@/hooks/useEmployeePoints";
import { supabase } from "@/integrations/supabase/client";

interface Employee {
  id: string;
  name: string;
  role: string;
  totalMinutes: number;
  totalTasks: number;
  points: number;
  efficiency: number;
  burnoutRisk: 'low' | 'medium' | 'high';
  workDate: string; // Дата для фильтрации
  weeklyData: Array<{ day: string; hours: number; date: string }>;
  categories: Array<{ name: string; hours: number; percentage: number }>;
  status: 'active' | 'inactive';
}

interface AdminDashboardProps {
  onEmployeeClick: (employee: Employee) => void;
  user: {
    name: string;
    role: 'admin' | 'employee' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
    department?: string;
    employeeId?: string;
  };
}

export const AdminDashboard = ({ onEmployeeClick, user }: AdminDashboardProps) => {
  const [dateFrom, setDateFrom] = useState<Date | undefined>();
  const [dateTo, setDateTo] = useState<Date | undefined>();
  const [workTimeData, setWorkTimeData] = useState<any[]>([]);
  const [taskCategoriesData, setTaskCategoriesData] = useState<any[]>([]);
  
  // Determine department filter based on user role
  const departmentFilter = (() => {
    if (user.role === 'руководитель тех отдела') {
      return 'тех отдел';
    } else if (user.role === 'руководитель ИИ отдела') {
      return 'креатив отдел';
    }
    return undefined; // Admin sees all
  })();
  
  // Use real data from database with department filtering
  const { stats: allEmployeeStats, loading: statsLoading } = useAllEmployeeStats(departmentFilter);
  const { pointsData: allPointsData, loading: pointsLoading } = useAllEmployeePoints();

  // Fetch work time logs and task categories
  useEffect(() => {
    const fetchWorkTimeData = async () => {
      try {
        const { data: workLogs, error: workError } = await supabase
          .from('work_time_logs')
          .select(`
            *,
            employees!fk_work_time_logs_employee(id, name, department)
          `)
          .gte('start_time', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

        if (workError) throw workError;

        const { data: tasks, error: tasksError } = await supabase
          .from('employee_tasks')
          .select(`
            employee_id,
            category,
            actual_minutes,
            created_at,
            completed_at,
            due_date,
            status,
            employees!fk_employee_tasks_employee(id, name, department)
          `)
          .not('actual_minutes', 'is', null);

        if (tasksError) throw tasksError;

        setWorkTimeData(workLogs || []);
        setTaskCategoriesData(tasks || []);
      } catch (error) {
        console.error('Error fetching work time data:', error);
      }
    };

    fetchWorkTimeData();
  }, []);

  // Filter employees based on user role
  const filteredEmployeeStats = useMemo(() => {
    // For department managers, use already filtered data from useAllEmployeeStats
    if (user.role === 'руководитель тех отдела' || user.role === 'руководитель ИИ отдела') {
      return allEmployeeStats; // Already filtered by departmentFilter
    }
    
    // For admins, exclude sales department only
    return allEmployeeStats.filter(emp => 
      emp.department?.toLowerCase() !== 'отдел продаж'
    );
  }, [allEmployeeStats, user.role]);

  // Calculate team stats from filtered data (excluding sales department)
  const teamStats = useMemo(() => {
    if (!filteredEmployeeStats.length) {
      return {
        totalEmployees: 0,
        activeToday: 0,
        totalHours: 0,
        totalTasks: 0,
        averageEfficiency: 0,
        totalPoints: 0
      };
    }

    const filteredPointsData = allPointsData.filter(p => 
      filteredEmployeeStats.some(emp => emp.id === p.employee_id)
    );
    
    const totalPoints = filteredPointsData.reduce((sum, emp) => sum + emp.total_points, 0);
    const totalHours = filteredEmployeeStats.reduce((sum, emp) => sum + (emp.total_hours || 0), 0);
    const totalTasks = filteredEmployeeStats.reduce((sum, emp) => sum + (emp.total_tasks || 0), 0);
    const avgEfficiency = filteredEmployeeStats.reduce((sum, emp) => sum + (emp.efficiency || 0), 0) / filteredEmployeeStats.length;

    return {
      totalEmployees: filteredEmployeeStats.length,
      activeToday: filteredEmployeeStats.filter(emp => emp.status === 'active').length,
      totalHours: Math.round(totalHours * 10) / 10,
      totalTasks,
      averageEfficiency: Math.round(avgEfficiency),
      totalPoints
    };
  }, [filteredEmployeeStats, allPointsData]);

  // Convert filtered database stats to UI format (excluding sales department)
  const employees: Employee[] = useMemo(() => {
    console.log('🔍 Building employees data...', { 
      filteredEmployeeStats: filteredEmployeeStats.length, 
      allPointsData: allPointsData.length 
    });
    
    return filteredEmployeeStats.map((stat, index) => {
      // For department managers, get points from stat.total_points (already available)
      // For admins, try to get from allPointsData first, then fallback to stat.total_points
      const pointsRecord = allPointsData.find(p => p.employee_id === stat.id);
      const points = pointsRecord?.total_points || stat.total_points || 0;
      
      console.log(`👤 Employee ${stat.name}:`, {
        id: stat.id,
        points: points,
        pointsRecord: pointsRecord,
        department: stat.department
      });
      
      const totalMinutes = stat.total_minutes || 0;
      const totalTasks = stat.total_tasks || 0;
      const efficiency = stat.efficiency || 0;
      
      // Generate real weekly data and categories from completed tasks
      const employeeTasks = taskCategoriesData.filter(task => 
        task.employees?.id === stat.id
      );

      const weeklyData = Array.from({ length: 7 }, (_, i) => {
        const dayDate = new Date();
        dayDate.setDate(dayDate.getDate() - (6 - i));
        const dayName = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"][dayDate.getDay()];
        
        // Filter tasks by completion date (use created_at as proxy for completion date if completed_at not available)
        const dayTasks = employeeTasks.filter(task => {
          const taskDate = new Date(task.created_at);
          return taskDate.toDateString() === dayDate.toDateString() && task.actual_minutes > 0;
        });

        const totalMinutesForDay = dayTasks.reduce((sum, task) => sum + (task.actual_minutes || 0), 0);

        return {
          day: dayName,
          hours: Math.round((totalMinutesForDay / 60) * 10) / 10,
          date: dayDate.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })
        };
      });

      // Generate real categories from task data
      const categoryHours: { [key: string]: number } = {};
      employeeTasks.forEach(task => {
        const category = task.category || 'Общие';
        categoryHours[category] = (categoryHours[category] || 0) + (task.actual_minutes || 0);
      });

      const totalCategoryHours = Object.values(categoryHours).reduce((sum, hours) => sum + hours, 0);
      const categories = Object.entries(categoryHours).map(([name, hours]) => ({
        name,
        hours: Math.round(hours),
        percentage: totalCategoryHours > 0 ? Math.round((hours / totalCategoryHours) * 100) : 0
      }));

      // Determine burnout risk based on efficiency and hours
      let burnoutRisk: 'low' | 'medium' | 'high' = 'low';
      if (efficiency < 80 || totalMinutes > 2700) burnoutRisk = 'high'; // 45 hours = 2700 minutes
      else if (efficiency < 90 || totalMinutes > 2400) burnoutRisk = 'medium'; // 40 hours = 2400 minutes

      return {
        id: stat.id || '',
        name: stat.name || 'Unknown',
        role: stat.position || 'Employee',
        totalMinutes: totalMinutes,
        totalTasks: totalTasks,
        points: points,
        efficiency: efficiency,
        burnoutRisk,
        workDate: new Date().toISOString().split('T')[0], // Today's date - исправить фильтрацию
        status: (stat.status === 'active' ? 'active' : 'inactive') as 'active' | 'inactive',
        weeklyData: weeklyData,
        categories: categories
      };
    });
  }, [filteredEmployeeStats, allPointsData, taskCategoriesData]);

  // Apply date filter to employees based on task completion dates
  const filteredEmployees = useMemo(() => {
    if (!dateFrom && !dateTo) {
      return employees;
    }

    return employees.map(employee => {
      // Filter tasks by date range from taskCategoriesData
      const employeeTasks = taskCategoriesData.filter(task => 
        task.employees?.id === employee.id
      );

      let filteredTasks = employeeTasks;
      
      if (dateFrom || dateTo) {
        filteredTasks = employeeTasks.filter(task => {
          if (!task.completed_at && !task.due_date) return false;
          
          // Use completed_at if available, otherwise use due_date
          const taskDate = new Date(task.completed_at || task.due_date);
          
          if (dateFrom && dateTo) {
            return isWithinInterval(taskDate, { 
              start: startOfDay(dateFrom), 
              end: startOfDay(dateTo) 
            });
          } else if (dateFrom) {
            return taskDate >= startOfDay(dateFrom);
          } else if (dateTo) {
            return taskDate <= startOfDay(dateTo);
          }
          
          return true;
        });
      }

      // Recalculate stats based on filtered tasks
      const totalMinutes = filteredTasks.reduce((sum, task) => sum + (task.actual_minutes || 0), 0);
      const totalTasks = filteredTasks.length;

      // Recalculate categories
      const categoryHours: { [key: string]: number } = {};
      filteredTasks.forEach(task => {
        const category = task.category || 'Общие';
        categoryHours[category] = (categoryHours[category] || 0) + (task.actual_minutes || 0);
      });

      const totalCategoryHours = Object.values(categoryHours).reduce((sum, hours) => sum + hours, 0);
      const categories = Object.entries(categoryHours).map(([name, hours]) => ({
        name,
        hours: Math.round(hours),
        percentage: totalCategoryHours > 0 ? Math.round((hours / totalCategoryHours) * 100) : 0
      }));

      return {
        ...employee,
        totalMinutes,
        totalTasks,
        categories
      };
    });
  }, [employees, dateFrom, dateTo, taskCategoriesData]);

  // Calculate weekly team data based on filtered employees
  const weeklyTeamData = useMemo(() => {
    const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
    
    const calculateMedian = (values: number[]) => {
      const sorted = values.sort((a, b) => a - b);
      const mid = Math.floor(sorted.length / 2);
      return sorted.length % 2 !== 0 
        ? sorted[mid] 
        : (sorted[mid - 1] + sorted[mid]) / 2;
    };

    // Create weekly data based on actual task completion dates (due_date)
    const weekData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayKey = date.toDateString();
      const dayName = date.toLocaleDateString('ru-RU', { weekday: 'short' });
      
      // Get all team hours for this day from completed tasks
      const dayHours = filteredEmployees
        .filter(emp => emp.status === 'active')
        .map(emp => {
          // Get tasks for this employee from taskCategoriesData
          const employeeTasks = taskCategoriesData.filter(task => 
            task.employees?.id === emp.id
          );
          
          // Filter tasks completed on this specific day using due_date as completion date
          const dayTasks = employeeTasks.filter(task => {
            if (task.status !== 'completed' || !task.due_date) return false;
            const taskDate = new Date(task.due_date);
            return taskDate.toDateString() === dayKey && task.actual_minutes > 0;
          });
          
          return dayTasks.reduce((sum, task) => sum + (task.actual_minutes || 0), 0) / 60;
        })
        .filter(hours => hours > 0);

      const medianHours = dayHours.length > 0 ? calculateMedian(dayHours) : 0;
      
      weekData.push({
        day: dayName,
        hours: Math.round(medianHours * 10) / 10,
        displayValue: medianHours > 0 ? `${Math.round(medianHours * 10) / 10}ч` : '0ч'
      });
    }
    
    return weekData;
  }, [filteredEmployees, taskCategoriesData]);

  // Calculate top performers from original employee data (not date-filtered)
  const topPerformers = useMemo(() => {
    console.log('🏆 Calculating top performers...', { 
      totalEmployees: employees.length,
      employeesWithPoints: employees.filter(emp => emp.points > 0)
    });
    
    const activeEmployees = employees.filter(emp => emp.status === 'active');
    console.log('📊 Active employees with points:', activeEmployees.map(emp => ({
      name: emp.name,
      points: emp.points,
      status: emp.status
    })));
    
    const sorted = activeEmployees.sort((a, b) => {
      console.log(`🔄 Comparing ${a.name} (${a.points}) vs ${b.name} (${b.points})`);
      return b.points - a.points;
    });
    
    const top3 = sorted.slice(0, 3);
    console.log('🥇 Top 3 performers:', top3.map(emp => ({
      name: emp.name,
      points: emp.points
    })));
    
    return top3.map(emp => ({
      name: emp.name,
      points: emp.points,
      hours: Number((emp.totalMinutes / 60).toFixed(2)),
      efficiency: emp.efficiency
    }));
  }, [employees]);

  // Update team stats based on filtered employees
  const filteredTeamStats = useMemo(() => {
    if (!filteredEmployees.length) {
      return {
        totalEmployees: 0,
        activeToday: 0,
        totalHours: 0,
        totalTasks: 0,
        averageEfficiency: 0,
        totalPoints: 0
      };
    }

    const totalPoints = filteredEmployees.reduce((sum, emp) => sum + emp.points, 0);
    const totalMinutes = filteredEmployees.reduce((sum, emp) => sum + emp.totalMinutes, 0);
    const totalTasks = filteredEmployees.reduce((sum, emp) => sum + emp.totalTasks, 0);
    const avgEfficiency = filteredEmployees.reduce((sum, emp) => sum + emp.efficiency, 0) / filteredEmployees.length;

    return {
      totalEmployees: filteredEmployees.length,
      activeToday: filteredEmployees.filter(emp => emp.status === 'active').length,
      totalHours: Math.round((totalMinutes / 60) * 10) / 10,
      totalTasks,
      averageEfficiency: Math.round(avgEfficiency),
      totalPoints
    };
  }, [filteredEmployees]);


  const getBurnoutRiskColor = (risk: 'low' | 'medium' | 'high') => {
    switch (risk) {
      case 'low': return "bg-success/20 text-success border-success/30";
      case 'medium': return "bg-warning/20 text-warning border-warning/30";
      case 'high': return "bg-destructive/20 text-destructive border-destructive/30";
    }
  };

  const getBurnoutRiskIcon = (risk: 'low' | 'medium' | 'high') => {
    switch (risk) {
      case 'low': return <Heart className="h-4 w-4" />;
      case 'medium': return <Activity className="h-4 w-4" />;
      case 'high': return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency >= 90) return "text-success";
    if (efficiency >= 80) return "text-warning";
    return "text-destructive";
  };

  const getEfficiencyBadge = (efficiency: number) => {
    if (efficiency >= 90) return "bg-success/20 text-success border-success/30";
    if (efficiency >= 80) return "bg-warning/20 text-warning border-warning/30";
    return "bg-destructive/20 text-destructive border-destructive/30";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold">Панель руководителя</h2>
          <p className="text-muted-foreground mt-1">Статистика команды и управление сотрудниками</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Date From Filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "justify-start text-left font-normal",
                  !dateFrom && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateFrom ? (
                  format(dateFrom, "d MMM yyyy", { locale: ru })
                ) : (
                  <span>Дата от</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                mode="single"
                selected={dateFrom}
                onSelect={setDateFrom}
                disabled={(date) =>
                  date > new Date() || date < new Date("1900-01-01")
                }
                initialFocus
                className="pointer-events-auto"
              />
            </PopoverContent>
          </Popover>

          {/* Date To Filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "justify-start text-left font-normal",
                  !dateTo && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateTo ? (
                  format(dateTo, "d MMM yyyy", { locale: ru })
                ) : (
                  <span>Дата до</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                mode="single"
                selected={dateTo}
                onSelect={setDateTo}
                disabled={(date) =>
                  date > new Date() || date < new Date("1900-01-01") || 
                  (dateFrom && date < dateFrom)
                }
                initialFocus
                className="pointer-events-auto"
              />
            </PopoverContent>
          </Popover>

          {/* Clear Filters Button */}
          {(dateFrom || dateTo) && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setDateFrom(undefined);
                setDateTo(undefined);
              }}
            >
              <X className="h-4 w-4 mr-2" />
              Сбросить
            </Button>
          )}
        </div>
      </div>

      {/* Team Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <Card className="bg-gradient-to-br from-primary/10 to-blue/10 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Сотрудников</p>
                <p className="text-2xl font-bold">{filteredTeamStats.totalEmployees}</p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-success/10 to-green/10 border-success/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Активных сегодня</p>
                <p className="text-2xl font-bold">{filteredTeamStats.activeToday}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue/10 to-primary/10 border-blue/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Общие часы</p>
                <p className="text-2xl font-bold">{formatTime(filteredTeamStats.totalHours * 60)}</p>
              </div>
              <Clock className="h-8 w-8 text-blue" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-info/10 to-blue/10 border-info/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Всего задач</p>
                <p className="text-2xl font-bold">{filteredTeamStats.totalTasks}</p>
              </div>
              <Target className="h-8 w-8 text-info" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-warning/10 to-gold/10 border-warning/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Средняя эффект.</p>
                <p className="text-2xl font-bold">{filteredTeamStats.averageEfficiency}%</p>
              </div>
              <Trophy className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-gold border-warning/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gold-foreground/80">Общие баллы</p>
                <p className="text-2xl font-bold text-gold-foreground">{filteredTeamStats.totalPoints}</p>
              </div>
              <Zap className="h-8 w-8 text-gold-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Team Weekly Chart */}
        <Card className="shadow-card border border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Активность команды за неделю
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-2">
              <p className="text-sm text-muted-foreground">Медианное время работы по дням (часы)</p>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyTeamData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <XAxis 
                  dataKey="day" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <Bar 
                  dataKey="hours" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]}
                >
                  <LabelList 
                    dataKey="displayValue" 
                    position="top" 
                    style={{ 
                      fontSize: '12px', 
                      fill: 'hsl(var(--foreground))',
                      fontWeight: '500'
                    }} 
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Performers */}
        <Card className="shadow-card border border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-warning" />
              Топ исполнители
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {topPerformers.map((performer, index) => (
              <div 
                key={performer.name}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-primary text-primary-foreground text-sm font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium">{performer.name}</p>
                    <p className="text-xs text-muted-foreground">{performer.hours}ч • {performer.efficiency}%</p>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground">
                  {performer.points}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Employees List */}
      <Card className="shadow-card border border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Список сотрудников
            {(dateFrom || dateTo) && (
              <Badge variant="outline" className="ml-2">
                {filteredEmployees.length} из {employees.length}
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredEmployees.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                {(dateFrom || dateTo)
                  ? `Нет сотрудников, работавших в указанный период`
                  : "Сотрудники не найдены"
                }
              </p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => {
                  setDateFrom(undefined);
                  setDateTo(undefined);
                }}
              >
                Сбросить фильтр
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Сотрудник</TableHead>
                  <TableHead>Роль</TableHead>
                  <TableHead>Часы</TableHead>
                  <TableHead>Задачи</TableHead>
                  <TableHead>Эффективность</TableHead>
                  <TableHead>Риск выгорания</TableHead>
                  <TableHead>Баллы</TableHead>
                  <TableHead>Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmployees.map((employee) => (
                  <TableRow 
                    key={employee.id}
                    className={cn(
                      "cursor-pointer hover:bg-muted/50",
                      employee.status === 'inactive' ? "opacity-60" : ""
                    )}
                    onClick={() => onEmployeeClick(employee)}
                  >
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className={cn(
                          "w-3 h-3 rounded-full",
                          employee.status === 'active' ? "bg-success" : "bg-muted-foreground"
                        )} />
                        <div>
                          <p className="font-medium">{employee.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {employee.status === 'active' ? 'Активен' : 'Неактивен'}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <span className="text-sm">{employee.role}</span>
                    </TableCell>
                    
                    <TableCell>
                      <span className="font-medium">{formatTime(employee.totalMinutes)}</span>
                    </TableCell>
                    
                    <TableCell>
                      <span className="font-medium">{employee.totalTasks}</span>
                    </TableCell>
                    
                    <TableCell>
                      <Badge className={cn("text-xs", getEfficiencyBadge(employee.efficiency))}>
                        {employee.efficiency}%
                      </Badge>
                    </TableCell>
                    
                    <TableCell>
                      <Badge className={cn("text-xs flex items-center gap-1", getBurnoutRiskColor(employee.burnoutRisk))}>
                        {getBurnoutRiskIcon(employee.burnoutRisk)}
                        {employee.burnoutRisk === 'low' ? 'Низкий' : 
                         employee.burnoutRisk === 'medium' ? 'Средний' : 'Высокий'}
                      </Badge>
                    </TableCell>
                    
                    <TableCell>
                      <Badge variant="secondary" className="bg-gradient-gold text-gold-foreground text-xs">
                        {employee.points}
                      </Badge>
                    </TableCell>
                    
                    <TableCell>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};