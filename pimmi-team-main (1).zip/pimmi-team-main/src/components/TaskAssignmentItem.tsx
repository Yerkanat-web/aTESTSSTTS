import { User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Employee {
  id: string;
  name: string;
  position: string;
  department: string;
}

interface ProjectTask {
  id: string;
  task_name: string;
  task_type: string;
  assignee_id: string | null;
  assignee_name: string | null;
  status: string | null;
}

interface TaskAssignmentItemProps {
  task: ProjectTask;
  employees: Employee[];
  currentAssigneeId: string;
  onAssignmentChange: (taskId: string, assigneeId: string) => void;
}

export const TaskAssignmentItem = ({ 
  task, 
  employees, 
  currentAssigneeId, 
  onAssignmentChange 
}: TaskAssignmentItemProps) => {
  return (
    <div className="p-3 border rounded-lg space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4" />
          <span className="font-medium">{task.task_name}</span>
        </div>
        <Badge variant="secondary" className="text-xs">
          {task.task_type}
        </Badge>
      </div>
      
      <div className="space-y-2">
        <Label className="text-xs text-muted-foreground">
          Текущий исполнитель: {task.assignee_name || "Не назначен"}
        </Label>
        
        <Select 
          value={currentAssigneeId || ""} 
          onValueChange={(value) => onAssignmentChange(task.id, value)}
        >
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Выберите исполнителя" />
          </SelectTrigger>
          <SelectContent className="bg-popover border shadow-md z-50">
            {employees.length === 0 ? (
              <div className="p-2 text-sm text-muted-foreground">
                Нет подходящих сотрудников
              </div>
            ) : (
              employees.filter(employee => employee.id && employee.id.trim() !== '').map((employee) => (
                <SelectItem key={employee.id} value={employee.id}>
                  <div className="flex flex-col">
                    <span>{employee.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {employee.position} • {employee.department}
                    </span>
                  </div>
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};