import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, Edit, Loader2, Briefcase, Users, Settings, Search, UserCheck, ListTodo } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { AdminProjectsPage } from "./AdminProjectsPage";
import { ProjectAssignmentDialog } from "./ProjectAssignmentDialog";
import { ChangeResponsibleDialog } from "./ChangeResponsibleDialog";
import { ProjectTasksDialog } from "./ProjectTasksDialog";
import { Database } from "@/integrations/supabase/types";

type ProjectStatus = Database["public"]["Enums"]["project_status_enum"];

interface ProjectTask {
  id: string;
  task_name: string;
  task_type: string;
  status: string | null;
  due_date: string | null;
  assignee_name: string;
  client_name: string | null;
  project_name: string | null;
  created_at: string;
  assignee_id: string | null;
}

interface ProjectData {
  id: string;
  project_name: string | null;
  client_name: string | null;
  manager_name: string;
  employee_id: string;
  work_format: string[] | null;
  project_status: ProjectStatus | null;
  sale_date: string;
  sale_amount: number;
  client_type: string | null;
  project_type: string | null;
  tasks_generated: boolean | null;
}

export const ProjectManagementPage = () => {
  const [projectTasks, setProjectTasks] = useState<ProjectTask[]>([]);
  const [filteredTasks, setFilteredTasks] = useState<ProjectTask[]>([]);
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [loading, setLoading] = useState(true);
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  const [searchProject, setSearchProject] = useState("");
  const [searchClient, setSearchClient] = useState("");
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editingDate, setEditingDate] = useState<Date | undefined>(undefined);
  const [updatingTaskId, setUpdatingTaskId] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectData | null>(null);
  const [isAssignmentDialogOpen, setIsAssignmentDialogOpen] = useState(false);
  const [isChangeResponsibleDialogOpen, setIsChangeResponsibleDialogOpen] = useState(false);
  const [selectedProjectForChange, setSelectedProjectForChange] = useState<ProjectData | null>(null);
  const [updatingProjectId, setUpdatingProjectId] = useState<string | null>(null);
  const [employees, setEmployees] = useState<any[]>([]);
  const [isProjectTasksDialogOpen, setIsProjectTasksDialogOpen] = useState(false);
  const [selectedProjectForTasks, setSelectedProjectForTasks] = useState<ProjectData | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchCurrentUserRole();
  }, []);

  useEffect(() => {
    if (currentUserRole) {
      console.log("Current user role:", currentUserRole);
      if (currentUserRole === 'admin' || currentUserRole === 'руководитель отдела продаж') {
        // Для админа и руководителя продаж показываем компонент проектов продаж
        setLoading(false);
      } else if (currentUserRole === 'руководитель тех отдела' || currentUserRole === 'руководитель ИИ отдела') {
        // Руководители тех и ИИ отделов видят проекты И задачи, загружаем всё
        fetchProjects();
        fetchProjectTasks();
        fetchEmployees();
      } else {
        // Для остальных руководителей показываем проектные задачи (полагаемся на RLS)
        fetchProjectTasks();
      }
    }
  }, [currentUserRole]);

  // Эффект для фильтрации и сортировки задач
  useEffect(() => {
    let filtered = projectTasks.filter(task => {
      const matchesProject = !searchProject || 
        task.project_name?.toLowerCase().includes(searchProject.toLowerCase());
      const matchesClient = !searchClient || 
        task.client_name?.toLowerCase().includes(searchClient.toLowerCase());
      return matchesProject && matchesClient;
    });

    // Сортировка по дедлайну - ближайшие сверху, потом задачи без дедлайна
    filtered.sort((a, b) => {
      if (!a.due_date && !b.due_date) return 0;
      if (!a.due_date) return 1; // задачи без дедлайна в конец
      if (!b.due_date) return -1; // задачи без дедлайна в конец
      
      const dateA = new Date(a.due_date);
      const dateB = new Date(b.due_date);
      return dateA.getTime() - dateB.getTime(); // ближайшие даты сверху
    });

    setFilteredTasks(filtered);
  }, [projectTasks, searchProject, searchClient]);

  const fetchCurrentUserRole = async () => {
    try {
      const { data: currentUser } = await supabase.auth.getUser();
      if (!currentUser.user) return;

      const { data: employee, error } = await supabase
        .from("employees")
        .select("role, department")
        .eq("user_id", currentUser.user.id)
        .single();

      if (error) {
        console.error("Error fetching user role:", error);
        return;
      }

      console.log("Employee data:", employee);
      setCurrentUserRole(employee?.role || null);
    } catch (error) {
      console.error("Error fetching current user role:", error);
    }
  };

  const fetchProjects = async () => {
    try {
      setProjectsLoading(true);
      console.log("Fetching projects from sales_results...");
      
      // Получаем все проекты отдела продаж
      const { data: salesEmployees, error: employeesError } = await supabase
        .from("employees")
        .select("id, name")
        .eq("department", "отдел продаж");

      if (employeesError) {
        console.error("Error fetching sales employees:", employeesError);
        throw employeesError;
      }

      if (!salesEmployees || salesEmployees.length === 0) {
        console.log("No sales employees found");
        setProjects([]);
        return;
      }

      const salesEmployeeIds = salesEmployees.map(emp => emp.id);
      
      const { data, error } = await supabase
        .from("sales_results")
        .select(`
          id,
          project_name,
          client_name,
          work_format,
          project_status,
          sale_date,
          sale_amount,
          employee_id,
          client_type,
          project_type,
          tasks_generated,
          employees!fk_sales_results_employee(name)
        `)
        .in("employee_id", salesEmployeeIds)
        .order("sale_date", { ascending: false });

      if (error) {
        console.error("Error fetching sales results:", error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить проекты",
          variant: "destructive",
        });
        return;
      }

      const projectsData = data?.map((item: any) => ({
        id: item.id,
        project_name: item.project_name,
        client_name: item.client_name,
        manager_name: item.employees?.name || "Неизвестен",
        employee_id: item.employee_id,
        work_format: item.work_format,
        project_status: item.project_status,
        sale_date: item.sale_date,
        sale_amount: item.sale_amount,
        client_type: item.client_type,
        project_type: item.project_type,
        tasks_generated: item.tasks_generated,
      })) || [];

      setProjects(projectsData);
    } catch (error) {
      console.error("Error in fetchProjects:", error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при загрузке проектов",
        variant: "destructive",
      });
    } finally {
      setProjectsLoading(false);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from("employees")
        .select("id, name, department")
        .eq("status", "active")
        .order("name");

      if (error) {
        console.error("Error fetching employees:", error);
        return;
      }

      setEmployees(data || []);
    } catch (error) {
      console.error("Error in fetchEmployees:", error);
    }
  };

  const fetchProjectTasks = async () => {
    try {
      setLoading(true);
      console.log("Fetching project tasks for user role:", currentUserRole);
      
      // Простой запрос - полагаемся на RLS политики для фильтрации
      const { data, error } = await supabase
        .from("project_tasks")
        .select(`
          id,
          task_name,
          task_type,
          status,
          due_date,
          created_at,
          assignee_id,
          employees!project_tasks_assignee_id_fkey(name),
          sales_results(client_name, project_name)
        `)
        .not("assignee_id", "is", null)
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching project tasks:", error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить задачи проектов",
          variant: "destructive",
        });
        return;
      }

      console.log("Raw project tasks received:", data?.length || 0);
      console.log("Sample task data:", data?.[0]);

      const tasksData = data?.map((item: any) => ({
        id: item.id,
        task_name: item.task_name,
        task_type: item.task_type,
        status: item.status,
        due_date: item.due_date,
        assignee_name: item.employees?.name || "Не назначен",
        client_name: item.sales_results?.client_name || "Не указан",
        project_name: item.sales_results?.project_name || "Не указан",
        created_at: item.created_at,
        assignee_id: item.assignee_id,
      })) || [];

      console.log("Final tasks for display:", tasksData.length);
      setProjectTasks(tasksData);
    } catch (error) {
      console.error("Error in fetchProjectTasks:", error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при загрузке данных",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusVariant = (status: string | null) => {
    switch (status) {
      case "completed":
        return "default";
      case "in_progress":
        return "secondary";
      case "pending":
        return "outline";
      case "issues":
        return "destructive";
      case "postponed":
        return "secondary";
      default:
        return "outline";
    }
  };

  const getStatusText = (status: string | null) => {
    switch (status) {
      case "completed":
        return "Завершена";
      case "in_progress":
        return "В работе";
      case "pending":
        return "Ожидает";
      case "issues":
        return "Проблемы";
      case "postponed":
        return "Отложена";
      default:
        return "Ожидает";
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Не указан";
    return new Date(dateString).toLocaleDateString("ru-RU");
  };

  const updateTaskDeadline = async (taskId: string, newDate: Date | null) => {
    try {
      setUpdatingTaskId(taskId);
      
      const { error } = await supabase
        .from("project_tasks")
        .update({ 
          due_date: newDate ? newDate.toISOString().split('T')[0] : null 
        })
        .eq("id", taskId);

      if (error) {
        console.error("Error updating task deadline:", error);
        toast({
          title: "Ошибка",
          description: "Не удалось обновить дедлайн",
          variant: "destructive",
        });
        return;
      }

      // Обновляем локальное состояние
      setProjectTasks(prevTasks => 
        prevTasks.map(task => 
          task.id === taskId 
            ? { ...task, due_date: newDate ? newDate.toISOString().split('T')[0] : null }
            : task
        )
      );

      setEditingTaskId(null);
      setEditingDate(undefined);

      toast({
        title: "Успешно",
        description: "Дедлайн обновлен",
      });

    } catch (error) {
      console.error("Error updating task deadline:", error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при обновлении дедлайна",
        variant: "destructive",
      });
    } finally {
      setUpdatingTaskId(null);
    }
  };

  const updateProjectStatus = async (projectId: string, newStatus: ProjectStatus) => {
    setUpdatingProjectId(projectId);
    try {
      console.log(`Updating project ${projectId} status to: ${newStatus}`);
      
      // Если статус "Завершили работу", удаляем все незавершенные задачи
      if (newStatus === "Завершили работу") {
        const { error: deleteError } = await supabase
          .from("project_tasks")
          .delete()
          .eq("sales_result_id", projectId)
          .in("status", ["pending", "in_progress", "issues", "postponed"]);

        if (deleteError) {
          console.error("Error deleting tasks:", deleteError);
          throw deleteError;
        }
      }

      // Обновляем статус проекта
      const { error: updateError } = await supabase
        .from("sales_results")
        .update({ project_status: newStatus })
        .eq("id", projectId);

      if (updateError) {
        console.error("Error updating project status:", updateError);
        throw updateError;
      }
      
      // Обновляем локальное состояние
      setProjects(prevProjects => 
        prevProjects.map(project => 
          project.id === projectId 
            ? { ...project, project_status: newStatus }
            : project
        )
      );

      const statusMessage = newStatus === "Завершили работу" 
        ? "Проект завершен, незавершенные задачи удалены"
        : "Статус проекта обновлен";

      toast({
        title: "Успешно",
        description: statusMessage,
      });

    } catch (error) {
      console.error("Error updating project:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус проекта",
        variant: "destructive",
      });
    } finally {
      setUpdatingProjectId(null);
    }
  };

  const updateTaskAssignee = async (taskId: string, newAssigneeId: string) => {
    try {
      const { error } = await supabase
        .from("project_tasks")
        .update({ assignee_id: newAssigneeId })
        .eq("id", taskId);

      if (error) {
        console.error("Error updating task assignee:", error);
        toast({
          title: "Ошибка",
          description: "Не удалось обновить исполнителя",
          variant: "destructive",
        });
        return;
      }

      // Обновляем локальное состояние
      const assigneeName = employees.find(emp => emp.id === newAssigneeId)?.name || "Не назначен";
      setProjectTasks(prevTasks => 
        prevTasks.map(task => 
          task.id === taskId 
            ? { ...task, assignee_id: newAssigneeId, assignee_name: assigneeName }
            : task
        )
      );

      toast({
        title: "Успешно",
        description: "Исполнитель обновлен",
      });

    } catch (error) {
      console.error("Error updating task assignee:", error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при обновлении исполнителя",
        variant: "destructive",
      });
    }
  };

  const getProjectStatusVariant = (status: string | null) => {
    switch (status) {
      case "Работаем":
        return "default";
      case "Завершили работу":
      case "Закончили":
        return "outline";
      case "Еще не начали":
        return "secondary";
      case "Ждём остаток":
        return "destructive";
      case "Не указан":
      default:
        return "secondary";
    }
  };

  const formatWorkFormat = (formats: string[] | null) => {
    if (!formats || formats.length === 0) return "Не указано";
    return formats.join(", ");
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("ru-RU").format(amount) + " ₸";
  };

  // Если пользователь - админ, руководитель отдела продаж или тех отдела, показываем проекты
  if (currentUserRole === 'admin' || currentUserRole === 'руководитель отдела продаж' || currentUserRole === 'руководитель тех отдела') {
    return <AdminProjectsPage />;
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Специальный интерфейс для руководителей ИИ отделов
  if (currentUserRole === 'руководитель ИИ отдела') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Settings className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">Управление проектами</h2>
          <Badge variant="secondary" className="ml-2">
            {projects.length} проектов • {projectTasks.length} задач
          </Badge>
        </div>

        <Tabs defaultValue="projects" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="projects" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              Все проекты
            </TabsTrigger>
            <TabsTrigger value="tasks" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Все проектные задачи
            </TabsTrigger>
          </TabsList>

          <TabsContent value="projects">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5" />
                  Все проекты отдела продаж
                </CardTitle>
              </CardHeader>
              <CardContent>
                {projectsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Название проекта</TableHead>
                          <TableHead>Имя клиента</TableHead>
                          <TableHead>Менеджер</TableHead>
                          <TableHead>Формат работы</TableHead>
                          <TableHead>Статус проекта</TableHead>
                          <TableHead>Дата продажи</TableHead>
                          <TableHead>Сумма</TableHead>
                          <TableHead>Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {projects.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                              Проекты не найдены
                            </TableCell>
                          </TableRow>
                        ) : (
                          projects.map((project) => (
                            <TableRow key={project.id}>
                              <TableCell className="font-medium">
                                {project.project_name || "Без названия"}
                              </TableCell>
                              <TableCell>
                                {project.client_name || "Не указан"}
                              </TableCell>
                              <TableCell>
                                {project.manager_name}
                              </TableCell>
                              <TableCell>
                                <span className="text-sm">
                                  {formatWorkFormat(project.work_format)}
                                </span>
                              </TableCell>
                              <TableCell>
                                <Select
                                  value={project.project_status || "Не указан"}
                                  onValueChange={(newStatus) => updateProjectStatus(project.id, newStatus as ProjectStatus)}
                                  disabled={updatingProjectId === project.id}
                                >
                                  <SelectTrigger className="w-40">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent className="bg-popover border shadow-md z-50">
                                    <SelectItem value="Не указан">Не указан</SelectItem>
                                    <SelectItem value="Работаем">Работаем</SelectItem>
                                    <SelectItem value="Завершили работу">Завершили работу</SelectItem>
                                  </SelectContent>
                                </Select>
                              </TableCell>
                              <TableCell>
                                {formatDate(project.sale_date)}
                              </TableCell>
                              <TableCell className="font-medium">
                                {formatAmount(project.sale_amount)}
                              </TableCell>
                               <TableCell>
                                 <div className="flex gap-2">
                                   {project.tasks_generated ? (
                                     <div className="text-sm text-muted-foreground px-3 py-2">
                                       Задачи сгенерированы
                                     </div>
                                   ) : (
                                     <Button
                                       variant="outline"
                                       size="sm"
                                       onClick={() => {
                                         setSelectedProject(project);
                                         setIsAssignmentDialogOpen(true);
                                       }}
                                     >
                                       Назначить исполнителей
                                     </Button>
                                   )}
                                   
                                   {project.tasks_generated && (
                                     <Button
                                       variant="outline"
                                       size="sm"
                                       onClick={() => {
                                         setSelectedProjectForTasks(project);
                                         setIsProjectTasksDialogOpen(true);
                                       }}
                                     >
                                       <ListTodo className="h-4 w-4 mr-1" />
                                       Задачи проекта
                                     </Button>
                                   )}
                                   
                                   <Button
                                     variant="outline"
                                     size="sm"
                                     onClick={() => {
                                       setSelectedProjectForChange(project);
                                       setIsChangeResponsibleDialogOpen(true);
                                     }}
                                   >
                                     <UserCheck className="h-4 w-4 mr-1" />
                                     Сменить ответственного
                                   </Button>
                                 </div>
                               </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tasks">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Все проектные задачи
                </CardTitle>
                
                {/* Фильтры поиска */}
                <div className="flex gap-4 mt-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Поиск по проекту..."
                        value={searchProject}
                        onChange={(e) => setSearchProject(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Поиск по клиенту..."
                        value={searchClient}
                        onChange={(e) => setSearchClient(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Название задачи</TableHead>
                          <TableHead>Тип задачи</TableHead>
                          <TableHead>Исполнитель</TableHead>
                          <TableHead>Проект</TableHead>
                          <TableHead>Клиент</TableHead>
                          <TableHead>Статус</TableHead>
                          <TableHead className="w-40">Дедлайн</TableHead>
                          <TableHead>Создана</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                         {filteredTasks.length === 0 ? (
                           <TableRow>
                             <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                               {searchProject || searchClient ? 
                                 'Задачи не найдены по заданным критериям поиска' :
                                 'Проектные задачи не найдены (проверьте, есть ли назначенные задачи)'}
                             </TableCell>
                           </TableRow>
                        ) : (
                          filteredTasks.map((task) => (
                            <TableRow key={task.id}>
                              <TableCell className="font-medium">
                                {task.task_name}
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline">
                                  {task.task_type}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {currentUserRole === 'руководитель ИИ отдела' && task.assignee_id ? (
                                  <Select
                                    value={task.assignee_id}
                                    onValueChange={(newAssigneeId) => updateTaskAssignee(task.id, newAssigneeId)}
                                  >
                                    <SelectTrigger className="w-40">
                                      <SelectValue placeholder={task.assignee_name} />
                                    </SelectTrigger>
                                    <SelectContent className="bg-popover border shadow-md z-50">
                                      {employees.map((employee) => (
                                        <SelectItem key={employee.id} value={employee.id}>
                                          {employee.name} ({employee.department})
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                ) : (
                                  task.assignee_name
                                )}
                              </TableCell>
                              <TableCell>
                                {task.project_name}
                              </TableCell>
                              <TableCell>
                                {task.client_name}
                              </TableCell>
                              <TableCell>
                                <Badge variant={getStatusVariant(task.status)}>
                                  {getStatusText(task.status)}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <span className={cn(
                                    "text-sm",
                                    task.due_date && new Date(task.due_date) < new Date() ? "text-destructive font-medium" : "text-muted-foreground"
                                  )}>
                                    {formatDate(task.due_date)}
                                  </span>
                                  <Popover>
                                    <PopoverTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-6 w-6 p-0"
                                        onClick={() => {
                                          setEditingTaskId(task.id);
                                          setEditingDate(task.due_date ? new Date(task.due_date) : undefined);
                                        }}
                                      >
                                        <Edit className="h-3 w-3" />
                                      </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0" align="start">
                                      <Calendar
                                        mode="single"
                                        selected={editingTaskId === task.id ? editingDate : undefined}
                                        onSelect={(date) => {
                                          setEditingDate(date);
                                          updateTaskDeadline(task.id, date || null);
                                        }}
                                        initialFocus
                                        className="p-3 pointer-events-auto"
                                        locale={ru}
                                      />
                                    </PopoverContent>
                                  </Popover>
                                  {updatingTaskId === task.id && (
                                    <Loader2 className="h-3 w-3 animate-spin" />
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                {formatDate(task.created_at)}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Диалоги */}
        <ProjectAssignmentDialog
          isOpen={isAssignmentDialogOpen}
          onClose={() => {
            setIsAssignmentDialogOpen(false);
            setSelectedProject(null);
          }}
          project={selectedProject}
          onSuccess={() => {
            fetchProjects();
          }}
        />

        <ChangeResponsibleDialog
          isOpen={isChangeResponsibleDialogOpen}
          onClose={() => {
            setIsChangeResponsibleDialogOpen(false);
            setSelectedProjectForChange(null);
          }}
          project={selectedProjectForChange}
          onSuccess={() => {
            fetchProjects();
          }}
        />

        <ProjectTasksDialog
          isOpen={isProjectTasksDialogOpen}
          onOpenChange={(open) => {
            setIsProjectTasksDialogOpen(open);
            if (!open) setSelectedProjectForTasks(null);
          }}
          projectId={selectedProjectForTasks?.id || ""}
          projectName={selectedProjectForTasks?.project_name || ""}
        />
      </div>
    );
  }

  // Для других ролей - старый интерфейс задач
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Управление проектами</h2>
        <Badge variant="secondary" className="ml-2">
          {projectTasks.length} задач
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Проектные задачи отдела
          </CardTitle>
          
          {/* Фильтры поиска */}
          <div className="flex gap-4 mt-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по проекту..."
                  value={searchProject}
                  onChange={(e) => setSearchProject(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по клиенту..."
                  value={searchClient}
                  onChange={(e) => setSearchClient(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Название задачи</TableHead>
                  <TableHead>Тип задачи</TableHead>
                  <TableHead>Исполнитель</TableHead>
                  <TableHead>Проект</TableHead>
                  <TableHead>Клиент</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead className="w-40">Дедлайн</TableHead>
                  <TableHead>Создана</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                 {filteredTasks.length === 0 ? (
                   <TableRow>
                     <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                       {searchProject || searchClient ? 
                         'Задачи не найдены по заданным критериям поиска' :
                         currentUserRole === 'руководитель ИИ отдела' ?
                         'Проектные задачи для креативного отдела не найдены' :
                         'Проектные задачи не найдены'}
                     </TableCell>
                   </TableRow>
                ) : (
                  filteredTasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">
                        {task.task_name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {task.task_type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {task.assignee_name}
                      </TableCell>
                      <TableCell>
                        {task.project_name}
                      </TableCell>
                      <TableCell>
                        {task.client_name}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusVariant(task.status)}>
                          {getStatusText(task.status)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "text-sm",
                            task.due_date && new Date(task.due_date) < new Date() ? "text-destructive font-medium" : "text-muted-foreground"
                          )}>
                            {formatDate(task.due_date)}
                          </span>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 p-0"
                                onClick={() => {
                                  setEditingTaskId(task.id);
                                  setEditingDate(task.due_date ? new Date(task.due_date) : undefined);
                                }}
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={editingTaskId === task.id ? editingDate : undefined}
                                onSelect={(date) => {
                                  setEditingDate(date);
                                  updateTaskDeadline(task.id, date || null);
                                }}
                                initialFocus
                                className="p-3 pointer-events-auto"
                                locale={ru}
                              />
                            </PopoverContent>
                          </Popover>
                          {updatingTaskId === task.id && (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {formatDate(task.created_at)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};