
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { useEmployeePoints } from "@/hooks/useEmployeePoints";
import { useOrgId } from "@/hooks/useOrgId";
import { supabase } from "@/integrations/supabase/client";
import { 
  ShoppingBag, 
  Gift, 
  Zap
} from "lucide-react";
import { ShopAdminPanel } from "./shop/ShopAdminPanel";
import { ShopCategoriesAdmin } from "./shop/ShopCategoriesAdmin";

// Fallback image
import placeholder from "/public/placeholder.svg";

interface ShopItemDb {
  id: string;
  org_id: string;
  name: string;
  description: string | null;
  price: number;
  category: string;
  is_available: boolean;
  image_url: string | null;
}

interface ShopPageProps {
  employeeId?: string;
}

export const ShopPage = ({ employeeId }: ShopPageProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("Все");
  const [purchasing, setPurchasing] = useState<string | null>(null);

  // Get real points from database
  const { points: userPoints, loading: pointsLoading, refetch: refetchPoints } = useEmployeePoints(employeeId);

  // Determine current org
  const { data: orgId, isLoading: orgLoading, error: orgError } = useOrgId(employeeId);

  // Check if user is admin in org (to show admin panel)
  const { data: isAdmin } = useQuery({
    queryKey: ["isAdminInOrg", orgId],
    enabled: Boolean(orgId),
    queryFn: async () => {
      const { data, error } = await supabase.rpc("is_admin_in_org", { p_org_id: orgId });
      if (error) throw error;
      return Boolean(data);
    },
  });

  // Load shop items from DB
  const { data: shopItems = [], refetch: refetchItems, isLoading: itemsLoading } = useQuery<ShopItemDb[]>({
    queryKey: ["shop_items", orgId],
    enabled: Boolean(orgId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("shop_items")
        .select("*")
        .eq("org_id", orgId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data || []) as ShopItemDb[];
    },
  });

  const handlePurchase = async (item: ShopItemDb) => {
    if (!employeeId) {
      toast({
        title: "Ошибка",
        description: "Не удалось определить сотрудника",
        variant: "destructive"
      });
      return;
    }

    if (!userPoints || userPoints < item.price) {
      toast({
        title: "Недостаточно баллов",
        description: `Вам нужно еще ${item.price - (userPoints || 0)} баллов для покупки "${item.name}"`,
        variant: "destructive"
      });
      return;
    }

    if (!item.is_available) {
      toast({
        title: "Товар недоступен",
        description: "Этот товар временно недоступен для покупки",
        variant: "destructive"
      });
      return;
    }

    setPurchasing(item.id);

    try {
      const { data, error } = await supabase.rpc('process_shop_purchase', {
        emp_id: employeeId,
        item_name: item.name,
        item_price: item.price
      });

      if (error) {
        throw error;
      }

      const result = data as any;

      if (!result?.success) {
        toast({
          title: "Ошибка покупки",
          description: result?.error || "Неизвестная ошибка",
          variant: "destructive"
        });
        return;
      }

      await refetchPoints();

      const message = `Привет! Я выбрал приз: "${item.name}". Стоимость: ${item.price} баллов. У меня сейчас осталось: ${result.points_after} баллов.`;
      const whatsappUrl = `https://wa.me/77073712230?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');

      toast({
        title: "Покупка совершена!",
        description: `Поздравляем! Вы купили "${item.name}" за ${item.price} баллов. Переходим в WhatsApp...`,
      });

    } catch (error) {
      console.error('Purchase error:', error);
      toast({
        title: "Ошибка покупки",
        description: "Произошла ошибка при покупке товара. Попробуйте еще раз.",
        variant: "destructive"
      });
    } finally {
      setPurchasing(null);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Техника': return 'bg-blue text-blue-foreground';
      case 'Отдых': return 'bg-success text-success-foreground';
      case 'Офис': return 'bg-warning text-warning-foreground';
      case 'Удобства': return 'bg-primary text-primary-foreground';
      case 'Путешествия': return 'bg-purple-500 text-white';
      case 'Еда': return 'bg-orange-500 text-white';
      case 'Развлечения': return 'bg-purple-500 text-white';
      case 'Творчество': return 'bg-pink-500 text-white';
      case 'Мерч': return 'bg-indigo-500 text-white';
      case 'Здоровье': return 'bg-emerald-500 text-white';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const categories = useMemo(() => {
    const cats = new Set<string>(["Все"]);
    (shopItems || []).forEach((i) => cats.add(i.category || "Прочее"));
    return Array.from(cats);
  }, [shopItems]);

  const filteredItems = useMemo(() => {
    return selectedCategory === "Все" 
      ? shopItems 
      : (shopItems || []).filter(item => (item.category || "Прочее") === selectedCategory);
  }, [selectedCategory, shopItems]);

  if (orgLoading) {
    return <div className="space-y-6">Загрузка магазина...</div>;
  }
  if (orgError) {
    return <div className="space-y-6 text-destructive">Ошибка: {(orgError as any)?.message || "Не удалось определить организацию"}</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Магазин наград</h2>
          <p className="text-muted-foreground mt-1">Обменивайте баллы на полезные призы</p>
        </div>
        
        <Card className="bg-gradient-gold text-gold-foreground border-0 shadow-elegant">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Zap className="h-5 w-5" />
              <div>
                <p className="text-sm font-medium opacity-90">Ваши баллы</p>
                <p className="text-2xl font-bold">{pointsLoading ? '...' : userPoints || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Admin Panel */}
      {isAdmin ? (
        <div className="space-y-4">
          <ShopCategoriesAdmin orgId={orgId as string} />
          <ShopAdminPanel
            orgId={orgId as string}
            items={shopItems as any}
            refetch={refetchItems}
          />
        </div>
      ) : null}

      {/* Category Filter */}
      <div className="flex items-center gap-4">
        <h3 className="text-lg font-semibold">Категория:</h3>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Выберите категорию" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Shop Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {itemsLoading && (
          <div className="col-span-full text-muted-foreground">Загрузка товаров...</div>
        )}
        {!itemsLoading && filteredItems.map((item) => {
          const canAfford = (userPoints || 0) >= item.price;
          
          return (
            <Card 
              key={item.id} 
              className={`shadow-card border transition-all duration-200 hover:shadow-lg overflow-hidden ${
                !item.is_available ? "opacity-60" : "hover:scale-105"
              }`}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={item.image_url || placeholder} 
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-200 hover:scale-110"
                />
                <div className="absolute top-2 right-2">
                  <Badge className={getCategoryColor(item.category || "Прочее")} variant="secondary">
                    {item.category || "Прочее"}
                  </Badge>
                </div>
                {!item.is_available && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Badge variant="secondary" className="bg-destructive/90 text-destructive-foreground">
                      Недоступно
                    </Badge>
                  </div>
                )}
              </div>
              
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{item.name}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{item.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    <Zap className="h-4 w-4 text-warning" />
                    <span className="font-bold text-lg">{item.price}</span>
                    <span className="text-sm text-muted-foreground">баллов</span>
                  </div>
                </div>
                
                {(canAfford && item.is_available && purchasing !== item.id) ? (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button className="w-full" variant="default">
                        <ShoppingBag className="h-4 w-4 mr-2" />
                        Купить
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Подтвердите покупку</AlertDialogTitle>
                        <AlertDialogDescription>
                          Вы уверены, что хотите купить "{item.name}" за {item.price} баллов?
                          <br /><br />
                          <strong className="text-warning">⚠️ Внимание: Баллы будут списаны сразу после подтверждения!</strong>
                          <br /><br />
                          У вас сейчас: {userPoints || 0} баллов
                          <br />
                          После покупки останется: {(userPoints || 0) - item.price} баллов
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Отмена</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handlePurchase(item)}>
                          Подтвердить покупку
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                ) : (
                  <Button 
                    className="w-full"
                    variant="outline"
                    disabled={!canAfford || !item.is_available || purchasing === item.id}
                  >
                    {purchasing === item.id ? (
                      "Покупаем..."
                    ) : !item.is_available ? (
                      "Недоступно"
                    ) : !canAfford ? (
                      `Нужно ${item.price - (userPoints || 0)} баллов`
                    ) : (
                      <>
                        <ShoppingBag className="h-4 w-4 mr-2" />
                        Купить
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {!itemsLoading && filteredItems.length === 0 && (
        <div className="text-center py-12">
          <Gift className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
          <h3 className="text-xl font-semibold mb-2">Товары не найдены</h3>
          <p className="text-muted-foreground">Попробуйте выбрать другую категорию</p>
        </div>
      )}
    </div>
  );
};
