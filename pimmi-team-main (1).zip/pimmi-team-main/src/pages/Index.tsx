
import { useState, useEffect } from "react";
import { PimmiLayout } from "@/components/PimmiLayout";
import { AdminLayout } from "@/components/AdminLayout";
import { SalesLayout } from "@/components/SalesLayout";
import { Dashboard } from "@/components/Dashboard";
import { SalesDashboard } from "@/components/SalesDashboard";
import { AdminDashboard } from "@/components/AdminDashboard";
import { AdminProjectsPage } from "@/components/AdminProjectsPage";
import { ProjectManagementPage } from "@/components/ProjectManagementPage";
import { EmployeeDetails } from "@/components/EmployeeDetails";
import { TasksPage } from "@/components/TasksPage";
import { AchievementsPage } from "@/components/AchievementsPage";
import { SalesAchievementsPage } from "@/components/SalesAchievementsPage";
import { SalesKnowledgePage } from "@/components/SalesKnowledgePage";
import { SalesCasesPage } from "@/components/SalesCasesPage";
import { ShopPage } from "@/components/ShopPage";
import { AIAnalysisPage } from "@/components/AIAnalysisPage";
import { AdminSettingsPage } from "@/components/AdminSettingsPage";
import { AdminSalesManagement } from "@/components/AdminSalesManagement";
import { AdminCasesManagement } from "@/components/AdminCasesManagement";
import { SalesReportPage } from "@/components/SalesReportPage";
import { ProjectTasksPage } from "@/components/ProjectTasksPage";
import { OverdueTasksPage } from "@/components/OverdueTasksPage";
import { FinancesPage } from "@/components/FinancesPage";
import { FinanceLayout } from "@/components/FinanceLayout";
import FinanceAnalyticsPage from "@/components/FinanceAnalyticsPage";
import { AccountsPage } from "@/components/AccountsPage";
import { LandingPage } from "@/components/LandingPage";
import { AuthPage } from "@/components/AuthPage";
import { supabase } from "@/integrations/supabase/client";
import { RolesAccessPage } from "@/components/RolesAccessPage";
import { AdminAchievementsManager } from "@/components/AdminAchievementsManager";
const Index = () => {
  const [currentView, setCurrentView] = useState<'landing' | 'login' | 'app' | 'loading'>('loading');
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [selectedEmployee, setSelectedEmployee] = useState<any>(null);
  const [user, setUser] = useState<{
    name: string;
    points?: number; // Optional now since we get from DB
    employeeId?: string;
    role: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела';
    department?: string;
  } | null>(null);

  // Проверка существующей сессии при загрузке
  useEffect(() => {
    const checkExistingSession = async () => {
      console.log('🔍 Checking existing session...');
      
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('❌ Error getting session:', error);
          setCurrentView('landing');
          return;
        }

        if (session?.user) {
          console.log('✅ Found existing session for user:', session.user.email);
          
          // Получаем данные сотрудника из базы
          const { data: employees, error: employeeError } = await supabase
            .from('employees')
            .select('*')
            .eq('user_id', session.user.id)
            .single();

          if (employeeError || !employees) {
            console.error('❌ Employee not found for user:', session.user.email, employeeError);
            await supabase.auth.signOut();
            setCurrentView('landing');
            return;
          }

          console.log('👤 Employee found:', employees);

          // Формируем данные пользователя
          const userData = {
            name: employees.name,
            employeeId: employees.id,
            role: employees.role as any,
            department: employees.department,
          };

          console.log('🚀 Auto-login with existing session:', userData);
          handleLogin(employees.role as any, userData);
        } else {
          console.log('ℹ️ No existing session found');
          setCurrentView('landing');
        }
      } catch (error) {
        console.error('❌ Error checking session:', error);
        setCurrentView('landing');
      }
    };

    checkExistingSession();

    // Слушаем изменения аутентификации
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('🔄 Auth state changed:', event, session?.user?.email);
        
        if (event === 'SIGNED_OUT') {
          setUser(null);
          setCurrentView('landing');
          setCurrentPage('dashboard');
          setSelectedEmployee(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const handleLogin = (role: 'employee' | 'admin' | 'финансист' | 'руководитель тех отдела' | 'руководитель отдела продаж' | 'руководитель ИИ отдела', userData: any) => {
    console.log('🚀 handleLogin called with:', {
      role,
      userData,
      department: userData.department,
      departmentNormalized: userData.department?.toLowerCase().trim()
    });

    setUser(userData);
    setCurrentView('app');
    
    // Устанавливаем стартовую страницу в зависимости от роли и отдела
    if (role === 'admin') {
      console.log('👑 Setting admin dashboard');
      setCurrentPage('admin-dashboard');
    } else if (role === 'руководитель тех отдела') {
      console.log('🔧 Setting tech lead dashboard');
      setCurrentPage('admin-dashboard');
    } else if (role === 'руководитель отдела продаж') {
      console.log('💰 Setting sales lead dashboard');
      setCurrentPage('sales-dashboard');
    } else if (role === 'руководитель ИИ отдела') {
      console.log('🤖 Setting AI lead dashboard');
      setCurrentPage('admin-dashboard');
    } else if (userData.role === 'финансист') {
      console.log('💰 Setting dashboard for financist');
      setCurrentPage('dashboard');
    } else if (userData.department?.toLowerCase().trim() === 'отдел продаж') {
      console.log('💰 Setting sales dashboard for sales department');
      setCurrentPage('sales-dashboard');
    } else {
      console.log('👤 Setting regular dashboard for department:', userData.department);
      setCurrentPage('dashboard');
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setCurrentView('landing');
    setCurrentPage('dashboard');
    setSelectedEmployee(null);
  };

  // Remove this function since points are now handled in the database
  // const handlePurchase = (pointsSpent: number) => {
  //   if (user) {
  //     setUser({
  //       ...user,
  //       points: user.points - pointsSpent
  //     });
  //   }
  // };

  const handleEmployeeClick = (employee: any) => {
    setSelectedEmployee(employee);
    setCurrentPage('employee-details');
  };

  const handleBackToTeam = () => {
    setSelectedEmployee(null);
    setCurrentPage('admin-dashboard');
  };

  // Страницы для сотрудников
  const renderEmployeePage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard onPageChange={setCurrentPage} />;
      case "project-tasks":
        return <ProjectTasksPage />;
      case "tasks":
        return <TasksPage />;
      case "achievements":
        return <AchievementsPage employeeId={user?.employeeId} />;
      case "shop":
        return <ShopPage employeeId={user?.employeeId} />;
      case "accounts":
        return <AccountsPage />;
      default:
        return <Dashboard onPageChange={setCurrentPage} />;
    }
  };

  // Страницы для отдела продаж
  const renderSalesPage = () => {
    switch (currentPage) {
      case "sales-dashboard":
        return <SalesDashboard />;
      case "sales-knowledge":
        return <SalesKnowledgePage />;
      case "sales-cases":
        return <SalesCasesPage />;
      case "achievements":
        return <SalesAchievementsPage employeeId={user?.employeeId} />;
      case "shop":
        return <ShopPage employeeId={user?.employeeId} />;
      case "sales-management":
        return <AdminSalesManagement />;
      case "roles-access":
        return <RolesAccessPage user={user} />;
      default:
        return <SalesDashboard />;
    }
  };

  // Страницы для финансиста (все сотрудничиские + финансы)
  const renderFinancePage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard onPageChange={setCurrentPage} />;
      case "project-tasks":
        return <ProjectTasksPage />;
      case "tasks":
        return <TasksPage />;
      case "achievements":
        return <AchievementsPage employeeId={user?.employeeId} />;
      case "shop":
        return <ShopPage employeeId={user?.employeeId} />;
      case "finances":
        return <FinancesPage />;
      case "analytics":
        return <FinanceAnalyticsPage />;
      default:
        return <Dashboard onPageChange={setCurrentPage} />;
    }
  };

  // Страницы для руководителя
  const renderAdminPage = () => {
    switch (currentPage) {
      case "admin-dashboard":
        return <AdminDashboard onEmployeeClick={handleEmployeeClick} user={user} />;
      case "employee-details":
        return selectedEmployee ? (
          <EmployeeDetails employee={selectedEmployee} onBack={handleBackToTeam} />
        ) : <AdminDashboard onEmployeeClick={handleEmployeeClick} user={user} />;
      case "sales-management":
        return <AdminSalesManagement />;
      case "projects-management":
        return <ProjectManagementPage />;
      case "overdue-tasks":
        return <OverdueTasksPage />;
      case "cases-management":
        return <AdminCasesManagement />;
      case "achievements-management":
        return <AdminAchievementsManager />;
      case "ai-analysis":
        return <AIAnalysisPage />;
      case "settings":
        return <AdminSettingsPage />;
      case "roles-access":
        return <RolesAccessPage user={user} />;
      // Employee sections for department leads
      case "dashboard":
        return <Dashboard onPageChange={setCurrentPage} />;
      case "project-tasks":
        return <ProjectTasksPage />;
      case "tasks":
        return <TasksPage />;
      case "achievements":
        return <AchievementsPage employeeId={user?.employeeId} />;
      case "shop":
        return <ShopPage employeeId={user?.employeeId} />;
      default:
        return <AdminDashboard onEmployeeClick={handleEmployeeClick} user={user} />;
    }
  };

  if (currentView === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (currentView === 'landing') {
    return <LandingPage onLoginClick={() => setCurrentView('login')} />;
  }

  if (currentView === 'login') {
    return (
      <AuthPage 
        onBack={() => setCurrentView('landing')}
        onLogin={handleLogin}
      />
    );
  }

  if (currentView === 'app' && user) {
    // Для админа и руководителей тех отдела и ИИ показываем AdminLayout
    if (user.role === 'admin' || user.role === 'руководитель тех отдела' || user.role === 'руководитель ИИ отдела') {
      return (
        <AdminLayout 
          currentPage={currentPage} 
          onPageChange={setCurrentPage}
          user={user}
          onLogout={handleLogout}
        >
          {renderAdminPage()}
        </AdminLayout>
      );
    }
    
    // Для руководителя отдела продаж и сотрудников отдела продаж показываем SalesLayout
    if (user.role === 'руководитель отдела продаж' || user.department?.toLowerCase().trim() === 'отдел продаж') {
      console.log('🎯 Rendering SalesLayout for sales user:', user.name);
      return (
        <SalesLayout 
          currentPage={currentPage} 
          onPageChange={setCurrentPage}
          user={user}
          onLogout={handleLogout}
        >
          {renderSalesPage()}
        </SalesLayout>
      );
    }
    
    // Для финансиста показываем FinanceLayout
    if (user.role === 'финансист') {
      console.log('💰 Rendering FinanceLayout for financist user:', user.name);
      return (
        <FinanceLayout 
          currentPage={currentPage} 
          onPageChange={setCurrentPage}
          user={user}
          onLogout={handleLogout}
        >
          {renderFinancePage()}
        </FinanceLayout>
      );
    }
    
    // Для остальных сотрудников показываем обычный PimmiLayout
    return (
      <PimmiLayout 
        currentPage={currentPage} 
        onPageChange={setCurrentPage}
        user={user}
        onLogout={handleLogout}
      >
        {renderEmployeePage()}
      </PimmiLayout>
    );
  }

  return null;
};

export default Index;
