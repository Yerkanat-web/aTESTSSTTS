// Centralized work format options and types
// Keep this list as the single source of truth for work formats across the app

export const WORK_FORMATS = [
  "Таргет",
  "Дожим чатбот",
  "Креатив",
  "ИИ видео",
  "ИИ сайт",
  "Мастер Класс",
  "Курс обучения",
  "ИИ продажник",
  "CRM",
  "Консультация"
] as const;

export type WorkFormat = typeof WORK_FORMATS[number];

export const WORK_FORMAT_SET: Set<string> = new Set(WORK_FORMATS);

// Sanitize array of arbitrary strings to valid WorkFormat[] with normalization
export function sanitizeWorkFormats(values: string[] | null | undefined): WorkFormat[] {
  if (!values || values.length === 0) return [];
  // Normalize common aliases/casing
  const normalized = values.map((v) => v.trim())
    .map((v) => {
      const lower = v.toLowerCase();
      if (lower === "таргет") return "Таргет";
      if (lower === "креатив") return "Креатив";
      if (lower === "crm" || lower === "срм") return "CRM";
      if (lower === "ии видео") return "ИИ видео";
      if (lower === "ии сайт") return "ИИ сайт";
      if (lower === "ии продажник") return "ИИ продажник";
      if (lower === "курс обучения" || lower === "курс обучении" || lower === "курсобучения") return "Курс обучения";
      if (lower === "мастер класс" || lower === "мастер-класс") return "Мастер Класс";
      if (lower === "консультация") return "Консультация";
      if (lower === "дожим чатбот" || lower === "дожим чат-бот" || lower === "дожим чат бот") return "Дожим чатбот";
      return v; // keep as is, will be validated below
    });

  const unique: WorkFormat[] = [];
  for (const v of normalized) {
    if (WORK_FORMAT_SET.has(v) && !unique.includes(v as WorkFormat)) {
      unique.push(v as WorkFormat);
    }
  }
  return unique;
}
