// Скрипт для создания администратора
console.log('Вызываем упрощенную функцию создания администратора...');

fetch('https://nsnaucwxgidofohozayb.supabase.co/functions/v1/create-admin-simple', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({})
})
.then(response => {
  console.log('Статус ответа:', response.status);
  return response.json();
})
.then(data => {
  console.log('✅ Полный ответ:', data);
  if (data.success) {
    console.log('🎉 Администратор создан!');
    console.log('📧 Email:', data.credentials.email);
    console.log('🔑 Пароль:', data.credentials.password);
    console.log('👤 Имя:', data.credentials.name);
    console.log('🆔 ID пользователя:', data.admin?.user_id);
  } else {
    console.error('❌ Ошибка:', data.error);
  }
})
.catch(error => {
  console.error('❌ Ошибка запроса:', error);
});