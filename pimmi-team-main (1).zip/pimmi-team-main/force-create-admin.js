// ПРИНУДИТЕЛЬНОЕ СОЗДАНИЕ АДМИНИСТРАТОРА
console.log('🚀 Запускаем принудительное создание администратора...');

fetch('https://nsnaucwxgidofohozayb.supabase.co/functions/v1/force-create-admin', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({})
})
.then(response => {
  console.log('📡 Статус ответа:', response.status);
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  return response.json();
})
.then(data => {
  console.log('📦 Полный ответ:', data);
  if (data.success) {
    console.log('🎉 АДМИНИСТРАТОР СОЗДАН УСПЕШНО!');
    console.log('📧 Email:', data.credentials.email);
    console.log('🔑 Пароль:', data.credentials.password);
    console.log('👤 Имя:', data.credentials.name);
    console.log('🆔 Auth ID:', data.authUser?.id);
    console.log('💼 Employee ID:', data.admin?.id);
    console.log('');
    console.log('✅ Теперь можете войти в систему!');
  } else {
    console.error('❌ Ошибка создания:', data.error);
  }
})
.catch(error => {
  console.error('💥 Критическая ошибка:', error);
});