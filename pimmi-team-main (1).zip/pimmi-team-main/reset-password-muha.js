// Скрипт для сброса пароля пользователя muha@mail.ru
const SUPABASE_URL = "https://nsnaucwxgidofohozayb.supabase.co";
const SUPABASE_SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5zbmF1Y3d4Z2lkb2ZvaG96YXliIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0ODQzMzU0NiwiZXhwIjoyMDY0MDA5NTQ2fQ.A7qlF2HrPH6t1tXYYB8_4Zei3Y4wAhCLOhhKtm3BPLA";

async function resetPassword() {
  try {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/reset-user-password`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'muha@mail.ru',
        newPassword: 'Erkanat'
      })
    });

    const result = await response.json();
    
    if (response.ok) {
      console.log('✅ Пароль успешно сброшен:', result);
    } else {
      console.error('❌ Ошибка:', result);
    }
  } catch (error) {
    console.error('❌ Ошибка выполнения:', error);
  }
}

resetPassword();