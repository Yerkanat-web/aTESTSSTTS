import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ClientMessageRequest {
  clientIndustry: string;
  managerContext: string;
  caseData: {
    project_name: string;
    category: string;
    services: string[];
    point_a_description?: string;
    point_b_description?: string;
    our_work_description?: string;
    instagram_url?: string;
  };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      console.error('OPENAI_API_KEY is not set');
      return new Response(JSON.stringify({ error: 'OpenAI API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { clientIndustry, managerContext, caseData }: ClientMessageRequest = await req.json();

    const systemPrompt = `
Сіз тәжірибелі сату менеджерісіз. Клиенттерге түсінікті және сенімді хабарламалар жасайсыз.

Міндетіңіз: әлеуетті клиентке өте түсінікті, сататын хабарлама жазу.

Талаптар:
- 200-250 сөз
- Қарапайым, түсінікті тіл (формалды сөздерсіз)
- Нақты нәтижелер мен пайда туралы айту
- Клиентке не береміз деп нақты көрсету
- Сенімді, сататын стиль

МІНДЕТТІ структура:
1. Қысқа сәлемдесу + клиент саласын атау
2. "Біз жақында [жоба атауы] атты [санат] жұмыс істедік. Оларда осындай проблемалар болды:"
   - [проблема 1]
   - [проблема 2]
   - [проблема 3]

3. "Біз осындай нәрселер істедік:"
   - [шешім 1]
   - [шешім 2]
   - [шешім 3]

4. "Нәтижесінде осындай результат болды:"
   - [нәтиже 1]
   - [нәтиже 2]
   - [нәтиже 3]

5. Кездесуге шақыру

Әр бөлімді жаңа жолдан баста. Тізім элементтерін "-" белгісімен көрсет.
Қазақ тілінде жаз. Қарапайым, түсінікті сөздер қолдан.
`;

     const userPrompt = `
"${clientIndustry}" саласынан клиент үшін коммерциялық ұсыныс жаса.

Мысал ретінде кейс деректері:
- Жоба атауы: ${caseData.project_name}
- Санат: ${caseData.category}
- Қызметтер: ${caseData.services.join(', ')}
- Бастапқы жағдай: ${caseData.point_a_description || 'Көрсетілмеген'}
- Қол жеткізілген нәтижелер: ${caseData.point_b_description || 'Көрсетілмеген'}
- Жұмыс сипаттамасы: ${caseData.our_work_description || 'Көрсетілмеген'}

Менеджерден қосымша контекст: ${managerContext}

"${caseData.project_name}" жобасымен тәжірибеміз "${clientIndustry}" саласындағы клиенттің бизнесіне қалай көмектесе алатынын көрсететін жекелендірілген хабарлама жаса.
`;

    console.log('Generating client message...');
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openAIApiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user', 
            content: userPrompt
          }
        ],
        temperature: 0.7,
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('OpenAI API Error:', response.status, errorData);
      throw new Error(`OpenAI API Error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    const generatedMessage = data.choices[0]?.message?.content;
    
    if (!generatedMessage) {
      throw new Error('Пустой ответ от OpenAI API');
    }

    console.log('Client message generated successfully');

    return new Response(JSON.stringify({ 
      message: generatedMessage,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in generate-client-message function:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Internal server error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});