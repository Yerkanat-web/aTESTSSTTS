import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AnalysisRequest {
  employees: Array<{
    id: number;
    name: string;
    role: string;
    department: string;
    tasks: number;
    completedTasks: number;
    points: number;
    activeHours: number;
    efficiency: number;
  }>;
  periodDays: number;
  startDate?: string;
  endDate?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      console.error('OPENAI_API_KEY is not set');
      return new Response(JSON.stringify({ error: 'OpenAI API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { employees, periodDays, startDate, endDate }: AnalysisRequest = await req.json();

    // Валидация входных данных
    if (!employees || !Array.isArray(employees) || employees.length === 0) {
      console.error('Invalid or empty employees data');
      return new Response(JSON.stringify({ error: 'Отсутствуют данные о сотрудниках' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!periodDays || periodDays < 1) {
      console.error('Invalid period days:', periodDays);
      return new Response(JSON.stringify({ error: 'Некорректный период анализа' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`📊 Starting analysis for ${employees.length} employees over ${periodDays} days`);

    const periodText = periodDays === 1 ? '1 день' :
                      periodDays === 7 ? '7 дней' :
                      periodDays === 30 ? '30 дней' :
                      periodDays === 90 ? '90 дней' :
                      periodDays === 365 ? '365 дней' :
                      `${periodDays} дней`;

    const prompt = `
Ты профессиональный HR-аналитик. Проанализируй данные команды за период ${periodText} и верни ТОЛЬКО JSON без дополнительного текста.

Данные сотрудников:
${JSON.stringify(employees, null, 2)}

Верни JSON в точно таком формате:
{
  "teamInsights": {
    "overallHealth": 87,
    "productivityTrend": "up",
    "burnoutRisk": 15,
    "teamEfficiency": 92,
    "workloadBalance": 78
  },
  "employeeAnalyses": [
    {
      "id": 1,
      "name": "Имя сотрудника",
      "role": "Роль",
      "performanceScore": 95,
      "trends": {
        "productivity": "up",
        "efficiency": "up", 
        "workload": "normal"
      },
      "strengths": ["Сильная сторона 1", "Сильная сторона 2"],
      "improvements": ["Область роста 1", "Область роста 2"],
      "recommendations": ["Рекомендация 1", "Рекомендация 2"],
      "riskLevel": "low"
    }
  ]
}

Требования:
- performanceScore: 0-100
- trends: только "up", "down", "stable"
- workload: только "high", "normal", "low"  
- riskLevel: только "low", "medium", "high"
- productivityTrend: только "up", "down", "stable"
- Все значения teamInsights: 0-100
- Рекомендации должны быть конкретными и практичными для казахстанского бизнеса
- Анализируй на основе задач, эффективности, активных часов, набранных баллов
- Учитывай специфику отделов (продажи, техники, администрации)
- Давай рекомендации на русском языке
- Если у сотрудника мало данных, указывай это в анализе
`;

    console.log('Sending request to OpenAI...');
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openAIApiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'Ты профессиональный HR-аналитик для казахстанской IT-компании. Анализируй команду и давай практичные рекомендации. Отвечай только валидным JSON без markdown форматирования.'
          },
          {
            role: 'user', 
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 4000
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('OpenAI API Error:', response.status, errorData);
      throw new Error(`OpenAI API Error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error('Пустой ответ от OpenAI API');
    }

    console.log('OpenAI response received');

    // Очищаем ответ от markdown форматирования
    const cleanContent = content.replace(/```json\n?|\n?```/g, '').trim();
    let analysisData;
    
    try {
      analysisData = JSON.parse(cleanContent);
    } catch (parseError) {
      console.error('JSON Parse Error:', parseError);
      console.error('Content:', cleanContent);
      throw new Error('Некорректный JSON ответ от AI');
    }

    const result = {
      teamInsights: analysisData.teamInsights,
      employeeAnalyses: analysisData.employeeAnalyses,
      analysisDate: new Date().toISOString(),
      period: periodText
    };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in ai-analysis function:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Internal server error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});