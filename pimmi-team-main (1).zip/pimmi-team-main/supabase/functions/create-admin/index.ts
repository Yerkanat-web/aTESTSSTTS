import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Создаем администратора по умолчанию
    const adminData = {
      name: "Мария Иванова",
      email: "admin@example.com",
      position: "Руководитель",
      department: "управление"
    }

    // Проверяем, есть ли уже админ
    const { data: existingAdmin } = await supabaseClient
      .from('employees')
      .select('id')
      .eq('email', adminData.email)
      .single()

    if (existingAdmin) {
      return new Response(
        JSON.stringify({ message: 'Администратор уже существует' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    // Создаем пользователя в auth.users
    const { data: authUser, error: authError } = await supabaseClient.auth.admin.createUser({
      email: adminData.email,
      password: 'Qwerty56',
      email_confirm: true
    })

    if (authError) {
      throw authError
    }

    // Создаем запись администратора
    const { data: admin, error: adminError } = await supabaseClient
      .from('employees')
      .insert({
        user_id: authUser.user.id,
        name: adminData.name,
        email: adminData.email,
        position: adminData.position,
        department: adminData.department,
        status: 'active',
        role: 'admin'
      })
      .select()
      .single()

    if (adminError) {
      // Если ошибка при создании админа, удаляем пользователя
      await supabaseClient.auth.admin.deleteUser(authUser.user.id)
      throw adminError
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        admin,
        message: 'Администратор создан. Email: admin@example.com, Пароль: Qwerty56'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )
  }
})