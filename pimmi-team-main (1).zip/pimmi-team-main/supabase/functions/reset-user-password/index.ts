import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface ResetPasswordRequest {
  email: string;
  newPassword: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const body: ResetPasswordRequest = await req.json()
    const { email, newPassword } = body

    console.log('Сброс пароля для пользователя:', email)

    // Находим пользователя по email
    const { data: users, error: listError } = await supabaseClient.auth.admin.listUsers()
    
    if (listError) {
      console.error('Ошибка получения списка пользователей:', listError)
      throw listError
    }

    const user = users.users.find(u => u.email === email)
    
    if (!user) {
      throw new Error(`Пользователь с email ${email} не найден`)
    }

    console.log('Пользователь найден:', user.id)

    // Обновляем пароль пользователя
    const { data: updatedUser, error: updateError } = await supabaseClient.auth.admin.updateUserById(
      user.id,
      { 
        password: newPassword,
        email_confirm: true // Убеждаемся что email подтвержден
      }
    )

    if (updateError) {
      console.error('Ошибка обновления пароля:', updateError)
      throw updateError
    }

    console.log('Пароль успешно обновлен для пользователя:', updatedUser.user.id)

    return new Response(JSON.stringify({
      success: true,
      message: `Пароль для пользователя ${email} успешно сброшен`,
      user: {
        id: updatedUser.user.id,
        email: updatedUser.user.email
      }
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200 
    })

  } catch (error: any) {
    console.error('Ошибка сброса пароля:', error)
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message || 'Неизвестная ошибка при сбросе пароля'
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400 
    })
  }
})