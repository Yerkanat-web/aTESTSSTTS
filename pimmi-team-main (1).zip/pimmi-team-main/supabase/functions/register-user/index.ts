
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

function slugify(input: string): string {
  const base = input
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-');
  return base || `org-${Date.now()}`;
}

interface RegisterRequest {
  email: string;
  password: string;
  name: string;
  position?: string;
  department?: string;
  role: 'employee' | 'admin';
  org_id?: string;
  create_org?: boolean;
  org_name?: string;
  org_code?: string; // Новый параметр для присоединения к организации по коду
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const body: RegisterRequest = await req.json()
    const { email, password, name, position, department, role, org_id, create_org, org_name, org_code } = body

    console.log('Регистрация пользователя:', { email, name, role, create_org, org_name, org_code_present: !!org_code })

    // Создаем пользователя с подтвержденным email через admin API
    const { data: authUser, error: authError } = await supabaseClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Автоматически подтверждаем email
      user_metadata: {
        name,
        role: create_org ? 'admin' : role
      }
    })

    if (authError) {
      console.error('Ошибка создания auth пользователя:', authError)
      throw authError
    }

    console.log('Auth пользователь создан:', authUser.user.id)

    // Определяем организацию для пользователя
    let orgIdToUse: string | null = org_id || null;
    let createdOrg: { id: string; slug: string; name: string; join_code?: string } | null = null;

    if (create_org && org_name) {
      // Создаем новую организацию с уникальным slug
      const baseSlug = slugify(org_name);
      let candidate = baseSlug;
      let suffix = 1;
      while (true) {
        const { data: existing } = await supabaseClient
          .from('organizations')
          .select('id')
          .eq('slug', candidate)
          .maybeSingle();
        if (!existing) break;
        candidate = `${baseSlug}-${suffix++}`;
      }

      const { data: newOrg, error: orgError } = await supabaseClient
        .from('organizations')
        .insert({ name: org_name, slug: candidate })
        .select()
        .single();

      if (orgError) {
        console.error('Ошибка создания организации:', orgError);
        await supabaseClient.auth.admin.deleteUser(authUser.user.id);
        throw orgError;
      }

      // Генерируем код подключения для новой организации (если не проставился)
      let joinCode = (newOrg as any)?.join_code as string | null | undefined;
      if (!joinCode) {
        const { data: code } = await supabaseClient.rpc('generate_org_join_code');
        if (code) {
          const { data: updatedOrg, error: updErr } = await supabaseClient
            .from('organizations')
            .update({ join_code: code })
            .eq('id', newOrg.id)
            .select('id, slug, name, join_code')
            .single();
          if (updErr) {
            console.error('Не удалось обновить join_code у новой организации:', updErr);
          } else {
            joinCode = (updatedOrg as any)?.join_code;
          }
        }
      }

      createdOrg = { id: newOrg.id, slug: newOrg.slug, name: newOrg.name, join_code: joinCode || undefined };
      orgIdToUse = newOrg.id;
    } else if (!create_org && org_code) {
      // Присоединение по коду организации
      const codeUpper = org_code.trim().toUpperCase();
      const { data: orgByCode, error: codeErr } = await supabaseClient
        .from('organizations')
        .select('id, join_code_enabled, join_code_expires_at')
        .eq('join_code', codeUpper)
        .maybeSingle();

      if (codeErr) {
        console.error('Ошибка поиска организации по коду:', codeErr);
        await supabaseClient.auth.admin.deleteUser(authUser.user.id);
        throw codeErr;
      }

      if (!orgByCode) {
        console.error('Организация по коду не найдена');
        await supabaseClient.auth.admin.deleteUser(authUser.user.id);
        return new Response(JSON.stringify({
          success: false,
          error: 'Неверный код организации'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400
        });
      }

      const enabled = (orgByCode as any).join_code_enabled !== false;
      const expiresAt = (orgByCode as any).join_code_expires_at ? new Date((orgByCode as any).join_code_expires_at) : null;
      if (!enabled || (expiresAt && expiresAt.getTime() < Date.now())) {
        console.error('Код организации отключен или истек');
        await supabaseClient.auth.admin.deleteUser(authUser.user.id);
        return new Response(JSON.stringify({
          success: false,
          error: 'Код организации отключен или истек'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400
        });
      }

      orgIdToUse = (orgByCode as any).id;
    }

    if (!orgIdToUse) {
      const { data: mainOrg } = await supabaseClient
        .from('organizations')
        .select('id, slug')
        .eq('slug', 'main')
        .maybeSingle();
      orgIdToUse = mainOrg?.id || null;
    }

    // Определяем роль и создаем членство в организации ДО создания employee
    const roleUsed = (create_org ? 'admin' : role);

    let employee: any = null;

    // Сначала создаем членство, чтобы триггеры/политики пропустили вставку employee
    if (orgIdToUse) {
      const membershipRole = (create_org || roleUsed === 'admin') ? 'owner' : 'member';
      const { error: memberError } = await supabaseClient
        .from('organization_members')
        .insert({ org_id: orgIdToUse, user_id: authUser.user.id, role: membershipRole });

      if (memberError) {
        console.error('Ошибка создания членства в организации:', memberError);
        // Откатываем создание auth пользователя
        await supabaseClient.auth.admin.deleteUser(authUser.user.id);
        throw memberError;
      }
    }

    // Вставку employee делаем от имени самого пользователя (JWT), чтобы не падали проверки на auth.uid()
    const publicClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    const { data: signInData, error: signInError } = await publicClient.auth.signInWithPassword({
      email,
      password
    });

    if (signInError) {
      console.error('Не удалось авторизоваться от имени нового пользователя:', signInError);
      // Откат членства и удаления пользователя
      if (orgIdToUse) {
        await supabaseClient.from('organization_members')
          .delete()
          .eq('org_id', orgIdToUse)
          .eq('user_id', authUser.user.id);
      }
      await supabaseClient.auth.admin.deleteUser(authUser.user.id);
      throw signInError;
    }

    const employeeData = {
      user_id: authUser.user.id,
      name,
      email,
      position: roleUsed === 'admin' ? 'Администратор' : position,
      department: roleUsed === 'admin' ? 'управление' : department,
      status: 'active',
      role: roleUsed,
      org_id: orgIdToUse
    }

    const { data: employeeInsert, error: employeeError } = await publicClient
      .from('employees')
      .insert(employeeData)
      .select()
      .single()

    if (employeeError) {
      console.error('Ошибка создания employee:', employeeError)
      // Откатываем членство и auth пользователя
      if (orgIdToUse) {
        await supabaseClient.from('organization_members')
          .delete()
          .eq('org_id', orgIdToUse)
          .eq('user_id', authUser.user.id)
      }
      await supabaseClient.auth.admin.deleteUser(authUser.user.id)
      throw employeeError
    }

    employee = employeeInsert

    console.log('Employee создан:', employee.id)

    // (Членство уже создано выше)

    return new Response(JSON.stringify({
      success: true,
      message: 'Регистрация успешна! Можете сразу войти в систему.',
      user: {
        id: authUser.user.id,
        email: authUser.user.email,
        name,
        role: roleUsed
      },
      employee,
      organization: createdOrg ? { id: createdOrg.id, slug: createdOrg.slug, name: createdOrg.name, join_code: createdOrg.join_code } : (orgIdToUse ? { id: orgIdToUse } : null)
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200 
    })

  } catch (error: any) {
    console.error('Ошибка регистрации:', error)
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message || 'Неизвестная ошибка при регистрации'
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400 
    })
  }
})
