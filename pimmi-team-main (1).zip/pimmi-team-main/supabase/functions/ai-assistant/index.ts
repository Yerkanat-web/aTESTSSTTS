import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AssistantRequest {
  message: string;
  context?: {
    userRole?: string;
    currentPage?: string;
    employeeData?: any;
    teamData?: any;
  };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      console.error('OPENAI_API_KEY is not set');
      return new Response(JSON.stringify({ error: 'OpenAI API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { message, context }: AssistantRequest = await req.json();

    const systemPrompt = `
Ты умный помощник в системе управления сотрудниками. Помогай пользователям с:

1. **Анализом производительности** - объясняй метрики, тренды, предлагай улучшения
2. **Управлением задачами** - советы по приоритизации, планированию, распределению
3. **HR вопросами** - рекомендации по развитию команды, мотивации сотрудников
4. **Интерпретацией данных** - помогай понять графики, статистику, отчеты

Отвечай на русском языке, будь конкретным и практичным.

${context?.userRole ? `Роль пользователя: ${context.userRole}` : ''}
${context?.currentPage ? `Текущая страница: ${context.currentPage}` : ''}
${context?.employeeData ? `Данные сотрудника: ${JSON.stringify(context.employeeData)}` : ''}
${context?.teamData ? `Данные команды: ${JSON.stringify(context.teamData)}` : ''}
`;

    console.log('Sending request to OpenAI Assistant...');
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openAIApiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user', 
            content: message
          }
        ],
        temperature: 0.8,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('OpenAI API Error:', response.status, errorData);
      throw new Error(`OpenAI API Error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    const assistantResponse = data.choices[0]?.message?.content;
    
    if (!assistantResponse) {
      throw new Error('Пустой ответ от OpenAI API');
    }

    console.log('OpenAI assistant response received');

    return new Response(JSON.stringify({ 
      response: assistantResponse,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in ai-assistant function:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Internal server error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});