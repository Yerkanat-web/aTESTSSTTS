import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Retry function for OpenAI API calls
async function callOpenAIWithRetry(requestBody: any, maxRetries = 2) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAIApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`OpenAI API error (attempt ${i + 1}):`, response.status, response.statusText, errorText);
        
        if (i === maxRetries - 1) {
          throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
        }
        continue;
      }

      return await response.json();
    } catch (error) {
      console.error(`OpenAI API call failed (attempt ${i + 1}):`, error);
      if (i === maxRetries - 1) {
        throw error;
      }
      // Wait before retry
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting business analysis function...');
    
    // Check if API key is present
    if (!openAIApiKey) {
      console.error('OPENAI_API_KEY is not set');
      return new Response(
        JSON.stringify({ error: 'OpenAI API key is not configured' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const { businessName, businessDescription } = await req.json();
    console.log('Request data:', { businessName, businessDescription: businessDescription?.slice(0, 100) + '...' });

    if (!businessName || !businessDescription) {
      return new Response(
        JSON.stringify({ error: 'Business name and description are required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Shortened and simplified prompt
    const prompt = `Проведи анализ клиента для бизнеса "${businessName}".

Описание: ${businessDescription}

Ответь строго в JSON формате:

{
  "avatarName": "Имя типичного клиента",
  "detailedDescription": "Описание аватара клиента (пол, возраст, должность, поведение)",
  "alternatives": "Альтернативы нашему решению",
  "problemsWithoutProduct": "Проблемы без нашего продукта",
  "mainMotivation": "Главная мотивация покупки",
  "decisionFactors": "Факторы принятия решения",
  "stopFactors": "Что может остановить покупку",
  "fears": "Основные страхи клиента",
  "needs": "Ключевые потребности",
  "convincingFacts": "Убедительные факты",
  "companyQuestions": "Вопросы к нашей компании"
}

Каждое поле - краткий, но информативный текст. Только JSON, без дополнительного текста.`;

    console.log('Prompt length:', prompt.length);
    console.log('Sending request to OpenAI API...');

    const requestBody = {
      model: 'gpt-4.1-2025-04-14',
      messages: [
        { 
          role: 'system', 
          content: 'Ты маркетолог-аналитик. Создавай краткие, но точные портреты клиентов. Отвечай только на русском.' 
        },
        { role: 'user', content: prompt }
      ],
      max_tokens: 2000,
      temperature: 0.7,
    };

    const data = await callOpenAIWithRetry(requestBody);
    const analysisText = data.choices[0].message.content;

    console.log('Raw OpenAI response length:', analysisText.length);
    console.log('Raw OpenAI response preview:', analysisText.slice(0, 200) + '...');

    // Parse the JSON response from OpenAI
    let analysis;
    try {
      // Try to extract JSON from the response (sometimes OpenAI adds extra text)
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : analysisText;
      console.log('Extracted JSON string length:', jsonString.length);
      
      analysis = JSON.parse(jsonString);
      console.log('Successfully parsed JSON with keys:', Object.keys(analysis));
    } catch (parseError) {
      console.error('Error parsing OpenAI response:', parseError);
      console.error('Response was:', analysisText);
      
      // Fallback: return a simple structure if JSON parsing fails
      analysis = {
        avatarName: "Анализ не удался",
        detailedDescription: "Произошла ошибка при парсинге ответа от ИИ. Попробуйте еще раз.",
        alternatives: "Нет данных",
        problemsWithoutProduct: "Нет данных", 
        mainMotivation: "Нет данных",
        decisionFactors: "Нет данных",
        stopFactors: "Нет данных",
        fears: "Нет данных",
        needs: "Нет данных",
        convincingFacts: "Нет данных",
        companyQuestions: "Нет данных"
      };
    }

    console.log('Business analysis generated successfully');

    return new Response(
      JSON.stringify({ analysis }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error in business-analysis function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});