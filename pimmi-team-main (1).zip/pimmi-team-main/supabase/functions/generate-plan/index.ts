import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (!openAIApiKey) {
      return new Response(
        JSON.stringify({ error: 'OpenAI API key is not configured' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const { analysisResult } = await req.json();

    if (!analysisResult) {
      return new Response(
        JSON.stringify({ error: 'Analysis result is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const planPrompts = [
      {
        title: "🔥 Главный оффер для рекламы",
        prompt: "На основе анализа клиента (боли, мотивации, страхов и потребностей), сформулируй 5 сильных рекламных оффера. Они должны вызывать интерес, попадать в боль, быть простыми и конкретными. Формат: как заголовок в рекламе или первое сообщение в чате."
      },
      {
        title: "🎬 Идеи креативов",
        prompt: "Сгенерируй 5–7 идей рекламных креативов, основанных на болях, страхах, желаниях и альтернативных решениях клиента. Варианты должны быть разными по формату: видео, карусель, кейс, мем, текст. Укажи кратко формат + идею."
      },
      {
        title: "🤖 Скрипт чат-бота",
        prompt: "Составь примерную структуру чат-бота (5–7 сообщений), который помогает выявить потребности клиента, снять страхи и довести до заявки. Используй данные из анализа: какие вопросы задать, как отвечать на сомнения, как предлагать решение."
      },
      {
        title: "📈 Структура автоворонки",
        prompt: "Предложи структуру автоворонки для продаж этого продукта. Опиши этапы от первого касания до продажи, включая ретаргет, квиз, консультацию, дожим и апсейлы. Формат: поэтапный список."
      },
      {
        title: "⚙️ Что автоматизировать",
        prompt: "На основе типичных действий и поведения клиента, предложи 3–5 процессов, которые можно автоматизировать с помощью чат-бота, WhatsApp или CRM. Формулируй как задачи для системы автоматизации (n8n/Make)."
      },
      {
        title: "🚀 Точка масштабирования",
        prompt: "Исходя из аватара, продукта и анализа поведения, предложи идею масштабирования прибыли: запуск нового канала продаж, создание франшизы, upsell-продукта или подписки. Формат: 3 идеи с кратким описанием."
      }
    ];

    // Создаем массив промисов для параллельного выполнения
    const planPromises = planPrompts.map(async (item) => {
      const fullPrompt = `Анализ клиента:
- Имя аватара: ${analysisResult.avatarName}
- Описание: ${analysisResult.detailedDescription}
- Альтернативы: ${analysisResult.alternatives}
- Проблемы без продукта: ${analysisResult.problemsWithoutProduct}
- Главная мотивация: ${analysisResult.mainMotivation}
- Факторы принятия решения: ${analysisResult.decisionFactors}
- Стоп-факторы: ${analysisResult.stopFactors}
- Страхи: ${analysisResult.fears}
- Потребности: ${analysisResult.needs}
- Убеждающие факты: ${analysisResult.convincingFacts}
- Вопросы к компании: ${analysisResult.companyQuestions}

Задача: ${item.prompt}

Ответь на русском языке, структурированно и практично.`;

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAIApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: 'Ты маркетолог-стратег. Создаваешь практические маркетинговые решения на основе анализа клиентов.' },
            { role: 'user', content: fullPrompt }
          ],
          max_tokens: 800,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status}`);
      }

      const data = await response.json();
      return {
        title: item.title,
        content: data.choices[0].message.content
      };
    });

    // Выполняем все запросы параллельно
    const planResults = await Promise.all(planPromises);

    // Собираем результаты в объект
    const plan = {};
    planResults.forEach(result => {
      plan[result.title] = result.content;
    });

    return new Response(
      JSON.stringify({ plan }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error generating plan:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});