import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('=== Начинаем создание администратора ===')
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const adminData = {
      email: "admin@example.com",
      password: "Qwerty56"
    }

    console.log('1. Создаем пользователя в auth.users...')
    
    // Создаем пользователя в auth.users
    const { data: authUser, error: authError } = await supabaseClient.auth.admin.createUser({
      email: adminData.email,
      password: adminData.password,
      email_confirm: true
    })

    if (authError) {
      console.error('Ошибка создания auth пользователя:', authError)
      if (authError.message.includes('already registered')) {
        console.log('Пользователь уже существует, получаем его...')
        const { data: users } = await supabaseClient.auth.admin.listUsers()
        const existingUser = users.users.find(u => u.email === adminData.email)
        if (existingUser) {
          console.log('2. Связываем с существующим пользователем:', existingUser.id)
          
          // Обновляем администратора с user_id
          const { data: admin, error: updateError } = await supabaseClient
            .from('employees')
            .update({ user_id: existingUser.id })
            .eq('email', adminData.email)
            .select()
            .single()

          if (updateError) {
            console.error('Ошибка обновления администратора:', updateError)
            throw updateError
          }

          console.log('✅ Администратор связан с пользователем')
          return new Response(JSON.stringify({
            success: true,
            message: 'Администратор успешно связан с существующим пользователем!',
            credentials: { email: adminData.email, password: adminData.password },
            admin
          }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
        }
      }
      throw authError
    }

    console.log('2. Пользователь создан:', authUser.user.id)
    console.log('3. Связываем с записью администратора...')

    // Обновляем администратора с user_id
    const { data: admin, error: updateError } = await supabaseClient
      .from('employees')
      .update({ user_id: authUser.user.id })
      .eq('email', adminData.email)
      .select()
      .single()

    if (updateError) {
      console.error('Ошибка обновления администратора:', updateError)
      // Если не удалось связать, удаляем auth пользователя
      await supabaseClient.auth.admin.deleteUser(authUser.user.id)
      throw updateError
    }

    console.log('✅ Администратор успешно создан и связан!')

    return new Response(JSON.stringify({
      success: true,
      message: 'Администратор успешно создан!',
      credentials: {
        email: adminData.email,
        password: adminData.password,
        name: 'Мария Иванова'
      },
      admin
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200 
    })

  } catch (error) {
    console.error('❌ Ошибка при создании администратора:', error)
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message || 'Неизвестная ошибка при создании администратора'
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400 
    })
  }
})