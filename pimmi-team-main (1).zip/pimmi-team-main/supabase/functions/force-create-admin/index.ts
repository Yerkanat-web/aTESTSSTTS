import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('=== СОЗДАНИЕ АДМИНИСТРАТОРА ===')
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const adminData = {
      email: "admin@example.com",
      password: "Qwerty56",
      name: "Мария Иванова"
    }

    console.log('Шаг 1: Проверяем существующих пользователей...')
    
    // Получаем всех пользователей
    const { data: usersData, error: usersError } = await supabaseClient.auth.admin.listUsers()
    if (usersError) {
      console.error('Ошибка получения пользователей:', usersError)
    } else {
      console.log('Найдено пользователей:', usersData.users.length)
      const adminUser = usersData.users.find(u => u.email === adminData.email)
      if (adminUser) {
        console.log('Администратор уже существует в auth:', adminUser.id)
        
        // Обновляем user_id в employees
        const { data: updatedAdmin, error: updateError } = await supabaseClient
          .from('employees')
          .update({ user_id: adminUser.id })
          .eq('email', adminData.email)
          .select()
          .single()

        if (updateError) {
          console.error('Ошибка обновления employee:', updateError)
        } else {
          console.log('✅ Employee обновлен:', updatedAdmin)
          return new Response(JSON.stringify({
            success: true,
            message: 'Администратор связан с существующим auth пользователем',
            admin: updatedAdmin
          }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
        }
      }
    }

    console.log('Шаг 2: Создаем нового пользователя...')
    
    // Создаем нового пользователя
    const { data: newUser, error: createError } = await supabaseClient.auth.admin.createUser({
      email: adminData.email,
      password: adminData.password,
      email_confirm: true,
      user_metadata: {
        name: adminData.name
      }
    })

    if (createError) {
      console.error('Ошибка создания пользователя:', createError)
      throw new Error(`Не удалось создать пользователя: ${createError.message}`)
    }

    console.log('✅ Пользователь создан:', newUser.user.id)
    console.log('Шаг 3: Обновляем employee...')

    // Обновляем employee
    const { data: updatedAdmin, error: updateError } = await supabaseClient
      .from('employees')
      .update({ user_id: newUser.user.id })
      .eq('email', adminData.email)
      .select()
      .single()

    if (updateError) {
      console.error('Ошибка обновления employee:', updateError)
      // Откатываем создание пользователя
      await supabaseClient.auth.admin.deleteUser(newUser.user.id)
      throw new Error(`Не удалось связать пользователя: ${updateError.message}`)
    }

    console.log('✅ АДМИНИСТРАТОР СОЗДАН УСПЕШНО!')
    console.log('Email:', adminData.email)
    console.log('Password:', adminData.password)
    console.log('Auth ID:', newUser.user.id)
    console.log('Employee ID:', updatedAdmin.id)

    return new Response(JSON.stringify({
      success: true,
      message: 'Администратор создан и готов к использованию!',
      credentials: {
        email: adminData.email,
        password: adminData.password,
        name: adminData.name
      },
      admin: updatedAdmin,
      authUser: newUser.user
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200 
    })

  } catch (error) {
    console.error('❌ КРИТИЧЕСКАЯ ОШИБКА:', error)
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message || 'Неизвестная ошибка'
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500 
    })
  }
})