import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Получаем всех сотрудников из базы данных
    const { data: employees, error: employeesError } = await supabaseClient
      .from('employees')
      .select('*')
      .is('user_id', null)

    if (employeesError) {
      throw employeesError
    }

    const results = []
    const defaultPassword = 'Qwerty56'

    // Создаем пользователей для каждого сотрудника
    for (const employee of employees || []) {
      try {
        // Создаем пользователя в auth.users
        const { data: authUser, error: authError } = await supabaseClient.auth.admin.createUser({
          email: employee.email,
          password: defaultPassword,
          email_confirm: true
        })

        if (authError) {
          // Если пользователь уже существует, попробуем найти его
          if (authError.message.includes('already been registered')) {
            const { data: existingUser, error: getUserError } = await supabaseClient.auth.admin.getUserByEmail(employee.email)
            
            if (!getUserError && existingUser) {
              // Обновляем запись сотрудника с user_id
              await supabaseClient
                .from('employees')
                .update({ user_id: existingUser.id })
                .eq('id', employee.id)
              
              results.push({
                employee: employee.name,
                email: employee.email,
                password: defaultPassword,
                status: 'linked_existing'
              })
              continue
            }
          }
          
          results.push({
            employee: employee.name,
            email: employee.email,
            password: defaultPassword,
            status: 'error',
            error: authError.message
          })
          continue
        }

        // Обновляем запись сотрудника с user_id
        const { error: updateError } = await supabaseClient
          .from('employees')
          .update({ user_id: authUser.user.id })
          .eq('id', employee.id)

        if (updateError) {
          // Если ошибка при обновлении сотрудника, удаляем пользователя
          await supabaseClient.auth.admin.deleteUser(authUser.user.id)
          results.push({
            employee: employee.name,
            email: employee.email,
            password: defaultPassword,
            status: 'error',
            error: updateError.message
          })
          continue
        }

        results.push({
          employee: employee.name,
          email: employee.email,
          password: defaultPassword,
          status: 'created'
        })

      } catch (error) {
        results.push({
          employee: employee.name,
          email: employee.email,
          password: defaultPassword,
          status: 'error',
          error: error.message
        })
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        results,
        summary: {
          total: results.length,
          created: results.filter(r => r.status === 'created').length,
          linked: results.filter(r => r.status === 'linked_existing').length,
          errors: results.filter(r => r.status === 'error').length
        }
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )
  }
})