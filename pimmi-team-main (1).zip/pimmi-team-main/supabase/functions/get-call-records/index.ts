import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Получаем текущего пользователя
    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser();

    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const url = new URL(req.url);
    const date = url.searchParams.get('date') || new Date().toISOString().split('T')[0];
    const limit = parseInt(url.searchParams.get('limit') || '10');

    console.log(`Fetching call records for user ${user.id}, date: ${date}, limit: ${limit}`);

    // Получаем записи звонков из базы данных
    const { data: callRecords, error: recordsError } = await supabaseClient
      .from('call_records')
      .select('*')
      .eq('user_id', user.id)
      .gte('call_date', `${date}T00:00:00`)
      .lte('call_date', `${date}T23:59:59`)
      .order('call_date', { ascending: false })
      .limit(limit);

    if (recordsError) {
      console.error('Error fetching call records:', recordsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch call records' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Получаем статистику звонков за день
    const { data: dayStats, error: statsError } = await supabaseClient
      .from('call_statistics')
      .select('*')
      .eq('user_id', user.id)
      .eq('date', date)
      .single();

    if (statsError && statsError.code !== 'PGRST116') {
      console.error('Error fetching call statistics:', statsError);
    }

    return new Response(
      JSON.stringify({
        success: true,
        call_records: callRecords || [],
        day_stats: dayStats || {
          incoming_calls: 0,
          outgoing_calls: 0,
          missed_calls: 0,
          total_duration: 0
        }
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in get-call-records function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});