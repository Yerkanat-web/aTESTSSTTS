import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log('Создание администратора...')

    // Данные администратора
    const adminData = {
      name: "Мария Иванова", 
      email: "admin@example.com",
      position: "Руководитель",
      department: "управление",
      password: "Qwerty56"
    }

    // Проверяем, есть ли уже пользователь в auth.users
    const { data: existingAuthUser } = await supabaseClient.auth.admin.listUsers()
    const authUserExists = existingAuthUser.users.some(user => user.email === adminData.email)

    let authUser;
    if (!authUserExists) {
      // Создаем пользователя в auth.users
      const { data: newAuthUser, error: authError } = await supabaseClient.auth.admin.createUser({
        email: adminData.email,
        password: adminData.password,
        email_confirm: true
      })

      if (authError) {
        console.error('Ошибка создания auth пользователя:', authError)
        throw authError
      }
      authUser = newAuthUser.user
      console.log('Auth пользователь создан:', authUser.id)
    } else {
      authUser = existingAuthUser.users.find(user => user.email === adminData.email)
      console.log('Auth пользователь уже существует:', authUser.id)
    }

    // Обновляем запись администратора с user_id
    const { data: admin, error: adminError } = await supabaseClient
      .from('employees')
      .update({ user_id: authUser.id })
      .eq('email', adminData.email)
      .select()
      .single()

    if (adminError) {
      console.error('Ошибка обновления администратора:', adminError)
      throw adminError
    }

    console.log('Администратор успешно создан и связан с auth пользователем')

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Администратор успешно создан!',
        credentials: {
          email: adminData.email,
          password: adminData.password,
          name: adminData.name
        },
        admin
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('Ошибка при создании администратора:', error)
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error.message || 'Неизвестная ошибка при создании администратора'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )
  }
})