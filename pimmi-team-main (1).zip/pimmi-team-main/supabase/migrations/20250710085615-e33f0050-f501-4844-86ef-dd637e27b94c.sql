-- Add file_content column to task_attachments table to store file data in database
ALTER TABLE public.task_attachments 
ADD COLUMN file_content BYTEA;

-- Make file_path nullable since we'll store content in database
ALTER TABLE public.task_attachments 
ALTER COLUMN file_path DROP NOT NULL;