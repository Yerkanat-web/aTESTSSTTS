-- Создаем таблицу для задач сотрудников
CREATE TABLE public.employee_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  due_date DATE,
  assigned_by UUID, -- кто назначил задачу
  category TEXT DEFAULT 'general', -- тип работы: разработка, дизайн, аналитика и т.д.
  estimated_hours INTEGER DEFAULT 0,
  actual_hours INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Создаем таблицу для отслеживания времени работы
CREATE TABLE public.work_time_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL,
  task_id UUID,
  start_time TIMESTAMP WITH TIME ZONE NOT NULL,
  end_time TIMESTAMP WITH TIME ZONE,
  hours_worked NUMERIC(4,2) DEFAULT 0,
  description TEXT,
  work_type TEXT DEFAULT 'task', -- task, meeting, break, training
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Создаем таблицу для комментариев к задачам
CREATE TABLE public.task_comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  task_id UUID NOT NULL,
  employee_id UUID NOT NULL,
  comment_text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Создаем таблицу для файлов/вложений к задачам
CREATE TABLE public.task_attachments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  task_id UUID NOT NULL,
  employee_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  content_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Включаем RLS для всех таблиц
ALTER TABLE public.employee_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.work_time_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_attachments ENABLE ROW LEVEL SECURITY;

-- Политики для employee_tasks
CREATE POLICY "Admins can manage all tasks" 
ON public.employee_tasks 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their own tasks" 
ON public.employee_tasks 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = employee_tasks.employee_id 
  AND employees.user_id = auth.uid()
));

CREATE POLICY "Employees can update their own tasks" 
ON public.employee_tasks 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = employee_tasks.employee_id 
  AND employees.user_id = auth.uid()
));

-- Политики для work_time_logs
CREATE POLICY "Admins can manage all time logs" 
ON public.work_time_logs 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can manage their own time logs" 
ON public.work_time_logs 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = work_time_logs.employee_id 
  AND employees.user_id = auth.uid()
));

-- Политики для task_comments
CREATE POLICY "Admins can manage all comments" 
ON public.task_comments 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view comments on their tasks" 
ON public.task_comments 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees e
  JOIN employee_tasks t ON (t.employee_id = e.id OR t.assigned_by = e.id)
  WHERE t.id = task_comments.task_id 
  AND e.user_id = auth.uid()
));

CREATE POLICY "Employees can create comments" 
ON public.task_comments 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = task_comments.employee_id 
  AND employees.user_id = auth.uid()
));

-- Политики для task_attachments
CREATE POLICY "Admins can manage all attachments" 
ON public.task_attachments 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view attachments on their tasks" 
ON public.task_attachments 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees e
  JOIN employee_tasks t ON t.employee_id = e.id
  WHERE t.id = task_attachments.task_id 
  AND e.user_id = auth.uid()
));

CREATE POLICY "Employees can create attachments for their tasks" 
ON public.task_attachments 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = task_attachments.employee_id 
  AND employees.user_id = auth.uid()
));

-- Создаем триггеры для автоматического обновления updated_at
CREATE TRIGGER update_employee_tasks_updated_at
BEFORE UPDATE ON public.employee_tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_work_time_logs_updated_at
BEFORE UPDATE ON public.work_time_logs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Создаем функцию для автоматического обновления completed_at
CREATE OR REPLACE FUNCTION public.update_task_completed_at()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    NEW.completed_at = now();
  ELSIF NEW.status != 'completed' THEN
    NEW.completed_at = NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Триггер для автоматического обновления completed_at
CREATE TRIGGER update_task_completed_at_trigger
BEFORE UPDATE ON public.employee_tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_task_completed_at();

-- Создаем индексы для лучшей производительности
CREATE INDEX idx_employee_tasks_employee ON public.employee_tasks(employee_id);
CREATE INDEX idx_employee_tasks_status ON public.employee_tasks(status);
CREATE INDEX idx_employee_tasks_due_date ON public.employee_tasks(due_date);
CREATE INDEX idx_work_time_logs_employee ON public.work_time_logs(employee_id);
CREATE INDEX idx_work_time_logs_task ON public.work_time_logs(task_id);
CREATE INDEX idx_work_time_logs_date ON public.work_time_logs(start_time);
CREATE INDEX idx_task_comments_task ON public.task_comments(task_id);
CREATE INDEX idx_task_attachments_task ON public.task_attachments(task_id);

-- Добавляем foreign key constraints
ALTER TABLE public.employee_tasks 
ADD CONSTRAINT fk_employee_tasks_employee 
FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;

ALTER TABLE public.employee_tasks 
ADD CONSTRAINT fk_employee_tasks_assigned_by 
FOREIGN KEY (assigned_by) REFERENCES public.employees(id) ON DELETE SET NULL;

ALTER TABLE public.work_time_logs 
ADD CONSTRAINT fk_work_time_logs_employee 
FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;

ALTER TABLE public.work_time_logs 
ADD CONSTRAINT fk_work_time_logs_task 
FOREIGN KEY (task_id) REFERENCES public.employee_tasks(id) ON DELETE CASCADE;

ALTER TABLE public.task_comments 
ADD CONSTRAINT fk_task_comments_task 
FOREIGN KEY (task_id) REFERENCES public.employee_tasks(id) ON DELETE CASCADE;

ALTER TABLE public.task_comments 
ADD CONSTRAINT fk_task_comments_employee 
FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;

ALTER TABLE public.task_attachments 
ADD CONSTRAINT fk_task_attachments_task 
FOREIGN KEY (task_id) REFERENCES public.employee_tasks(id) ON DELETE CASCADE;

ALTER TABLE public.task_attachments 
ADD CONSTRAINT fk_task_attachments_employee 
FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;

-- Добавляем тестовые данные для демонстрации
INSERT INTO public.employee_tasks (employee_id, title, description, priority, status, category, estimated_hours, actual_hours)
SELECT 
  e.id,
  CASE 
    WHEN e.department = 'IT' THEN 
      (ARRAY['Разработка новой функции', 'Исправление бага', 'Код ревью', 'Настройка сервера', 'Документация API'])[FLOOR(RANDOM() * 5 + 1)]
    WHEN e.department = 'Маркетинг' THEN 
      (ARRAY['Создание рекламной кампании', 'Анализ конкурентов', 'Контент план', 'SEO оптимизация', 'Социальные сети'])[FLOOR(RANDOM() * 5 + 1)]
    WHEN e.department = 'HR' THEN 
      (ARRAY['Собеседование кандидатов', 'Обучение персонала', 'Адаптация новичков', 'Оценка производительности', 'Кадровое планирование'])[FLOOR(RANDOM() * 5 + 1)]
    ELSE 
      (ARRAY['Общая задача', 'Планерка', 'Отчет', 'Встреча с клиентом', 'Административная работа'])[FLOOR(RANDOM() * 5 + 1)]
  END,
  'Описание задачи для сотрудника отдела ' || e.department,
  (ARRAY['low', 'medium', 'high'])[FLOOR(RANDOM() * 3 + 1)],
  (ARRAY['completed', 'in_progress', 'pending'])[FLOOR(RANDOM() * 3 + 1)],
  CASE 
    WHEN e.department = 'IT' THEN 'development'
    WHEN e.department = 'Маркетинг' THEN 'marketing'
    WHEN e.department = 'HR' THEN 'hr'
    ELSE 'general'
  END,
  FLOOR(RANDOM() * 8 + 1),
  CASE WHEN RANDOM() > 0.5 THEN FLOOR(RANDOM() * 6 + 1) ELSE 0 END
FROM employees e
WHERE e.department != 'Продажи'
AND RANDOM() < 0.8; -- 80% вероятность создания задачи

-- Добавляем логи рабочего времени
INSERT INTO public.work_time_logs (employee_id, task_id, start_time, end_time, hours_worked, work_type)
SELECT 
  e.id,
  NULL, -- общее рабочее время, не привязанное к конкретной задаче
  CURRENT_DATE - (RANDOM() * 7)::INTEGER + (RANDOM() * 8 + 1) * INTERVAL '1 hour',
  CURRENT_DATE - (RANDOM() * 7)::INTEGER + (RANDOM() * 8 + 9) * INTERVAL '1 hour',
  ROUND((RANDOM() * 7 + 1)::NUMERIC, 2),
  (ARRAY['task', 'meeting', 'training'])[FLOOR(RANDOM() * 3 + 1)]
FROM employees e
WHERE RANDOM() < 0.7; -- 70% вероятность создания лога времени