-- Добавляем поле для привязки сотрудника к пользователю Sipuni
ALTER TABLE public.employees 
ADD COLUMN sipuni_user_id TEXT;

-- Добавляем индекс для быстрого поиска по sipuni_user_id
CREATE INDEX idx_employees_sipuni_user_id ON public.employees(sipuni_user_id);

-- Добавляем комментарий для документации
COMMENT ON COLUMN public.employees.sipuni_user_id IS 'ID пользователя или номер телефона в системе Sipuni для привязки статистики звонков';