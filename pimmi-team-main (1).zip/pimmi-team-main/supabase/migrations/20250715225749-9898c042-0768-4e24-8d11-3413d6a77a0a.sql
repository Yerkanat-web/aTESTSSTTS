-- Добавляем политику для руководителей отделов на просмотр сотрудников
CREATE POLICY "Department leads can view employees" 
ON employees 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1
    FROM employees manager
    WHERE manager.user_id = auth.uid()
    AND (
      -- Руководитель тех отдела видит ВСЕХ сотрудников
      manager.role = 'руководитель тех отдела' OR
      -- Остальные руководители видят только сотрудников своего отдела
      (
        manager.role = 'руководитель отдела продаж' AND 
        employees.department = 'отдел продаж'
      ) OR
      (
        manager.role = 'руководитель ИИ отдела' AND 
        employees.department = 'креатив отдел'
      )
    )
  )
);