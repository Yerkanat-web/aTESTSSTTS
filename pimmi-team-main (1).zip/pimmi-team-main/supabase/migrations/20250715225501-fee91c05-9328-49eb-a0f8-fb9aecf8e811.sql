-- Изменяем политику для руководителей отделов на project_tasks - руководитель тех отдела видит ВСЕ задачи
DROP POLICY IF EXISTS "Department leads can view their department project tasks" ON project_tasks;

-- Новая политика: руководитель тех отдела видит ВСЕ задачи (как админ), остальные руководители - только своего отдела
CREATE POLICY "Department leads can view project tasks" 
ON project_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1
    FROM employees manager
    WHERE manager.user_id = auth.uid()
    AND (
      -- Руководитель тех отдела видит ВСЕ задачи
      manager.role = 'руководитель тех отдела' OR
      -- Остальные руководители видят только задачи своего отдела
      (
        manager.role = 'руководитель отдела продаж' AND 
        EXISTS (
          SELECT 1 FROM employees assignee 
          WHERE assignee.id = project_tasks.assignee_id 
          AND assignee.department = 'отдел продаж'
        )
      ) OR
      (
        manager.role = 'руководитель ИИ отдела' AND 
        EXISTS (
          SELECT 1 FROM employees assignee 
          WHERE assignee.id = project_tasks.assignee_id 
          AND assignee.department = 'креатив отдел'
        )
      )
    )
  )
);