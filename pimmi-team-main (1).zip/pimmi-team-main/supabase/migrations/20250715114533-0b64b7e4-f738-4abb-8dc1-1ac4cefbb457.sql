-- Add INSERT policy for project_tasks to allow employees to create tasks
CREATE POLICY "Employees can create project tasks" 
ON project_tasks 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.user_id = auth.uid() 
    AND employees.role = 'employee'
  )
);