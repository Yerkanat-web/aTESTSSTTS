-- Создаем таблицу для хранения статистики звонков
CREATE TABLE public.call_statistics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  date DATE NOT NULL,
  incoming_calls INTEGER DEFAULT 0,
  outgoing_calls INTEGER DEFAULT 0,
  missed_calls INTEGER DEFAULT 0,
  total_duration INTEGER DEFAULT 0, -- в секундах
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Создаем таблицу для записей звонков
CREATE TABLE public.call_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  sipuni_call_id TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  direction TEXT NOT NULL, -- 'incoming' или 'outgoing'
  duration INTEGER DEFAULT 0,
  recording_url TEXT,
  call_date TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Включаем RLS
ALTER TABLE public.call_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.call_records ENABLE ROW LEVEL SECURITY;

-- Политики для call_statistics
CREATE POLICY "Users can view their own call stats" 
ON public.call_statistics 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own call stats" 
ON public.call_statistics 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own call stats" 
ON public.call_statistics 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Политики для call_records  
CREATE POLICY "Users can view their own call records" 
ON public.call_records 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own call records" 
ON public.call_records 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Триггеры для автоматического обновления updated_at
CREATE TRIGGER update_call_statistics_updated_at
BEFORE UPDATE ON public.call_statistics
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Индексы для производительности
CREATE INDEX idx_call_statistics_user_date ON public.call_statistics(user_id, date);
CREATE INDEX idx_call_records_user_date ON public.call_records(user_id, call_date);
CREATE INDEX idx_call_records_sipuni_id ON public.call_records(sipuni_call_id);