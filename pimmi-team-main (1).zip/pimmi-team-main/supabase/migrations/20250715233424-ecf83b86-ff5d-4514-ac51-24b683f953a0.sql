-- Проверяем и применяем политику для руководителей ИИ отдела
DO $$
BEGIN
  -- Проверяем существует ли уже политика
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'project_categories' 
    AND policyname = 'AI leads can view categories'
  ) THEN
    -- Создаем политику если её нет
    EXECUTE 'CREATE POLICY "AI leads can view categories" ON public.project_categories FOR SELECT USING (is_ai_lead())';
  END IF;
END $$;