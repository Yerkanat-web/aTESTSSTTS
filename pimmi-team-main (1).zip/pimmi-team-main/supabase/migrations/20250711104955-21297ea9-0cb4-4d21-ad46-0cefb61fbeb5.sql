-- Update employee_stats_view to convert minutes to hours for backward compatibility
DROP VIEW IF EXISTS employee_stats_view;

CREATE VIEW employee_stats_view AS
SELECT 
  e.id,
  ep.total_points,
  COUNT(et.id) as total_tasks,
  COUNT(CASE WHEN et.status = 'completed' THEN 1 END) as completed_tasks,
  -- Convert minutes to hours for display (sum all actual_minutes and divide by 60)
  COALESCE(SUM(CASE WHEN et.status = 'completed' THEN et.actual_minutes END), 0) / 60 as total_hours,
  CASE 
    WHEN COUNT(et.id) > 0 THEN 
      ROUND((COUNT(CASE WHEN et.status = 'completed' THEN 1 END)::numeric / COUNT(et.id)::numeric) * 100, 2)
    ELSE 0 
  END as efficiency,
  e.name,
  e.email,
  e.position,
  e.department,
  e.role,
  e.status
FROM employees e
LEFT JOIN employee_points ep ON e.id = ep.employee_id
LEFT JOIN employee_tasks et ON e.id = et.employee_id
GROUP BY e.id, e.name, e.email, e.position, e.department, e.role, e.status, ep.total_points;