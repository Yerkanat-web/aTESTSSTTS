
-- Найдем и удалим дублированную запись Dream Mebel (оставим самую раннюю по дате создания)
DELETE FROM sales_results 
WHERE id IN (
  SELECT id 
  FROM (
    SELECT id, 
           ROW_NUMBER() OVER (PARTITION BY client_name, project_name, employee_id ORDER BY created_at) as rn
    FROM sales_results 
    WHERE client_name = 'Dream Mebel'
  ) ranked 
  WHERE rn > 1
);
