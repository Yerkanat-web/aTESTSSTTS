-- Update employee_stats_view to keep total minutes instead of converting to hours
DROP VIEW IF EXISTS employee_stats_view;

CREATE VIEW employee_stats_view AS
SELECT 
  e.id,
  ep.total_points,
  COUNT(et.id) as total_tasks,
  COUNT(CASE WHEN et.status = 'completed' THEN 1 END) as completed_tasks,
  -- Keep total_hours as decimal hours for backward compatibility, but also add total_minutes
  COALESCE(SUM(CASE WHEN et.status = 'completed' THEN et.actual_minutes END), 0) as total_minutes,
  COALESCE(SUM(CASE WHEN et.status = 'completed' THEN et.actual_minutes END), 0)::numeric / 60 as total_hours,
  CASE 
    WHEN COUNT(et.id) > 0 THEN 
      ROUND((COUNT(CASE WHEN et.status = 'completed' THEN 1 END)::numeric / COUNT(et.id)::numeric) * 100, 2)
    ELSE 0 
  END as efficiency,
  e.name,
  e.email,
  e.position,
  e.department,
  e.role,
  e.status
FROM employees e
LEFT JOIN employee_points ep ON e.id = ep.employee_id
LEFT JOIN employee_tasks et ON e.id = et.employee_id
GROUP BY e.id, e.name, e.email, e.position, e.department, e.role, e.status, ep.total_points;