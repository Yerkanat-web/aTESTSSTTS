-- Добавляем политики для удаления связанных данных проектов руководителями тех отдела

-- Политика для удаления задач проектов
CREATE POLICY "Tech leads can delete project tasks" 
ON public.project_tasks 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND role = 'руководитель тех отдела' 
    AND status = 'active'
  )
);

-- Политика для удаления ежемесячных платежей
CREATE POLICY "Tech leads can delete monthly payments" 
ON public.monthly_payments 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND role = 'руководитель тех отдела' 
    AND status = 'active'
  )
);

-- Политика для удаления аккаунтов проектов
CREATE POLICY "Tech leads can delete project accounts" 
ON public.project_accounts 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND role = 'руководитель тех отдела' 
    AND status = 'active'
  )
);