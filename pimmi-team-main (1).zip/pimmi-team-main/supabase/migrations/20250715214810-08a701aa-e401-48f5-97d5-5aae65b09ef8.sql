-- Обновляем роли руководителей
UPDATE public.employees 
SET role = 'руководитель тех отдела', updated_at = now()
WHERE email IN ('almagul.turdumuratova@mail.ru', 'marlmuratov@yandex.kz');

UPDATE public.employees 
SET role = 'руководитель ИИ отдела', updated_at = now()
WHERE email = 'nurtaibalnur2003@gmail.com';

UPDATE public.employees 
SET role = 'руководитель отдела продаж', updated_at = now()
WHERE email = 'zhanbakitovnaa@gmail.com';