-- Разрешаем руководителям тех отдела обновлять статус проектов
CREATE POLICY "Tech leads can update project status" 
ON sales_results 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.user_id = auth.uid() 
    AND employees.role = 'руководитель тех отдела'
    AND employees.status = 'active'
  )
);