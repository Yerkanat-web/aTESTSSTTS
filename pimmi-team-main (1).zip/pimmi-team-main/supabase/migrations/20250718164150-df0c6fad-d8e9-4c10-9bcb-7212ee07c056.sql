-- Добавляем политику для создания продлений проектов руководителями
CREATE POLICY "Department leads can create project extensions" 
ON public.sales_results 
FOR INSERT 
WITH CHECK (
  is_extension = true AND
  EXISTS (
    SELECT 1
    FROM employees
    WHERE employees.user_id = auth.uid()
    AND employees.role IN (
      'руководитель тех отдела',
      'руководитель отдела продаж', 
      'руководитель ИИ отдела'
    )
    AND employees.status = 'active'
  )
);