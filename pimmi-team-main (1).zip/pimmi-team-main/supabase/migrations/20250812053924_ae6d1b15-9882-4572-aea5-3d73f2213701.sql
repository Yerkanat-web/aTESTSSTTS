
-- 1) Тип ролей в организации
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'org_role') THEN
    CREATE TYPE public.org_role AS ENUM ('owner', 'admin', 'member', 'viewer');
  END IF;
END$$;

-- 2) Таблицы организаций и членств
CREATE TABLE IF NOT EXISTS public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.organization_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  -- Привязываем к public.profiles (а не к auth.users) согласно рекомендациям
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  org_role public.org_role NOT NULL DEFAULT 'member',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (org_id, user_id)
);

-- Обновление updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'organizations_set_updated_at'
  ) THEN
    CREATE TRIGGER organizations_set_updated_at
    BEFORE UPDATE ON public.organizations
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
  END IF;
END$$;

-- 3) Функции для орг-изоляции и дефолтной орг
CREATE OR REPLACE FUNCTION public.has_org_membership(_org_id uuid, _user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.organization_members
    WHERE org_id = _org_id AND user_id = _user_id
  );
$$;

CREATE OR REPLACE FUNCTION public.has_org_role(_org_id uuid, _role text, _user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  /* Логика: owner >= admin >= member >= viewer */
  SELECT EXISTS (
    SELECT 1
    FROM public.organization_members om
    WHERE om.org_id = _org_id
      AND om.user_id = _user_id
      AND (
        om.org_role = 'owner'::public.org_role OR
        (om.org_role = 'admin'::public.org_role AND _role IN ('admin','member','viewer')) OR
        (om.org_role = 'member'::public.org_role AND _role IN ('member','viewer')) OR
        (om.org_role = 'viewer'::public.org_role AND _role = 'viewer')
      )
  );
$$;

CREATE OR REPLACE FUNCTION public.get_user_default_org(_user_id uuid DEFAULT auth.uid())
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT om.org_id
  FROM public.organization_members om
  WHERE om.user_id = _user_id
  ORDER BY om.created_at ASC
  LIMIT 1
$$;

-- 4) RLS для organizations / organization_members
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;

-- Члены могут видеть свои организации
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Members can view their orgs' AND tablename = 'organizations') THEN
    CREATE POLICY "Members can view their orgs"
      ON public.organizations
      FOR SELECT
      USING (public.has_org_membership(id));
  END IF;
END$$;

-- Владелец/админ могут обновлять организацию
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Owners/Admins can update org' AND tablename = 'organizations') THEN
    CREATE POLICY "Owners/Admins can update org"
      ON public.organizations
      FOR UPDATE
      USING (public.has_org_role(id, 'admin'));
  END IF;
END$$;

-- Удалять организацию — только owner
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Owners can delete org' AND tablename = 'organizations') THEN
    CREATE POLICY "Owners can delete org"
      ON public.organizations
      FOR DELETE
      USING (public.has_org_role(id, 'owner'));
  END IF;
END$$;

-- Создать организацию может любой аутентифицированный (для будущего сценария self-serve)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Authenticated can create org' AND tablename = 'organizations') THEN
    CREATE POLICY "Authenticated can create org"
      ON public.organizations
      FOR INSERT
      WITH CHECK (auth.uid() IS NOT NULL);
  END IF;
END$$;

-- Члены видят свои membership'ы
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Members can view own memberships' AND tablename = 'organization_members') THEN
    CREATE POLICY "Members can view own memberships"
      ON public.organization_members
      FOR SELECT
      USING (auth.uid() = user_id);
  END IF;
END$$;

-- Админы/владельцы управляют членствами своей орг
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Admins/Owners can manage memberships' AND tablename = 'organization_members') THEN
    CREATE POLICY "Admins/Owners can manage memberships"
      ON public.organization_members
      FOR ALL
      USING (public.has_org_role(org_id, 'admin'))
      WITH CHECK (public.has_org_role(org_id, 'admin'));
  END IF;
END$$;

-- 5) Авто-присвоение создателя как owner (на будущее)
CREATE OR REPLACE FUNCTION public.add_creator_as_owner()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN
    INSERT INTO public.organization_members (org_id, user_id, org_role)
    VALUES (NEW.id, auth.uid(), 'owner')
    ON CONFLICT (org_id, user_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'organizations_add_creator_as_owner'
  ) THEN
    CREATE TRIGGER organizations_add_creator_as_owner
    AFTER INSERT ON public.organizations
    FOR EACH ROW EXECUTE PROCEDURE public.add_creator_as_owner();
  END IF;
END$$;

-- 6) Создаем дефолтную организацию и назначаем владельца
INSERT INTO public.organizations (name)
VALUES ('Main Company')
ON CONFLICT (name) DO NOTHING;

-- Назначаем владельца, если админ с таким email существует в profiles
INSERT INTO public.organization_members (org_id, user_id, org_role)
SELECT o.id, p.id, 'owner'
FROM public.organizations o
JOIN public.profiles p ON p.email = 'admin@demo.kz'
WHERE o.name = 'Main Company'
ON CONFLICT (org_id, user_id) DO NOTHING;

-- 7) Добавление org_id в бизнес-таблицы, бэкофилл и ограничения
-- Удобный helper для получения id "Main Company"
WITH default_org AS (
  SELECT id FROM public.organizations WHERE name = 'Main Company'
)
-- employees
UPDATE public.employees e
SET updated_at = e.updated_at -- no-op to allow CTE scope
WHERE FALSE;

ALTER TABLE public.employees ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.employees SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.employees ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.employees ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.employees
  ADD CONSTRAINT IF NOT EXISTS employees_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_employees_org_id ON public.employees(org_id);

-- employee_points
ALTER TABLE public.employee_points ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.employee_points SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.employee_points ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.employee_points ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.employee_points
  ADD CONSTRAINT IF NOT EXISTS employee_points_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_employee_points_org_id ON public.employee_points(org_id);

-- employee_tasks
ALTER TABLE public.employee_tasks ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.employee_tasks SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.employee_tasks ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.employee_tasks ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.employee_tasks
  ADD CONSTRAINT IF NOT EXISTS employee_tasks_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_employee_tasks_org_id ON public.employee_tasks(org_id);

-- employee_achievements
ALTER TABLE public.employee_achievements ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.employee_achievements SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.employee_achievements ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.employee_achievements ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.employee_achievements
  ADD CONSTRAINT IF NOT EXISTS employee_achievements_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_employee_achievements_org_id ON public.employee_achievements(org_id);

-- employee_activity_logs
ALTER TABLE public.employee_activity_logs ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.employee_activity_logs SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.employee_activity_logs ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.employee_activity_logs ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.employee_activity_logs
  ADD CONSTRAINT IF NOT EXISTS employee_activity_logs_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_employee_activity_logs_org_id ON public.employee_activity_logs(org_id);

-- daily_reports
ALTER TABLE public.daily_reports ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.daily_reports SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.daily_reports ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.daily_reports ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.daily_reports
  ADD CONSTRAINT IF NOT EXISTS daily_reports_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_daily_reports_org_id ON public.daily_reports(org_id);

-- sales_results
ALTER TABLE public.sales_results ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.sales_results SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.sales_results ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.sales_results ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.sales_results
  ADD CONSTRAINT IF NOT EXISTS sales_results_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_sales_results_org_id ON public.sales_results(org_id);

-- monthly_payments
ALTER TABLE public.monthly_payments ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.monthly_payments SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.monthly_payments ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.monthly_payments ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.monthly_payments
  ADD CONSTRAINT IF NOT EXISTS monthly_payments_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_monthly_payments_org_id ON public.monthly_payments(org_id);

-- project_tasks
ALTER TABLE public.project_tasks ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.project_tasks SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.project_tasks ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.project_tasks ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.project_tasks
  ADD CONSTRAINT IF NOT EXISTS project_tasks_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_org_id ON public.project_tasks(org_id);

-- project_accounts
ALTER TABLE public.project_accounts ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.project_accounts SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.project_accounts ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.project_accounts ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.project_accounts
  ADD CONSTRAINT IF NOT EXISTS project_accounts_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_project_accounts_org_id ON public.project_accounts(org_id);

-- project_categories
ALTER TABLE public.project_categories ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.project_categories SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.project_categories ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.project_categories ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.project_categories
  ADD CONSTRAINT IF NOT EXISTS project_categories_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_project_categories_org_id ON public.project_categories(org_id);

-- project_cases
ALTER TABLE public.project_cases ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.project_cases SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.project_cases ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.project_cases ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.project_cases
  ADD CONSTRAINT IF NOT EXISTS project_cases_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_project_cases_org_id ON public.project_cases(org_id);

-- shop_purchases
ALTER TABLE public.shop_purchases ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.shop_purchases SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.shop_purchases ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.shop_purchases ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.shop_purchases
  ADD CONSTRAINT IF NOT EXISTS shop_purchases_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_shop_purchases_org_id ON public.shop_purchases(org_id);

-- sales_targets
ALTER TABLE public.sales_targets ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.sales_targets SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.sales_targets ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.sales_targets ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.sales_targets
  ADD CONSTRAINT IF NOT EXISTS sales_targets_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_sales_targets_org_id ON public.sales_targets(org_id);

-- call_records
ALTER TABLE public.call_records ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.call_records SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.call_records ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.call_records ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.call_records
  ADD CONSTRAINT IF NOT EXISTS call_records_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_call_records_org_id ON public.call_records(org_id);

-- call_statistics
ALTER TABLE public.call_statistics ADD COLUMN IF NOT EXISTS org_id UUID;
UPDATE public.call_statistics SET org_id = (SELECT id FROM public.organizations WHERE name = 'Main Company') WHERE org_id IS NULL;
ALTER TABLE public.call_statistics ALTER COLUMN org_id SET DEFAULT public.get_user_default_org();
ALTER TABLE public.call_statistics ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.call_statistics
  ADD CONSTRAINT IF NOT EXISTS call_statistics_org_id_fkey
  FOREIGN KEY (org_id) REFERENCES public.organizations(id);
CREATE INDEX IF NOT EXISTS idx_call_statistics_org_id ON public.call_statistics(org_id);

-- 8) Добавляем RESTRICTIVE RLS-политику "Org membership required" для всех таблиц с org_id
-- Функция: добавляем, только если еще нет

-- helper DO block to create restrictive policies
DO $$
DECLARE
  t TEXT;
  tables TEXT[] := ARRAY[
    'employees',
    'employee_points',
    'employee_tasks',
    'employee_achievements',
    'employee_activity_logs',
    'daily_reports',
    'sales_results',
    'monthly_payments',
    'project_tasks',
    'project_accounts',
    'project_categories',
    'project_cases',
    'shop_purchases',
    'sales_targets',
    'call_records',
    'call_statistics'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', t);
    IF NOT EXISTS (
      SELECT 1 FROM pg_policies 
      WHERE schemaname = 'public' AND tablename = t AND policyname = 'Org membership required'
    ) THEN
      EXECUTE format(
        'CREATE POLICY "Org membership required" ON public.%I AS RESTRICTIVE FOR ALL
         USING (public.has_org_membership(org_id))
         WITH CHECK (public.has_org_membership(org_id));', t
      );
    END IF;
  END LOOP;
END$$;

-- Готово: все существующие политики теперь пересекаются с требованием членства в организации
