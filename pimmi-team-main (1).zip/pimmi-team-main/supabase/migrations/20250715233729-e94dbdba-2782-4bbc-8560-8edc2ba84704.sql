UPDATE employees 
SET role = 'руководитель ИИ отдела', 
    updated_at = now()
WHERE email = 'nurtaibalnur2003@mail.ru';