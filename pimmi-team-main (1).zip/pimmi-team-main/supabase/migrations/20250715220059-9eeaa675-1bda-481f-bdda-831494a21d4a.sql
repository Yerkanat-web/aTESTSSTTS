-- Удаляем проблемную политику которая вызывает рекурсию
DROP POLICY IF EXISTS "Department leads can view their department employees" ON employees;

-- Создаем простую политику без рекурсии
CREATE POLICY "Simple employee access" 
ON employees 
FOR SELECT 
USING (
  CASE 
    WHEN auth.uid() IS NULL THEN false
    WHEN is_admin() THEN true
    ELSE auth.uid() = user_id
  END
);

-- Создаем функцию для безопасного получения информации о сотруднике
CREATE OR REPLACE FUNCTION public.get_employee_by_user_id(check_user_id uuid DEFAULT auth.uid())
RETURNS TABLE (
  id uuid,
  name text,
  email text,
  position text,
  department text,
  role text,
  status text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT e.id, e.name, e.email, e.position, e.department, e.role, e.status
  FROM employees e
  WHERE e.user_id = check_user_id
  AND e.status = 'active';
$$;

-- Создаем функцию для руководителей отделов
CREATE OR REPLACE FUNCTION public.get_department_employees(manager_user_id uuid DEFAULT auth.uid())
RETURNS TABLE (
  id uuid,
  name text,
  email text,
  position text,
  department text,
  role text,
  status text,
  user_id uuid
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT e.id, e.name, e.email, e.position, e.department, e.role, e.status, e.user_id
  FROM employees e
  WHERE EXISTS (
    SELECT 1
    FROM employees manager
    WHERE manager.user_id = manager_user_id
    AND (
      (manager.role = 'руководитель тех отдела' AND e.department = 'тех отдел') OR
      (manager.role = 'руководитель отдела продаж' AND e.department = 'отдел продаж') OR
      (manager.role = 'руководитель ИИ отдела' AND e.department = 'креатив отдел') OR
      manager.role = 'admin'
    )
  )
  AND e.status = 'active';
$$;