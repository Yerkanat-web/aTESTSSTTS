-- Remove the restrictive policy for employees
DROP POLICY IF EXISTS "Employees can view their project accounts" ON public.project_accounts;

-- Create new policy allowing all employees to view all project accounts
CREATE POLICY "All employees can view project accounts" 
ON public.project_accounts 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE user_id = auth.uid() 
  AND role = 'employee'
));