-- Исправляем функцию создания ежемесячных платежей для продлений
CREATE OR REPLACE FUNCTION public.create_extension_monthly_payment()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  -- Только для продлений проектов
  IF NEW.is_extension = TRUE THEN
    -- Создаем ежемесячный платеж с фактическими значениями из продления
    INSERT INTO monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      prepayment,
      remainder,
      remainder_due_date,
      status
    ) VALUES (
      NEW.id,
      NEW.sale_date + INTERVAL '1 month', -- Первый платеж через месяц
      NEW.sale_amount,     -- Фактическая сумма продления (не делим на 12)
      NEW.prepayment,      -- Фактическая предоплата из продления
      NEW.remainder,       -- Фактический остаток из продления (должен быть 0 для полных предоплат)
      NEW.remainder_due_date,
      CASE 
        WHEN NEW.remainder <= 0 THEN 'paid'  -- Если остатка нет, сразу помечаем как оплаченный
        ELSE 'pending'
      END
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Обновляем существующие записи monthly_payments для продлений, где сумма неправильная
UPDATE monthly_payments 
SET 
  amount = sr.sale_amount,
  prepayment = sr.prepayment,
  remainder = sr.remainder
FROM sales_results sr 
WHERE monthly_payments.sales_result_id = sr.id 
  AND sr.is_extension = true 
  AND monthly_payments.amount != sr.sale_amount;