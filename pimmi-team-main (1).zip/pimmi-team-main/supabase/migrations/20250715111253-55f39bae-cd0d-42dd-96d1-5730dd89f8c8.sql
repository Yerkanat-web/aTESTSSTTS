-- Изменить таблицу project_tasks, чтобы sales_result_id мог быть NULL
ALTER TABLE project_tasks 
ALTER COLUMN sales_result_id DROP NOT NULL;

-- Обновить внешний ключ, чтобы он не требовал NOT NULL
ALTER TABLE project_tasks 
DROP CONSTRAINT project_tasks_sales_result_id_fkey;

ALTER TABLE project_tasks 
ADD CONSTRAINT project_tasks_sales_result_id_fkey 
FOREIGN KEY (sales_result_id) 
REFERENCES sales_results(id) 
ON DELETE CASCADE;