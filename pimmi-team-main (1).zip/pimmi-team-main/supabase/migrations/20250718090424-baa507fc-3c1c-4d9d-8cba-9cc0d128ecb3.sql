-- Обновляем существующие ежемесячные платежи для продлений
-- чтобы они показывали правильные значения из sales_results
UPDATE monthly_payments 
SET 
  amount = sr.sale_amount,
  prepayment = sr.prepayment,
  remainder = sr.remainder,
  updated_at = now()
FROM sales_results sr
WHERE monthly_payments.sales_result_id = sr.id
  AND sr.is_extension = true;