-- Сначала удаляем старое ограничение на роли
ALTER TABLE employees DROP CONSTRAINT IF EXISTS employees_role_check;

-- Добавляем новое ограничение, включающее роль финансист
ALTER TABLE employees ADD CONSTRAINT employees_role_check 
CHECK (role IN ('admin', 'employee', 'финансист'));

-- Теперь обновляем роль Арай на финансист
UPDATE employees 
SET role = 'финансист', 
    updated_at = now()
WHERE email = 'aakmyrzaevva@gmail.com';