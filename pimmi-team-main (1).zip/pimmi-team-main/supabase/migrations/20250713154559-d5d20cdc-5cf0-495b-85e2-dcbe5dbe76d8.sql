-- Create project_tasks table
CREATE TABLE public.project_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sales_result_id UUID NOT NULL REFERENCES sales_results(id) ON DELETE CASCADE,
  task_name TEXT NOT NULL,
  task_type TEXT NOT NULL,
  assignee_id UUID REFERENCES employees(id),
  due_date DATE,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add tasks_generated column to sales_results
ALTER TABLE sales_results 
ADD COLUMN tasks_generated BOOLEAN DEFAULT false;

-- Enable RLS for project_tasks
ALTER TABLE project_tasks ENABLE ROW LEVEL SECURITY;

-- Create policies for project_tasks
CREATE POLICY "Admins can manage all project tasks" 
ON project_tasks 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their assigned tasks" 
ON project_tasks 
FOR SELECT 
USING (
  assignee_id IN (
    SELECT id FROM employees WHERE user_id = auth.uid()
  )
);

-- Add trigger for updated_at
CREATE TRIGGER update_project_tasks_updated_at
BEFORE UPDATE ON project_tasks
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Add index for performance
CREATE INDEX idx_project_tasks_sales_result_id ON project_tasks(sales_result_id);
CREATE INDEX idx_project_tasks_assignee_id ON project_tasks(assignee_id);