-- Создаем функцию для автоматического присуждения достижений по продажам
CREATE OR REPLACE FUNCTION public.check_sales_achievements(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  employee_dept text;
  total_leads integer := 0;
  qualified_leads integer := 0;
  total_reports integer := 0;
  total_sales integer := 0;
  total_sale_amount numeric := 0;
BEGIN
  -- Проверяем, что сотрудник из отдела продаж
  SELECT department INTO employee_dept
  FROM employees 
  WHERE id = emp_id;
  
  IF employee_dept != 'отдел продаж' THEN
    RETURN;
  END IF;
  
  -- Получаем статистику по лидам и отчетам
  SELECT 
    COALESCE(SUM(leads_count), 0),
    COALESCE(SUM(qualified_leads_count), 0),
    COUNT(*)
  INTO total_leads, qualified_leads, total_reports
  FROM daily_reports 
  WHERE employee_id = emp_id;
  
  -- Получаем статистику по продажам
  SELECT 
    COUNT(*),
    COALESCE(SUM(sale_amount), 0)
  INTO total_sales, total_sale_amount
  FROM sales_results 
  WHERE employee_id = emp_id;
  
  -- Достижения по лидам
  IF total_leads >= 1 THEN
    PERFORM award_achievement_safely(emp_id, 'Первый лид', 'Обработал первого лида', 50);
  END IF;
  
  IF total_leads >= 10 THEN
    PERFORM award_achievement_safely(emp_id, 'Охотник за лидами', 'Обработал 10 лидов', 100);
  END IF;
  
  IF total_leads >= 50 THEN
    PERFORM award_achievement_safely(emp_id, 'Мастер лидогенерации', 'Обработал 50 лидов', 200);
  END IF;
  
  IF total_leads >= 100 THEN
    PERFORM award_achievement_safely(emp_id, 'Лидерный магнат', 'Обработал 100 лидов', 300);
  END IF;
  
  -- Достижения по квалифицированным лидам
  IF qualified_leads >= 5 THEN
    PERFORM award_achievement_safely(emp_id, 'Квалификатор', 'Получил 5 квалифицированных лидов', 75);
  END IF;
  
  IF qualified_leads >= 25 THEN
    PERFORM award_achievement_safely(emp_id, 'Эксперт отбора', 'Получил 25 квалифицированных лидов', 150);
  END IF;
  
  -- Достижения по отчетам
  IF total_reports >= 1 THEN
    PERFORM award_achievement_safely(emp_id, 'Первый отчет', 'Создал первый отчет', 30);
  END IF;
  
  IF total_reports >= 7 THEN
    PERFORM award_achievement_safely(emp_id, 'Недельная отчетность', 'Создал 7 отчетов', 100);
  END IF;
  
  IF total_reports >= 30 THEN
    PERFORM award_achievement_safely(emp_id, 'Месячная дисциплина', 'Создал 30 отчетов', 200);
  END IF;
  
  IF total_reports >= 90 THEN
    PERFORM award_achievement_safely(emp_id, 'Мастер отчетности', 'Создал 90 отчетов', 300);
  END IF;
  
  -- Достижения по продажам
  IF total_sales >= 1 THEN
    PERFORM award_achievement_safely(emp_id, 'Первая продажа', 'Закрыл первую сделку', 120);
  END IF;
  
  IF total_sales >= 5 THEN
    PERFORM award_achievement_safely(emp_id, 'Продавец-новичок', 'Закрыл 5 сделок', 250);
  END IF;
  
  IF total_sales >= 10 THEN
    PERFORM award_achievement_safely(emp_id, 'Опытный продавец', 'Закрыл 10 сделок', 400);
  END IF;
  
  IF total_sales >= 25 THEN
    PERFORM award_achievement_safely(emp_id, 'Мастер продаж', 'Закрыл 25 сделок', 600);
  END IF;
  
  IF total_sales >= 50 THEN
    PERFORM award_achievement_safely(emp_id, 'Легенда продаж', 'Закрыл 50 сделок', 1000);
  END IF;
  
  -- Достижения по сумме продаж
  IF total_sale_amount >= 100000 THEN
    PERFORM award_achievement_safely(emp_id, 'Первые 100К', 'Продажи на 100,000 тенге', 150);
  END IF;
  
  IF total_sale_amount >= 500000 THEN
    PERFORM award_achievement_safely(emp_id, 'Полумиллионер', 'Продажи на 500,000 тенге', 300);
  END IF;
  
  IF total_sale_amount >= 1000000 THEN
    PERFORM award_achievement_safely(emp_id, 'Миллионер', 'Продажи на 1,000,000 тенге', 500);
  END IF;
  
  IF total_sale_amount >= 2000000 THEN
    PERFORM award_achievement_safely(emp_id, 'Двукратный миллионер', 'Продажи на 2,000,000 тенге', 750);
  END IF;
  
  IF total_sale_amount >= 5000000 THEN
    PERFORM award_achievement_safely(emp_id, 'Золотой продавец', 'Продажи на 5,000,000 тенге', 1200);
  END IF;
  
  -- Комбинированные достижения
  IF total_sales >= 10 AND qualified_leads >= 20 THEN
    PERFORM award_achievement_safely(emp_id, 'Эффективный менеджер', 'Высокие показатели продаж и лидов', 400);
  END IF;
  
  IF total_reports >= 30 AND total_sales >= 15 THEN
    PERFORM award_achievement_safely(emp_id, 'Дисциплинированный продавец', 'Регулярные отчеты и продажи', 350);
  END IF;
  
END;
$$;

-- Обновляем триггеры для проверки достижений
CREATE OR REPLACE FUNCTION public.update_points_on_sales()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Пересчитываем баллы при добавлении или удалении продаж
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_employee_points(NEW.employee_id);
    -- Проверяем достижения
    PERFORM check_sales_achievements(NEW.employee_id);
    RETURN NEW;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    PERFORM calculate_employee_points(OLD.employee_id);
    -- Проверяем достижения (они могут быть отозваны если нужно)
    PERFORM check_sales_achievements(OLD.employee_id);
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_points_on_reports()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Пересчитываем баллы при добавлении или удалении отчетов
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_employee_points(NEW.employee_id);
    -- Проверяем достижения
    PERFORM check_sales_achievements(NEW.employee_id);
    RETURN NEW;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    PERFORM calculate_employee_points(OLD.employee_id);
    -- Проверяем достижения
    PERFORM check_sales_achievements(OLD.employee_id);
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Пересоздаем триггеры с обновленными функциями
DROP TRIGGER IF EXISTS sales_points_trigger ON sales_results;
DROP TRIGGER IF EXISTS reports_points_trigger ON daily_reports;

CREATE TRIGGER sales_points_trigger
  AFTER INSERT OR UPDATE OR DELETE ON sales_results
  FOR EACH ROW
  EXECUTE FUNCTION update_points_on_sales();

CREATE TRIGGER reports_points_trigger
  AFTER INSERT OR UPDATE OR DELETE ON daily_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_points_on_reports();

-- Проверяем достижения для всех существующих сотрудников отдела продаж
DO $$
DECLARE
  emp RECORD;
BEGIN
  FOR emp IN SELECT id FROM employees WHERE status = 'active' AND department = 'отдел продаж'
  LOOP
    PERFORM check_sales_achievements(emp.id);
  END LOOP;
END $$;