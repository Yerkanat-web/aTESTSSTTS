-- Удаляем все продления проекта "Принтер"
DELETE FROM public.sales_results 
WHERE is_extension = true 
  AND (
    project_name LIKE '%Принтер%' OR 
    description LIKE '%Принтер%' OR
    parent_project_id IN (
      SELECT id FROM public.sales_results 
      WHERE project_name LIKE '%Принтер%' AND is_extension = false
    )
  );