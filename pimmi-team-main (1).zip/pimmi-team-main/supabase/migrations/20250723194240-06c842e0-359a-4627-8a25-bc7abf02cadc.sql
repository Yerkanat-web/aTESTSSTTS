-- Remove the problematic policy that causes infinite recursion
DROP POLICY IF EXISTS "Financists can view all employees for analytics" ON public.employees;

-- Create a security definer function to check if user is financist
CREATE OR REPLACE FUNCTION public.is_financist(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = check_user_id
    AND role = 'финансист'
    AND status = 'active'
  );
$$;

-- Create proper policy using the security definer function
CREATE POLICY "Financists can view all employees for analytics" 
ON public.employees 
FOR SELECT 
USING (is_financist());