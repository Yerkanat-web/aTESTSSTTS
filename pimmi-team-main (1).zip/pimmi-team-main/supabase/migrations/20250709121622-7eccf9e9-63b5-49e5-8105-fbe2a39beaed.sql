-- Создаем таблицу для планов продаж сотрудников
CREATE TABLE public.sales_targets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL,
  target_amount NUMERIC NOT NULL DEFAULT 0,
  target_period DATE NOT NULL, -- месяц/год для плана
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Создаем таблицу для фактических продаж сотрудников
CREATE TABLE public.sales_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL,
  sale_amount NUMERIC NOT NULL DEFAULT 0,
  sale_date DATE NOT NULL,
  client_name TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Создаем таблицу для достижений сотрудников
CREATE TABLE public.employee_achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL,
  achievement_name TEXT NOT NULL,
  description TEXT,
  points INTEGER NOT NULL DEFAULT 0,
  earned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Включаем RLS для всех таблиц
ALTER TABLE public.sales_targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_achievements ENABLE ROW LEVEL SECURITY;

-- Политики для sales_targets
CREATE POLICY "Admins can manage sales targets" 
ON public.sales_targets 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their own targets" 
ON public.sales_targets 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = sales_targets.employee_id 
  AND employees.user_id = auth.uid()
));

-- Политики для sales_results
CREATE POLICY "Admins can manage sales results" 
ON public.sales_results 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their own results" 
ON public.sales_results 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = sales_results.employee_id 
  AND employees.user_id = auth.uid()
));

CREATE POLICY "Employees can insert their own results" 
ON public.sales_results 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = sales_results.employee_id 
  AND employees.user_id = auth.uid()
));

-- Политики для employee_achievements
CREATE POLICY "Admins can manage achievements" 
ON public.employee_achievements 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their own achievements" 
ON public.employee_achievements 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = employee_achievements.employee_id 
  AND employees.user_id = auth.uid()
));

-- Создаем триггеры для автоматического обновления updated_at
CREATE TRIGGER update_sales_targets_updated_at
BEFORE UPDATE ON public.sales_targets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_sales_results_updated_at
BEFORE UPDATE ON public.sales_results
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Создаем индексы для лучшей производительности
CREATE INDEX idx_sales_targets_employee_period ON public.sales_targets(employee_id, target_period);
CREATE INDEX idx_sales_results_employee_date ON public.sales_results(employee_id, sale_date);
CREATE INDEX idx_employee_achievements_employee ON public.employee_achievements(employee_id);

-- Добавляем тестовые данные для работы системы
INSERT INTO public.sales_targets (employee_id, target_amount, target_period)
SELECT 
  e.id,
  CASE 
    WHEN e.department = 'Продажи' THEN 500000 + (RANDOM() * 500000)::INTEGER
    ELSE 0
  END,
  DATE_TRUNC('month', CURRENT_DATE)::DATE
FROM employees e
WHERE e.department = 'Продажи';

-- Добавляем тестовые продажи за последние дни
INSERT INTO public.sales_results (employee_id, sale_amount, sale_date, client_name, description)
SELECT 
  e.id,
  (50000 + RANDOM() * 200000)::INTEGER,
  CURRENT_DATE - (RANDOM() * 30)::INTEGER,
  'Клиент ' || (RANDOM() * 100)::INTEGER,
  'Продажа услуг'
FROM employees e
WHERE e.department = 'Продажи'
AND RANDOM() < 0.7; -- 70% вероятность продажи

-- Добавляем еще несколько продаж для последних 5 дней
INSERT INTO public.sales_results (employee_id, sale_amount, sale_date, client_name, description)
SELECT 
  e.id,
  (30000 + RANDOM() * 150000)::INTEGER,
  CURRENT_DATE - (RANDOM() * 5)::INTEGER,
  'Клиент ' || (RANDOM() * 100)::INTEGER,
  'Дополнительная продажа'
FROM employees e
WHERE e.department = 'Продажи'
AND RANDOM() < 0.5; -- 50% вероятность дополнительной продажи