-- Create project_cases table for sales team
CREATE TABLE public.project_cases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_name TEXT NOT NULL,
  category TEXT NOT NULL,
  services TEXT[] NOT NULL DEFAULT '{}',
  point_a_description TEXT,
  our_work_description TEXT,
  point_b_description TEXT,
  result_screenshots TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Enable Row Level Security
ALTER TABLE public.project_cases ENABLE ROW LEVEL SECURITY;

-- Create policies for project_cases
CREATE POLICY "Sales employees can view active cases" 
ON public.project_cases 
FOR SELECT 
USING (
  is_active = true AND 
  EXISTS (
    SELECT 1 FROM employees 
    WHERE user_id = auth.uid() 
    AND department = 'отдел продаж'
  )
);

CREATE POLICY "Admins can manage all cases" 
ON public.project_cases 
FOR ALL 
USING (is_admin());

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_project_cases_updated_at
BEFORE UPDATE ON public.project_cases
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert some demo cases
INSERT INTO public.project_cases (
  project_name,
  category,
  services,
  point_a_description,
  our_work_description,
  point_b_description,
  result_screenshots
) VALUES 
(
  'Интернет-магазин ElectroShop',
  'E-commerce',
  ARRAY['сайт', 'таргет', 'срм'],
  'Компания продавала электронику через Instagram, без собственного сайта. Конверсия была низкой, много времени тратилось на обработку заказов вручную.',
  'Создали современный интернет-магазин с удобной навигацией, интегрировали CRM для автоматизации процессов, настроили таргетированную рекламу в соцсетях.',
  'Увеличение продаж на 340%, автоматизация 80% процессов, рост конверсии с 1.2% до 4.8%. ROI рекламы составил 380%.',
  ARRAY['https://example.com/screenshot1.jpg', 'https://example.com/screenshot2.jpg']
),
(
  'Медицинский центр "Здоровье+"',
  'Медицина',
  ARRAY['сайт', 'чатбот', 'таргет'],
  'Клиника принимала записи только по телефону, много пропущенных звонков, отсутствие онлайн-присутствия.',
  'Разработали сайт с онлайн-записью, создали чат-бота для консультаций и записи, запустили таргетированную рекламу.',
  'Рост записей на 250%, снижение нагрузки на администраторов на 60%, увеличение узнаваемости бренда в 3 раза.',
  ARRAY['https://example.com/screenshot3.jpg', 'https://example.com/screenshot4.jpg']
),
(
  'Ресторан "Вкус Азии"',
  'Ресторанный бизнес',
  ARRAY['таргет', 'видео', 'чатбот'],
  'Ресторан работал только на проходимость, низкая узнаваемость, отсутствие системы доставки.',
  'Создали видео-контент для соцсетей, настроили таргетинг на любителей азиатской кухни, внедрили чат-бота для заказов.',
  'Увеличение заказов доставки на 420%, рост подписчиков в Instagram в 5 раз, средний чек вырос на 35%.',
  ARRAY['https://example.com/screenshot5.jpg']
);