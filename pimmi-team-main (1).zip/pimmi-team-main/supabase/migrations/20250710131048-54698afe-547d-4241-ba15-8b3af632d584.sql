-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create policies for task-attachments bucket
CREATE POLICY "Users can upload task attachments" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'task-attachments' 
  AND EXISTS (
    SELECT 1 FROM employees 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can view task attachments" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'task-attachments' 
  AND EXISTS (
    SELECT 1 FROM employees 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Admins can manage all task attachments" 
ON storage.objects 
FOR ALL 
USING (
  bucket_id = 'task-attachments' 
  AND is_admin()
);

CREATE POLICY "Users can delete their own task attachments" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'task-attachments' 
  AND EXISTS (
    SELECT 1 FROM employees 
    WHERE user_id = auth.uid()
  )
);