-- Update check_sales_achievements to use dynamic templates for sales achievements
CREATE OR REPLACE FUNCTION public.check_sales_achievements(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  employee_dept text;
  emp_org uuid;
  total_leads integer := 0;
  qualified_leads integer := 0;
  total_reports integer := 0;
  total_sales integer := 0;
  total_sale_amount numeric := 0;
  tpl record;
BEGIN
  -- Determine department and org for the employee
  SELECT department, org_id INTO employee_dept, emp_org
  FROM public.employees 
  WHERE id = emp_id;
  
  -- Only process for sales department
  IF employee_dept != 'отдел продаж' THEN
    RETURN;
  END IF;
  
  -- Aggregate current sales metrics
  SELECT 
    COALESCE(SUM(leads_count), 0),
    COALESCE(SUM(qualified_leads_count), 0),
    COUNT(*)
  INTO total_leads, qualified_leads, total_reports
  FROM public.daily_reports 
  WHERE employee_id = emp_id;
  
  SELECT 
    COUNT(*),
    COALESCE(SUM(sale_amount), 0)
  INTO total_sales, total_sale_amount
  FROM public.sales_results 
  WHERE employee_id = emp_id;
  
  -- Dynamically award sales achievements based on active templates
  FOR tpl IN 
    SELECT id, name, description, points, condition_type, condition_value
    FROM public.achievement_templates
    WHERE is_active = true
      AND org_id = emp_org
      AND condition_type IN ('sales_count', 'sales_amount')
  LOOP
    IF tpl.condition_type = 'sales_count' AND total_sales >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(
        emp_id,
        tpl.name,
        COALESCE(tpl.description, 'Достижение по продажам'),
        tpl.points
      );
    END IF;
    
    IF tpl.condition_type = 'sales_amount' AND total_sale_amount >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(
        emp_id,
        tpl.name,
        COALESCE(tpl.description, 'Достижение по сумме продаж'),
        tpl.points
      );
    END IF;
  END LOOP;
  
  -- Keep legacy static achievements for backward compatibility
  IF total_leads >= 20 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первый лид', 'Обработал 20 лидов', 50);
  END IF;
  IF total_leads >= 200 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Охотник за лидами', 'Обработал 200 лидов', 100);
  END IF;
  IF total_leads >= 1000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер лидогенерации', 'Обработал 1000 лидов', 200);
  END IF;
  IF total_leads >= 2000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Лидерный магнат', 'Обработал 2000 лидов', 300);
  END IF;
  
  IF qualified_leads >= 100 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Квалификатор', 'Получил 100 квалифицированных лидов', 75);
  END IF;
  IF qualified_leads >= 500 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Эксперт отбора', 'Получил 500 квалифицированных лидов', 150);
  END IF;
  
  IF total_reports >= 1 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первый отчет', 'Создал первый отчет', 30);
  END IF;
  IF total_reports >= 7 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Недельная отчетность', 'Создал 7 отчетов', 100);
  END IF;
  IF total_reports >= 30 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Месячная дисциплина', 'Создал 30 отчетов', 200);
  END IF;
  IF total_reports >= 90 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер отчетности', 'Создал 90 отчетов', 300);
  END IF;
  
  IF total_sales >= 1 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первая продажа', 'Закрыл первую сделку', 120);
  END IF;
  IF total_sales >= 5 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Продавец-новичок', 'Закрыл 5 сделок', 250);
  END IF;
  IF total_sales >= 10 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Опытный продавец', 'Закрыл 10 сделок', 400);
  END IF;
  IF total_sales >= 25 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер продаж', 'Закрыл 25 сделок', 600);
  END IF;
  IF total_sales >= 50 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Легенда продаж', 'Закрыл 50 сделок', 1000);
  END IF;
  
  IF total_sale_amount >= 100000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первые 100К', 'Продажи на 100,000 тенге', 150);
  END IF;
  IF total_sale_amount >= 500000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Полумиллионер', 'Продажи на 500,000 тенге', 300);
  END IF;
  IF total_sale_amount >= 1000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Миллионер', 'Продажи на 1,000,000 тенге', 500);
  END IF;
  IF total_sale_amount >= 2000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Двукратный миллионер', 'Продажи на 2,000,000 тенге', 750);
  END IF;
  IF total_sale_amount >= 5000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Золотой продавец', 'Продажи на 5,000,000 тенге', 1200);
  END IF;
  
  IF total_sales >= 10 AND qualified_leads >= 400 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Эффективный менеджер', 'Высокие показатели продаж и лидов', 400);
  END IF;
  IF total_reports >= 30 AND total_sales >= 15 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Дисциплинированный продавец', 'Регулярные отчеты и продажи', 350);
  END IF;
END;
$function$;