-- Update the view to use new column names
DROP VIEW IF EXISTS employee_tasks_with_attachments_view;

CREATE VIEW employee_tasks_with_attachments_view AS
SELECT 
  t.*,
  COUNT(a.id) as attachment_count,
  CASE 
    WHEN COUNT(a.id) > 0 THEN 
      json_agg(
        json_build_object(
          'id', a.id,
          'file_name', a.file_name,
          'file_url', a.file_url,
          'content_type', a.content_type,
          'file_size', a.file_size
        )
      ) 
    ELSE NULL 
  END as attachments
FROM employee_tasks t
LEFT JOIN task_attachments a ON t.id = a.task_id
GROUP BY t.id, t.employee_id, t.title, t.description, t.priority, t.status, 
         t.category, t.estimated_minutes, t.actual_minutes, t.due_date, 
         t.assigned_by, t.created_at, t.updated_at, t.completed_at;