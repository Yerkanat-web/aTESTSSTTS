
-- 1) Таблица товаров магазина (org-scoped)
create table if not exists public.shop_items (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  description text,
  price integer not null default 0,
  category text not null default 'Прочее',
  is_available boolean not null default true,
  image_url text,
  created_by uuid references public.employees(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Полезные индексы
create index if not exists idx_shop_items_org on public.shop_items(org_id);
create index if not exists idx_shop_items_org_available on public.shop_items(org_id, is_available);
create index if not exists idx_shop_items_org_category on public.shop_items(org_id, category);

-- Триггер на updated_at
drop trigger if exists trg_shop_items_set_updated_at on public.shop_items;
create trigger trg_shop_items_set_updated_at
before update on public.shop_items
for each row execute function public.update_updated_at_column();

-- Включаем RLS
alter table public.shop_items enable row level security;

-- Политики RLS
-- Члены организации могут видеть товары своей организации
drop policy if exists "Tenant org gate (SELECT) on shop_items" on public.shop_items;
create policy "Tenant org gate (SELECT) on shop_items"
on public.shop_items
for select
using ((org_id is not null) and public.is_member_of_org(org_id));

-- Ограждение по организации (INSERT)
drop policy if exists "Tenant org gate (INSERT) on shop_items" on public.shop_items;
create policy "Tenant org gate (INSERT) on shop_items"
on public.shop_items
for insert
with check ((org_id is not null) and public.is_member_of_org(org_id));

-- Ограждение по организации (UPDATE)
drop policy if exists "Tenant org gate (UPDATE) on shop_items" on public.shop_items;
create policy "Tenant org gate (UPDATE) on shop_items"
on public.shop_items
for update
using ((org_id is not null) and public.is_member_of_org(org_id));

-- Ограждение по организации (DELETE)
drop policy if exists "Tenant org gate (DELETE) on shop_items" on public.shop_items;
create policy "Tenant org gate (DELETE) on shop_items"
on public.shop_items
for delete
using ((org_id is not null) and public.is_member_of_org(org_id));

-- Админы организации могут все (дополнительная "прямой доступ" политика)
drop policy if exists "Admins can manage all shop items" on public.shop_items;
create policy "Admins can manage all shop items"
on public.shop_items
for all
using (public.is_admin_in_org(org_id))
with check (public.is_admin_in_org(org_id));

--------------------------------------------------------------------------------
-- 2) [Опционально] Хранилище изображений товаров: публичный bucket shop-images
--------------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from storage.buckets where id = 'shop-images') then
    insert into storage.buckets (id, name, public)
    values ('shop-images', 'shop-images', true);
  end if;
end $$;

-- Политики для storage.objects (ограничены bucket'ом shop-images)
-- Публичное чтение
drop policy if exists "Public read shop images" on storage.objects;
create policy "Public read shop images"
on storage.objects
for select
using (bucket_id = 'shop-images');

-- Загрузка для аутентифицированных
drop policy if exists "Authenticated can upload shop images" on storage.objects;
create policy "Authenticated can upload shop images"
on storage.objects
for insert
with check (bucket_id = 'shop-images' and auth.role() = 'authenticated');

-- Обновление только владельцем объекта
drop policy if exists "Owners can update shop images" on storage.objects;
create policy "Owners can update shop images"
on storage.objects
for update
using (bucket_id = 'shop-images' and owner = auth.uid())
with check (bucket_id = 'shop-images' and owner = auth.uid());

-- Удаление только владельцем объекта
drop policy if exists "Owners can delete shop images" on storage.objects;
create policy "Owners can delete shop images"
on storage.objects
for delete
using (bucket_id = 'shop-images' and owner = auth.uid());
