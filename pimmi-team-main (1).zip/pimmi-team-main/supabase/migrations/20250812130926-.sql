-- Add target_group to achievement_templates and set values
ALTER TABLE public.achievement_templates
ADD COLUMN IF NOT EXISTS target_group text NOT NULL DEFAULT 'general';

-- Optional: constrain allowed values via trigger-safe domain (simple CHECK is fine for static values)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'achievement_templates_target_group_check'
  ) THEN
    ALTER TABLE public.achievement_templates
    ADD CONSTRAINT achievement_templates_target_group_check
    CHECK (target_group IN ('sales','general'));
  END IF;
END $$;

-- Backfill existing rows based on condition_type
UPDATE public.achievement_templates
SET target_group = 'sales'
WHERE condition_type IN ('sales_count','sales_amount','leads_count','qualified_leads_count','reports_count');

-- Ensure award_achievement_safely sets org_id
CREATE OR REPLACE FUNCTION public.award_achievement_safely(emp_id uuid, ach_name text, ach_description text, ach_points integer)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  emp_org uuid;
BEGIN
  SELECT org_id INTO emp_org FROM public.employees WHERE id = emp_id;

  IF EXISTS (
    SELECT 1 FROM public.employee_achievements 
    WHERE employee_id = emp_id AND achievement_name = ach_name
  ) THEN
    RETURN FALSE;
  END IF;
  
  INSERT INTO public.employee_achievements (
    employee_id, 
    achievement_name, 
    description, 
    points,
    org_id
  ) VALUES (
    emp_id, 
    ach_name, 
    ach_description, 
    ach_points,
    emp_org
  );
  
  PERFORM public.calculate_employee_points(emp_id);
  
  RETURN TRUE;
END;
$$;

-- Create function for task (general) achievements
CREATE OR REPLACE FUNCTION public.check_task_achievements(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  emp_org uuid;
  total_completed integer := 0;
  total_points integer := 0;
  tpl record;
  -- For category tasks
  easy_cnt integer := 0;
  med_cnt integer := 0;
  hard_cnt integer := 0;
  max_in_day integer := 0;
BEGIN
  SELECT org_id INTO emp_org FROM public.employees WHERE id = emp_id;
  IF emp_org IS NULL THEN
    RETURN;
  END IF;

  SELECT COUNT(*) INTO total_completed
  FROM public.employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';

  SELECT total_points INTO total_points
  FROM public.employee_points
  WHERE employee_id = emp_id;
  total_points := COALESCE(total_points, 0);

  -- Precompute category counts
  SELECT COUNT(*) FILTER (WHERE priority = 'easy'),
         COUNT(*) FILTER (WHERE priority = 'medium'),
         COUNT(*) FILTER (WHERE priority = 'hard')
  INTO easy_cnt, med_cnt, hard_cnt
  FROM public.employee_tasks
  WHERE employee_id = emp_id AND status = 'completed';

  -- Max tasks in a single day (for consecutive-in-one-day logic)
  SELECT COALESCE(MAX(cnt),0) INTO max_in_day
  FROM (
    SELECT date_trunc('day', completed_at) AS d, COUNT(*) AS cnt
    FROM public.employee_tasks
    WHERE employee_id = emp_id AND status = 'completed' AND completed_at IS NOT NULL
    GROUP BY 1
  ) t;

  FOR tpl IN 
    SELECT id, name, description, points, condition_type, condition_value, condition_data
    FROM public.achievement_templates
    WHERE is_active = true
      AND org_id = emp_org
      AND target_group = 'general'
      AND condition_type IN ('task_count','points_total','category_tasks')
  LOOP
    IF tpl.condition_type = 'task_count' AND total_completed >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по задачам'), tpl.points);
    ELSIF tpl.condition_type = 'points_total' AND total_points >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по баллам'), tpl.points);
    ELSIF tpl.condition_type = 'category_tasks' THEN
      -- Handle priority and optional consecutive flag
      IF (tpl.condition_data ? 'priority') THEN
        IF tpl.condition_data->>'priority' = 'easy' AND easy_cnt >= tpl.condition_value THEN
          PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Задачи по приоритету'), tpl.points);
        ELSIF tpl.condition_data->>'priority' = 'medium' AND med_cnt >= tpl.condition_value THEN
          PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Задачи по приоритету'), tpl.points);
        ELSIF tpl.condition_data->>'priority' = 'hard' AND hard_cnt >= tpl.condition_value THEN
          PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Задачи по приоритету'), tpl.points);
        END IF;
      ELSE
        -- No priority specified, use total_completed as baseline
        IF total_completed >= tpl.condition_value THEN
          PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Задачи по категории'), tpl.points);
        END IF;
      END IF;

      -- If consecutive flag exists (perform additional check for tasks in one day)
      IF (tpl.condition_data ? 'consecutive') AND (tpl.condition_data->>'consecutive')::boolean = true THEN
        IF max_in_day >= tpl.condition_value THEN
          PERFORM public.award_achievement_safely(emp_id, tpl.name || ' (за день)', COALESCE(tpl.description, 'Выполнено за один день'), tpl.points);
        END IF;
      END IF;
    END IF;
  END LOOP;
END;
$$;

-- Tighten sales achievements to target_group='sales'
CREATE OR REPLACE FUNCTION public.check_sales_achievements(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  employee_dept text;
  emp_org uuid;
  total_leads integer := 0;
  qualified_leads integer := 0;
  total_reports integer := 0;
  total_sales integer := 0;
  total_sale_amount numeric := 0;
  tpl record;
BEGIN
  SELECT department, org_id INTO employee_dept, emp_org
  FROM public.employees 
  WHERE id = emp_id;
  
  IF employee_dept != 'отдел продаж' THEN
    RETURN;
  END IF;
  
  SELECT 
    COALESCE(SUM(leads_count), 0),
    COALESCE(SUM(qualified_leads_count), 0),
    COUNT(*)
  INTO total_leads, qualified_leads, total_reports
  FROM public.daily_reports 
  WHERE employee_id = emp_id;
  
  SELECT 
    COUNT(*),
    COALESCE(SUM(sale_amount), 0)
  INTO total_sales, total_sale_amount
  FROM public.sales_results 
  WHERE employee_id = emp_id;
  
  FOR tpl IN 
    SELECT id, name, description, points, condition_type, condition_value
    FROM public.achievement_templates
    WHERE is_active = true
      AND org_id = emp_org
      AND target_group = 'sales'
      AND condition_type IN ('sales_count', 'sales_amount', 'leads_count', 'qualified_leads_count', 'reports_count')
  LOOP
    IF tpl.condition_type = 'sales_count' AND total_sales >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по продажам'), tpl.points);
    ELSIF tpl.condition_type = 'sales_amount' AND total_sale_amount >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по сумме продаж'), tpl.points);
    ELSIF tpl.condition_type = 'leads_count' AND total_leads >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по лидам'), tpl.points);
    ELSIF tpl.condition_type = 'qualified_leads_count' AND qualified_leads >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по квал. лидам'), tpl.points);
    ELSIF tpl.condition_type = 'reports_count' AND total_reports >= tpl.condition_value THEN
      PERFORM public.award_achievement_safely(emp_id, tpl.name, COALESCE(tpl.description, 'Достижение по отчетам'), tpl.points);
    END IF;
  END LOOP;

  -- Legacy static achievements kept
  IF total_leads >= 20 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первый лид', 'Обработал 20 лидов', 50);
  END IF;
  IF total_leads >= 200 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Охотник за лидами', 'Обработал 200 лидов', 100);
  END IF;
  IF total_leads >= 1000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер лидогенерации', 'Обработал 1000 лидов', 200);
  END IF;
  IF total_leads >= 2000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Лидерный магнат', 'Обработал 2000 лидов', 300);
  END IF;
  IF qualified_leads >= 100 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Квалификатор', 'Получил 100 квалифицированных лидов', 75);
  END IF;
  IF qualified_leads >= 500 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Эксперт отбора', 'Получил 500 квалифицированных лидов', 150);
  END IF;
  IF total_reports >= 1 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первый отчет', 'Создал первый отчет', 30);
  END IF;
  IF total_reports >= 7 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Недельная отчетность', 'Создал 7 отчетов', 100);
  END IF;
  IF total_reports >= 30 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Месячная дисциплина', 'Создал 30 отчетов', 200);
  END IF;
  IF total_reports >= 90 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер отчетности', 'Создал 90 отчетов', 300);
  END IF;
  IF total_sales >= 1 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первая продажа', 'Закрыл первую сделку', 120);
  END IF;
  IF total_sales >= 5 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Продавец-новичок', 'Закрыл 5 сделок', 250);
  END IF;
  IF total_sales >= 10 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Опытный продавец', 'Закрыл 10 сделок', 400);
  END IF;
  IF total_sales >= 25 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер продаж', 'Закрыл 25 сделок', 600);
  END IF;
  IF total_sales >= 50 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Легенда продаж', 'Закрыл 50 сделок', 1000);
  END IF;
  IF total_sale_amount >= 100000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первые 100К', 'Продажи на 100,000 тенге', 150);
  END IF;
  IF total_sale_amount >= 500000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Полумиллионер', 'Продажи на 500,000 тенге', 300);
  END IF;
  IF total_sale_amount >= 1000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Миллионер', 'Продажи на 1,000,000 тенге', 500);
  END IF;
  IF total_sale_amount >= 2000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Двукратный миллионер', 'Продажи на 2,000,000 тенге', 750);
  END IF;
  IF total_sale_amount >= 5000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Золотой продавец', 'Продажи на 5,000,000 тенге', 1200);
  END IF;

  IF total_sales >= 10 AND qualified_leads >= 400 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Эффективный менеджер', 'Высокие показатели продаж и лидов', 400);
  END IF;
  IF total_reports >= 30 AND total_sales >= 15 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Дисциплинированный продавец', 'Регулярные отчеты и продажи', 350);
  END IF;
END;
$$;

-- Update trigger function for tasks to call check_task_achievements
CREATE OR REPLACE FUNCTION public.check_achievements_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF TG_TABLE_NAME = 'employee_tasks' THEN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
      IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
        PERFORM public.calculate_employee_points(NEW.employee_id);
        PERFORM public.check_task_achievements(NEW.employee_id);
      END IF;
    ELSIF TG_OP = 'DELETE' THEN
      PERFORM public.calculate_employee_points(OLD.employee_id);
      PERFORM public.check_task_achievements(OLD.employee_id);
    END IF;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create missing triggers if not present
DO $$ BEGIN
  -- employee_tasks points recompute
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_points_from_employee_tasks'
  ) THEN
    CREATE TRIGGER trg_update_points_from_employee_tasks
    AFTER INSERT OR UPDATE OR DELETE ON public.employee_tasks
    FOR EACH ROW EXECUTE FUNCTION public.update_employee_points_trigger();
  END IF;

  -- employee_achievements points recompute
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_points_from_employee_achievements'
  ) THEN
    CREATE TRIGGER trg_update_points_from_employee_achievements
    AFTER INSERT OR UPDATE OR DELETE ON public.employee_achievements
    FOR EACH ROW EXECUTE FUNCTION public.update_employee_points_trigger();
  END IF;

  -- set completed_at
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'set_task_completed_at'
  ) THEN
    CREATE TRIGGER set_task_completed_at
    BEFORE UPDATE ON public.employee_tasks
    FOR EACH ROW EXECUTE FUNCTION public.update_task_completed_at();
  END IF;

  -- check achievements on tasks
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_check_achievements_on_tasks'
  ) THEN
    CREATE TRIGGER trg_check_achievements_on_tasks
    AFTER INSERT OR UPDATE OR DELETE ON public.employee_tasks
    FOR EACH ROW EXECUTE FUNCTION public.check_achievements_trigger();
  END IF;

  -- sales results points + achievements
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_points_on_sales'
  ) THEN
    CREATE TRIGGER trg_update_points_on_sales
    AFTER INSERT OR UPDATE OR DELETE ON public.sales_results
    FOR EACH ROW EXECUTE FUNCTION public.update_points_on_sales();
  END IF;

  -- daily reports points + achievements
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_points_on_reports'
  ) THEN
    CREATE TRIGGER trg_update_points_on_reports
    AFTER INSERT OR UPDATE OR DELETE ON public.daily_reports
    FOR EACH ROW EXECUTE FUNCTION public.update_points_on_reports();
  END IF;

  -- project tasks points recompute
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_project_task_points'
  ) THEN
    CREATE TRIGGER trg_update_project_task_points
    AFTER INSERT OR UPDATE OR DELETE ON public.project_tasks
    FOR EACH ROW EXECUTE FUNCTION public.update_project_task_points_trigger();
  END IF;
END $$;