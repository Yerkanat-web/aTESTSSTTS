-- Добавляем политики для руководителей тех отдела на расширенные права

-- Политика для создания проектных задач для любых сотрудников
CREATE POLICY "Tech leads can create project tasks for any employee"
ON public.project_tasks
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM employees
    WHERE user_id = auth.uid()
    AND role = 'руководитель тех отдела'
    AND status = 'active'
  )
);

-- Политика для редактирования любых проектных задач
CREATE POLICY "Tech leads can update any project task"
ON public.project_tasks
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM employees
    WHERE user_id = auth.uid()
    AND role = 'руководитель тех отдела'
    AND status = 'active'
  )
);

-- Политика для создания задач для любых сотрудников
CREATE POLICY "Tech leads can create tasks for any employee"
ON public.employee_tasks
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM employees
    WHERE user_id = auth.uid()
    AND role = 'руководитель тех отдела'
    AND status = 'active'
  )
);

-- Политика для редактирования любых задач сотрудников
CREATE POLICY "Tech leads can update any employee task"
ON public.employee_tasks
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM employees
    WHERE user_id = auth.uid()
    AND role = 'руководитель тех отдела'
    AND status = 'active'
  )
);