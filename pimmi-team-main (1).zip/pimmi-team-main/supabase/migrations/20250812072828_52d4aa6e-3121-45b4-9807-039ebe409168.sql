-- Ensure RLS and org scoping for sales_targets and task_attachments; add triggers and indexes
-- 1) SALES TARGETS: RLS, policies, triggers, indexes

-- Enable RLS
ALTER TABLE public.sales_targets ENABLE ROW LEVEL SECURITY;

-- Admins can manage all sales targets
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'sales_targets' AND policyname = 'Admins can manage sales_targets'
  ) THEN
    CREATE POLICY "Admins can manage sales_targets"
    ON public.sales_targets
    FOR ALL
    USING (public.is_admin())
    WITH CHECK (public.is_admin());
  END IF;
END$$;

-- Employees and financists can view their own sales targets
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'sales_targets' AND policyname = 'Employees and financists can view own targets'
  ) THEN
    CREATE POLICY "Employees and financists can view own targets"
    ON public.sales_targets
    FOR SELECT
    USING (
      EXISTS (
        SELECT 1 FROM public.employees e
        WHERE e.id = sales_targets.employee_id
          AND e.user_id = auth.uid()
          AND e.role = ANY (ARRAY['employee'::text, 'финансист'::text])
      )
    );
  END IF;
END$$;

-- Department leads can view their department sales targets
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'sales_targets' AND policyname = 'Department leads can view department targets'
  ) THEN
    CREATE POLICY "Department leads can view department targets"
    ON public.sales_targets
    FOR SELECT
    USING (
      EXISTS (
        SELECT 1
        FROM public.employees e1, public.employees e2
        WHERE e1.user_id = auth.uid()
          AND e2.id = sales_targets.employee_id
          AND (
            (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
            (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
            (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
          )
      )
    );
  END IF;
END$$;

-- Department leads can create sales targets for their department employees
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'sales_targets' AND policyname = 'Department leads can insert targets'
  ) THEN
    CREATE POLICY "Department leads can insert targets"
    ON public.sales_targets
    FOR INSERT
    WITH CHECK (
      EXISTS (
        SELECT 1
        FROM public.employees manager, public.employees assignee
        WHERE manager.user_id = auth.uid()
          AND manager.role IN ('руководитель тех отдела','руководитель отдела продаж','руководитель ИИ отдела')
          AND manager.status = 'active'
          AND assignee.id = sales_targets.employee_id
          AND (
            (manager.role = 'руководитель тех отдела' AND assignee.department = 'тех отдел') OR
            (manager.role = 'руководитель отдела продаж' AND assignee.department = 'отдел продаж') OR
            (manager.role = 'руководитель ИИ отдела' AND assignee.department = 'креатив отдел')
          )
      )
    );
  END IF;
END$$;

-- Department leads can update sales targets for their department employees
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'sales_targets' AND policyname = 'Department leads can update targets'
  ) THEN
    CREATE POLICY "Department leads can update targets"
    ON public.sales_targets
    FOR UPDATE
    USING (
      EXISTS (
        SELECT 1
        FROM public.employees manager, public.employees assignee
        WHERE manager.user_id = auth.uid()
          AND manager.role IN ('руководитель тех отдела','руководитель отдела продаж','руководитель ИИ отдела')
          AND manager.status = 'active'
          AND assignee.id = sales_targets.employee_id
          AND (
            (manager.role = 'руководитель тех отдела' AND assignee.department = 'тех отдел') OR
            (manager.role = 'руководитель отдела продаж' AND assignee.department = 'отдел продаж') OR
            (manager.role = 'руководитель ИИ отдела' AND assignee.department = 'креатив отдел')
          )
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1
        FROM public.employees manager, public.employees assignee
        WHERE manager.user_id = auth.uid()
          AND manager.role IN ('руководитель тех отдела','руководитель отдела продаж','руководитель ИИ отдела')
          AND manager.status = 'active'
          AND assignee.id = sales_targets.employee_id
          AND (
            (manager.role = 'руководитель тех отдела' AND assignee.department = 'тех отдел') OR
            (manager.role = 'руководитель отдела продаж' AND assignee.department = 'отдел продаж') OR
            (manager.role = 'руководитель ИИ отдела' AND assignee.department = 'креатив отдел')
          )
      )
    );
  END IF;
END$$;

-- Tenant org gate policies for sales_targets
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='sales_targets' AND policyname='Tenant org gate (SELECT)'
  ) THEN
    CREATE POLICY "Tenant org gate (SELECT)" ON public.sales_targets
    FOR SELECT USING ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='sales_targets' AND policyname='Tenant org gate (INSERT)'
  ) THEN
    CREATE POLICY "Tenant org gate (INSERT)" ON public.sales_targets
    FOR INSERT WITH CHECK ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='sales_targets' AND policyname='Tenant org gate (UPDATE)'
  ) THEN
    CREATE POLICY "Tenant org gate (UPDATE)" ON public.sales_targets
    FOR UPDATE USING ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='sales_targets' AND policyname='Tenant org gate (DELETE)'
  ) THEN
    CREATE POLICY "Tenant org gate (DELETE)" ON public.sales_targets
    FOR DELETE USING ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;
END$$;

-- Triggers to set and protect org_id on sales_targets
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'set_org_id_sales_targets') THEN
    CREATE TRIGGER set_org_id_sales_targets
    BEFORE INSERT ON public.sales_targets
    FOR EACH ROW EXECUTE FUNCTION public.set_org_id_from_user();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'prevent_org_id_change_sales_targets') THEN
    CREATE TRIGGER prevent_org_id_change_sales_targets
    BEFORE UPDATE ON public.sales_targets
    FOR EACH ROW EXECUTE FUNCTION public.prevent_org_id_change();
  END IF;
END$$;

-- Indexes for sales_targets
CREATE INDEX IF NOT EXISTS idx_sales_targets_org_id ON public.sales_targets(org_id);
CREATE INDEX IF NOT EXISTS idx_sales_targets_employee_id ON public.sales_targets(employee_id);
CREATE INDEX IF NOT EXISTS idx_sales_targets_target_period ON public.sales_targets(target_period);


-- 2) TASK ATTACHMENTS: add org_id, backfill, RLS, policies, triggers, indexes

-- Add org_id column if missing
ALTER TABLE public.task_attachments
  ADD COLUMN IF NOT EXISTS org_id uuid;

-- Backfill org_id from employees
UPDATE public.task_attachments ta
SET org_id = e.org_id
FROM public.employees e
WHERE ta.employee_id = e.id
  AND ta.org_id IS NULL;

-- Enable RLS
ALTER TABLE public.task_attachments ENABLE ROW LEVEL SECURITY;

-- Admins can manage all attachments
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'task_attachments' AND policyname = 'Admins can manage attachments'
  ) THEN
    CREATE POLICY "Admins can manage attachments"
    ON public.task_attachments
    FOR ALL
    USING (public.is_admin())
    WITH CHECK (public.is_admin());
  END IF;
END$$;

-- Employees and financists can manage their own attachments
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'task_attachments' AND policyname = 'Employees and financists can view own attachments'
  ) THEN
    CREATE POLICY "Employees and financists can view own attachments"
    ON public.task_attachments
    FOR SELECT
    USING (
      EXISTS (
        SELECT 1 FROM public.employees e
        WHERE e.id = task_attachments.employee_id
          AND e.user_id = auth.uid()
          AND e.role = ANY (ARRAY['employee'::text, 'финансист'::text])
      )
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'task_attachments' AND policyname = 'Employees and financists can insert own attachments'
  ) THEN
    CREATE POLICY "Employees and financists can insert own attachments"
    ON public.task_attachments
    FOR INSERT
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.employees e
        WHERE e.id = task_attachments.employee_id
          AND e.user_id = auth.uid()
          AND e.role = ANY (ARRAY['employee'::text, 'финансист'::text])
      )
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'task_attachments' AND policyname = 'Employees and financists can update own attachments'
  ) THEN
    CREATE POLICY "Employees and financists can update own attachments"
    ON public.task_attachments
    FOR UPDATE
    USING (
      EXISTS (
        SELECT 1 FROM public.employees e
        WHERE e.id = task_attachments.employee_id
          AND e.user_id = auth.uid()
          AND e.role = ANY (ARRAY['employee'::text, 'финансист'::text])
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.employees e
        WHERE e.id = task_attachments.employee_id
          AND e.user_id = auth.uid()
          AND e.role = ANY (ARRAY['employee'::text, 'финансист'::text])
      )
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'task_attachments' AND policyname = 'Employees and financists can delete own attachments'
  ) THEN
    CREATE POLICY "Employees and financists can delete own attachments"
    ON public.task_attachments
    FOR DELETE
    USING (
      EXISTS (
        SELECT 1 FROM public.employees e
        WHERE e.id = task_attachments.employee_id
          AND e.user_id = auth.uid()
          AND e.role = ANY (ARRAY['employee'::text, 'финансист'::text])
      )
    );
  END IF;
END$$;

-- Department leads can view department attachments
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'task_attachments' AND policyname = 'Department leads can view department attachments'
  ) THEN
    CREATE POLICY "Department leads can view department attachments"
    ON public.task_attachments
    FOR SELECT
    USING (
      EXISTS (
        SELECT 1
        FROM public.employees e1, public.employees e2
        WHERE e1.user_id = auth.uid()
          AND e2.id = task_attachments.employee_id
          AND (
            (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
            (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
            (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
          )
      )
    );
  END IF;
END$$;

-- Tenant org gate policies for task_attachments
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='task_attachments' AND policyname='Tenant org gate (SELECT)'
  ) THEN
    CREATE POLICY "Tenant org gate (SELECT)" ON public.task_attachments
    FOR SELECT USING ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='task_attachments' AND policyname='Tenant org gate (INSERT)'
  ) THEN
    CREATE POLICY "Tenant org gate (INSERT)" ON public.task_attachments
    FOR INSERT WITH CHECK ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='task_attachments' AND policyname='Tenant org gate (UPDATE)'
  ) THEN
    CREATE POLICY "Tenant org gate (UPDATE)" ON public.task_attachments
    FOR UPDATE USING ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='task_attachments' AND policyname='Tenant org gate (DELETE)'
  ) THEN
    CREATE POLICY "Tenant org gate (DELETE)" ON public.task_attachments
    FOR DELETE USING ((org_id IS NOT NULL) AND public.is_member_of_org(org_id));
  END IF;
END$$;

-- Triggers to set and protect org_id on task_attachments
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'set_org_id_task_attachments') THEN
    CREATE TRIGGER set_org_id_task_attachments
    BEFORE INSERT ON public.task_attachments
    FOR EACH ROW EXECUTE FUNCTION public.set_org_id_from_user();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'prevent_org_id_change_task_attachments') THEN
    CREATE TRIGGER prevent_org_id_change_task_attachments
    BEFORE UPDATE ON public.task_attachments
    FOR EACH ROW EXECUTE FUNCTION public.prevent_org_id_change();
  END IF;
END$$;

-- Indexes for task_attachments
CREATE INDEX IF NOT EXISTS idx_task_attachments_org_id ON public.task_attachments(org_id);
CREATE INDEX IF NOT EXISTS idx_task_attachments_employee_id ON public.task_attachments(employee_id);
CREATE INDEX IF NOT EXISTS idx_task_attachments_task_id ON public.task_attachments(task_id);
