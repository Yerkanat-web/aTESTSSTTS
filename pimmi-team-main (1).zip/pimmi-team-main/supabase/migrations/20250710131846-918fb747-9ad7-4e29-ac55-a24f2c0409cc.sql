-- Drop and recreate employee_stats_view to calculate hours correctly
DROP VIEW IF EXISTS employee_stats_view;

CREATE VIEW employee_stats_view AS
SELECT 
  e.id,
  e.name,
  e.email,
  e.position,
  e.department,
  e.role,
  e.status,
  COALESCE(ep.total_points, 0) as total_points,
  COUNT(et.id) as total_tasks,
  COUNT(CASE WHEN et.status = 'completed' THEN 1 END) as completed_tasks,
  COALESCE(SUM(et.actual_hours), 0) as total_hours,
  CASE 
    WHEN COUNT(et.id) > 0 THEN 
      ROUND((COUNT(CASE WHEN et.status = 'completed' THEN 1 END)::numeric / COUNT(et.id)) * 100)
    ELSE 0 
  END as efficiency
FROM employees e
LEFT JOIN employee_points ep ON e.id = ep.employee_id
LEFT JOIN employee_tasks et ON e.id = et.employee_id
GROUP BY e.id, e.name, e.email, e.position, e.department, e.role, e.status, ep.total_points;