-- Удаляем старый constraint
ALTER TABLE public.employee_tasks DROP CONSTRAINT employee_tasks_priority_check;

-- Добавляем новый constraint с правильными значениями
ALTER TABLE public.employee_tasks ADD CONSTRAINT employee_tasks_priority_check 
CHECK (priority = ANY (ARRAY['easy'::text, 'medium'::text, 'hard'::text]));