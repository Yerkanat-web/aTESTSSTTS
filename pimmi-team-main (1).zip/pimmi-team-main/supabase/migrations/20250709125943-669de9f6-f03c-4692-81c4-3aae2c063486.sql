
-- Add new columns to daily_reports table
ALTER TABLE public.daily_reports 
ADD COLUMN sale_amount NUMERIC DEFAULT 0,
ADD COLUMN project_name TEXT,
ADD COLUMN categories TEXT[] DEFAULT '{}';

-- Update the existing reports to have default values
UPDATE public.daily_reports 
SET sale_amount = 0, categories = '{}' 
WHERE sale_amount IS NULL OR categories IS NULL;
