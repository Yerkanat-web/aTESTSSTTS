-- 1) Helper functions for multi-tenancy
CREATE OR REPLACE FUNCTION public.is_member_of_org(p_org_id uuid, p_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.organization_members m
    WHERE m.org_id = p_org_id
      AND m.user_id = p_user_id
  );
$$;

-- Return a single org id when user belongs to exactly one org, else NULL
CREATE OR REPLACE FUNCTION public.get_single_org_id_for_user(p_user_id uuid DEFAULT auth.uid())
RETURNS uuid
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
  org_count int;
  single_org uuid;
BEGIN
  SELECT COUNT(*), MIN(org_id) INTO org_count, single_org
  FROM public.organization_members
  WHERE user_id = p_user_id;

  IF org_count = 1 THEN
    RETURN single_org;
  END IF;
  RETURN NULL;
END;
$$;

-- Generic trigger to set/check org_id on INSERT
CREATE OR REPLACE FUNCTION public.set_org_id_from_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  resolved_org uuid;
BEGIN
  -- If org_id not set, try to infer when user has exactly one org
  IF NEW.org_id IS NULL THEN
    resolved_org := public.get_single_org_id_for_user(auth.uid());
    IF resolved_org IS NULL THEN
      RAISE EXCEPTION 'org_id is required and cannot be inferred for multi-tenant data';
    END IF;
    NEW.org_id := resolved_org;
  END IF;

  -- Validate membership
  IF NOT public.is_member_of_org(NEW.org_id, auth.uid()) THEN
    RAISE EXCEPTION 'User is not a member of org %', NEW.org_id;
  END IF;

  RETURN NEW;
END;
$$;

-- Prevent changing org_id once set
CREATE OR REPLACE FUNCTION public.prevent_org_id_change()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.org_id IS DISTINCT FROM OLD.org_id THEN
    RAISE EXCEPTION 'Changing org_id is not allowed';
  END IF;
  RETURN NEW;
END;
$$;

-- 2) Backfill org_id where possible
-- employees: from membership when missing
UPDATE public.employees e
SET org_id = (
  SELECT m.org_id FROM public.organization_members m
  WHERE m.user_id = e.user_id
  ORDER BY m.created_at ASC NULLS LAST
  LIMIT 1
)
WHERE e.org_id IS NULL AND e.user_id IS NOT NULL;

-- From employees -> child tables
UPDATE public.daily_reports dr
SET org_id = e.org_id
FROM public.employees e
WHERE dr.employee_id = e.id AND dr.org_id IS NULL;

UPDATE public.employee_achievements ea
SET org_id = e.org_id
FROM public.employees e
WHERE ea.employee_id = e.id AND ea.org_id IS NULL;

UPDATE public.employee_points ep
SET org_id = e.org_id
FROM public.employees e
WHERE ep.employee_id = e.id AND ep.org_id IS NULL;

UPDATE public.employee_tasks t
SET org_id = e.org_id
FROM public.employees e
WHERE t.employee_id = e.id AND t.org_id IS NULL;

UPDATE public.project_tasks pt
SET org_id = e.org_id
FROM public.employees e
WHERE pt.assignee_id = e.id AND pt.org_id IS NULL;

UPDATE public.sales_results sr
SET org_id = e.org_id
FROM public.employees e
WHERE sr.employee_id = e.id AND sr.org_id IS NULL;

-- From sales_results -> dependents
UPDATE public.monthly_payments mp
SET org_id = sr.org_id
FROM public.sales_results sr
WHERE mp.sales_result_id = sr.id AND mp.org_id IS NULL;

UPDATE public.project_accounts pa
SET org_id = sr.org_id
FROM public.sales_results sr
WHERE pa.sales_result_id = sr.id AND pa.org_id IS NULL;

-- 3) Attach triggers to enforce org_id presence/validity
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN SELECT unnest(ARRAY[
    'daily_reports',
    'employee_achievements',
    'employee_points',
    'employee_tasks',
    'monthly_payments',
    'project_accounts',
    'project_cases',
    'project_categories',
    'project_tasks',
    'sales_results'
  ]) AS tbl LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS set_org_id_from_user_%I ON public.%I;', r.tbl, r.tbl);
    EXECUTE format('CREATE TRIGGER set_org_id_from_user_%I BEFORE INSERT ON public.%I FOR EACH ROW EXECUTE FUNCTION public.set_org_id_from_user();', r.tbl, r.tbl);

    EXECUTE format('DROP TRIGGER IF EXISTS prevent_org_change_%I ON public.%I;', r.tbl, r.tbl);
    EXECUTE format('CREATE TRIGGER prevent_org_change_%I BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.prevent_org_id_change();', r.tbl, r.tbl);
  END LOOP;
END $$;

-- 4) Restrictive tenant-gate RLS policies
-- Helper to create restrictive policies per table that has org_id
-- Note: Policies names must be unique per table; create separate names per command

-- daily_reports
CREATE POLICY "Tenant org gate (SELECT)" ON public.daily_reports AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.daily_reports AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.daily_reports AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.daily_reports AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- employee_achievements
CREATE POLICY "Tenant org gate (SELECT)" ON public.employee_achievements AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.employee_achievements AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.employee_achievements AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.employee_achievements AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- employee_points
CREATE POLICY "Tenant org gate (SELECT)" ON public.employee_points AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.employee_points AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.employee_points AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.employee_points AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- employee_tasks
CREATE POLICY "Tenant org gate (SELECT)" ON public.employee_tasks AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.employee_tasks AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.employee_tasks AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.employee_tasks AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- employees (view/update/etc are already complex; add restrictive org gate for any command)
CREATE POLICY "Tenant org gate (SELECT)" ON public.employees AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND (
  public.is_member_of_org(org_id)
));
CREATE POLICY "Tenant org gate (INSERT)" ON public.employees AS RESTRICTIVE FOR INSERT WITH CHECK (
  (org_id IS NOT NULL AND public.is_member_of_org(org_id)) OR auth.uid() IS NULL -- allow service role/admin operations
);
CREATE POLICY "Tenant org gate (UPDATE)" ON public.employees AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.employees AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- monthly_payments
CREATE POLICY "Tenant org gate (SELECT)" ON public.monthly_payments AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.monthly_payments AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.monthly_payments AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.monthly_payments AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- project_accounts
CREATE POLICY "Tenant org gate (SELECT)" ON public.project_accounts AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.project_accounts AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.project_accounts AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.project_accounts AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- project_cases
CREATE POLICY "Tenant org gate (SELECT)" ON public.project_cases AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.project_cases AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.project_cases AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.project_cases AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- project_categories
CREATE POLICY "Tenant org gate (SELECT)" ON public.project_categories AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.project_categories AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.project_categories AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.project_categories AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- project_tasks
CREATE POLICY "Tenant org gate (SELECT)" ON public.project_tasks AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.project_tasks AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.project_tasks AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.project_tasks AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- sales_results
CREATE POLICY "Tenant org gate (SELECT)" ON public.sales_results AS RESTRICTIVE FOR SELECT USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (INSERT)" ON public.sales_results AS RESTRICTIVE FOR INSERT WITH CHECK (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (UPDATE)" ON public.sales_results AS RESTRICTIVE FOR UPDATE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));
CREATE POLICY "Tenant org gate (DELETE)" ON public.sales_results AS RESTRICTIVE FOR DELETE USING (org_id IS NOT NULL AND public.is_member_of_org(org_id));

-- employee_activity_logs: gate by employee org via join
DROP POLICY IF EXISTS "Admins can view all activity logs" ON public.employee_activity_logs;
CREATE POLICY "Tenant org gate (SELECT)" ON public.employee_activity_logs AS RESTRICTIVE FOR SELECT USING (
  EXISTS (
    SELECT 1
    FROM public.employees e
    WHERE e.id = employee_activity_logs.employee_id
      AND e.org_id IS NOT NULL
      AND public.is_member_of_org(e.org_id)
  )
);
-- keep INSERT policy but add restrictive check as well
CREATE POLICY "Tenant org gate (INSERT)" ON public.employee_activity_logs AS RESTRICTIVE FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.employees e
    WHERE e.id = NEW.employee_id
      AND e.org_id IS NOT NULL
      AND public.is_member_of_org(e.org_id)
  )
);

-- 5) Indexes for performance
CREATE INDEX IF NOT EXISTS idx_employees_org ON public.employees(org_id);
CREATE INDEX IF NOT EXISTS idx_daily_reports_org ON public.daily_reports(org_id);
CREATE INDEX IF NOT EXISTS idx_employee_achievements_org ON public.employee_achievements(org_id);
CREATE INDEX IF NOT EXISTS idx_employee_points_org ON public.employee_points(org_id);
CREATE INDEX IF NOT EXISTS idx_employee_tasks_org ON public.employee_tasks(org_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_org ON public.project_tasks(org_id);
CREATE INDEX IF NOT EXISTS idx_sales_results_org ON public.sales_results(org_id);
CREATE INDEX IF NOT EXISTS idx_monthly_payments_org ON public.monthly_payments(org_id);
CREATE INDEX IF NOT EXISTS idx_project_accounts_org ON public.project_accounts(org_id);
CREATE INDEX IF NOT EXISTS idx_project_cases_org ON public.project_cases(org_id);
CREATE INDEX IF NOT EXISTS idx_project_categories_org ON public.project_categories(org_id);
