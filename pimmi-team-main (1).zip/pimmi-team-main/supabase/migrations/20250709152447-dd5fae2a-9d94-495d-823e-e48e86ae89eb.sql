-- Очищаем старые демо данные
DELETE FROM sales_results;
DELETE FROM sales_targets;
DELETE FROM employee_tasks;
DELETE FROM work_time_logs;
DELETE FROM employee_achievements;
DELETE FROM employees WHERE department IN ('отдел продаж', 'тех отдел');

-- Добавляем сотрудников отдела продаж
INSERT INTO employees (name, email, position, department, status, role) VALUES
('Нурасхан', 'nurasxan@company.kz', 'Менеджер по продажам', 'отдел продаж', 'active', 'employee'),
('Нурбек', 'nurbek@company.kz', 'Старший менеджер по продажам', 'отдел продаж', 'active', 'employee'),
('Асем', 'asem@company.kz', 'Менеджер по продажам', 'отдел продаж', 'active', 'employee');

-- Добавляем сотрудников тех отдела
INSERT INTO employees (name, email, position, department, status, role) VALUES
('Марлен', 'marlen@company.kz', 'Frontend Developer', 'тех отдел', 'active', 'employee'),
('Алмагуль', 'almagul@company.kz', 'Backend Developer', 'тех отдел', 'active', 'employee'),
('Амирбек', 'amirbek@company.kz', 'QA Engineer', 'тех отдел', 'active', 'employee'),
('Нурдаулет', 'nurdaulet@company.kz', 'UI/UX Designer', 'тех отдел', 'active', 'employee'),
('Назар', 'nazar@company.kz', 'DevOps Engineer', 'тех отдел', 'active', 'employee');

-- Создаем планы продаж на текущий месяц
INSERT INTO sales_targets (employee_id, target_amount, target_period)
SELECT id, 
  CASE 
    WHEN name = 'Нурасхан' THEN 2500000
    WHEN name = 'Нурбек' THEN 3000000
    WHEN name = 'Асем' THEN 2200000
  END,
  DATE_TRUNC('month', CURRENT_DATE)::date
FROM employees 
WHERE department = 'отдел продаж';

-- Создаем демо данные по продажам за текущий месяц
INSERT INTO sales_results (employee_id, sale_amount, sale_date, client_name, description)
SELECT e.id, amounts.amount, dates.sale_date, clients.client_name, descriptions.description
FROM employees e
CROSS JOIN (
  SELECT unnest(ARRAY[450000, 320000, 780000, 550000, 380000, 620000, 290000, 440000, 510000, 370000]) as amount,
         unnest(ARRAY[1, 2, 3, 5, 6, 8, 9, 12, 15, 18]) as day_offset
) amounts
CROSS JOIN (
  SELECT (DATE_TRUNC('month', CURRENT_DATE) + (amounts.day_offset || ' days')::interval)::date as sale_date
) dates
CROSS JOIN (
  SELECT unnest(ARRAY['ТОО "Астана Строй"', 'ИП "Алматы Трейд"', 'ТОО "Шымкент Лтд"', 'ООО "Актобе Групп"', 'ТОО "Караганда Бизнес"', 'ИП "Павлодар Сервис"', 'ТОО "Костанай Плюс"', 'ООО "Атырау Ойл"', 'ТОО "Тараз Компани"', 'ИП "Усть-Каменогорск"']) as client_name
) clients
CROSS JOIN (
  SELECT unnest(ARRAY['Продажа CRM системы', 'Внедрение автоматизации', 'Консалтинговые услуги', 'Техническая поддержка', 'Разработка ПО', 'Обучение персонала', 'Интеграция систем', 'Аудит ИТ процессов', 'Модернизация оборудования', 'Сопровождение проекта']) as description
) descriptions
WHERE e.department = 'отдел продаж'
AND e.name = CASE 
  WHEN amounts.day_offset <= 3 THEN 'Нурасхан'
  WHEN amounts.day_offset <= 6 THEN 'Нурбек' 
  ELSE 'Асем'
END;

-- Создаем задачи для всех сотрудников
INSERT INTO employee_tasks (employee_id, title, description, priority, status, category, estimated_hours, actual_hours, due_date, created_at, completed_at)
SELECT e.id, tasks.title, tasks.description, tasks.priority, tasks.status, tasks.category, tasks.estimated_hours, tasks.actual_hours, 
       (CURRENT_DATE + (tasks.due_offset || ' days')::interval)::date,
       (CURRENT_DATE - (tasks.created_offset || ' days')::interval),
       CASE WHEN tasks.status = 'completed' THEN (CURRENT_DATE - (tasks.completed_offset || ' days')::interval) ELSE NULL END
FROM employees e
CROSS JOIN (
  -- Задачи для отдела продаж
  SELECT 'Подготовка коммерческого предложения' as title, 'Составление КП для нового клиента' as description, 
         'medium' as priority, 'completed' as status, 'sales' as category, 4 as estimated_hours, 3 as actual_hours,
         3 as due_offset, 5 as created_offset, 1 as completed_offset
  WHERE e.department = 'отдел продаж'
  UNION ALL
  SELECT 'Звонки потенциальным клиентам', 'Холодные звонки по базе лидов', 
         'easy' as priority, 'completed' as status, 'sales' as category, 6 as estimated_hours, 5 as actual_hours,
         2 as due_offset, 3 as created_offset, 0 as completed_offset
  WHERE e.department = 'отдел продаж'
  UNION ALL
  SELECT 'Встреча с клиентом', 'Презентация продукта крупному заказчику', 
         'hard' as priority, 'in_progress' as status, 'sales' as category, 3 as estimated_hours, 1 as actual_hours,
         1 as due_offset, 2 as created_offset, NULL as completed_offset
  WHERE e.department = 'отдел продаж'
  
  -- Задачи для тех отдела
  UNION ALL
  SELECT 'Разработка API модуля', 'Создание REST API для новой функциональности', 
         'hard' as priority, 'completed' as status, 'development' as category, 16 as estimated_hours, 14 as actual_hours,
         5 as due_offset, 8 as created_offset, 2 as completed_offset
  WHERE e.department = 'тех отдел' AND e.name IN ('Марлен', 'Алмагуль')
  UNION ALL
  SELECT 'Тестирование нового функционала', 'Написание автотестов и проведение QA', 
         'medium' as priority, 'completed' as status, 'development' as category, 12 as estimated_hours, 10 as actual_hours,
         3 as due_offset, 6 as created_offset, 1 as completed_offset
  WHERE e.department = 'тех отдел' AND e.name = 'Амирбек'
  UNION ALL
  SELECT 'Дизайн пользовательского интерфейса', 'Создание макетов для мобильного приложения', 
         'medium' as priority, 'in_progress' as status, 'development' as category, 20 as estimated_hours, 12 as actual_hours,
         7 as due_offset, 10 as created_offset, NULL as completed_offset
  WHERE e.department = 'тех отдел' AND e.name = 'Нурдаулет'
  UNION ALL
  SELECT 'Настройка CI/CD pipeline', 'Автоматизация процесса деплоя', 
         'hard' as priority, 'pending' as status, 'development' as category, 8 as estimated_hours, 0 as actual_hours,
         10 as due_offset, 1 as created_offset, NULL as completed_offset
  WHERE e.department = 'тех отдел' AND e.name = 'Назар'
) tasks;

-- Создаем логи рабочего времени за последнюю неделю
INSERT INTO work_time_logs (employee_id, start_time, end_time, hours_worked, description, work_type)
SELECT e.id, 
       (CURRENT_DATE - (days.day_offset || ' days')::interval + '09:00:00'::time),
       (CURRENT_DATE - (days.day_offset || ' days')::interval + (('09:00:00'::time + (hours.hours || ' hours')::interval))),
       hours.hours,
       work.description,
       'task'
FROM employees e
CROSS JOIN (
  SELECT generate_series(0, 6) as day_offset
) days
CROSS JOIN (
  SELECT unnest(ARRAY[8.5, 7.2, 8.8, 6.5, 8.1, 4.2, 2.0]) as hours,
         unnest(ARRAY[0, 1, 2, 3, 4, 5, 6]) as day_idx
) hours
CROSS JOIN (
  SELECT unnest(ARRAY['Работа над проектом', 'Встречи с клиентами', 'Разработка функций', 'Тестирование', 'Планирование', 'Документация', 'Обучение']) as description
) work
WHERE days.day_offset = hours.day_idx
AND e.department IN ('отдел продаж', 'тех отдел');

-- Создаем достижения
INSERT INTO employee_achievements (employee_id, achievement_name, description, points, earned_at)
SELECT e.id, achv.name, achv.description, achv.points, (CURRENT_DATE - (achv.days_ago || ' days')::interval)
FROM employees e
CROSS JOIN (
  SELECT 'Первая продажа месяца' as name, 'Заключил первую сделку в этом месяце' as description, 100 as points, 5 as days_ago
  WHERE e.department = 'отдел продаж'
  UNION ALL
  SELECT 'План выполнен на 80%' as name, 'Выполнение плана продаж на 80%' as description, 200 as points, 3 as days_ago
  WHERE e.department = 'отдел продаж' AND e.name = 'Нурбек'
  UNION ALL
  SELECT 'Задача выполнена досрочно' as name, 'Завершил задачу раньше срока' as description, 50 as points, 2 as days_ago
  WHERE e.department = 'тех отдел'
  UNION ALL
  SELECT 'Код без багов' as name, 'Код прошел проверку без найденных ошибок' as description, 75 as points, 1 as days_ago
  WHERE e.department = 'тех отдел' AND e.name IN ('Марлен', 'Алмагуль')
) achv;