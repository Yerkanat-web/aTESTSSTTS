-- Обновляем enum project_status_enum, добавляя нужные статусы
ALTER TYPE public.project_status_enum ADD VALUE IF NOT EXISTS 'Не указан';
ALTER TYPE public.project_status_enum ADD VALUE IF NOT EXISTS 'Завершили работу';

-- Можно также переименовать "Закончили" в "Завершили работу" если нужно, но лучше оставить оба варианта для совместимости
-- UPDATE sales_results SET project_status = 'Завершили работу' WHERE project_status = 'Закончили';