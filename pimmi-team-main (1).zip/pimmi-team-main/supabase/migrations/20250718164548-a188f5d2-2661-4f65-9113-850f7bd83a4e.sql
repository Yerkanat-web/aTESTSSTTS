-- Добавляем политику для создания ежемесячных платежей при создании продлений
CREATE POLICY "Department leads can create monthly payments for extensions" 
ON public.monthly_payments 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM employees e, sales_results sr
    WHERE e.user_id = auth.uid()
    AND e.role IN (
      'руководитель тех отдела',
      'руководитель отдела продаж', 
      'руководитель ИИ отдела'
    )
    AND e.status = 'active'
    AND sr.id = monthly_payments.sales_result_id
    AND sr.is_extension = true
  )
);