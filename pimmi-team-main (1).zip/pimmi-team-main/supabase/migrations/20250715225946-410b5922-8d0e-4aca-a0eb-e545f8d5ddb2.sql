-- Удаляем проблемную политику
DROP POLICY IF EXISTS "Department leads can view employees" ON employees;

-- Создаем security definer функцию для проверки доступа к сотрудникам
CREATE OR REPLACE FUNCTION public.can_view_employee(target_employee_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT 
    -- Администраторы видят всех
    is_admin() OR
    -- Пользователь видит самого себя
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = target_employee_id 
      AND user_id = auth.uid()
    ) OR
    -- Руководители отделов видят сотрудников
    EXISTS (
      SELECT 1
      FROM employees manager, employees target
      WHERE manager.user_id = auth.uid()
      AND target.id = target_employee_id
      AND (
        -- Руководитель тех отдела видит ВСЕХ сотрудников
        manager.role = 'руководитель тех отдела' OR
        -- Остальные руководители видят только сотрудников своего отдела
        (
          manager.role = 'руководитель отдела продаж' AND 
          target.department = 'отдел продаж'
        ) OR
        (
          manager.role = 'руководитель ИИ отдела' AND 
          target.department = 'креатив отдел'
        )
      )
    );
$$;

-- Создаем новую политику с использованием функции
CREATE POLICY "Enhanced employee access" 
ON employees 
FOR SELECT 
USING (can_view_employee(id));