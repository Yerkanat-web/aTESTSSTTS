-- Исправляем функцию создания ежемесячных платежей для продлений
-- amount должен быть полной суммой продажи, а не остатком
CREATE OR REPLACE FUNCTION public.create_extension_monthly_payment()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  -- Только для продлений проектов
  IF NEW.is_extension = TRUE THEN
    -- Создаем ежемесячный платеж с правильными значениями из продления
    INSERT INTO monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      prepayment,
      remainder,
      remainder_due_date,
      status
    ) VALUES (
      NEW.id,
      NEW.sale_date + INTERVAL '1 month', -- Первый платеж через месяц
      NEW.sale_amount, -- Полная сумма продажи
      NEW.prepayment,  -- Предоплата из продления
      NEW.remainder,   -- Остаток из продления
      NEW.remainder_due_date,
      'pending'
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Обновляем существующую запись для продления Индиры
UPDATE monthly_payments 
SET 
  amount = 300000
WHERE sales_result_id = '3f429549-edc5-4123-86b9-50b4b8effaed';