-- Создаем пользователей для всех сотрудников
-- Функция для создания пользователей через Supabase Auth будет вызвана отдельно

-- Обновляем email на правильный формат для некоторых существующих пользователей
UPDATE employees SET email = 'marlen@mail.ru' WHERE name = 'Марлен';

-- Создаем тестового админа для демонстрации
INSERT INTO employees (name, email, position, department, status, role) VALUES
('Администратор', 'admin@demo.kz', 'Руководитель', 'управление', 'active', 'admin')
ON CONFLICT (email) DO UPDATE SET 
name = EXCLUDED.name,
position = EXCLUDED.position,
department = EXCLUDED.department,
role = EXCLUDED.role;