-- Создаем тестовые проекты с нужными услугами для проверки
INSERT INTO sales_results (
  employee_id,
  client_name,
  project_name,
  work_format,
  sale_amount,
  sale_date,
  project_type
) VALUES 
(
  '391a82b8-8a7e-42e9-ad76-3a6648f9e27f', -- Нұрбек
  'Тестовый клиент 1',
  'Чатбот проект',
  ARRAY['Дожим чатбот'],
  50000,
  CURRENT_DATE,
  'Разовый'
),
(
  '391a82b8-8a7e-42e9-ad76-3a6648f9e27f', -- Нұрбек  
  'Тестовый клиент 2',
  'CRM проект',
  ARRAY['CRM'],
  75000,
  CURRENT_DATE,
  'Разовый'
);