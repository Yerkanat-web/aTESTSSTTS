DELETE FROM project_tasks WHERE id IN (
  'ec1f62ad-810a-459d-9189-d0ef6d0982f2',
  'e23e5347-05d0-46aa-a57f-a396235317f8', 
  '9cd39068-3938-47f2-8ce2-661e6b6c50bd'
);