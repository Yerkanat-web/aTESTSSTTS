-- Обновляем функцию расчета баллов для учета баллов за продажи и отчеты
CREATE OR REPLACE FUNCTION public.calculate_employee_points(emp_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  task_points INTEGER := 0;
  achievement_points INTEGER := 0;
  sales_points INTEGER := 0;
  report_points INTEGER := 0;
  spent_points INTEGER := 0;
  total INTEGER := 0;
BEGIN
  -- Calculate points from completed tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO task_points
  FROM employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';
  
  -- Calculate points from achievements
  SELECT COALESCE(SUM(points), 0) INTO achievement_points
  FROM employee_achievements 
  WHERE employee_id = emp_id;
  
  -- Calculate points from sales (120 points per sale for sales department)
  SELECT COALESCE(COUNT(*) * 120, 0) INTO sales_points
  FROM sales_results sr
  JOIN employees e ON sr.employee_id = e.id
  WHERE sr.employee_id = emp_id AND e.department = 'отдел продаж';
  
  -- Calculate points from daily reports (30 points per report)
  SELECT COALESCE(COUNT(*) * 30, 0) INTO report_points
  FROM daily_reports 
  WHERE employee_id = emp_id;
  
  -- Calculate spent points from shop purchases
  SELECT COALESCE(SUM(item_price), 0) INTO spent_points
  FROM shop_purchases 
  WHERE employee_id = emp_id;
  
  -- Total = task points + achievement points + sales points + report points - spent points
  total := task_points + achievement_points + sales_points + report_points - spent_points;
  
  -- Ensure total is never negative
  IF total < 0 THEN
    total := 0;
  END IF;
  
  -- Log for debugging
  RAISE NOTICE 'Employee % points calculation: tasks=%, achievements=%, sales=%, reports=%, spent=%, total=%', 
    emp_id, task_points, achievement_points, sales_points, report_points, spent_points, total;
  
  -- Update or insert into employee_points
  INSERT INTO employee_points (employee_id, total_points, updated_at)
  VALUES (emp_id, total, now())
  ON CONFLICT (employee_id) 
  DO UPDATE SET 
    total_points = total,
    updated_at = now();
    
  RETURN total;
END;
$$;

-- Создаем триггер для автоматического пересчета баллов при добавлении продаж
CREATE OR REPLACE FUNCTION public.update_points_on_sales()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Пересчитываем баллы при добавлении или удалении продаж
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_employee_points(NEW.employee_id);
    RETURN NEW;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    PERFORM calculate_employee_points(OLD.employee_id);
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Создаем триггер для автоматического пересчета баллов при добавлении отчетов
CREATE OR REPLACE FUNCTION public.update_points_on_reports()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Пересчитываем баллы при добавлении или удалении отчетов
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_employee_points(NEW.employee_id);
    RETURN NEW;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    PERFORM calculate_employee_points(OLD.employee_id);
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Удаляем старые триггеры если они существуют
DROP TRIGGER IF EXISTS sales_points_trigger ON sales_results;
DROP TRIGGER IF EXISTS reports_points_trigger ON daily_reports;

-- Создаем триггеры
CREATE TRIGGER sales_points_trigger
  AFTER INSERT OR UPDATE OR DELETE ON sales_results
  FOR EACH ROW
  EXECUTE FUNCTION update_points_on_sales();

CREATE TRIGGER reports_points_trigger
  AFTER INSERT OR UPDATE OR DELETE ON daily_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_points_on_reports();

-- Пересчитываем баллы для всех существующих сотрудников
DO $$
DECLARE
  emp RECORD;
BEGIN
  FOR emp IN SELECT id FROM employees WHERE status = 'active'
  LOOP
    PERFORM calculate_employee_points(emp.id);
  END LOOP;
END $$;