-- Add foreign key constraint between sales_results and employees
ALTER TABLE sales_results 
ADD CONSTRAINT fk_sales_results_employee 
FOREIGN KEY (employee_id) REFERENCES employees(id);

-- Ensure admin can view all sales results with employee data
-- (This should already exist but let's make sure)
DROP POLICY IF EXISTS "Admins can view all sales with employees" ON sales_results;
CREATE POLICY "Admins can view all sales with employees" 
ON sales_results 
FOR SELECT 
USING (is_admin());