-- Добавляем новый статус проекта "Пауза"
ALTER TYPE public.project_status_enum ADD VALUE IF NOT EXISTS 'Пауза';