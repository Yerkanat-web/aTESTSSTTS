
-- 1) Генератор кода организации
create or replace function public.generate_org_join_code()
returns text
language sql
stable
set search_path to 'public'
as $$
  select upper(encode(gen_random_bytes(5), 'hex')); -- 10 символов HEX в верхнем регистре
$$;

-- 2) Колонки в organizations
alter table public.organizations
  add column if not exists join_code text,
  add column if not exists join_code_enabled boolean not null default true,
  add column if not exists join_code_expires_at timestamptz null;

-- 3) Заполнить коды для существующих организаций
update public.organizations
set join_code = public.generate_org_join_code()
where join_code is null;

-- 4) Уникальный индекс на код
create unique index if not exists organizations_join_code_unique
  on public.organizations (join_code);

-- 5) Функция: получить настройки кода (только для админов)
create or replace function public.get_org_join_settings(p_org_id uuid default null)
returns table (
  org_id uuid,
  join_code text,
  join_code_enabled boolean,
  join_code_expires_at timestamptz
)
language sql
stable
security definer
set search_path to 'public'
as $$
  with org as (
    select coalesce(p_org_id, public.get_single_org_id_for_user()) as id
  )
  select
    o.id as org_id,
    o.join_code,
    o.join_code_enabled,
    o.join_code_expires_at
  from public.organizations o
  join org on o.id = org.id
  where public.is_admin_in_org(o.id);
$$;

-- 6) Функция: сгенерировать новый код (только для админов)
create or replace function public.rotate_org_join_code(p_org_id uuid default null)
returns table (
  org_id uuid,
  join_code text,
  join_code_enabled boolean,
  join_code_expires_at timestamptz
)
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_org uuid;
begin
  v_org := coalesce(p_org_id, public.get_single_org_id_for_user());
  if v_org is null then
    raise exception 'Organization not resolved for current user';
  end if;
  if not public.is_admin_in_org(v_org) then
    raise exception 'Only org admins can rotate the join code';
  end if;

  update public.organizations
  set
    join_code = public.generate_org_join_code(),
    join_code_expires_at = null
  where id = v_org
  returning id, join_code, join_code_enabled, join_code_expires_at
  into org_id, join_code, join_code_enabled, join_code_expires_at;

  return;
end;
$$;

-- 7) Функция: включить/выключить код (только для админов)
create or replace function public.set_org_join_enabled(p_org_id uuid default null, p_enabled boolean)
returns void
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_org uuid;
begin
  v_org := coalesce(p_org_id, public.get_single_org_id_for_user());
  if v_org is null then
    raise exception 'Organization not resolved for current user';
  end if;
  if not public.is_admin_in_org(v_org) then
    raise exception 'Only org admins can update join settings';
  end if;

  update public.organizations
  set join_code_enabled = p_enabled
  where id = v_org;
end;
$$;
