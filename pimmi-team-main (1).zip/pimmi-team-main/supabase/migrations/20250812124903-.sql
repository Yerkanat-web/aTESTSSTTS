-- Ensure triggers to auto-update points and check sales achievements on data changes
DO $$ BEGIN
  -- Drop triggers if they already exist to avoid duplicates
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_points_on_sales') THEN
    DROP TRIGGER trg_update_points_on_sales ON public.sales_results;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_points_on_reports') THEN
    DROP TRIGGER trg_update_points_on_reports ON public.daily_reports;
  END IF;
END $$;

-- Create trigger on sales_results table
CREATE TRIGGER trg_update_points_on_sales
AFTER INSERT OR UPDATE OR DELETE ON public.sales_results
FOR EACH ROW
EXECUTE FUNCTION public.update_points_on_sales();

-- Create trigger on daily_reports table
CREATE TRIGGER trg_update_points_on_reports
AFTER INSERT OR UPDATE OR DELETE ON public.daily_reports
FOR EACH ROW
EXECUTE FUNCTION public.update_points_on_reports();