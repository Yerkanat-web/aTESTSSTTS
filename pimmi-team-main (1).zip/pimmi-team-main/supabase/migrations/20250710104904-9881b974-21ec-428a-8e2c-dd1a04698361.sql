-- Удаляем все данные кроме админа admin@demo.kz
-- Сначала удаляем связанные данные для всех сотрудников кроме админа

-- Удаляем вложения задач для всех сотрудников кроме админа
DELETE FROM task_attachments 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем комментарии к задачам для всех сотрудников кроме админа
DELETE FROM task_comments 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем логи рабочего времени для всех сотрудников кроме админа
DELETE FROM work_time_logs 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем достижения сотрудников для всех кроме админа
DELETE FROM employee_achievements 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем очки сотрудников для всех кроме админа
DELETE FROM employee_points 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем задачи сотрудников для всех кроме админа
DELETE FROM employee_tasks 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем ежедневные отчеты для всех сотрудников кроме админа
DELETE FROM daily_reports 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем результаты продаж для всех сотрудников кроме админа
DELETE FROM sales_results 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Удаляем цели продаж для всех сотрудников кроме админа
DELETE FROM sales_targets 
WHERE employee_id IN (
  SELECT id FROM employees WHERE email != 'admin@demo.kz'
);

-- Сохраняем user_id админа для очистки auth.users
DO $$
DECLARE
  admin_user_id UUID;
BEGIN
  -- Получаем user_id админа
  SELECT user_id INTO admin_user_id 
  FROM employees 
  WHERE email = 'admin@demo.kz';
  
  -- Удаляем всех сотрудников кроме админа
  DELETE FROM employees WHERE email != 'admin@demo.kz';
  
  -- Удаляем профили всех пользователей кроме админа
  IF admin_user_id IS NOT NULL THEN
    DELETE FROM profiles WHERE id != admin_user_id;
  ELSE
    DELETE FROM profiles;
  END IF;
  
  -- Удаляем статистику звонков для всех кроме админа
  IF admin_user_id IS NOT NULL THEN
    DELETE FROM call_statistics WHERE user_id != admin_user_id;
    DELETE FROM call_records WHERE user_id != admin_user_id;
  ELSE
    DELETE FROM call_statistics;
    DELETE FROM call_records;
  END IF;
  
  -- Удаляем прогресс пользователей кроме админа
  IF admin_user_id IS NOT NULL THEN
    DELETE FROM user_progress WHERE user_id != admin_user_id;
  ELSE
    DELETE FROM user_progress;
  END IF;
END $$;

-- Обновляем email админа на admin@demo.kz если нужно
UPDATE employees 
SET email = 'admin@demo.kz' 
WHERE role = 'admin' AND status = 'active';