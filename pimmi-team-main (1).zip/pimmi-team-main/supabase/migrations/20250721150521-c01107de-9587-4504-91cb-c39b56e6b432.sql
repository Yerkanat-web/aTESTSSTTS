-- Помечаем все просроченные задачи сотрудников как выполненные
UPDATE employee_tasks 
SET 
  status = 'completed',
  completed_at = now(),
  updated_at = now()
WHERE due_date < CURRENT_DATE 
  AND status != 'completed';

-- Помечаем все просроченные проектные задачи как выполненные
UPDATE project_tasks 
SET 
  status = 'completed',
  completed_at = now(),
  updated_at = now()
WHERE due_date < CURRENT_DATE 
  AND status != 'completed';