-- Обновляем функцию для более точной проверки достижений
CREATE OR REPLACE FUNCTION public.check_achievements_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  task_count INTEGER;
  streak_days INTEGER;
  category_count INTEGER;
BEGIN
  -- Проверяем достижения когда задача помечается как выполненная
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Пересчитываем баллы
    PERFORM calculate_employee_points(NEW.employee_id);
    
    -- Логируем для отладки
    RAISE NOTICE 'Achievement check triggered for employee: %', NEW.employee_id;
    
    -- Проверяем простые достижения по количеству задач
    SELECT COUNT(*) INTO task_count 
    FROM employee_tasks 
    WHERE employee_id = NEW.employee_id AND status = 'completed';
    
    -- Логируем количество выполненных задач
    RAISE NOTICE 'Employee % has completed % tasks', NEW.employee_id, task_count;
    
    -- Здесь можно добавить автоматическое присуждение достижений
    -- Пока оставляем только логирование
    
  END IF;
  
  RETURN NEW;
END;
$$;

-- Пересоздаем триггер
DROP TRIGGER IF EXISTS check_achievements_on_task_completion ON employee_tasks;
CREATE TRIGGER check_achievements_on_task_completion
  AFTER UPDATE ON employee_tasks
  FOR EACH ROW
  EXECUTE FUNCTION check_achievements_trigger();

-- Добавляем индексы для улучшения производительности запросов достижений
CREATE INDEX IF NOT EXISTS idx_employee_tasks_employee_status 
ON employee_tasks(employee_id, status);

CREATE INDEX IF NOT EXISTS idx_employee_tasks_employee_priority_status 
ON employee_tasks(employee_id, priority, status);

CREATE INDEX IF NOT EXISTS idx_employee_tasks_completed_at 
ON employee_tasks(completed_at) 
WHERE status = 'completed';

CREATE INDEX IF NOT EXISTS idx_employee_achievements_employee_name 
ON employee_achievements(employee_id, achievement_name);