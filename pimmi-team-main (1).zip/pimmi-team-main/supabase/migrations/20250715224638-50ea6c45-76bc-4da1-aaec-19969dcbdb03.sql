-- Добавляем RLS политики для руководителей отделов

-- Политика для project_tasks - руководители отделов могут видеть задачи своих сотрудников
CREATE POLICY "Department leads can view their department project tasks" 
ON project_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1
    FROM employees manager, employees assignee
    WHERE manager.user_id = auth.uid()
    AND assignee.id = project_tasks.assignee_id
    AND (
      (manager.role = 'руководитель тех отдела' AND assignee.department = 'тех отдел') OR
      (manager.role = 'руководитель отдела продаж' AND assignee.department = 'отдел продаж') OR
      (manager.role = 'руководитель ИИ отдела' AND assignee.department = 'креатив отдел')
    )
  )
);

-- Политика для project_cases - руководители отделов могут видеть кейсы для работы с клиентами
CREATE POLICY "Department leads can view project cases" 
ON project_cases 
FOR SELECT 
USING (
  is_active = true AND 
  EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = auth.uid()
    AND role IN ('руководитель тех отдела', 'руководитель отдела продаж', 'руководитель ИИ отдела')
  )
);