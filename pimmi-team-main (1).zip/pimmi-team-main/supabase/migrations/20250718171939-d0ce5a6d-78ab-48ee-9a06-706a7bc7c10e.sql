-- Разрешаем руководителям отделов редактировать продления проектов
CREATE POLICY "Department leads can update project extensions" 
ON sales_results 
FOR UPDATE 
USING (
  is_extension = true AND 
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.user_id = auth.uid() 
    AND employees.role IN ('руководитель тех отдела', 'руководитель отдела продаж', 'руководитель ИИ отдела')
    AND employees.status = 'active'
  )
);