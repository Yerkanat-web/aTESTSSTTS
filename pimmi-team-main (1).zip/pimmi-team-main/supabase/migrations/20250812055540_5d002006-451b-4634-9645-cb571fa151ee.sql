-- 1) Organizations and memberships
CREATE TABLE IF NOT EXISTS public.organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'organizations' AND policyname = 'Members can view their orgs'
  ) THEN
    CREATE POLICY "Members can view their orgs" ON public.organizations
    FOR SELECT USING (
      EXISTS (
        SELECT 1 FROM public.organization_members m 
        WHERE m.org_id = organizations.id AND m.user_id = auth.uid()
      )
    );
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.organization_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  role text NOT NULL DEFAULT 'member',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, user_id)
);

ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'organization_members' AND policyname = 'Users can view their memberships'
  ) THEN
    CREATE POLICY "Users can view their memberships" ON public.organization_members
    FOR SELECT USING (user_id = auth.uid());
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'organization_members' AND policyname = 'Users can insert their membership'
  ) THEN
    CREATE POLICY "Users can insert their membership" ON public.organization_members
    FOR INSERT WITH CHECK (user_id = auth.uid());
  END IF;
END $$;

-- 2) Add org_id columns to key domain tables (nullable for compatibility) + indexes
ALTER TABLE public.employees ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_employees_org_id ON public.employees(org_id);

ALTER TABLE public.sales_results ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_sales_results_org_id ON public.sales_results(org_id);

ALTER TABLE public.project_tasks ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_project_tasks_org_id ON public.project_tasks(org_id);

ALTER TABLE public.employee_tasks ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_employee_tasks_org_id ON public.employee_tasks(org_id);

ALTER TABLE public.daily_reports ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_daily_reports_org_id ON public.daily_reports(org_id);

ALTER TABLE public.employee_achievements ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_employee_achievements_org_id ON public.employee_achievements(org_id);

ALTER TABLE public.employee_points ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_employee_points_org_id ON public.employee_points(org_id);

ALTER TABLE public.shop_purchases ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_shop_purchases_org_id ON public.shop_purchases(org_id);

ALTER TABLE public.project_accounts ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_project_accounts_org_id ON public.project_accounts(org_id);

ALTER TABLE public.monthly_payments ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_monthly_payments_org_id ON public.monthly_payments(org_id);

ALTER TABLE public.project_cases ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_project_cases_org_id ON public.project_cases(org_id);

ALTER TABLE public.project_categories ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_project_categories_org_id ON public.project_categories(org_id);

ALTER TABLE public.sales_targets ADD COLUMN IF NOT EXISTS org_id uuid;
CREATE INDEX IF NOT EXISTS idx_sales_targets_org_id ON public.sales_targets(org_id);

-- 3) Seed default org and backfill existing data based on employees
DO $$
DECLARE
  default_org_id uuid;
BEGIN
  -- Ensure default organization exists
  INSERT INTO public.organizations (name, slug)
  VALUES ('Main Company', 'main')
  ON CONFLICT (slug) DO NOTHING;

  SELECT id INTO default_org_id FROM public.organizations WHERE slug = 'main';

  -- Backfill employees.org_id
  UPDATE public.employees
  SET org_id = COALESCE(org_id, default_org_id);

  -- Create memberships for users who already exist
  INSERT INTO public.organization_members (org_id, user_id, role)
  SELECT DISTINCT e.org_id, e.user_id, 'member'
  FROM public.employees e
  WHERE e.user_id IS NOT NULL
  ON CONFLICT (org_id, user_id) DO NOTHING;

  -- Backfill org_id across tables using employees linkage
  UPDATE public.sales_results sr
  SET org_id = COALESCE(sr.org_id, e.org_id)
  FROM public.employees e
  WHERE sr.employee_id = e.id;

  UPDATE public.project_tasks pt
  SET org_id = COALESCE(pt.org_id, e.org_id)
  FROM public.employees e
  WHERE pt.assignee_id = e.id;
  -- Fallback via sales_result
  UPDATE public.project_tasks pt
  SET org_id = COALESCE(pt.org_id, sr.org_id)
  FROM public.sales_results sr
  WHERE pt.sales_result_id = sr.id;

  UPDATE public.employee_tasks t
  SET org_id = COALESCE(t.org_id, e.org_id)
  FROM public.employees e
  WHERE t.employee_id = e.id;

  UPDATE public.daily_reports r
  SET org_id = COALESCE(r.org_id, e.org_id)
  FROM public.employees e
  WHERE r.employee_id = e.id;

  UPDATE public.employee_achievements a
  SET org_id = COALESCE(a.org_id, e.org_id)
  FROM public.employees e
  WHERE a.employee_id = e.id;

  UPDATE public.employee_points p
  SET org_id = COALESCE(p.org_id, e.org_id)
  FROM public.employees e
  WHERE p.employee_id = e.id;

  UPDATE public.shop_purchases sp
  SET org_id = COALESCE(sp.org_id, e.org_id)
  FROM public.employees e
  WHERE sp.employee_id = e.id;

  UPDATE public.project_accounts pa
  SET org_id = COALESCE(pa.org_id, sr.org_id)
  FROM public.sales_results sr
  WHERE pa.sales_result_id = sr.id;

  UPDATE public.monthly_payments mp
  SET org_id = COALESCE(mp.org_id, sr.org_id)
  FROM public.sales_results sr
  WHERE mp.sales_result_id = sr.id;

  -- For standalone catalogs, default them to default org if empty
  UPDATE public.project_cases pc
  SET org_id = COALESCE(org_id, default_org_id);

  UPDATE public.project_categories pc
  SET org_id = COALESCE(org_id, default_org_id);

  UPDATE public.sales_targets st
  SET org_id = COALESCE(st.org_id, e.org_id)
  FROM public.employees e
  WHERE st.employee_id = e.id;
END $$;
