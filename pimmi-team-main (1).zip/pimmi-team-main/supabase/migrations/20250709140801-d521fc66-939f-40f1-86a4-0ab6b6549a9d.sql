-- Add DELETE policy for employees to delete their own tasks
CREATE POLICY "Employees can delete their own tasks" 
ON public.employee_tasks 
FOR DELETE 
USING (EXISTS (
  SELECT 1
  FROM employees
  WHERE employees.id = employee_tasks.employee_id 
  AND employees.user_id = auth.uid()
));