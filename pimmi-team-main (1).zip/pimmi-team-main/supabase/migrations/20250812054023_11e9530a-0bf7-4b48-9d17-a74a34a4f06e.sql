
-- Добавляем членство 'member' в "Main Company" всем существующим пользователям,
-- у которых есть запись в employees и установлен user_id
INSERT INTO public.organization_members (org_id, user_id, org_role)
SELECT o.id, e.user_id, 'member'
FROM public.organizations o
JOIN public.employees e ON e.user_id IS NOT NULL
LEFT JOIN public.organization_members om 
  ON om.org_id = o.id AND om.user_id = e.user_id
WHERE o.name = 'Main Company'
  AND om.id IS NULL;
