-- Add RLS policy for financists to view all employees for analytics
CREATE POLICY "Financists can view all employees for analytics" 
ON public.employees 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND role = 'финансист'
    AND status = 'active'
  )
);