-- Исправляем функцию award_achievement_safely - убираем конфликт имен
DROP FUNCTION IF EXISTS public.award_achievement_safely(UUID, TEXT, TEXT, INTEGER);

CREATE OR REPLACE FUNCTION public.award_achievement_safely(
  emp_id UUID,
  ach_name TEXT,
  ach_description TEXT,
  ach_points INTEGER
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Проверяем, что достижение еще не получено
  IF EXISTS (
    SELECT 1 FROM employee_achievements 
    WHERE employee_id = emp_id AND achievement_name = ach_name
  ) THEN
    RETURN FALSE; -- Достижение уже получено
  END IF;
  
  -- Присуждаем достижение
  INSERT INTO employee_achievements (
    employee_id, 
    achievement_name, 
    description, 
    points
  ) VALUES (
    emp_id, 
    ach_name, 
    ach_description, 
    ach_points
  );
  
  -- Пересчитываем баллы
  PERFORM calculate_employee_points(emp_id);
  
  RETURN TRUE; -- Достижение успешно присуждено
END;
$$;