-- Удаляем существующие политики для employees
DROP POLICY IF EXISTS "Admins can view all employees" ON employees;
DROP POLICY IF EXISTS "Admins can insert employees" ON employees;
DROP POLICY IF EXISTS "Admins can update employees" ON employees;
DROP POLICY IF EXISTS "Admins can delete employees" ON employees;

-- Создаем функцию для проверки роли администратора без рекурсии
CREATE OR REPLACE FUNCTION public.is_admin(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = check_user_id
    AND role = 'admin'
    AND status = 'active'
  );
$$;

-- Создаем новые политики без рекурсии
CREATE POLICY "Admins can view all employees" 
ON employees 
FOR SELECT 
USING (
  -- Администраторы могут видеть всех, сотрудники только себя
  CASE 
    WHEN auth.uid() IS NULL THEN false
    WHEN public.is_admin() THEN true
    ELSE auth.uid() = user_id
  END
);

CREATE POLICY "Admins can insert employees" 
ON employees 
FOR INSERT 
WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update employees" 
ON employees 
FOR UPDATE 
USING (public.is_admin());

CREATE POLICY "Admins can delete employees" 
ON employees 
FOR DELETE 
USING (public.is_admin());