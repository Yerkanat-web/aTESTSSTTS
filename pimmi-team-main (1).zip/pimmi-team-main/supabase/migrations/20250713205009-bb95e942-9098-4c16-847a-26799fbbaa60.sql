-- Update monthly payments system to create one payment at a time

-- First, let's create a function to create the next monthly payment
CREATE OR REPLACE FUNCTION public.create_next_monthly_payment(p_sales_result_id UUID, p_monthly_amount NUMERIC, p_from_date DATE DEFAULT CURRENT_DATE)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  next_payment_date DATE;
BEGIN
  -- Calculate next payment date (add one month to the from_date)
  next_payment_date := p_from_date + INTERVAL '1 month';
  
  -- Check if payment for this date already exists
  IF NOT EXISTS (
    SELECT 1 FROM public.monthly_payments 
    WHERE sales_result_id = p_sales_result_id 
    AND payment_date = next_payment_date
  ) THEN
    -- Create the next monthly payment
    INSERT INTO public.monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      status
    ) VALUES (
      p_sales_result_id,
      next_payment_date,
      p_monthly_amount,
      'pending'
    );
  END IF;
END;
$$;

-- Update the generate_monthly_payments function to create only the first payment
CREATE OR REPLACE FUNCTION public.generate_monthly_payments(p_sales_result_id UUID, p_monthly_amount NUMERIC, p_start_date DATE, p_months_count INTEGER DEFAULT 1)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  i INTEGER;
  payment_date DATE;
BEGIN
  -- Delete existing monthly payments for this sales result to avoid duplicates
  DELETE FROM public.monthly_payments 
  WHERE sales_result_id = p_sales_result_id;
  
  -- Generate only the specified number of payment records (default 1)
  FOR i IN 0..(p_months_count - 1) LOOP
    payment_date := p_start_date + (i || ' months')::INTERVAL;
    
    INSERT INTO public.monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      status
    ) VALUES (
      p_sales_result_id,
      payment_date,
      p_monthly_amount,
      'pending'
    );
  END LOOP;
END;
$$;

-- Update the mark_payment_as_paid function to create the next payment
CREATE OR REPLACE FUNCTION public.mark_payment_as_paid(p_payment_id UUID, p_actual_date DATE DEFAULT CURRENT_DATE, p_notes TEXT DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  payment_record RECORD;
  monthly_amount NUMERIC;
BEGIN
  -- Get the payment record and related sales result
  SELECT mp.*, sr.project_type, 
         CASE 
           WHEN sr.remainder > 0 THEN sr.remainder
           ELSE sr.sale_amount / 12
         END as calculated_amount
  INTO payment_record
  FROM public.monthly_payments mp
  JOIN public.sales_results sr ON mp.sales_result_id = sr.id
  WHERE mp.id = p_payment_id;
  
  -- Update the payment status
  UPDATE public.monthly_payments
  SET 
    status = 'paid',
    actual_payment_date = p_actual_date,
    notes = COALESCE(p_notes, notes),
    updated_at = now()
  WHERE id = p_payment_id;
  
  -- If this is a monthly project, create the next payment
  IF payment_record.project_type IN ('Ежемесячный', 'ежемесячно') THEN
    PERFORM public.create_next_monthly_payment(
      payment_record.sales_result_id,
      payment_record.calculated_amount,
      payment_record.payment_date
    );
  END IF;
END;
$$;

-- Update the handle_monthly_project_payments trigger function to create only one payment
CREATE OR REPLACE FUNCTION public.handle_monthly_project_payments()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  -- Only process if project_type is 'Ежемесячный' or 'ежемесячно'
  IF NEW.project_type IN ('Ежемесячный', 'ежемесячно') THEN
    -- Calculate monthly amount (if remainder exists, use it, otherwise use sale_amount / 12)
    IF NEW.remainder > 0 THEN
      monthly_amount := NEW.remainder;
    ELSE
      monthly_amount := NEW.sale_amount / 12;
    END IF;
    
    -- Use remainder_due_date as start date, otherwise use sale_date + 1 month
    IF NEW.remainder_due_date IS NOT NULL THEN
      start_date := NEW.remainder_due_date;
    ELSE
      start_date := NEW.sale_date + INTERVAL '1 month';
    END IF;
    
    -- Generate only the first monthly payment
    PERFORM public.generate_monthly_payments(
      NEW.id,
      monthly_amount,
      start_date,
      1 -- Create only one payment initially
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Clean up duplicate payments for existing sales (keep only the earliest payment for each sales_result_id)
WITH ranked_payments AS (
  SELECT id, 
         ROW_NUMBER() OVER (PARTITION BY sales_result_id ORDER BY payment_date ASC) as rn
  FROM public.monthly_payments
  WHERE sales_result_id IN (
    SELECT sr.id 
    FROM sales_results sr 
    WHERE sr.project_type IN ('Ежемесячный', 'ежемесячно')
  )
)
DELETE FROM public.monthly_payments 
WHERE id IN (
  SELECT id FROM ranked_payments WHERE rn > 1
);