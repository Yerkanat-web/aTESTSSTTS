-- Изменение роли и отдела для пользователя sakenova@list.ru
UPDATE employees 
SET role = 'employee', 
    department = 'тех отдел',
    updated_at = now()
WHERE email = 'sakenova@list.ru';