UPDATE employees 
SET department = 'финансовый отдел', updated_at = now()
WHERE id = '4c4ed364-9254-45ce-b6cd-3755f8e4d7df';