-- Добавляем политику для руководителей тех отдела на полное редактирование продаж
CREATE POLICY "Tech leads can fully update sales results" 
ON public.sales_results 
FOR UPDATE 
USING (EXISTS ( 
  SELECT 1 
  FROM employees 
  WHERE employees.user_id = auth.uid() 
    AND employees.role = 'руководитель тех отдела'
    AND employees.status = 'active'
));