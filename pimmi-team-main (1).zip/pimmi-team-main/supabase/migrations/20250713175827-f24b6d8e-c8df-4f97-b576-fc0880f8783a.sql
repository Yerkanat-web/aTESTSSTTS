-- Обновляем политики для покупок в магазине
DROP POLICY IF EXISTS "Employees can view their own purchases" ON shop_purchases;
CREATE POLICY "Employees and financists can view their own purchases" 
ON shop_purchases 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = shop_purchases.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can create their own purchases" ON shop_purchases;
CREATE POLICY "Employees and financists can create their own purchases" 
ON shop_purchases 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = shop_purchases.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

-- Обновляем политики для отчетов
DROP POLICY IF EXISTS "Employees can view their own reports" ON daily_reports;
CREATE POLICY "Employees and financists can view their own reports" 
ON daily_reports 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = daily_reports.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can insert their own reports" ON daily_reports;
CREATE POLICY "Employees and financists can insert their own reports" 
ON daily_reports 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = daily_reports.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can update their own reports" ON daily_reports;
CREATE POLICY "Employees and financists can update their own reports" 
ON daily_reports 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = daily_reports.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

-- Обновляем политики для рабочих логов времени
DROP POLICY IF EXISTS "Employees can manage their own time logs" ON work_time_logs;
CREATE POLICY "Employees and financists can manage their own time logs" 
ON work_time_logs 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = work_time_logs.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);