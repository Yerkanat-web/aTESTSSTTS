-- Обновляем политику для обновления задач, добавляя руководителей отделов
DROP POLICY IF EXISTS "Employees and financists can update their own tasks" ON employee_tasks;

CREATE POLICY "Employees, financists and department leads can update their own tasks" 
ON employee_tasks 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1
    FROM employees
    WHERE employees.id = employee_tasks.employee_id 
    AND employees.user_id = auth.uid() 
    AND (
      employees.role = ANY (ARRAY['employee'::text, 'финансист'::text]) OR
      employees.role LIKE 'руководитель%'
    )
  )
);