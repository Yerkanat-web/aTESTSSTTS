-- Создаем таблицу для истории покупок в магазине
CREATE TABLE public.shop_purchases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL REFERENCES employees(id),
  item_name TEXT NOT NULL,
  item_price INTEGER NOT NULL,
  points_before INTEGER NOT NULL,
  points_after INTEGER NOT NULL,
  purchase_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Включаем RLS
ALTER TABLE public.shop_purchases ENABLE ROW LEVEL SECURITY;

-- Политики для покупок
CREATE POLICY "Admins can manage all purchases" 
ON public.shop_purchases 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their own purchases" 
ON public.shop_purchases 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = shop_purchases.employee_id 
  AND employees.user_id = auth.uid()
));

CREATE POLICY "Employees can create their own purchases" 
ON public.shop_purchases 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = shop_purchases.employee_id 
  AND employees.user_id = auth.uid()
));

-- Функция для списания баллов и записи покупки
CREATE OR REPLACE FUNCTION public.process_shop_purchase(
  emp_id UUID,
  item_name TEXT,
  item_price INTEGER
) RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_points INTEGER;
  new_points INTEGER;
  purchase_result JSON;
BEGIN
  -- Получаем текущие баллы
  SELECT total_points INTO current_points
  FROM employee_points 
  WHERE employee_id = emp_id;
  
  -- Если записи нет, создаем ее с 0 баллов
  IF current_points IS NULL THEN
    INSERT INTO employee_points (employee_id, total_points)
    VALUES (emp_id, 0)
    ON CONFLICT (employee_id) DO NOTHING;
    current_points := 0;
  END IF;
  
  -- Проверяем достаточность баллов
  IF current_points < item_price THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Недостаточно баллов',
      'current_points', current_points,
      'required_points', item_price
    );
  END IF;
  
  -- Рассчитываем новое количество баллов
  new_points := current_points - item_price;
  
  -- Обновляем баллы
  UPDATE employee_points 
  SET total_points = new_points, updated_at = now()
  WHERE employee_id = emp_id;
  
  -- Создаем запись о покупке
  INSERT INTO shop_purchases (
    employee_id, 
    item_name, 
    item_price, 
    points_before, 
    points_after
  ) VALUES (
    emp_id, 
    item_name, 
    item_price, 
    current_points, 
    new_points
  );
  
  -- Возвращаем результат
  RETURN json_build_object(
    'success', true,
    'points_before', current_points,
    'points_after', new_points,
    'item_name', item_name,
    'item_price', item_price
  );
END;
$$;