-- Remove file_content column from task_attachments as we'll use Storage for all files
ALTER TABLE public.task_attachments 
DROP COLUMN IF EXISTS file_content;

-- Update RLS policy to ensure admins can access all attachments
DROP POLICY IF EXISTS "Admins can manage all attachments" ON task_attachments;

CREATE POLICY "Admins can access all attachments" 
ON task_attachments 
FOR ALL 
USING (is_admin());