-- Удаляем старый constraint
ALTER TABLE employee_tasks DROP CONSTRAINT employee_tasks_status_check;

-- Добавляем новый constraint с дополнительными статусами
ALTER TABLE employee_tasks ADD CONSTRAINT employee_tasks_status_check 
CHECK (status = ANY (ARRAY['pending'::text, 'in_progress'::text, 'completed'::text, 'cancelled'::text, 'postponed'::text, 'issues'::text]));