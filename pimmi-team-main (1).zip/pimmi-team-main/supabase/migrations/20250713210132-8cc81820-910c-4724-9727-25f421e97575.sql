-- Исправим логику создания даты для ежемесячных платежей
CREATE OR REPLACE FUNCTION public.handle_monthly_project_payments()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  -- Only process if project_type is 'Ежемесячный' or 'ежемесячно'
  IF NEW.project_type IN ('Ежемесячный', 'ежемесячно') THEN
    -- Calculate monthly amount (if remainder exists, use it, otherwise use sale_amount / 12)
    IF NEW.remainder > 0 THEN
      monthly_amount := NEW.remainder;
    ELSE
      monthly_amount := NEW.sale_amount / 12;
    END IF;
    
    -- For monthly projects, ALWAYS use sale_date + 1 month for first payment
    -- This ensures monthly payments start the month after the sale
    start_date := NEW.sale_date + INTERVAL '1 month';
    
    -- Generate only the first monthly payment
    PERFORM public.generate_monthly_payments(
      NEW.id,
      monthly_amount,
      start_date,
      1 -- Create only one payment initially
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Теперь пересоздадим ежемесячные платежи для существующих продаж с правильными датами
DELETE FROM public.monthly_payments 
WHERE sales_result_id IN (
  SELECT id FROM sales_results 
  WHERE project_type IN ('Ежемесячный', 'ежемесячно')
);

-- Создадим платежи с правильными датами для всех ежемесячных продаж
DO $$
DECLARE
  sale_record RECORD;
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  FOR sale_record IN 
    SELECT * FROM sales_results 
    WHERE project_type IN ('Ежемесячный', 'ежемесячно')
  LOOP
    -- Calculate monthly amount
    IF sale_record.remainder > 0 THEN
      monthly_amount := sale_record.remainder;
    ELSE
      monthly_amount := sale_record.sale_amount / 12;
    END IF;
    
    -- Always use sale_date + 1 month for monthly projects
    start_date := sale_record.sale_date + INTERVAL '1 month';
    
    -- Generate the first monthly payment
    PERFORM public.generate_monthly_payments(
      sale_record.id,
      monthly_amount,
      start_date,
      1
    );
    
    RAISE NOTICE 'Recreated monthly payment for %: sale_date=%, payment_date=%', 
                 sale_record.project_name, sale_record.sale_date, start_date;
  END LOOP;
END $$;