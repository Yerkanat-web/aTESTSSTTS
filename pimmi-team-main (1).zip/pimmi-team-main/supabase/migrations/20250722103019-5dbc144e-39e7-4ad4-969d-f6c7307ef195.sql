-- Add RLS policies for financist to view sales data
CREATE POLICY "Financists can view all sales data" 
ON public.sales_results 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND role = 'финансист'
    AND status = 'active'
  )
);