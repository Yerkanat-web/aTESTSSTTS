-- Создаем триггеры для автоматического обновления баллов
CREATE TRIGGER employee_tasks_points_trigger
    AFTER INSERT OR UPDATE OR DELETE ON employee_tasks
    FOR EACH ROW
    EXECUTE FUNCTION update_employee_points_trigger();

CREATE TRIGGER employee_achievements_points_trigger
    AFTER INSERT OR UPDATE OR DELETE ON employee_achievements
    FOR EACH ROW
    EXECUTE FUNCTION update_employee_points_trigger();