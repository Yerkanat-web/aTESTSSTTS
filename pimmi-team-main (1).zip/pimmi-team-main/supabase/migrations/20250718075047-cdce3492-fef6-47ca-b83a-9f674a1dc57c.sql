-- Создаем функцию для удаления старых платежей при создании продления
CREATE OR REPLACE FUNCTION public.handle_extension_payments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
BEGIN
  -- Проверяем, что это продление проекта
  IF NEW.is_extension = TRUE AND NEW.parent_project_id IS NOT NULL THEN
    -- Удаляем все ежемесячные платежи для оригинального проекта
    DELETE FROM public.monthly_payments 
    WHERE sales_result_id = NEW.parent_project_id;
    
    -- Логируем для отладки
    RAISE NOTICE 'Deleted monthly payments for original project: %', NEW.parent_project_id;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Создаем триггер, который будет срабатывать при создании продления
CREATE TRIGGER handle_extension_payments_trigger
  AFTER INSERT ON public.sales_results
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_extension_payments();