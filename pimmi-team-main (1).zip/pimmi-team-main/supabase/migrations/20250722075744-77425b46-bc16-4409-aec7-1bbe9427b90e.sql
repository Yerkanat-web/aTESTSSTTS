-- Модифицируем функцию расчета остатка чтобы не пересчитывать для продлений
CREATE OR REPLACE FUNCTION public.calculate_monthly_payment_remainder()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  -- Проверяем, является ли это платежом продления
  IF EXISTS (
    SELECT 1 FROM sales_results 
    WHERE id = NEW.sales_result_id AND is_extension = true
  ) THEN
    -- Для продлений оставляем остаток как есть (уже правильно установлен)
    RETURN NEW;
  ELSE
    -- Для обычных продаж рассчитываем остаток как обычно
    NEW.remainder = NEW.amount - COALESCE(NEW.prepayment, 0);
    RETURN NEW;
  END IF;
END;
$function$;

-- Исправляем остаток для продления Индиры
UPDATE monthly_payments 
SET remainder = 100000
WHERE sales_result_id = '3f429549-edc5-4123-86b9-50b4b8effaed';