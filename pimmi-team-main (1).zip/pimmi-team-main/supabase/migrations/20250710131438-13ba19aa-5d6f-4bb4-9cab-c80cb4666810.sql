-- Update RLS policy for task_attachments to allow admins to view all attachments
DROP POLICY IF EXISTS "Employees can view attachments on their tasks" ON task_attachments;

CREATE POLICY "Employees can view attachments on their tasks" 
ON task_attachments 
FOR SELECT 
USING (
  -- Admins can see all attachments
  is_admin() 
  OR 
  -- Employees can see attachments on their own tasks
  EXISTS (
    SELECT 1 
    FROM employees e
    JOIN employee_tasks t ON t.employee_id = e.id
    WHERE t.id = task_attachments.task_id 
    AND e.user_id = auth.uid()
  )
);

-- Also add policy for admins to delete any attachments
CREATE POLICY "Admins can delete all attachments" 
ON task_attachments 
FOR DELETE 
USING (is_admin());