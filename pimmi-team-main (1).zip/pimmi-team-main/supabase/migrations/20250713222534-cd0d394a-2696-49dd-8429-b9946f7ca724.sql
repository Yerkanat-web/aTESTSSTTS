-- Добавляем политику INSERT для всех сотрудников в project_accounts
CREATE POLICY "All employees can create project accounts" 
ON public.project_accounts 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM employees 
  WHERE user_id = auth.uid() 
  AND role = 'employee'
));