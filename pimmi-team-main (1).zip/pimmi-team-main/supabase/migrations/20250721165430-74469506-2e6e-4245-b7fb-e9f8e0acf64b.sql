-- Создаем таблицу для логирования действий сотрудников
CREATE TABLE public.employee_activity_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL,
  action_description TEXT NOT NULL,
  target_type TEXT, -- тип объекта (task, sale, project, etc.)
  target_id UUID, -- id объекта
  metadata JSONB, -- дополнительные данные
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Создаем индексы для оптимизации запросов
CREATE INDEX idx_activity_logs_employee_id ON public.employee_activity_logs(employee_id);
CREATE INDEX idx_activity_logs_created_at ON public.employee_activity_logs(created_at DESC);
CREATE INDEX idx_activity_logs_action_type ON public.employee_activity_logs(action_type);
CREATE INDEX idx_activity_logs_target_type ON public.employee_activity_logs(target_type);

-- Включаем RLS
ALTER TABLE public.employee_activity_logs ENABLE ROW LEVEL SECURITY;

-- Политики RLS - только админы могут видеть логи
CREATE POLICY "Admins can view all activity logs" 
ON public.employee_activity_logs 
FOR SELECT 
USING (is_admin());

CREATE POLICY "System can insert activity logs" 
ON public.employee_activity_logs 
FOR INSERT 
WITH CHECK (true);

-- Создаем представление для удобного просмотра логов с информацией о сотрудниках
CREATE VIEW public.employee_activity_logs_view AS
SELECT 
  al.id,
  al.employee_id,
  e.name as employee_name,
  e.email as employee_email,
  e.department,
  e.position,
  al.action_type,
  al.action_description,
  al.target_type,
  al.target_id,
  al.metadata,
  al.ip_address,
  al.user_agent,
  al.created_at
FROM public.employee_activity_logs al
JOIN public.employees e ON al.employee_id = e.id;

-- Функция для записи логов действий
CREATE OR REPLACE FUNCTION public.log_employee_action(
  p_employee_id UUID,
  p_action_type TEXT,
  p_action_description TEXT,
  p_target_type TEXT DEFAULT NULL,
  p_target_id UUID DEFAULT NULL,
  p_metadata JSONB DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.employee_activity_logs (
    employee_id,
    action_type,
    action_description,
    target_type,
    target_id,
    metadata
  ) VALUES (
    p_employee_id,
    p_action_type,
    p_action_description,
    p_target_type,
    p_target_id,
    p_metadata
  );
END;
$$;

-- Функция для автоматической очистки старых логов (старше 90 дней)
CREATE OR REPLACE FUNCTION public.cleanup_old_activity_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM public.employee_activity_logs 
  WHERE created_at < NOW() - INTERVAL '90 days';
END;
$$;