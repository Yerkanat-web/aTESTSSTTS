-- Add INSERT policy for employees to create their own tasks
CREATE POLICY "Employees can insert their own tasks" 
ON public.employee_tasks 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1
  FROM employees
  WHERE employees.id = employee_tasks.employee_id 
  AND employees.user_id = auth.uid()
));