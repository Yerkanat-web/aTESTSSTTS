-- Добавляем политику для самостоятельной регистрации
CREATE POLICY "Users can create their own employee record" 
ON employees 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Также обновим политику для просмотра, чтобы пользователи могли видеть свою запись
DROP POLICY IF EXISTS "Admins can view all employees" ON employees;

CREATE POLICY "Users can view employees" 
ON employees 
FOR SELECT 
USING (
  -- Администраторы могут видеть всех, сотрудники только себя
  CASE 
    WHEN auth.uid() IS NULL THEN false
    WHEN public.is_admin() THEN true
    ELSE auth.uid() = user_id
  END
);