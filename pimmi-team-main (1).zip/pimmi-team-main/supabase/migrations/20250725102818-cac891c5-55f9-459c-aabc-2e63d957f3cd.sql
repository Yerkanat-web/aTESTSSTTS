-- Allow financists to view all sales results for analytics
CREATE POLICY "Financists can view all sales results" 
ON public.sales_results 
FOR SELECT 
USING (is_financist());