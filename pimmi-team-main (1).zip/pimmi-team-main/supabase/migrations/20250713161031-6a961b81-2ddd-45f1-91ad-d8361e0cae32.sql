-- Активируем Muha и обновляем его должность
UPDATE employees 
SET status = 'active', position = 'таргетолог'
WHERE name = 'Муха' AND email = 'muha@mail.ru';