-- Добавляем новые столбцы в таблицу monthly_payments
ALTER TABLE public.monthly_payments 
ADD COLUMN IF NOT EXISTS prepayment NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS remainder NUMERIC DEFAULT 0;

-- Добавляем функцию для автоматического расчета остатка
CREATE OR REPLACE FUNCTION public.calculate_monthly_payment_remainder()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.remainder = NEW.amount - COALESCE(NEW.prepayment, 0);
  RETURN NEW;
END;
$$;

-- Создаем триггер для автоматического расчета остатка
DROP TRIGGER IF EXISTS calculate_remainder_trigger ON public.monthly_payments;
CREATE TRIGGER calculate_remainder_trigger
  BEFORE INSERT OR UPDATE ON public.monthly_payments
  FOR EACH ROW
  EXECUTE FUNCTION public.calculate_monthly_payment_remainder();

-- Обновляем существующие записи - заполняем amount как remainder (так как prepayment = 0)
UPDATE public.monthly_payments 
SET remainder = amount 
WHERE remainder IS NULL OR remainder = 0;