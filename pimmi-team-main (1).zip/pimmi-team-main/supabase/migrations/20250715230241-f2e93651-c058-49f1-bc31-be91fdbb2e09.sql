-- Обновляем права доступа для project_tasks (добавляем доступ руководителям к данным о проектах)
CREATE POLICY "Department leads can view project task details" 
ON project_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1
    FROM employees manager
    WHERE manager.user_id = auth.uid()
    AND (
      manager.role = 'руководитель тех отдела' OR
      (manager.role = 'руководитель отдела продаж' AND 
       EXISTS (
         SELECT 1 FROM employees assignee
         WHERE assignee.id = project_tasks.assignee_id 
         AND assignee.department = 'отдел продаж'
       )) OR
      (manager.role = 'руководитель ИИ отдела' AND 
       EXISTS (
         SELECT 1 FROM employees assignee
         WHERE assignee.id = project_tasks.assignee_id 
         AND assignee.department = 'креатив отдел'
       ))
    )
  )
);

-- Обновляем права доступа для sales_results (добавляем доступ руководителям к данным о клиентах и проектах)
CREATE POLICY "Department leads can view sales results details" 
ON sales_results 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1
    FROM employees manager
    WHERE manager.user_id = auth.uid()
    AND (
      manager.role = 'руководитель тех отдела' OR
      (manager.role = 'руководитель отдела продаж' AND 
       EXISTS (
         SELECT 1 FROM employees e
         WHERE e.id = sales_results.employee_id 
         AND e.department = 'отдел продаж'
       )) OR
      (manager.role = 'руководитель ИИ отдела')
    )
  )
);