-- Добавляем политику для удаления проектов руководителями тех отдела
CREATE POLICY "Tech leads can delete sales results" 
ON public.sales_results 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND role = 'руководитель тех отдела' 
    AND status = 'active'
  )
);