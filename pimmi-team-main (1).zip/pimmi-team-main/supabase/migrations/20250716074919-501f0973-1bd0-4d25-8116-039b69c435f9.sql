-- Add missing status values to the task_status_enum
ALTER TYPE public.task_status_enum ADD VALUE IF NOT EXISTS 'in_progress';
ALTER TYPE public.task_status_enum ADD VALUE IF NOT EXISTS 'postponed';  
ALTER TYPE public.task_status_enum ADD VALUE IF NOT EXISTS 'issues';