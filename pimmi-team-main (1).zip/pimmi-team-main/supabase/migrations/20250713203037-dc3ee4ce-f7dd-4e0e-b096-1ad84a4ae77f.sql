-- Allow employees to delete their own sales results
CREATE POLICY "Employees can delete their own sales results" 
ON sales_results 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.id = sales_results.employee_id 
    AND employees.user_id = auth.uid()
  )
);