-- Fix mutable search_path on SECURITY DEFINER functions

CREATE OR REPLACE FUNCTION public.create_employee_with_auth(employee_name text, employee_email text, employee_position text, employee_department text, default_password text DEFAULT 'Qwerty56'::text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  new_employee_id UUID;
BEGIN
  INSERT INTO public.employees (name, email, position, department, status, role)
  VALUES (employee_name, employee_email, employee_position, employee_department, 'active', 'employee')
  RETURNING id INTO new_employee_id;
  RETURN new_employee_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.can_view_sales_employees()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM public.employees 
    WHERE user_id = auth.uid() 
    AND department = 'отдел продаж'
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_admin(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.employees
    WHERE user_id = check_user_id
    AND role = 'admin'
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_admin_or_tech_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.employees
    WHERE user_id = check_user_id
    AND role IN ('admin', 'руководитель тех отдела')
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_sales_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.employees
    WHERE user_id = check_user_id
    AND role = 'руководитель отдела продаж'
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_ai_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.employees
    WHERE user_id = check_user_id
    AND role = 'руководитель ИИ отдела'
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.get_employee_by_user_id(check_user_id uuid DEFAULT auth.uid())
RETURNS TABLE(id uuid, name text, email text, emp_position text, department text, role text, status text)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT e.id, e.name, e.email, e.position, e.department, e.role, e.status
  FROM public.employees e
  WHERE e.user_id = check_user_id
  AND e.status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.handle_extension_payments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  IF NEW.is_extension = TRUE AND NEW.parent_project_id IS NOT NULL THEN
    DELETE FROM public.monthly_payments 
    WHERE sales_result_id = NEW.parent_project_id;
    RAISE NOTICE 'Deleted monthly payments for original project: %', NEW.parent_project_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.clear_employee_shop_purchases(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  DELETE FROM public.shop_purchases 
  WHERE employee_id = emp_id;
  PERFORM public.calculate_employee_points(emp_id);
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_monthly_project_payments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  IF NEW.project_type IN ('Ежемесячный', 'ежемесячно') AND NEW.is_extension = FALSE THEN
    IF NEW.remainder > 0 THEN
      monthly_amount := NEW.remainder;
    ELSE
      monthly_amount := NEW.sale_amount / 12;
    END IF;
    start_date := NEW.sale_date + INTERVAL '1 month';
    PERFORM public.generate_monthly_payments(
      NEW.id,
      monthly_amount,
      start_date,
      1
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.log_employee_action(p_employee_id uuid, p_action_type text, p_action_description text, p_target_type text DEFAULT NULL::text, p_target_id uuid DEFAULT NULL::uuid, p_metadata jsonb DEFAULT NULL::jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  INSERT INTO public.employee_activity_logs (
    employee_id,
    action_type,
    action_description,
    target_type,
    target_id,
    metadata
  ) VALUES (
    p_employee_id,
    p_action_type,
    p_action_description,
    p_target_type,
    p_target_id,
    p_metadata
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.update_overdue_payments()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  UPDATE public.monthly_payments
  SET status = 'overdue'
  WHERE status = 'pending' 
    AND payment_date < CURRENT_DATE;
END;
$$;

CREATE OR REPLACE FUNCTION public.cleanup_old_activity_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  DELETE FROM public.employee_activity_logs 
  WHERE created_at < NOW() - INTERVAL '90 days';
END;
$$;

CREATE OR REPLACE FUNCTION public.get_department_employees(manager_user_id uuid DEFAULT auth.uid())
RETURNS TABLE(id uuid, name text, email text, emp_position text, department text, role text, status text, user_id uuid)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT e.id, e.name, e.email, e.position, e.department, e.role, e.status, e.user_id
  FROM public.employees e
  WHERE EXISTS (
    SELECT 1
    FROM public.employees manager
    WHERE manager.user_id = manager_user_id
    AND (
      (manager.role = 'руководитель тех отдела' AND e.department = 'тех отдел') OR
      (manager.role = 'руководитель отдела продаж' AND e.department = 'отдел продаж') OR
      (manager.role = 'руководитель ИИ отдела' AND e.department = 'креатив отдел') OR
      manager.role = 'admin'
    )
  )
  AND e.status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.create_next_monthly_payment(p_sales_result_id uuid, p_monthly_amount numeric, p_from_date date DEFAULT CURRENT_DATE)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  next_payment_date DATE;
BEGIN
  next_payment_date := p_from_date + INTERVAL '1 month';
  IF NOT EXISTS (
    SELECT 1 FROM public.monthly_payments 
    WHERE sales_result_id = p_sales_result_id 
    AND payment_date = next_payment_date
  ) THEN
    INSERT INTO public.monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      status
    ) VALUES (
      p_sales_result_id,
      next_payment_date,
      p_monthly_amount,
      'pending'
    );
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.generate_monthly_payments(p_sales_result_id uuid, p_monthly_amount numeric, p_start_date date, p_months_count integer DEFAULT 1)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  i INTEGER;
  payment_date DATE;
BEGIN
  DELETE FROM public.monthly_payments 
  WHERE sales_result_id = p_sales_result_id;
  FOR i IN 0..(p_months_count - 1) LOOP
    payment_date := p_start_date + (i || ' months')::INTERVAL;
    INSERT INTO public.monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      status
    ) VALUES (
      p_sales_result_id,
      payment_date,
      p_monthly_amount,
      'pending'
    );
  END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.can_view_employee(target_employee_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT 
    public.is_admin() OR
    EXISTS (
      SELECT 1 FROM public.employees 
      WHERE id = target_employee_id 
      AND user_id = auth.uid()
    ) OR
    EXISTS (
      SELECT 1
      FROM public.employees manager, public.employees target
      WHERE manager.user_id = auth.uid()
      AND target.id = target_employee_id
      AND (
        manager.role = 'руководитель тех отдела' OR
        (
          manager.role = 'руководитель отдела продаж' AND 
          target.department = 'отдел продаж'
        ) OR
        (
          manager.role = 'руководитель ИИ отдела' AND 
          target.department = 'креатив отдел'
        )
      )
    );
$$;

CREATE OR REPLACE FUNCTION public.calculate_employee_points(emp_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  task_points INTEGER := 0;
  project_task_points INTEGER := 0;
  achievement_points INTEGER := 0;
  sales_points INTEGER := 0;
  report_points INTEGER := 0;
  spent_points INTEGER := 0;
  total INTEGER := 0;
BEGIN
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO task_points
  FROM public.employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';
  
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO project_task_points
  FROM public.project_tasks 
  WHERE assignee_id = emp_id AND status = 'completed';
  
  SELECT COALESCE(SUM(points), 0) INTO achievement_points
  FROM public.employee_achievements 
  WHERE employee_id = emp_id;
  
  SELECT COALESCE(COUNT(*) * 120, 0) INTO sales_points
  FROM public.sales_results sr
  JOIN public.employees e ON sr.employee_id = e.id
  WHERE sr.employee_id = emp_id 
    AND e.department = 'отдел продаж'
    AND (sr.is_extension = FALSE OR sr.employee_id = emp_id);
  
  SELECT COALESCE(COUNT(*) * 30, 0) INTO report_points
  FROM public.daily_reports 
  WHERE employee_id = emp_id;
  
  SELECT COALESCE(SUM(item_price), 0) INTO spent_points
  FROM public.shop_purchases 
  WHERE employee_id = emp_id;
  
  total := task_points + project_task_points + achievement_points + sales_points + report_points - spent_points;
  IF total < 0 THEN
    total := 0;
  END IF;
  
  INSERT INTO public.employee_points (employee_id, total_points, updated_at)
  VALUES (emp_id, total, now())
  ON CONFLICT (employee_id) 
  DO UPDATE SET 
    total_points = total,
    updated_at = now();
    
  RETURN total;
END;
$$;

CREATE OR REPLACE FUNCTION public.mark_payment_as_paid(p_payment_id uuid, p_actual_date date DEFAULT CURRENT_DATE, p_notes text DEFAULT NULL::text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  UPDATE public.monthly_payments
  SET 
    status = 'paid',
    actual_payment_date = p_actual_date,
    notes = COALESCE(p_notes, notes),
    updated_at = now()
  WHERE id = p_payment_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.process_shop_purchase(emp_id uuid, item_name text, item_price integer)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  current_points INTEGER;
  new_points INTEGER;
  purchase_result JSON;
BEGIN
  SELECT total_points INTO current_points
  FROM public.employee_points 
  WHERE employee_id = emp_id;
  
  IF current_points IS NULL THEN
    INSERT INTO public.employee_points (employee_id, total_points)
    VALUES (emp_id, 0)
    ON CONFLICT (employee_id) DO NOTHING;
    current_points := 0;
  END IF;
  
  IF current_points < item_price THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Недостаточно баллов',
      'current_points', current_points,
      'required_points', item_price
    );
  END IF;
  
  new_points := current_points - item_price;
  
  UPDATE public.employee_points 
  SET total_points = new_points, updated_at = now()
  WHERE employee_id = emp_id;
  
  INSERT INTO public.shop_purchases (
    employee_id, 
    item_name, 
    item_price, 
    points_before, 
    points_after
  ) VALUES (
    emp_id, 
    item_name, 
    item_price, 
    current_points, 
    new_points
  );
  
  RETURN json_build_object(
    'success', true,
    'points_before', current_points,
    'points_after', new_points,
    'item_name', item_name,
    'item_price', item_price
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.check_achievements_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  task_count INTEGER;
  streak_days INTEGER;
  category_count INTEGER;
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    PERFORM public.calculate_employee_points(NEW.employee_id);
    RAISE NOTICE 'Achievement check triggered for employee: %', NEW.employee_id;
    SELECT COUNT(*) INTO task_count 
    FROM public.employee_tasks 
    WHERE employee_id = NEW.employee_id AND status = 'completed';
    RAISE NOTICE 'Employee % has completed % tasks', NEW.employee_id, task_count;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.award_achievement_safely(emp_id uuid, ach_name text, ach_description text, ach_points integer)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.employee_achievements 
    WHERE employee_id = emp_id AND achievement_name = ach_name
  ) THEN
    RETURN FALSE;
  END IF;
  
  INSERT INTO public.employee_achievements (
    employee_id, 
    achievement_name, 
    description, 
    points
  ) VALUES (
    emp_id, 
    ach_name, 
    ach_description, 
    ach_points
  );
  
  PERFORM public.calculate_employee_points(emp_id);
  
  RETURN TRUE;
END;
$$;

CREATE OR REPLACE FUNCTION public.is_financist(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.employees
    WHERE user_id = check_user_id
    AND role = 'финансист'
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.check_sales_achievements(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  employee_dept text;
  total_leads integer := 0;
  qualified_leads integer := 0;
  total_reports integer := 0;
  total_sales integer := 0;
  total_sale_amount numeric := 0;
BEGIN
  SELECT department INTO employee_dept
  FROM public.employees 
  WHERE id = emp_id;
  
  IF employee_dept != 'отдел продаж' THEN
    RETURN;
  END IF;
  
  SELECT 
    COALESCE(SUM(leads_count), 0),
    COALESCE(SUM(qualified_leads_count), 0),
    COUNT(*)
  INTO total_leads, qualified_leads, total_reports
  FROM public.daily_reports 
  WHERE employee_id = emp_id;
  
  SELECT 
    COUNT(*),
    COALESCE(SUM(sale_amount), 0)
  INTO total_sales, total_sale_amount
  FROM public.sales_results 
  WHERE employee_id = emp_id;
  
  IF total_leads >= 20 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первый лид', 'Обработал 20 лидов', 50);
  END IF;
  IF total_leads >= 200 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Охотник за лидами', 'Обработал 200 лидов', 100);
  END IF;
  IF total_leads >= 1000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер лидогенерации', 'Обработал 1000 лидов', 200);
  END IF;
  IF total_leads >= 2000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Лидерный магнат', 'Обработал 2000 лидов', 300);
  END IF;
  
  IF qualified_leads >= 100 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Квалификатор', 'Получил 100 квалифицированных лидов', 75);
  END IF;
  IF qualified_leads >= 500 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Эксперт отбора', 'Получил 500 квалифицированных лидов', 150);
  END IF;
  
  IF total_reports >= 1 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первый отчет', 'Создал первый отчет', 30);
  END IF;
  IF total_reports >= 7 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Недельная отчетность', 'Создал 7 отчетов', 100);
  END IF;
  IF total_reports >= 30 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Месячная дисциплина', 'Создал 30 отчетов', 200);
  END IF;
  IF total_reports >= 90 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер отчетности', 'Создал 90 отчетов', 300);
  END IF;
  
  IF total_sales >= 1 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первая продажа', 'Закрыл первую сделку', 120);
  END IF;
  IF total_sales >= 5 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Продавец-новичок', 'Закрыл 5 сделок', 250);
  END IF;
  IF total_sales >= 10 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Опытный продавец', 'Закрыл 10 сделок', 400);
  END IF;
  IF total_sales >= 25 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Мастер продаж', 'Закрыл 25 сделок', 600);
  END IF;
  IF total_sales >= 50 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Легенда продаж', 'Закрыл 50 сделок', 1000);
  END IF;
  
  IF total_sale_amount >= 100000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Первые 100К', 'Продажи на 100,000 тенге', 150);
  END IF;
  IF total_sale_amount >= 500000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Полумиллионер', 'Продажи на 500,000 тенге', 300);
  END IF;
  IF total_sale_amount >= 1000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Миллионер', 'Продажи на 1,000,000 тенге', 500);
  END IF;
  IF total_sale_amount >= 2000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Двукратный миллионер', 'Продажи на 2,000,000 тенге', 750);
  END IF;
  IF total_sale_amount >= 5000000 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Золотой продавец', 'Продажи на 5,000,000 тенге', 1200);
  END IF;
  
  IF total_sales >= 10 AND qualified_leads >= 400 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Эффективный менеджер', 'Высокие показатели продаж и лидов', 400);
  END IF;
  IF total_reports >= 30 AND total_sales >= 15 THEN
    PERFORM public.award_achievement_safely(emp_id, 'Дисциплинированный продавец', 'Регулярные отчеты и продажи', 350);
  END IF;
END;
$$;

-- Fix handle_new_user search_path that was set to ''
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (
    new.id,
    new.raw_user_meta_data ->> 'full_name',
    new.email
  );
  RETURN new;
END;
$$;