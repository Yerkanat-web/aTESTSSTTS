-- Make all public views security invoker so they use caller permissions and RLS
ALTER VIEW public.employee_activity_logs_view SET (security_invoker = true);
ALTER VIEW public.employee_stats_view SET (security_invoker = true);
ALTER VIEW public.employee_tasks_with_attachments_view SET (security_invoker = true);
ALTER VIEW public.unified_employee_tasks SET (security_invoker = true);