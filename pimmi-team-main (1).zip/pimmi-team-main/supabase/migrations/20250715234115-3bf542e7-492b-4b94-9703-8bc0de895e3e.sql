UPDATE employees 
SET role = 'руководитель ИИ отдела', 
    updated_at = now()
WHERE email = 'nurtaibalnur20033@mail.ru';