-- Allow employees to update their own sales results
CREATE POLICY "Employees can update their own sales results" 
ON sales_results 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.id = sales_results.employee_id 
    AND employees.user_id = auth.uid()
  )
);