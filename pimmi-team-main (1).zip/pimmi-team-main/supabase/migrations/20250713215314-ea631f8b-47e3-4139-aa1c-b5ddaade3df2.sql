-- Create project_accounts table
CREATE TABLE public.project_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sales_result_id UUID NOT NULL REFERENCES public.sales_results(id) ON DELETE CASCADE,
  service_type TEXT,
  login TEXT,
  password TEXT,
  subscription_end_date DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.project_accounts ENABLE ROW LEVEL SECURITY;

-- Create policies for project_accounts
CREATE POLICY "Admins can manage all project accounts" 
ON public.project_accounts 
FOR ALL 
USING (is_admin());

CREATE POLICY "Financists can manage all project accounts" 
ON public.project_accounts 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE user_id = auth.uid() AND role = 'финансист'
));

CREATE POLICY "Employees can view their project accounts" 
ON public.project_accounts 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM sales_results sr
  JOIN employees e ON sr.employee_id = e.id
  WHERE sr.id = project_accounts.sales_result_id 
  AND e.user_id = auth.uid()
));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_project_accounts_updated_at
BEFORE UPDATE ON public.project_accounts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();