
-- Обновляем функцию mark_payment_as_paid чтобы она НЕ создавала следующие платежи автоматически
CREATE OR REPLACE FUNCTION public.mark_payment_as_paid(p_payment_id uuid, p_actual_date date DEFAULT CURRENT_DATE, p_notes text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Просто обновляем статус платежа на 'paid' без создания следующего
  UPDATE public.monthly_payments
  SET 
    status = 'paid',
    actual_payment_date = p_actual_date,
    notes = COALESCE(p_notes, notes),
    updated_at = now()
  WHERE id = p_payment_id;
END;
$$;

-- Также обновляем функцию в FinancesPage которая вызывается при нажатии "оплачено"
-- Убираем вызов create_next_monthly_payment из markPaymentAsPaid
