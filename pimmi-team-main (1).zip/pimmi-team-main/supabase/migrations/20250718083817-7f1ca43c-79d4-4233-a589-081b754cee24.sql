DELETE FROM sales_results 
WHERE id = 'c5a9403d-5775-416e-a584-a1caf1e77c23' AND is_extension = true;