-- Изменение роли пользователя akma.satti@gmail.com на администратора
UPDATE employees 
SET role = 'admin', 
    updated_at = now()
WHERE email = 'akma.satti@gmail.com';