-- Create task_categories table for global task categories management
CREATE TABLE public.task_categories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  description text,
  color text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.task_categories ENABLE ROW LEVEL SECURITY;

-- Allow all authenticated users to read categories
CREATE POLICY "All users can view task categories" 
ON public.task_categories 
FOR SELECT 
USING (true);

-- Allow only admins to manage categories
CREATE POLICY "Admins can manage task categories" 
ON public.task_categories 
FOR ALL 
USING (is_admin());

-- Create trigger for updated_at
CREATE TRIGGER update_task_categories_updated_at
BEFORE UPDATE ON public.task_categories
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert standard categories
INSERT INTO public.task_categories (name, description, color) VALUES
  ('development', 'Разработка и программирование', '#3b82f6'),
  ('design', 'Дизайн и UI/UX', '#8b5cf6'),
  ('testing', 'Тестирование и QA', '#10b981'),
  ('documentation', 'Документация', '#f59e0b'),
  ('meeting', 'Встречи и совещания', '#ef4444'),
  ('research', 'Исследования и анализ', '#06b6d4'),
  ('maintenance', 'Техническое обслуживание', '#84cc16'),
  ('support', 'Поддержка клиентов', '#f97316'),
  ('training', 'Обучение и развитие', '#ec4899'),
  ('general', 'Общие задачи', '#6b7280');

-- Migrate existing unique categories from employee_tasks
INSERT INTO public.task_categories (name, description, color)
SELECT DISTINCT 
  category as name,
  'Категория из существующих задач' as description,
  '#64748b' as color
FROM employee_tasks 
WHERE category IS NOT NULL 
  AND category != ''
  AND category NOT IN (
    SELECT name FROM public.task_categories
  );