-- Fix Security Definer views issues

-- Drop existing views
DROP VIEW IF EXISTS public.employee_tasks_with_attachments_view;
DROP VIEW IF EXISTS public.employee_stats_view;

-- Recreate employee_stats_view without SECURITY DEFINER
CREATE VIEW public.employee_stats_view AS
SELECT 
  e.id,
  COALESCE(ep.total_points, 0) as total_points,
  COUNT(et.id) as total_tasks,
  COUNT(CASE WHEN et.status = 'completed' THEN 1 END) as completed_tasks,
  COALESCE(SUM(wt.hours_worked), 0) as total_hours,
  CASE 
    WHEN COUNT(et.id) > 0 THEN 
      ROUND((COUNT(CASE WHEN et.status = 'completed' THEN 1 END)::numeric / COUNT(et.id)::numeric) * 100, 2)
    ELSE 0 
  END as efficiency,
  e.name,
  e.email,
  e.position,
  e.department,
  e.role,
  e.status
FROM employees e
LEFT JOIN employee_points ep ON e.id = ep.employee_id
LEFT JOIN employee_tasks et ON e.id = et.employee_id
LEFT JOIN work_time_logs wt ON e.id = wt.employee_id
GROUP BY e.id, e.name, e.email, e.position, e.department, e.role, e.status, ep.total_points;

-- Recreate employee_tasks_with_attachments_view without SECURITY DEFINER
CREATE VIEW public.employee_tasks_with_attachments_view AS
SELECT 
  et.*,
  COUNT(ta.id) as attachment_count,
  COALESCE(
    array_agg(
      json_build_object(
        'id', ta.id,
        'file_name', ta.file_name,
        'file_url', ta.file_url,
        'content_type', ta.content_type,
        'file_size', ta.file_size
      ) ORDER BY ta.created_at
    ) FILTER (WHERE ta.id IS NOT NULL),
    '{}'::json[]
  ) as attachments
FROM employee_tasks et
LEFT JOIN task_attachments ta ON et.id = ta.task_id
GROUP BY et.id, et.employee_id, et.title, et.description, et.priority, et.status, 
         et.category, et.estimated_hours, et.actual_hours, et.due_date, 
         et.assigned_by, et.created_at, et.updated_at, et.completed_at;