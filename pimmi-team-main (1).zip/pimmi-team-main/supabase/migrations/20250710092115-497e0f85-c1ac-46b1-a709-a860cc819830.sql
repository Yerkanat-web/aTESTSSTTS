-- Part 1: Create employee_points table for single source of truth
CREATE TABLE public.employee_points (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  total_points INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(employee_id)
);

-- Enable RLS on employee_points
ALTER TABLE public.employee_points ENABLE ROW LEVEL SECURITY;

-- RLS policies for employee_points
CREATE POLICY "Admins can manage all points" 
ON public.employee_points 
FOR ALL 
USING (is_admin());

CREATE POLICY "Employees can view their own points" 
ON public.employee_points 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE employees.id = employee_points.employee_id 
  AND employees.user_id = auth.uid()
));

-- Create function to calculate employee points
CREATE OR REPLACE FUNCTION public.calculate_employee_points(emp_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  task_points INTEGER := 0;
  achievement_points INTEGER := 0;
  total INTEGER := 0;
BEGIN
  -- Calculate points from completed tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO task_points
  FROM employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';
  
  -- Calculate points from achievements
  SELECT COALESCE(SUM(points), 0) INTO achievement_points
  FROM employee_achievements 
  WHERE employee_id = emp_id;
  
  total := task_points + achievement_points;
  
  -- Update or insert into employee_points
  INSERT INTO employee_points (employee_id, total_points, updated_at)
  VALUES (emp_id, total, now())
  ON CONFLICT (employee_id) 
  DO UPDATE SET 
    total_points = total,
    updated_at = now();
    
  RETURN total;
END;
$$;

-- Create function to update points automatically
CREATE OR REPLACE FUNCTION public.update_employee_points_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- For INSERT/UPDATE on employee_tasks
  IF TG_TABLE_NAME = 'employee_tasks' THEN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
      PERFORM calculate_employee_points(NEW.employee_id);
    END IF;
    IF TG_OP = 'DELETE' THEN
      PERFORM calculate_employee_points(OLD.employee_id);
    END IF;
  END IF;
  
  -- For INSERT/UPDATE on employee_achievements
  IF TG_TABLE_NAME = 'employee_achievements' THEN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
      PERFORM calculate_employee_points(NEW.employee_id);
    END IF;
    IF TG_OP = 'DELETE' THEN
      PERFORM calculate_employee_points(OLD.employee_id);
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create triggers for automatic point updates
CREATE TRIGGER employee_tasks_points_trigger
  AFTER INSERT OR UPDATE OR DELETE ON employee_tasks
  FOR EACH ROW EXECUTE FUNCTION update_employee_points_trigger();

CREATE TRIGGER employee_achievements_points_trigger
  AFTER INSERT OR UPDATE OR DELETE ON employee_achievements
  FOR EACH ROW EXECUTE FUNCTION update_employee_points_trigger();

-- Part 2: Create Storage bucket for file attachments
INSERT INTO storage.buckets (id, name, public) 
VALUES ('task-attachments', 'task-attachments', false);

-- Storage policies for task attachments
CREATE POLICY "Admins can manage all attachments" 
ON storage.objects 
FOR ALL 
USING (bucket_id = 'task-attachments' AND is_admin());

CREATE POLICY "Employees can upload attachments for their tasks" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'task-attachments' 
  AND EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.user_id = auth.uid()
    AND employees.id::text = (storage.foldername(name))[1]
  )
);

CREATE POLICY "Employees can view attachments for their tasks" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'task-attachments' 
  AND EXISTS (
    SELECT 1 FROM employees e
    JOIN employee_tasks t ON t.employee_id = e.id
    WHERE e.user_id = auth.uid()
    AND t.id::text = (storage.foldername(name))[2]
  )
);

-- Update task_attachments table to use storage URLs instead of base64
ALTER TABLE public.task_attachments 
DROP COLUMN IF EXISTS file_content,
ADD COLUMN IF NOT EXISTS file_url TEXT,
ADD COLUMN IF NOT EXISTS storage_path TEXT;

-- Part 3: Create optimized views for performance
CREATE OR REPLACE VIEW public.employee_stats_view AS
SELECT 
  e.id,
  e.name,
  e.email,
  e.position,
  e.department,
  e.role,
  e.status,
  COALESCE(ep.total_points, 0) as total_points,
  COALESCE(task_stats.total_tasks, 0) as total_tasks,
  COALESCE(task_stats.completed_tasks, 0) as completed_tasks,
  COALESCE(task_stats.total_hours, 0) as total_hours,
  COALESCE(task_stats.efficiency, 0) as efficiency
FROM employees e
LEFT JOIN employee_points ep ON e.id = ep.employee_id
LEFT JOIN (
  SELECT 
    employee_id,
    COUNT(*) as total_tasks,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_tasks,
    SUM(COALESCE(actual_hours, estimated_hours, 0)) as total_hours,
    CASE 
      WHEN COUNT(CASE WHEN status = 'completed' THEN 1 END) > 0 
      THEN ROUND((COUNT(CASE WHEN status = 'completed' THEN 1 END)::FLOAT / COUNT(*)::FLOAT) * 100)
      ELSE 0 
    END as efficiency
  FROM employee_tasks 
  GROUP BY employee_id
) task_stats ON e.id = task_stats.employee_id;

CREATE OR REPLACE VIEW public.employee_tasks_with_attachments_view AS
SELECT 
  t.*,
  COUNT(ta.id) as attachment_count,
  ARRAY_AGG(
    CASE WHEN ta.id IS NOT NULL 
    THEN json_build_object(
      'id', ta.id,
      'file_name', ta.file_name,
      'file_url', ta.file_url,
      'content_type', ta.content_type,
      'file_size', ta.file_size
    ) END
  ) FILTER (WHERE ta.id IS NOT NULL) as attachments
FROM employee_tasks t
LEFT JOIN task_attachments ta ON t.id = ta.task_id
GROUP BY t.id, t.employee_id, t.title, t.description, t.priority, t.status, 
         t.category, t.estimated_hours, t.actual_hours, t.due_date, 
         t.assigned_by, t.created_at, t.updated_at, t.completed_at;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_employee_points_employee_id ON employee_points(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_tasks_employee_id_status ON employee_tasks(employee_id, status);
CREATE INDEX IF NOT EXISTS idx_employee_achievements_employee_id ON employee_achievements(employee_id);
CREATE INDEX IF NOT EXISTS idx_task_attachments_task_id ON task_attachments(task_id);

-- Initialize points for existing employees
INSERT INTO employee_points (employee_id, total_points)
SELECT id, 0 FROM employees
ON CONFLICT (employee_id) DO NOTHING;

-- Calculate initial points for all employees
DO $$
DECLARE
  emp_record RECORD;
BEGIN
  FOR emp_record IN SELECT id FROM employees LOOP
    PERFORM calculate_employee_points(emp_record.id);
  END LOOP;
END;
$$;