-- Добавляем столбец комментариев в таблицу sales_results
ALTER TABLE public.sales_results 
ADD COLUMN IF NOT EXISTS comments TEXT;