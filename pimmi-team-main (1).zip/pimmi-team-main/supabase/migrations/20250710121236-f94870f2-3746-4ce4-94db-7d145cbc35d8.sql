-- Удаляем все покупки пользователя galym@mail.ru
DELETE FROM shop_purchases 
WHERE employee_id = (
  SELECT id FROM employees 
  WHERE email = 'galym@mail.ru' 
  LIMIT 1
);

-- Пересчитываем баллы для этого пользователя
DO $$ 
DECLARE
    emp_id uuid;
BEGIN
    SELECT id INTO emp_id FROM employees WHERE email = 'galym@mail.ru' LIMIT 1;
    IF emp_id IS NOT NULL THEN
        PERFORM calculate_employee_points(emp_id);
    END IF;
END $$;