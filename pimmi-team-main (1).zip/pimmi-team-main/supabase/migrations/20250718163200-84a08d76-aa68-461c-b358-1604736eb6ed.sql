-- Удаляем все продления проекта "Принтер"
DELETE FROM public.sales_results 
WHERE is_extension = true 
  AND (
    project_name LIKE '%Принтер%' OR 
    parent_project_id = '8db1fdc1-77e2-4868-9863-7df061e7f701'
  );