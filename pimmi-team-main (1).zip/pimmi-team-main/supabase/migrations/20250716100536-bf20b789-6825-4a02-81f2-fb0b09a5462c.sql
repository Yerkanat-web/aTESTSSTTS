-- Add missing fields to project_tasks table to match employee_tasks functionality
ALTER TABLE project_tasks 
ADD COLUMN category text DEFAULT 'general',
ADD COLUMN priority text DEFAULT 'medium',
ADD COLUMN estimated_minutes integer DEFAULT 0,
ADD COLUMN actual_minutes integer DEFAULT 0,
ADD COLUMN completed_at timestamp with time zone,
ADD COLUMN description text;

-- Add trigger for automatic completed_at timestamp update
CREATE TRIGGER update_project_tasks_completed_at_trigger
BEFORE UPDATE ON project_tasks
FOR EACH ROW
EXECUTE FUNCTION update_task_completed_at();

-- Update existing completed tasks to have completed_at timestamp
UPDATE project_tasks 
SET completed_at = updated_at 
WHERE status = 'completed' AND completed_at IS NULL;