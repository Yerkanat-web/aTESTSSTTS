-- Create admin function to clear employee shop purchases
CREATE OR REPLACE FUNCTION public.clear_employee_shop_purchases(emp_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
BEGIN
  -- Delete all shop purchases for the employee
  DELETE FROM public.shop_purchases 
  WHERE employee_id = emp_id;
  
  -- Recalculate employee points after clearing purchases
  PERFORM calculate_employee_points(emp_id);
END;
$function$;