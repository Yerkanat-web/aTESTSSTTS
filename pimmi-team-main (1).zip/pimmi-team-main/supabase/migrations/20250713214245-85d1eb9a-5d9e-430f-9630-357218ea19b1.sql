-- Устанавливаем временную зону GMT+5 (Asia/Almaty) по умолчанию для всей базы данных
ALTER DATABASE postgres SET timezone = 'Asia/Almaty';

-- Устанавливаем временную зону для текущей сессии
SET timezone = 'Asia/Almaty';

-- Создаем функцию для получения текущего времени в GMT+5
CREATE OR REPLACE FUNCTION public.now_almaty()
RETURNS timestamp with time zone
LANGUAGE sql
STABLE
AS $$
  SELECT NOW() AT TIME ZONE 'Asia/Almaty';
$$;

-- Создаем функцию для форматирования даты в GMT+5
CREATE OR REPLACE FUNCTION public.format_almaty_date(input_date timestamp with time zone)
RETURNS text
LANGUAGE sql
STABLE
AS $$
  SELECT to_char(input_date AT TIME ZONE 'Asia/Almaty', 'DD.MM.YYYY HH24:MI');
$$;

-- Создаем функцию для получения только даты в формате YYYY-MM-DD в GMT+5
CREATE OR REPLACE FUNCTION public.almaty_date_string(input_date timestamp with time zone DEFAULT NOW())
RETURNS text
LANGUAGE sql
STABLE
AS $$
  SELECT to_char(input_date AT TIME ZONE 'Asia/Almaty', 'YYYY-MM-DD');
$$;

-- Комментарии для документации
COMMENT ON FUNCTION public.now_almaty() IS 'Возвращает текущее время в часовом поясе GMT+5 (Asia/Almaty)';
COMMENT ON FUNCTION public.format_almaty_date(timestamp with time zone) IS 'Форматирует дату и время в GMT+5 в формате ДД.ММ.ГГГГ ЧЧ:ММ';
COMMENT ON FUNCTION public.almaty_date_string(timestamp with time zone) IS 'Возвращает дату в GMT+5 в формате YYYY-MM-DD';