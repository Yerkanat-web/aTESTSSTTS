-- Обновляем существующие ежемесячные платежи для продлений
-- чтобы они также включали правильную дату остатка
UPDATE monthly_payments 
SET 
  remainder_due_date = sr.remainder_due_date,
  updated_at = now()
FROM sales_results sr
WHERE monthly_payments.sales_result_id = sr.id
  AND sr.is_extension = true
  AND sr.remainder_due_date IS NOT NULL;