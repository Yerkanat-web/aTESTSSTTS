-- Очищаем все достижения отдела продаж и пересчитываем с правильными порогами
DELETE FROM employee_achievements 
WHERE employee_id IN (
  SELECT id FROM employees WHERE department = 'отдел продаж'
);

-- Пересчитываем баллы после удаления достижений
DO $$
DECLARE
  emp RECORD;
BEGIN
  FOR emp IN SELECT id FROM employees WHERE status = 'active' AND department = 'отдел продаж'
  LOOP
    PERFORM calculate_employee_points(emp.id);
    PERFORM check_sales_achievements(emp.id);
  END LOOP;
END $$;