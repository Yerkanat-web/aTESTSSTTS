-- Добавляем политику для сотрудников отдела продаж чтобы они могли видеть всех сотрудников отдела продаж и админов
CREATE POLICY "Sales employees can view sales department and admins" 
ON employees 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees requester 
    WHERE requester.user_id = auth.uid() 
    AND requester.department = 'отдел продаж'
    AND requester.status = 'active'
  )
  AND (
    employees.department = 'отдел продаж' 
    OR employees.role = 'admin'
  )
  AND employees.status = 'active'
);