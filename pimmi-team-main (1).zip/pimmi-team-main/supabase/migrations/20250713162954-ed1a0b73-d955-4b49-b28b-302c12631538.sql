-- Add RLS policy to allow users to view sales results when they are assigned to related project tasks
CREATE POLICY "Users can view sales results for their assigned project tasks" 
ON sales_results 
FOR SELECT 
USING (
  id IN (
    SELECT pt.sales_result_id 
    FROM project_tasks pt
    WHERE pt.assignee_id IN (
      SELECT e.id FROM employees e WHERE e.user_id = auth.uid()
    )
  )
);