-- Удаляем все продажи и связанные данные для сотрудника asem@mail.ru

-- Сначала удаляем связанные записи из project_tasks
DELETE FROM project_tasks 
WHERE sales_result_id IN (
  SELECT id FROM sales_results 
  WHERE employee_id = '6e1e8ed0-4726-4b8c-89c6-ba1707fdcde4'
);

-- Удаляем связанные записи из project_accounts
DELETE FROM project_accounts 
WHERE sales_result_id IN (
  SELECT id FROM sales_results 
  WHERE employee_id = '6e1e8ed0-4726-4b8c-89c6-ba1707fdcde4'
);

-- Удаляем связанные ежемесячные платежи
DELETE FROM monthly_payments 
WHERE sales_result_id IN (
  SELECT id FROM sales_results 
  WHERE employee_id = '6e1e8ed0-4726-4b8c-89c6-ba1707fdcde4'
);

-- Наконец, удаляем сами продажи
DELETE FROM sales_results 
WHERE employee_id = '6e1e8ed0-4726-4b8c-89c6-ba1707fdcde4';