-- Добавляем RLS политику для руководителей отдела продаж
CREATE POLICY "Sales leads can view their department targets"
ON public.sales_targets
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM employees e1, employees e2
    WHERE e1.user_id = auth.uid()
    AND e1.role = 'руководитель отдела продаж'
    AND e2.id = sales_targets.employee_id
    AND e2.department = 'отдел продаж'
  )
);