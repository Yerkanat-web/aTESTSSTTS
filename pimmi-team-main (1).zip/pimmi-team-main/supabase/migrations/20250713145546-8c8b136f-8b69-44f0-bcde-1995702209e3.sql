-- Удаляем все продажи сотрудника Асем Демо (employee_id: 6e1e8ed0-4726-4b8c-89c6-ba1707fdcde4)
DELETE FROM sales_results 
WHERE employee_id = '6e1e8ed0-4726-4b8c-89c6-ba1707fdcde4';