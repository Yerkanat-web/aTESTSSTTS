-- Create monthly_payments table for tracking recurring payments
CREATE TABLE public.monthly_payments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sales_result_id UUID NOT NULL REFERENCES sales_results(id) ON DELETE CASCADE,
  payment_date DATE NOT NULL,
  amount NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue')),
  actual_payment_date DATE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.monthly_payments ENABLE ROW LEVEL SECURITY;

-- Create policies for monthly_payments
CREATE POLICY "Admins can manage all monthly payments" 
ON public.monthly_payments 
FOR ALL 
USING (is_admin());

CREATE POLICY "Financists can manage all monthly payments" 
ON public.monthly_payments 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.user_id = auth.uid() 
    AND employees.role = 'финансист'
  )
);

CREATE POLICY "Employees can view their monthly payments" 
ON public.monthly_payments 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM sales_results sr
    JOIN employees e ON sr.employee_id = e.id
    WHERE sr.id = monthly_payments.sales_result_id 
    AND e.user_id = auth.uid()
  )
);

-- Create trigger for updated_at
CREATE TRIGGER update_monthly_payments_updated_at
  BEFORE UPDATE ON public.monthly_payments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to generate monthly payments for a sales result
CREATE OR REPLACE FUNCTION public.generate_monthly_payments(
  p_sales_result_id UUID,
  p_monthly_amount NUMERIC,
  p_start_date DATE,
  p_months_count INTEGER DEFAULT 12
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  i INTEGER;
  payment_date DATE;
BEGIN
  -- Delete existing monthly payments for this sales result to avoid duplicates
  DELETE FROM public.monthly_payments 
  WHERE sales_result_id = p_sales_result_id;
  
  -- Generate monthly payment records
  FOR i IN 0..(p_months_count - 1) LOOP
    payment_date := p_start_date + (i || ' months')::INTERVAL;
    
    INSERT INTO public.monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      status
    ) VALUES (
      p_sales_result_id,
      payment_date,
      p_monthly_amount,
      'pending'
    );
  END LOOP;
END;
$$;

-- Function to automatically generate monthly payments for monthly projects
CREATE OR REPLACE FUNCTION public.handle_monthly_project_payments()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  -- Only process if project_type is 'Ежемесячный' or 'ежемесячно'
  IF NEW.project_type IN ('Ежемесячный', 'ежемесячно') THEN
    -- Calculate monthly amount (if remainder exists, use it, otherwise use sale_amount / 12)
    IF NEW.remainder > 0 THEN
      monthly_amount := NEW.remainder;
    ELSE
      monthly_amount := NEW.sale_amount / 12;
    END IF;
    
    -- Use remainder_due_date as start date, otherwise use sale_date + 1 month
    IF NEW.remainder_due_date IS NOT NULL THEN
      start_date := NEW.remainder_due_date;
    ELSE
      start_date := NEW.sale_date + INTERVAL '1 month';
    END IF;
    
    -- Generate monthly payments
    PERFORM public.generate_monthly_payments(
      NEW.id,
      monthly_amount,
      start_date,
      12 -- Generate for 12 months by default
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to automatically generate monthly payments
CREATE TRIGGER trigger_generate_monthly_payments
  AFTER INSERT OR UPDATE ON public.sales_results
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_monthly_project_payments();

-- Function to mark payment as paid
CREATE OR REPLACE FUNCTION public.mark_payment_as_paid(
  p_payment_id UUID,
  p_actual_date DATE DEFAULT CURRENT_DATE,
  p_notes TEXT DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.monthly_payments
  SET 
    status = 'paid',
    actual_payment_date = p_actual_date,
    notes = COALESCE(p_notes, notes),
    updated_at = now()
  WHERE id = p_payment_id;
END;
$$;

-- Function to update overdue payments
CREATE OR REPLACE FUNCTION public.update_overdue_payments()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.monthly_payments
  SET status = 'overdue'
  WHERE status = 'pending' 
    AND payment_date < CURRENT_DATE;
END;
$$;