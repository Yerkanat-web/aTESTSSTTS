-- Проверим и создадим триггер для автоматической генерации ежемесячных платежей

-- Сначала удалим триггер если он существует
DROP TRIGGER IF EXISTS trigger_generate_monthly_payments ON public.sales_results;

-- Создадим триггер, который будет срабатывать при INSERT и UPDATE
CREATE TRIGGER trigger_generate_monthly_payments
  AFTER INSERT OR UPDATE ON public.sales_results
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_monthly_project_payments();

-- Также давайте проверим существующие продажи с типом "Ежемесячный" и создадим для них платежи
-- Если у них еще нет ежемесячных платежей
DO $$
DECLARE
  sale_record RECORD;
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  FOR sale_record IN 
    SELECT sr.* 
    FROM sales_results sr 
    WHERE sr.project_type IN ('Ежемесячный', 'ежемесячно')
    AND NOT EXISTS (
      SELECT 1 FROM monthly_payments mp 
      WHERE mp.sales_result_id = sr.id
    )
  LOOP
    -- Calculate monthly amount
    IF sale_record.remainder > 0 THEN
      monthly_amount := sale_record.remainder;
    ELSE
      monthly_amount := sale_record.sale_amount / 12;
    END IF;
    
    -- Use remainder_due_date as start date, otherwise use sale_date + 1 month
    IF sale_record.remainder_due_date IS NOT NULL THEN
      start_date := sale_record.remainder_due_date;
    ELSE
      start_date := sale_record.sale_date + INTERVAL '1 month';
    END IF;
    
    -- Generate the first monthly payment
    PERFORM public.generate_monthly_payments(
      sale_record.id,
      monthly_amount,
      start_date,
      1 -- Create only one payment initially
    );
    
    RAISE NOTICE 'Created monthly payment for sale: % with date: %', sale_record.project_name, start_date;
  END LOOP;
END $$;