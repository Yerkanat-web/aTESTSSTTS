-- Обновляем все задачи со стандартными категориями на "прочие задачи"
UPDATE employee_tasks 
SET category = 'прочие задачи' 
WHERE category IN (
  'development', 'design', 'testing', 'documentation', 'meeting', 
  'research', 'maintenance', 'support', 'training', 'general'
);

-- Удаляем стандартные категории из таблицы task_categories
DELETE FROM task_categories 
WHERE name IN (
  'development', 'design', 'testing', 'documentation', 'meeting', 
  'research', 'maintenance', 'support', 'training', 'general'
);