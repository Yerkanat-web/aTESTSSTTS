-- Fix the completed_at trigger to properly set the timestamp when task status changes to completed
CREATE OR REPLACE FUNCTION public.update_task_completed_at()
RETURNS TRIGGER AS $$
BEGIN
  -- If status is changing to completed, set completed_at
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    NEW.completed_at = now();
  -- If status is changing from completed to something else, clear completed_at
  ELSIF NEW.status != 'completed' AND OLD.status = 'completed' THEN
    NEW.completed_at = NULL;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Ensure the trigger exists on employee_tasks table
DROP TRIGGER IF EXISTS update_task_completed_at_trigger ON employee_tasks;
CREATE TRIGGER update_task_completed_at_trigger
  BEFORE UPDATE ON employee_tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_task_completed_at();

-- Update existing completed tasks that don't have completed_at set
UPDATE employee_tasks 
SET completed_at = updated_at 
WHERE status = 'completed' AND completed_at IS NULL;