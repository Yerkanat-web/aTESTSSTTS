-- Добавляем политику для руководителей отделов создавать задачи своим подчиненным
CREATE POLICY "Department leads can create tasks for their employees"
ON public.employee_tasks
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM employees manager, employees assignee
    WHERE manager.user_id = auth.uid()
    AND assignee.id = employee_tasks.employee_id
    AND (
      (manager.role = 'руководитель тех отдела' AND assignee.department = 'тех отдел') OR
      (manager.role = 'руководитель отдела продаж' AND assignee.department = 'отдел продаж') OR
      (manager.role = 'руководитель ИИ отдела' AND assignee.department = 'креатив отдел')
    )
    AND manager.status = 'active'
    AND assignee.status = 'active'
  )
);