-- Добавляем политику для руководителей отделов создавать задачи в project_tasks
CREATE POLICY "Department leads can create project tasks for themselves"
ON public.project_tasks
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM employees
    WHERE employees.user_id = auth.uid()
    AND employees.role IN (
      'руководитель тех отдела',
      'руководитель отдела продаж', 
      'руководитель ИИ отдела'
    )
    AND employees.status = 'active'
    AND employees.id = project_tasks.assignee_id
  )
);