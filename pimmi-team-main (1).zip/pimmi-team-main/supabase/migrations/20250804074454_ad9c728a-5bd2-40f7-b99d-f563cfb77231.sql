-- Восстанавливаем роль финансиста для пользователя aakmyrzaevva@gmail.com
UPDATE public.employees 
SET role = 'финансист', updated_at = now()
WHERE email = 'aakmyrzaevva@gmail.com' AND status = 'active';