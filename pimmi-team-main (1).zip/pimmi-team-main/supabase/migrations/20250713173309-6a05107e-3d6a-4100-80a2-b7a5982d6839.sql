-- Присваиваем роль "Финансист" сотруднице Арай
UPDATE employees 
SET role = 'финансист' 
WHERE name ILIKE '%арай%' OR email ILIKE '%арай%';