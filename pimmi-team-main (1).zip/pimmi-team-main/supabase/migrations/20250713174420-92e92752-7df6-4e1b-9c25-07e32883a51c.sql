-- Добавляем RLS политики для доступа финансистов к финансовым данным
CREATE POLICY "Financists can view all sales results" 
ON public.sales_results 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.user_id = auth.uid() 
    AND employees.role = 'финансист'
  )
);