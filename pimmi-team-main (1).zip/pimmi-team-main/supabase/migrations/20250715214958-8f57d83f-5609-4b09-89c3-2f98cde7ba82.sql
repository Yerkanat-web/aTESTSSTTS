-- Сначала удаляем существующее ограничение на роли
ALTER TABLE employees DROP CONSTRAINT IF EXISTS employees_role_check;

-- Добавляем новое ограничение с дополнительными ролями руководителей
ALTER TABLE employees ADD CONSTRAINT employees_role_check 
CHECK (role IN ('admin', 'employee', 'финансист', 'руководитель тех отдела', 'руководитель отдела продаж', 'руководитель ИИ отдела'));

-- Добавляем тестовых руководителей для каждого отдела
INSERT INTO employees (name, email, position, department, role, status)
SELECT 'Тестовый Руководитель Тех Отдела', 'tech_lead@demo.kz', 'Руководитель тех отдела', 'тех отдел', 'руководитель тех отдела', 'active'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE role = 'руководитель тех отдела');

INSERT INTO employees (name, email, position, department, role, status)
SELECT 'Тестовый Руководитель Продаж', 'sales_lead@demo.kz', 'Руководитель отдела продаж', 'отдел продаж', 'руководитель отдела продаж', 'active'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE role = 'руководитель отдела продаж');

INSERT INTO employees (name, email, position, department, role, status)
SELECT 'Тестовый Руководитель ИИ', 'ai_lead@demo.kz', 'Руководитель ИИ отдела', 'креатив отдел', 'руководитель ИИ отдела', 'active'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE role = 'руководитель ИИ отдела');

-- Создаем функции для проверки ролей руководителей
CREATE OR REPLACE FUNCTION public.is_admin_or_tech_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = check_user_id
    AND role IN ('admin', 'руководитель тех отдела')
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_sales_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = check_user_id
    AND role = 'руководитель отдела продаж'
    AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_ai_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = check_user_id
    AND role = 'руководитель ИИ отдела'
    AND status = 'active'
  );
$$;