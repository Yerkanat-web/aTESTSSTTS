
-- Добавляем политику для руководителей отделов создавать продажи
CREATE POLICY "Department leads can create sales results" 
ON public.sales_results 
FOR INSERT 
WITH CHECK (
  is_extension = false AND
  EXISTS (
    SELECT 1
    FROM employees manager, employees seller
    WHERE manager.user_id = auth.uid()
    AND seller.id = sales_results.employee_id
    AND manager.role IN (
      'руководитель тех отдела',
      'руководитель отдела продаж', 
      'руководитель ИИ отдела'
    )
    AND manager.status = 'active'
    AND (
      -- Руководитель тех отдела может создавать продажи для любых сотрудников
      manager.role = 'руководитель тех отдела' OR
      -- Руководитель отдела продаж может создавать продажи только для сотрудников отдела продаж
      (manager.role = 'руководитель отдела продаж' AND seller.department = 'отдел продаж') OR
      -- Руководитель ИИ отдела может создавать продажи только для сотрудников креатив отдела
      (manager.role = 'руководитель ИИ отдела' AND seller.department = 'креатив отдел')
    )
  )
);
