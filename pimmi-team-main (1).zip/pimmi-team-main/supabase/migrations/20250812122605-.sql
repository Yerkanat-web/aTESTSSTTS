-- Adjust RLS on achievement_templates so active employees of the org can SELECT templates
DO $$
BEGIN
  -- Drop existing restrictive SELECT tenant gate policy if it exists
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
      AND tablename = 'achievement_templates'
      AND policyname = 'Tenant org gate (SELECT)'
  ) THEN
    DROP POLICY "Tenant org gate (SELECT)" ON public.achievement_templates;
  END IF;
END $$;

-- Recreate a restrictive SELECT policy that allows either org members or active employees in the same org
CREATE POLICY "Tenant org gate (SELECT)" 
ON public.achievement_templates
AS RESTRICTIVE
FOR SELECT
USING (
  (org_id IS NOT NULL) AND (
    is_member_of_org(org_id)
    OR EXISTS (
      SELECT 1 FROM public.employees e
      WHERE e.user_id = auth.uid()
        AND e.org_id = achievement_templates.org_id
        AND e.status = 'active'
    )
  )
);
