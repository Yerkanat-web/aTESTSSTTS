-- Удаляем все просроченные задачи проектов
DELETE FROM project_tasks 
WHERE due_date < CURRENT_DATE 
AND status != 'completed';