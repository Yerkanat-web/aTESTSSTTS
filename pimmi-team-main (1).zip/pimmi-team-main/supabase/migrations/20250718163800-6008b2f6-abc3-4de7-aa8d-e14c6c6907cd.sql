-- Создаем функцию для обновления статуса ежемесячных платежей при завершении проекта
CREATE OR REPLACE FUNCTION public.handle_project_completion()
RETURNS TRIGGER AS $$
BEGIN
  -- Если статус проекта изменился на "Завершили работу"
  IF NEW.project_status = 'Завершили работу' AND (OLD.project_status IS NULL OR OLD.project_status != 'Завершили работу') THEN
    -- Обновляем все ежемесячные платежи для этого проекта
    UPDATE public.monthly_payments 
    SET 
      status = 'Проект не продлил',
      updated_at = now()
    WHERE sales_result_id = NEW.id
      AND status = 'pending';
    
    RAISE NOTICE 'Updated monthly payments status for completed project: %', NEW.id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Создаем триггер для автоматического обновления ежемесячных платежей
CREATE TRIGGER trigger_project_completion
  AFTER UPDATE ON public.sales_results
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_project_completion();