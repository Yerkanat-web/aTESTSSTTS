-- Исправляем функцию calculate_employee_points для учета потраченных баллов
CREATE OR REPLACE FUNCTION public.calculate_employee_points(emp_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  task_points INTEGER := 0;
  achievement_points INTEGER := 0;
  spent_points INTEGER := 0;
  total INTEGER := 0;
BEGIN
  -- Calculate points from completed tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO task_points
  FROM employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';
  
  -- Calculate points from achievements
  SELECT COALESCE(SUM(points), 0) INTO achievement_points
  FROM employee_achievements 
  WHERE employee_id = emp_id;
  
  -- Calculate spent points from shop purchases
  SELECT COALESCE(SUM(item_price), 0) INTO spent_points
  FROM shop_purchases 
  WHERE employee_id = emp_id;
  
  -- Total = earned points - spent points
  total := task_points + achievement_points - spent_points;
  
  -- Ensure total is never negative
  IF total < 0 THEN
    total := 0;
  END IF;
  
  -- Update or insert into employee_points
  INSERT INTO employee_points (employee_id, total_points, updated_at)
  VALUES (emp_id, total, now())
  ON CONFLICT (employee_id) 
  DO UPDATE SET 
    total_points = total,
    updated_at = now();
    
  RETURN total;
END;
$$;

-- Пересчитываем баллы для всех сотрудников с учетом потраченных баллов
DO $$ 
DECLARE
    emp_record RECORD;
BEGIN
    FOR emp_record IN SELECT id FROM employees WHERE status = 'active'
    LOOP
        PERFORM calculate_employee_points(emp_record.id);
    END LOOP;
END $$;