-- Add project_type column to sales_results table
ALTER TABLE sales_results 
ADD COLUMN project_type TEXT CHECK (project_type IN ('Тестовый', 'Единоразовый', 'Ежемесячный'));