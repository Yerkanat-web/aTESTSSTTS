-- Удаляем ошибочно созданный платёж для оригинального проекта "Принтер"
DELETE FROM public.monthly_payments 
WHERE sales_result_id = '8db1fdc1-77e2-4868-9863-7df061e7f701';