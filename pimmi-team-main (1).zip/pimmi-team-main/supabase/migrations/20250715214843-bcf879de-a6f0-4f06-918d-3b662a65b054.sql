-- Добавляем новые роли руководителей в систему
-- Обновляем существующих сотрудников на руководящие позиции где это нужно

-- Сначала добавляем роли в таблицу employees (обновляем существующие CHECK constraint если есть)
-- Проверяем текущие роли
SELECT DISTINCT role FROM employees;

-- Добавляем образцы руководителей для каждого отдела
UPDATE employees 
SET role = 'руководитель тех отдела' 
WHERE department = 'тех отдел' AND position LIKE '%руководитель%' OR position LIKE '%ведущий%' OR position LIKE '%главный%'
LIMIT 1;

UPDATE employees 
SET role = 'руководитель отдела продаж' 
WHERE department = 'отдел продаж' AND (position LIKE '%руководитель%' OR position LIKE '%ведущий%' OR position LIKE '%главный%')
LIMIT 1;

UPDATE employees 
SET role = 'руководитель ИИ отдела' 
WHERE department = 'ИИ отдел' OR (department = 'тех отдел' AND position LIKE '%ИИ%')
LIMIT 1;

-- Если нет подходящих сотрудников, создаем тестовых руководителей
INSERT INTO employees (name, email, position, department, role, status)
SELECT 'Тестовый Руководитель Тех Отдела', 'tech_lead@demo.kz', 'Руководитель тех отдела', 'тех отдел', 'руководитель тех отдела', 'active'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE role = 'руководитель тех отдела');

INSERT INTO employees (name, email, position, department, role, status)
SELECT 'Тестовый Руководитель Продаж', 'sales_lead@demo.kz', 'Руководитель отдела продаж', 'отдел продаж', 'руководитель отдела продаж', 'active'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE role = 'руководитель отдела продаж');

INSERT INTO employees (name, email, position, department, role, status)
SELECT 'Тестовый Руководитель ИИ', 'ai_lead@demo.kz', 'Руководитель ИИ отдела', 'креатив отдел', 'руководитель ИИ отдела', 'active'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE role = 'руководитель ИИ отдела');

-- Обновляем функцию is_admin для включения руководителей с административными правами
CREATE OR REPLACE FUNCTION public.is_admin_or_tech_lead(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = check_user_id
    AND role IN ('admin', 'руководитель тех отдела')
    AND status = 'active'
  );
$$;

-- Обновляем политики для task_categories чтобы руководители тех отдела могли управлять категориями
DROP POLICY IF EXISTS "Admins can manage task categories" ON task_categories;
CREATE POLICY "Admins and tech leads can manage task categories" 
ON task_categories 
FOR ALL 
USING (is_admin_or_tech_lead());

-- Обновляем политики для employee_tasks чтобы руководители могли видеть задачи своего отдела
CREATE POLICY "Tech leads can view their department tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель тех отдела'
    AND e2.id = employee_tasks.employee_id 
    AND e2.department = 'тех отдел'
  )
);

CREATE POLICY "Sales leads can view their department tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель отдела продаж'
    AND e2.id = employee_tasks.employee_id 
    AND e2.department = 'отдел продаж'
  )
);

CREATE POLICY "AI leads can view creative department tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель ИИ отдела'
    AND e2.id = employee_tasks.employee_id 
    AND e2.department = 'креатив отдел'
  )
);

-- Аналогично для других таблиц где нужен доступ руководителей к данным своих отделов
CREATE POLICY "Leads can view their department reports" 
ON daily_reports 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND (
      (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
      (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
      (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
    )
    AND e2.id = daily_reports.employee_id
  )
);

CREATE POLICY "Leads can view their department achievements" 
ON employee_achievements 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND (
      (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
      (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
      (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
    )
    AND e2.id = employee_achievements.employee_id
  )
);

CREATE POLICY "Leads can view their department points" 
ON employee_points 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND (
      (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
      (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
      (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
    )
    AND e2.id = employee_points.employee_id
  )
);