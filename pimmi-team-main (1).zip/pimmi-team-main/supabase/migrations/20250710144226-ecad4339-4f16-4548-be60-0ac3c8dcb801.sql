-- Delete users Галым and Нурбек with all their associated data
-- This will permanently remove all traces of these employees

-- First, get the employee IDs
DO $$
DECLARE
    galym_id uuid;
    nurbek_id uuid;
BEGIN
    -- Get employee IDs
    SELECT id INTO galym_id FROM employees WHERE email = 'galym@mail.ru';
    SELECT id INTO nurbek_id FROM employees WHERE email = 'nurbek@gmail.com';
    
    -- Log the IDs for verification
    RAISE NOTICE 'Deleting Galym ID: %', galym_id;
    RAISE NOTICE 'Deleting Nurbek ID: %', nurbek_id;
    
    -- Delete in correct order to respect foreign key constraints
    
    -- 1. Delete task attachments
    DELETE FROM task_attachments 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 2. Delete task comments  
    DELETE FROM task_comments 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 3. Delete work time logs
    DELETE FROM work_time_logs 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 4. Delete employee tasks
    DELETE FROM employee_tasks 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 5. Delete employee achievements
    DELETE FROM employee_achievements 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 6. Delete shop purchases
    DELETE FROM shop_purchases 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 7. Delete daily reports
    DELETE FROM daily_reports 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 8. Delete sales results
    DELETE FROM sales_results 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 9. Delete employee points
    DELETE FROM employee_points 
    WHERE employee_id IN (galym_id, nurbek_id);
    
    -- 10. Finally delete the employees themselves
    DELETE FROM employees 
    WHERE id IN (galym_id, nurbek_id);
    
    RAISE NOTICE 'Successfully deleted employees Галым and Нурбек with all associated data';
END $$;