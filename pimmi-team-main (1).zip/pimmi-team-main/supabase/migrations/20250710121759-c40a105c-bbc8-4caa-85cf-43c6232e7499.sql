-- Создаем функцию для автоматической проверки достижений
CREATE OR REPLACE FUNCTION public.check_achievements_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Проверяем достижения когда задача помечается как выполненная
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Здесь можно добавить логику автоматической проверки достижений
    -- Пока просто пересчитываем баллы
    PERFORM calculate_employee_points(NEW.employee_id);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Создаем триггер для автоматической проверки достижений при завершении задач
DROP TRIGGER IF EXISTS check_achievements_on_task_completion ON employee_tasks;
CREATE TRIGGER check_achievements_on_task_completion
  AFTER UPDATE ON employee_tasks
  FOR EACH ROW
  EXECUTE FUNCTION check_achievements_trigger();