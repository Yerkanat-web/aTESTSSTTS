-- Обновляем политику INSERT для employee_tasks, добавляя руководителей отделов
DROP POLICY IF EXISTS "Employees and financists can insert their own tasks" ON employee_tasks;

CREATE POLICY "Employees, financists and department leads can insert their own tasks" 
ON employee_tasks 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_tasks.employee_id 
    AND employees.user_id = auth.uid() 
    AND (
      employees.role = ANY (ARRAY['employee'::text, 'финансист'::text]) OR
      employees.role LIKE 'руководитель%'
    )
  )
);