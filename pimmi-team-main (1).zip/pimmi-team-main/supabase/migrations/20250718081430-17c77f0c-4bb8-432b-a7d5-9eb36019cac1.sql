-- Синхронизируем существующие данные продлений
UPDATE sales_results 
SET 
  prepayment = mp.prepayment,
  remainder = mp.remainder,
  updated_at = now()
FROM (
  SELECT DISTINCT ON (mp.sales_result_id)
    mp.sales_result_id,
    mp.prepayment,
    mp.remainder
  FROM monthly_payments mp
  JOIN sales_results sr ON mp.sales_result_id = sr.id
  WHERE sr.is_extension = true
    AND mp.status = 'paid'
  ORDER BY mp.sales_result_id, mp.actual_payment_date DESC NULLS LAST
) mp
WHERE sales_results.id = mp.sales_result_id
  AND sales_results.is_extension = true;