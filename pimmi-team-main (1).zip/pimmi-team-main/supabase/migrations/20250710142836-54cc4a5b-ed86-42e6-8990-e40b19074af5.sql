-- Fix Storage RLS policies for task attachments

-- Drop all existing conflicting policies for task-attachments bucket
DROP POLICY IF EXISTS "Public access for task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Users can update task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Employees can upload attachments for their tasks" ON storage.objects;
DROP POLICY IF EXISTS "Employees can view attachments for their tasks" ON storage.objects;
DROP POLICY IF EXISTS "Admins can manage all attachments" ON storage.objects;
DROP POLICY IF EXISTS "Admins have full access to task attachments" ON storage.objects;

-- Create simplified and working policies
-- 1. Allow public read access for task attachments
CREATE POLICY "Allow public read access to task attachments" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'task-attachments');

-- 2. Allow authenticated users to upload files to task-attachments bucket
CREATE POLICY "Allow authenticated upload to task attachments" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'task-attachments' 
  AND auth.role() = 'authenticated'
);

-- 3. Allow authenticated users to update their files
CREATE POLICY "Allow authenticated update to task attachments" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'task-attachments' 
  AND auth.role() = 'authenticated'
);

-- 4. Allow authenticated users to delete their files  
CREATE POLICY "Allow authenticated delete from task attachments" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'task-attachments' 
  AND auth.role() = 'authenticated'
);

-- 5. Admin override policy
CREATE POLICY "Admin full access to task attachments" 
ON storage.objects 
FOR ALL 
USING (
  bucket_id = 'task-attachments' 
  AND is_admin()
);