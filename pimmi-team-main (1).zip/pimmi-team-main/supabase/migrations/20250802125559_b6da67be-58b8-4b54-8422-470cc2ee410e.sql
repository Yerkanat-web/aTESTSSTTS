-- Исправляем функцию для обработки ежемесячных проектов
-- Исключаем продления из автоматического деления на 12
CREATE OR REPLACE FUNCTION public.handle_monthly_project_payments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  monthly_amount NUMERIC;
  start_date DATE;
BEGIN
  -- Только для ежемесячных проектов, НО НЕ для продлений
  IF NEW.project_type IN ('Ежемесячный', 'ежемесячно') AND NEW.is_extension = FALSE THEN
    -- Calculate monthly amount (if remainder exists, use it, otherwise use sale_amount / 12)
    IF NEW.remainder > 0 THEN
      monthly_amount := NEW.remainder;
    ELSE
      monthly_amount := NEW.sale_amount / 12;
    END IF;
    
    -- For monthly projects, ALWAYS use sale_date + 1 month for first payment
    -- This ensures monthly payments start the month after the sale
    start_date := NEW.sale_date + INTERVAL '1 month';
    
    -- Generate only the first monthly payment
    PERFORM public.generate_monthly_payments(
      NEW.id,
      monthly_amount,
      start_date,
      1 -- Create only one payment initially
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Исправляем функцию создания ежемесячных платежей для продлений
-- Теперь она будет показывать фактические суммы
CREATE OR REPLACE FUNCTION public.create_extension_monthly_payment()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  -- Только для продлений проектов
  IF NEW.is_extension = TRUE THEN
    -- Создаем ежемесячный платеж с фактическими значениями из продления
    INSERT INTO monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      prepayment,
      remainder,
      remainder_due_date,
      status
    ) VALUES (
      NEW.id,
      NEW.sale_date + INTERVAL '1 month', -- Первый платеж через месяц
      NEW.sale_amount,     -- Фактическая сумма продления
      NEW.prepayment,      -- Фактическая предоплата из продления
      NEW.remainder,       -- Фактический остаток из продления
      NEW.remainder_due_date,
      CASE 
        WHEN NEW.remainder <= 0 THEN 'paid'  -- Если остатка нет, сразу помечаем как оплаченный
        ELSE 'pending'
      END
    );
  END IF;
  
  RETURN NEW;
END;
$function$;