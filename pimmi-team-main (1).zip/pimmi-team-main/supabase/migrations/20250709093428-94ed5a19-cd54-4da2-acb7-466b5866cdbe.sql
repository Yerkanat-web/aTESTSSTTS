-- Удаляем существующую запись администратора
DELETE FROM employees WHERE email = 'admin@example.com';

-- Создаем нового администратора с временно отключенными политиками
SET session_replication_role = replica;

INSERT INTO employees (name, email, position, department, status, role) 
VALUES ('Мария Иванова', 'admin@example.com', 'Руководитель', 'управление', 'active', 'admin');

SET session_replication_role = DEFAULT;