-- Rename time columns to store minutes instead of hours
ALTER TABLE employee_tasks 
RENAME COLUMN estimated_hours TO estimated_minutes;

ALTER TABLE employee_tasks 
RENAME COLUMN actual_hours TO actual_minutes;

-- Update existing data: convert hours to minutes
UPDATE employee_tasks 
SET estimated_minutes = estimated_minutes * 60 
WHERE estimated_minutes IS NOT NULL;

UPDATE employee_tasks 
SET actual_minutes = actual_minutes * 60 
WHERE actual_minutes IS NOT NULL;