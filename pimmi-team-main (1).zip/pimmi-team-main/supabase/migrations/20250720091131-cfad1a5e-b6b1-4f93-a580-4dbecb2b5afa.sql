-- Удаляем дублирующиеся политики для employees
DROP POLICY IF EXISTS "Users can view employees" ON employees;
DROP POLICY IF EXISTS "Simple employee access" ON employees;

-- Создаем одну правильную политику для чтения
CREATE POLICY "Users can view their own employee record" 
ON employees 
FOR SELECT 
USING (
  auth.uid() = user_id OR 
  is_admin() OR
  EXISTS (
    SELECT 1 
    FROM employees requester 
    WHERE requester.user_id = auth.uid() 
    AND requester.department = 'отдел продаж'
    AND requester.status = 'active'
    AND (
      employees.department = 'отдел продаж' 
      OR employees.role = 'admin'
    )
    AND employees.status = 'active'
  )
);