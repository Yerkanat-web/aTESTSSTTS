-- Добавляем политику для руководителей тех отдела для просмотра категорий
CREATE POLICY "Tech leads can view categories" 
ON public.project_categories 
FOR SELECT 
USING (is_admin_or_tech_lead());

-- Добавляем политику для руководителей ИИ отдела для просмотра категорий
CREATE POLICY "AI leads can view categories" 
ON public.project_categories 
FOR SELECT 
USING (is_ai_lead());