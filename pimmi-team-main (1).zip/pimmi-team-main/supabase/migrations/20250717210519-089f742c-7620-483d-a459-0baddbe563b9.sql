-- Add remainder_due_date column to monthly_payments table
ALTER TABLE public.monthly_payments
ADD COLUMN remainder_due_date DATE DEFAULT NULL;