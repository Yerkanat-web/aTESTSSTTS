-- Remove unused sales columns from daily_reports table
-- These columns are not being used since sales data is tracked in sales_results table
ALTER TABLE public.daily_reports 
DROP COLUMN IF EXISTS sales_count,
DROP COLUMN IF EXISTS sale_amount;