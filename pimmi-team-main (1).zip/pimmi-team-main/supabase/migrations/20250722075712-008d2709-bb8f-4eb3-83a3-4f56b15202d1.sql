-- Исправляем расчет остатка для платежей продлений
-- Обновляем платеж для продления Индиры правильными значениями
UPDATE monthly_payments 
SET 
  remainder = 100000
WHERE sales_result_id = '3f429549-edc5-4123-86b9-50b4b8effaed';