-- Update calculate_employee_points function to include project_tasks
CREATE OR REPLACE FUNCTION public.calculate_employee_points(emp_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  task_points INTEGER := 0;
  project_task_points INTEGER := 0;
  achievement_points INTEGER := 0;
  sales_points INTEGER := 0;
  report_points INTEGER := 0;
  spent_points INTEGER := 0;
  total INTEGER := 0;
BEGIN
  -- Calculate points from completed employee_tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO task_points
  FROM employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';
  
  -- Calculate points from completed project_tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO project_task_points
  FROM project_tasks 
  WHERE assignee_id = emp_id AND status = 'completed';
  
  -- Calculate points from achievements
  SELECT COALESCE(SUM(points), 0) INTO achievement_points
  FROM employee_achievements 
  WHERE employee_id = emp_id;
  
  -- Calculate points from sales (120 points per sale for sales department)
  SELECT COALESCE(COUNT(*) * 120, 0) INTO sales_points
  FROM sales_results sr
  JOIN employees e ON sr.employee_id = e.id
  WHERE sr.employee_id = emp_id AND e.department = 'отдел продаж';
  
  -- Calculate points from daily reports (30 points per report)
  SELECT COALESCE(COUNT(*) * 30, 0) INTO report_points
  FROM daily_reports 
  WHERE employee_id = emp_id;
  
  -- Calculate spent points from shop purchases
  SELECT COALESCE(SUM(item_price), 0) INTO spent_points
  FROM shop_purchases 
  WHERE employee_id = emp_id;
  
  -- Total = task points + project task points + achievement points + sales points + report points - spent points
  total := task_points + project_task_points + achievement_points + sales_points + report_points - spent_points;
  
  -- Ensure total is never negative
  IF total < 0 THEN
    total := 0;
  END IF;
  
  -- Log for debugging
  RAISE NOTICE 'Employee % points: employee_tasks=%, project_tasks=%, achievements=%, sales=%, reports=%, spent=%, total=%', 
    emp_id, task_points, project_task_points, achievement_points, sales_points, report_points, spent_points, total;
  
  -- Update or insert into employee_points
  INSERT INTO employee_points (employee_id, total_points, updated_at)
  VALUES (emp_id, total, now())
  ON CONFLICT (employee_id) 
  DO UPDATE SET 
    total_points = total,
    updated_at = now();
    
  RETURN total;
END;
$function$;

-- Create trigger function for project_tasks
CREATE OR REPLACE FUNCTION public.update_project_task_points_trigger()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  -- For INSERT/UPDATE on project_tasks
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    IF NEW.assignee_id IS NOT NULL THEN
      PERFORM calculate_employee_points(NEW.assignee_id);
    END IF;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    IF OLD.assignee_id IS NOT NULL THEN
      PERFORM calculate_employee_points(OLD.assignee_id);
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$function$;

-- Create trigger on project_tasks table
DROP TRIGGER IF EXISTS project_tasks_points_trigger ON project_tasks;
CREATE TRIGGER project_tasks_points_trigger
AFTER INSERT OR UPDATE OR DELETE ON project_tasks
FOR EACH ROW
EXECUTE FUNCTION update_project_task_points_trigger();

-- Recalculate points for all employees to include project_tasks
DO $$
DECLARE
  emp_record RECORD;
BEGIN
  FOR emp_record IN SELECT id FROM employees WHERE status = 'active' LOOP
    PERFORM calculate_employee_points(emp_record.id);
  END LOOP;
END $$;