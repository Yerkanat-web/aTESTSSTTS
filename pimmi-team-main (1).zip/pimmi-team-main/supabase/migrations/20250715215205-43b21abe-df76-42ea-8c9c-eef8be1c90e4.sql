-- Обновляем политики для task_categories чтобы руководители тех отдела могли управлять категориями
DROP POLICY IF EXISTS "Admins can manage task categories" ON task_categories;
CREATE POLICY "Admins and tech leads can manage task categories" 
ON task_categories 
FOR ALL 
USING (is_admin_or_tech_lead());

-- Добавляем политики для руководителей отделов для просмотра данных своих сотрудников
CREATE POLICY "Tech leads can view tech department tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель тех отдела'
    AND e2.id = employee_tasks.employee_id 
    AND e2.department = 'тех отдел'
  )
);

CREATE POLICY "Sales leads can view sales department tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель отдела продаж'
    AND e2.id = employee_tasks.employee_id 
    AND e2.department = 'отдел продаж'
  )
);

CREATE POLICY "AI leads can view creative department tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель ИИ отдела'
    AND e2.id = employee_tasks.employee_id 
    AND e2.department = 'креатив отдел'
  )
);

-- Политики для просмотра отчетов своих отделов
CREATE POLICY "Department leads can view their department reports" 
ON daily_reports 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND (
      (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
      (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
      (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
    )
    AND e2.id = daily_reports.employee_id
  )
);

-- Политики для просмотра достижений своих отделов  
CREATE POLICY "Department leads can view their department achievements" 
ON employee_achievements 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND (
      (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
      (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
      (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
    )
    AND e2.id = employee_achievements.employee_id
  )
);

-- Политики для просмотра баллов своих отделов
CREATE POLICY "Department leads can view their department points" 
ON employee_points 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND (
      (e1.role = 'руководитель тех отдела' AND e2.department = 'тех отдел') OR
      (e1.role = 'руководитель отдела продаж' AND e2.department = 'отдел продаж') OR
      (e1.role = 'руководитель ИИ отдела' AND e2.department = 'креатив отдел')
    )
    AND e2.id = employee_points.employee_id
  )
);

-- Политики для sales_results
CREATE POLICY "Sales leads can view their department sales" 
ON sales_results 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees e1, employees e2 
    WHERE e1.user_id = auth.uid() 
    AND e1.role = 'руководитель отдела продаж'
    AND e2.id = sales_results.employee_id 
    AND e2.department = 'отдел продаж'
  )
);

-- Политики для просмотра сотрудников своего отдела
CREATE POLICY "Department leads can view their department employees" 
ON employees 
FOR SELECT 
USING (
  CASE
    WHEN (auth.uid() IS NULL) THEN false
    WHEN is_admin() THEN true
    WHEN (auth.uid() = user_id) THEN true
    WHEN EXISTS (
      SELECT 1 
      FROM employees lead
      WHERE lead.user_id = auth.uid() 
      AND (
        (lead.role = 'руководитель тех отдела' AND employees.department = 'тех отдел') OR
        (lead.role = 'руководитель отдела продаж' AND employees.department = 'отдел продаж') OR
        (lead.role = 'руководитель ИИ отдела' AND employees.department = 'креатив отдел')
      )
    ) THEN true
    ELSE false
  END
);