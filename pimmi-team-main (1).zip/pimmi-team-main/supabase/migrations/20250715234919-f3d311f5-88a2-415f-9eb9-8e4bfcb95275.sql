-- Добавляем политику для руководителей отделов создавать кейсы
CREATE POLICY "Department leads can create project cases"
ON public.project_cases
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = auth.uid()
    AND role IN (
      'руководитель тех отдела',
      'руководитель отдела продаж', 
      'руководитель ИИ отдела'
    )
    AND status = 'active'
  )
);

-- Добавляем политику для руководителей отделов редактировать кейсы
CREATE POLICY "Department leads can update project cases"
ON public.project_cases
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM employees
    WHERE user_id = auth.uid()
    AND role IN (
      'руководитель тех отдела',
      'руководитель отдела продаж', 
      'руководитель ИИ отдела'
    )
    AND status = 'active'
  )
);