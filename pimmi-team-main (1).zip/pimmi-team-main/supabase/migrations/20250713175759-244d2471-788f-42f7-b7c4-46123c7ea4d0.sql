-- Обновляем политики для задач - финансисты получают такие же права как сотрудники
DROP POLICY IF EXISTS "Employees can view their own tasks" ON employee_tasks;
CREATE POLICY "Employees and financists can view their own tasks" 
ON employee_tasks 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_tasks.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can update their own tasks" ON employee_tasks;
CREATE POLICY "Employees and financists can update their own tasks" 
ON employee_tasks 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_tasks.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can insert their own tasks" ON employee_tasks;
CREATE POLICY "Employees and financists can insert their own tasks" 
ON employee_tasks 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_tasks.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can delete their own tasks" ON employee_tasks;
CREATE POLICY "Employees and financists can delete their own tasks" 
ON employee_tasks 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_tasks.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

-- Обновляем политики для баллов
DROP POLICY IF EXISTS "Employees can view their own points" ON employee_points;
CREATE POLICY "Employees and financists can view their own points" 
ON employee_points 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_points.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

-- Обновляем политики для достижений
DROP POLICY IF EXISTS "Employees can view their own achievements" ON employee_achievements;
CREATE POLICY "Employees and financists can view their own achievements" 
ON employee_achievements 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_achievements.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);

DROP POLICY IF EXISTS "Employees can create their own achievements" ON employee_achievements;
CREATE POLICY "Employees and financists can create their own achievements" 
ON employee_achievements 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM employees 
    WHERE employees.id = employee_achievements.employee_id 
    AND employees.user_id = auth.uid() 
    AND employees.role IN ('employee', 'финансист')
  )
);