-- Check current RLS policies for sales_results
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check 
FROM pg_policies 
WHERE tablename = 'sales_results';

-- Add UPDATE policy for financists on sales_results table
CREATE POLICY "Financists can update sales results" 
ON public.sales_results 
FOR UPDATE 
USING (EXISTS ( 
  SELECT 1 
  FROM employees 
  WHERE employees.user_id = auth.uid() AND employees.role = 'финансист'
));