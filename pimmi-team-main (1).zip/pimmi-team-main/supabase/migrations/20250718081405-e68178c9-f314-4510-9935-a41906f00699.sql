-- Создаем функцию для синхронизации данных между monthly_payments и sales_results
CREATE OR REPLACE FUNCTION sync_extension_payments()
RETURNS TRIGGER AS $$
BEGIN
  -- Обновляем только для продлений проектов (is_extension = true)
  IF EXISTS (
    SELECT 1 FROM sales_results 
    WHERE id = NEW.sales_result_id AND is_extension = true
  ) THEN
    -- Обновляем prepayment и remainder в sales_results на основе данных из monthly_payments
    UPDATE sales_results 
    SET 
      prepayment = NEW.prepayment,
      remainder = NEW.remainder,
      updated_at = now()
    WHERE id = NEW.sales_result_id;
    
    RAISE NOTICE 'Synced extension payment data for sales_result_id: %', NEW.sales_result_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Создаем триггер для синхронизации при обновлении monthly_payments
CREATE OR REPLACE TRIGGER sync_extension_payments_trigger
  AFTER UPDATE ON monthly_payments
  FOR EACH ROW
  EXECUTE FUNCTION sync_extension_payments();