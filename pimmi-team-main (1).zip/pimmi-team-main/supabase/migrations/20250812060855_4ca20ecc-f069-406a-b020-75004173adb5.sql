
-- 1) Функция-предикат: проверка членства пользователя в организации
create or replace function public.user_in_org(check_org uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(exists (
    select 1
    from public.organization_members m
    where m.user_id = auth.uid()
      and m.org_id = check_org
  ), false);
$$;

-- 2) Триггер-функция: запрет изменения org_id
create or replace function public.prevent_org_id_change()
returns trigger
language plpgsql
as $func$
begin
  if tg_op = 'UPDATE' and new.org_id is distinct from old.org_id then
    raise exception 'Changing org_id is not allowed on table %', tg_table_name
      using errcode = '42501';
  end if;
  return new;
end;
$func$;

-- 3) Включаем RLS на целевых таблицах (если вдруг где-то выключен)
do $$
declare t text;
begin
  foreach t in array array[
    'employees','daily_reports','employee_achievements','employee_points','employee_tasks',
    'monthly_payments','project_accounts','project_cases','project_categories','project_tasks','sales_results'
  ] loop
    execute format('alter table public.%I enable row level security;', t);
  end loop;
end$$;

-- 4) Индексы на org_id (если отсутствуют)
do $$
declare t text;
declare idx text;
begin
  foreach t in array array[
    'employees','daily_reports','employee_achievements','employee_points','employee_tasks',
    'monthly_payments','project_accounts','project_cases','project_categories','project_tasks','sales_results'
  ] loop
    idx := 'idx_'||t||'_org_id';
    if not exists (
      select 1 from pg_indexes
      where schemaname = 'public' and indexname = idx
    ) then
      execute format('create index %I on public.%I (org_id);', idx, t);
    end if;
  end loop;
end$$;

-- 5) RESTRICTIVE “tenant gate” политики: пропускают только строки той же org
-- Политики создаются только если ещё не существуют
do $$
declare t text;
begin
  foreach t in array array[
    'employees','daily_reports','employee_achievements','employee_points','employee_tasks',
    'monthly_payments','project_accounts','project_cases','project_categories','project_tasks','sales_results'
  ] loop
    -- SELECT
    if not exists (
      select 1 from pg_policies
      where schemaname='public' and tablename=t and policyname='tenant_gate_select'
    ) then
      execute format(
        'create policy tenant_gate_select as RESTRICTIVE on public.%I for select using (public.user_in_org(org_id));',
        t
      );
    end if;

    -- INSERT
    if not exists (
      select 1 from pg_policies
      where schemaname='public' and tablename=t and policyname='tenant_gate_insert'
    ) then
      execute format(
        'create policy tenant_gate_insert as RESTRICTIVE on public.%I for insert with check (public.user_in_org(org_id));',
        t
      );
    end if;

    -- UPDATE
    if not exists (
      select 1 from pg_policies
      where schemaname='public' and tablename=t and policyname='tenant_gate_update'
    ) then
      execute format(
        'create policy tenant_gate_update as RESTRICTIVE on public.%I for update using (public.user_in_org(org_id)) with check (public.user_in_org(org_id));',
        t
      );
    end if;

    -- DELETE
    if not exists (
      select 1 from pg_policies
      where schemaname='public' and tablename=t and policyname='tenant_gate_delete'
    ) then
      execute format(
        'create policy tenant_gate_delete as RESTRICTIVE on public.%I for delete using (public.user_in_org(org_id));',
        t
      );
    end if;
  end loop;
end$$;

-- 6) Триггеры запрета изменения org_id на всех целевых таблицах
do $$
declare t text;
declare trg text;
begin
  foreach t in array array[
    'employees','daily_reports','employee_achievements','employee_points','employee_tasks',
    'monthly_payments','project_accounts','project_cases','project_categories','project_tasks','sales_results'
  ] loop
    trg := 'prevent_org_id_change_'||t;
    if not exists (
      select 1 from pg_trigger where tgname = trg
    ) then
      execute format(
        'create trigger %I before update of org_id on public.%I
         for each row execute function public.prevent_org_id_change();',
        trg, t
      );
    end if;
  end loop;
end$$;
