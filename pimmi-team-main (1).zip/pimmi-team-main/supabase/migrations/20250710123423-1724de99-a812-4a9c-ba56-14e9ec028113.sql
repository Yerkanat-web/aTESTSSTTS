-- Исправляем RLS политики для таблицы employee_achievements
-- Разрешаем сотрудникам создавать свои достижения

-- Сначала удаляем старые политики
DROP POLICY IF EXISTS "Employees can view their own achievements" ON employee_achievements;
DROP POLICY IF EXISTS "Admins can manage achievements" ON employee_achievements;

-- Создаем новые политики
-- Сотрудники могут просматривать свои достижения
CREATE POLICY "Employees can view their own achievements" 
ON employee_achievements 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.id = employee_achievements.employee_id 
    AND employees.user_id = auth.uid()
  )
);

-- Сотрудники могут создавать свои достижения (для автоматического присуждения)
CREATE POLICY "Employees can create their own achievements" 
ON employee_achievements 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM employees 
    WHERE employees.id = employee_achievements.employee_id 
    AND employees.user_id = auth.uid()
  )
);

-- Администраторы могут управлять всеми достижениями
CREATE POLICY "Admins can manage all achievements" 
ON employee_achievements 
FOR ALL 
USING (is_admin());

-- Также создадим функцию для безопасного присуждения достижений
CREATE OR REPLACE FUNCTION public.award_achievement_safely(
  emp_id UUID,
  achievement_name TEXT,
  achievement_description TEXT,
  achievement_points INTEGER
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Проверяем, что достижение еще не получено
  IF EXISTS (
    SELECT 1 FROM employee_achievements 
    WHERE employee_id = emp_id AND achievement_name = award_achievement_safely.achievement_name
  ) THEN
    RETURN FALSE; -- Достижение уже получено
  END IF;
  
  -- Присуждаем достижение
  INSERT INTO employee_achievements (
    employee_id, 
    achievement_name, 
    description, 
    points
  ) VALUES (
    emp_id, 
    achievement_name, 
    achievement_description, 
    achievement_points
  );
  
  -- Пересчитываем баллы
  PERFORM calculate_employee_points(emp_id);
  
  RETURN TRUE; -- Достижение успешно присуждено
END;
$$;