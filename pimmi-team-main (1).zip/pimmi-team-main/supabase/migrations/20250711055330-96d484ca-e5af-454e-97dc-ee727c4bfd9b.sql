-- Обнуляем покупки для пользователя Нурбек
DELETE FROM shop_purchases 
WHERE employee_id IN (
  SELECT id FROM employees WHERE name ILIKE '%нурбек%'
);

-- Пересчитываем баллы для Нурбека после удаления покупок
DO $$
DECLARE
  nurbek_id UUID;
BEGIN
  SELECT id INTO nurbek_id FROM employees WHERE name ILIKE '%нурбек%' LIMIT 1;
  
  IF nurbek_id IS NOT NULL THEN
    PERFORM calculate_employee_points(nurbek_id);
    RAISE NOTICE 'Покупки обнулены и баллы пересчитаны для пользователя с ID: %', nurbek_id;
  ELSE
    RAISE NOTICE 'Пользователь Нурбек не найден';
  END IF;
END $$;