-- Set immutable search_path for remaining functions

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.calculate_remainder()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  NEW.remainder = NEW.sale_amount - COALESCE(NEW.prepayment, 0);
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_extension_monthly_payment()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF NEW.is_extension = TRUE THEN
    INSERT INTO monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      prepayment,
      remainder,
      remainder_due_date,
      status
    ) VALUES (
      NEW.id,
      NEW.sale_date + INTERVAL '1 month',
      NEW.sale_amount,
      NEW.prepayment,
      NEW.remainder,
      NEW.remainder_due_date,
      CASE 
        WHEN NEW.remainder <= 0 THEN 'paid'
        ELSE 'pending'
      END
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_project_completion()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF NEW.project_status = 'Завершили работу' AND (OLD.project_status IS NULL OR OLD.project_status != 'Завершили работу') THEN
    UPDATE public.monthly_payments 
    SET 
      status = 'Проект не продлил',
      updated_at = now()
    WHERE sales_result_id = NEW.id
      AND status = 'pending';
    
    RAISE NOTICE 'Updated monthly payments status for completed project: %', NEW.id;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.calculate_monthly_payment_remainder()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM sales_results 
    WHERE id = NEW.sales_result_id AND is_extension = true
  ) THEN
    RETURN NEW;
  ELSE
    NEW.remainder = NEW.amount - COALESCE(NEW.prepayment, 0);
    RETURN NEW;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_task_completed_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    NEW.completed_at = now();
  ELSIF NEW.status != 'completed' AND OLD.status = 'completed' THEN
    NEW.completed_at = NULL;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_project_task_points_trigger()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    IF NEW.assignee_id IS NOT NULL THEN
      PERFORM calculate_employee_points(NEW.assignee_id);
    END IF;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    IF OLD.assignee_id IS NOT NULL THEN
      PERFORM calculate_employee_points(OLD.assignee_id);
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE OR REPLACE FUNCTION public.update_points_on_sales()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_employee_points(NEW.employee_id);
    PERFORM check_sales_achievements(NEW.employee_id);
    RETURN NEW;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    PERFORM calculate_employee_points(OLD.employee_id);
    PERFORM check_sales_achievements(OLD.employee_id);
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_points_on_reports()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_employee_points(NEW.employee_id);
    PERFORM check_sales_achievements(NEW.employee_id);
    RETURN NEW;
  END IF;
  
  IF TG_OP = 'DELETE' THEN
    PERFORM calculate_employee_points(OLD.employee_id);
    PERFORM check_sales_achievements(OLD.employee_id);
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_employee_points_trigger()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF TG_TABLE_NAME = 'employee_tasks' THEN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
      PERFORM calculate_employee_points(NEW.employee_id);
    END IF;
    IF TG_OP = 'DELETE' THEN
      PERFORM calculate_employee_points(OLD.employee_id);
    END IF;
  END IF;
  
  IF TG_TABLE_NAME = 'employee_achievements' THEN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
      PERFORM calculate_employee_points(NEW.employee_id);
    END IF;
    IF TG_OP = 'DELETE' THEN
      PERFORM calculate_employee_points(OLD.employee_id);
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE OR REPLACE FUNCTION public.prevent_org_id_change()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO public
AS $$
BEGIN
  IF NEW.org_id IS DISTINCT FROM OLD.org_id THEN
    RAISE EXCEPTION 'Changing org_id is not allowed';
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.now_almaty()
RETURNS timestamp with time zone
LANGUAGE sql
STABLE
SET search_path TO public
AS $$
  SELECT NOW() AT TIME ZONE 'Asia/Almaty';
$$;

CREATE OR REPLACE FUNCTION public.format_almaty_date(input_date timestamp with time zone)
RETURNS text
LANGUAGE sql
STABLE
SET search_path TO public
AS $$
  SELECT to_char(input_date AT TIME ZONE 'Asia/Almaty', 'DD.MM.YYYY HH24:MI');
$$;

CREATE OR REPLACE FUNCTION public.almaty_date_string(input_date timestamp with time zone DEFAULT now())
RETURNS text
LANGUAGE sql
STABLE
SET search_path TO public
AS $$
  SELECT to_char(input_date AT TIME ZONE 'Asia/Almaty', 'YYYY-MM-DD');
$$;