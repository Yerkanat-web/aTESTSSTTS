-- Синхронизируем данные продления "Принтер" с актуальными данными из monthly_payments
UPDATE sales_results 
SET 
  prepayment = 150000,
  remainder = 0,
  updated_at = now()
WHERE id = '6a6ea02f-ea6c-4831-a5a9-7691decbe275';