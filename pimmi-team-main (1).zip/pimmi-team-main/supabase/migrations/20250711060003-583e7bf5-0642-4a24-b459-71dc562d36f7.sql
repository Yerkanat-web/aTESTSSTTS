-- Add instagram_url column to project_cases table
ALTER TABLE public.project_cases 
ADD COLUMN instagram_url text;

-- Create a categories table for managing categories
CREATE TABLE public.project_categories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Insert default categories
INSERT INTO public.project_categories (name) VALUES
  ('E-commerce'),
  ('Медицина'),
  ('Ресторанный бизнес'),
  ('Образование'),
  ('Недвижимость');

-- Enable RLS for project_categories
ALTER TABLE public.project_categories ENABLE ROW LEVEL SECURITY;

-- Allow sales employees to view categories
CREATE POLICY "Sales employees can view categories" 
ON public.project_categories 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM employees 
  WHERE user_id = auth.uid() 
  AND department = 'отдел продаж'
));

-- Allow admins to manage categories
CREATE POLICY "Admins can manage categories" 
ON public.project_categories 
FOR ALL 
USING (is_admin());