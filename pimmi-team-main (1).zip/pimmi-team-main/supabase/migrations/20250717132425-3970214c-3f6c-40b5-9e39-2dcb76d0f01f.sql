-- Add fields for project extensions to sales_results table
ALTER TABLE public.sales_results 
ADD COLUMN parent_project_id UUID REFERENCES public.sales_results(id),
ADD COLUMN is_extension BOOLEAN DEFAULT FALSE NOT NULL,
ADD COLUMN extension_sequence INTEGER DEFAULT 0 NOT NULL,
ADD COLUMN original_employee_id UUID REFERENCES public.employees(id);

-- Create index for better performance on extension queries
CREATE INDEX idx_sales_results_parent_project ON public.sales_results(parent_project_id);
CREATE INDEX idx_sales_results_is_extension ON public.sales_results(is_extension);

-- Update the calculate_employee_points function to exclude extensions from original manager's points
CREATE OR REPLACE FUNCTION public.calculate_employee_points(emp_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  task_points INTEGER := 0;
  project_task_points INTEGER := 0;
  achievement_points INTEGER := 0;
  sales_points INTEGER := 0;
  report_points INTEGER := 0;
  spent_points INTEGER := 0;
  total INTEGER := 0;
BEGIN
  -- Calculate points from completed employee_tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO task_points
  FROM employee_tasks 
  WHERE employee_id = emp_id AND status = 'completed';
  
  -- Calculate points from completed project_tasks
  SELECT COALESCE(SUM(
    CASE 
      WHEN priority = 'easy' THEN 5
      WHEN priority = 'medium' THEN 15
      WHEN priority = 'hard' THEN 30
      ELSE 10
    END
  ), 0) INTO project_task_points
  FROM project_tasks 
  WHERE assignee_id = emp_id AND status = 'completed';
  
  -- Calculate points from achievements
  SELECT COALESCE(SUM(points), 0) INTO achievement_points
  FROM employee_achievements 
  WHERE employee_id = emp_id;
  
  -- Calculate points from sales (120 points per sale for sales department)
  -- NOW: Only count non-extension sales OR extensions where employee is the actual assigned manager
  SELECT COALESCE(COUNT(*) * 120, 0) INTO sales_points
  FROM sales_results sr
  JOIN employees e ON sr.employee_id = e.id
  WHERE sr.employee_id = emp_id 
    AND e.department = 'отдел продаж'
    AND (sr.is_extension = FALSE OR sr.employee_id = emp_id);
  
  -- Calculate points from daily reports (30 points per report)
  SELECT COALESCE(COUNT(*) * 30, 0) INTO report_points
  FROM daily_reports 
  WHERE employee_id = emp_id;
  
  -- Calculate spent points from shop purchases
  SELECT COALESCE(SUM(item_price), 0) INTO spent_points
  FROM shop_purchases 
  WHERE employee_id = emp_id;
  
  -- Total = task points + project task points + achievement points + sales points + report points - spent points
  total := task_points + project_task_points + achievement_points + sales_points + report_points - spent_points;
  
  -- Ensure total is never negative
  IF total < 0 THEN
    total := 0;
  END IF;
  
  -- Update or insert into employee_points
  INSERT INTO employee_points (employee_id, total_points, updated_at)
  VALUES (emp_id, total, now())
  ON CONFLICT (employee_id) 
  DO UPDATE SET 
    total_points = total,
    updated_at = now();
    
  RETURN total;
END;
$function$;