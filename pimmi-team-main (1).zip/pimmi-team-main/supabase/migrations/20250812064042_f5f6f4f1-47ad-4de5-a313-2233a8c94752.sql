-- Harden SECURITY DEFINER functions by fixing search_path
CREATE OR REPLACE FUNCTION public.is_member_of_org(p_org_id uuid, p_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.organization_members m
    WHERE m.org_id = p_org_id
      AND m.user_id = p_user_id
  );
$$;

CREATE OR REPLACE FUNCTION public.get_single_org_id_for_user(p_user_id uuid DEFAULT auth.uid())
RETURNS uuid
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  org_count int;
  single_org uuid;
BEGIN
  SELECT COUNT(*), MIN(org_id) INTO org_count, single_org
  FROM public.organization_members
  WHERE user_id = p_user_id;

  IF org_count = 1 THEN
    RETURN single_org;
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.set_org_id_from_user()
RETURNS trigger
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  resolved_org uuid;
BEGIN
  IF NEW.org_id IS NULL THEN
    resolved_org := public.get_single_org_id_for_user(auth.uid());
    IF resolved_org IS NULL THEN
      RAISE EXCEPTION 'org_id is required and cannot be inferred for multi-tenant data';
    END IF;
    NEW.org_id := resolved_org;
  END IF;

  IF NOT public.is_member_of_org(NEW.org_id, auth.uid()) THEN
    RAISE EXCEPTION 'User is not a member of org %', NEW.org_id;
  END IF;

  RETURN NEW;
END;
$$;