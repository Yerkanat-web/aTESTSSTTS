-- Удаление всех данных неактивных пользователей
-- Это удалит все записи сотрудников со статусом 'inactive' и все связанные данные

DO $$
DECLARE
  inactive_employee_ids UUID[];
BEGIN
  -- Получаем все ID неактивных сотрудников
  SELECT ARRAY_AGG(id) INTO inactive_employee_ids
  FROM employees 
  WHERE status = 'inactive';
  
  -- Логируем количество сотрудников для удаления
  RAISE NOTICE 'Found % inactive employees to delete', COALESCE(array_length(inactive_employee_ids, 1), 0);
  
  -- Если есть неактивные сотрудники, удаляем их данные
  IF inactive_employee_ids IS NOT NULL AND array_length(inactive_employee_ids, 1) > 0 THEN
    
    -- 1. Удаляем вложения задач
    DELETE FROM task_attachments 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted task attachments';
    
    -- 2. Удаляем комментарии к задачам
    DELETE FROM task_comments 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted task comments';
    
    -- 3. Удаляем логи рабочего времени
    DELETE FROM work_time_logs 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted work time logs';
    
    -- 4. Удаляем задачи проектов (где сотрудник назначен)
    DELETE FROM project_tasks 
    WHERE assignee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted project tasks';
    
    -- 5. Удаляем ежемесячные платежи для продаж этих сотрудников
    DELETE FROM monthly_payments 
    WHERE sales_result_id IN (
      SELECT id FROM sales_results 
      WHERE employee_id = ANY(inactive_employee_ids)
    );
    RAISE NOTICE 'Deleted monthly payments';
    
    -- 6. Удаляем аккаунты проектов для продаж этих сотрудников
    DELETE FROM project_accounts 
    WHERE sales_result_id IN (
      SELECT id FROM sales_results 
      WHERE employee_id = ANY(inactive_employee_ids)
    );
    RAISE NOTICE 'Deleted project accounts';
    
    -- 7. Удаляем результаты продаж
    DELETE FROM sales_results 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted sales results';
    
    -- 8. Удаляем задачи сотрудников
    DELETE FROM employee_tasks 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted employee tasks';
    
    -- 9. Удаляем достижения сотрудников
    DELETE FROM employee_achievements 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted employee achievements';
    
    -- 10. Удаляем покупки в магазине
    DELETE FROM shop_purchases 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted shop purchases';
    
    -- 11. Удаляем ежедневные отчеты
    DELETE FROM daily_reports 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted daily reports';
    
    -- 12. Удаляем цели продаж
    DELETE FROM sales_targets 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted sales targets';
    
    -- 13. Удаляем баллы сотрудников
    DELETE FROM employee_points 
    WHERE employee_id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted employee points';
    
    -- 14. Наконец, удаляем самих сотрудников
    DELETE FROM employees 
    WHERE id = ANY(inactive_employee_ids);
    RAISE NOTICE 'Deleted inactive employees';
    
    RAISE NOTICE 'Successfully cleaned up all data for inactive employees';
  ELSE
    RAISE NOTICE 'No inactive employees found to delete';
  END IF;
END $$;