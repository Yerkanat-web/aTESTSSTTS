-- Удаление указанных задач у сотрудника Марлен Рабочий

-- Удаление из employee_tasks
DELETE FROM employee_tasks 
WHERE id = 'ec30ca05-818f-4d09-aae8-864930b4252d'; -- Месси

-- Удаление из project_tasks
DELETE FROM project_tasks 
WHERE id IN (
  '0d50f8d5-8661-4986-9cbb-db1154dacd9c', -- Марлин
  '2b3908e4-78e9-43a8-88fd-8d5760dae282', -- Марлиииин
  'a4fe6c63-6685-4c9b-956e-445bb6ee26ae', -- Тика демо
  'beb14940-e7c2-432a-8708-233590c5d547', -- Суарес
  'fa8662e4-106a-4d32-a968-c8a7466c4724', -- Найман
  'acba883c-c7ca-4f61-b25e-6e9fb2ffe3d6'  -- Зука
);