UPDATE project_tasks 
SET due_date = '2025-07-14' 
WHERE id = 'e23e5347-05d0-46aa-a57f-a396235317f8'