-- Отключаем автоматическую синхронизацию для продлений
DROP TRIGGER IF EXISTS sync_extension_payments_trigger ON monthly_payments;
DROP FUNCTION IF EXISTS sync_extension_payments();

-- Создаем новую функцию для создания ежемесячных платежей для продлений
CREATE OR REPLACE FUNCTION create_extension_monthly_payment()
RETURNS TRIGGER AS $$
BEGIN
  -- Только для продлений проектов
  IF NEW.is_extension = TRUE THEN
    -- Создаем ежемесячный платеж с правильными значениями из продления
    INSERT INTO monthly_payments (
      sales_result_id,
      payment_date,
      amount,
      prepayment,
      remainder,
      remainder_due_date,
      status
    ) VALUES (
      NEW.id,
      NEW.sale_date + INTERVAL '1 month', -- Первый платеж через месяц
      NEW.sale_amount, -- Сумма из продления, а не остаток
      NEW.prepayment,  -- Предоплата из продления
      NEW.remainder,   -- Остаток из продления
      NEW.remainder_due_date,
      'pending'
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Создаем триггер для продлений
CREATE TRIGGER create_extension_monthly_payment_trigger
  AFTER INSERT ON sales_results
  FOR EACH ROW
  WHEN (NEW.is_extension = TRUE)
  EXECUTE FUNCTION create_extension_monthly_payment();