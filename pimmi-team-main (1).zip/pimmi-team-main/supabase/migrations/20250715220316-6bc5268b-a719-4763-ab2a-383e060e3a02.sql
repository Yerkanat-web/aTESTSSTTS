-- Обновляем роли руководителей отделов
UPDATE employees 
SET role = 'руководитель тех отдела'
WHERE email IN ('almagul.turdumuratova@mail.ru', 'marlmuratov@yandex.kz');

UPDATE employees 
SET role = 'руководитель ИИ отдела'
WHERE email = 'nurtaibalnur2003@gmail.com';

UPDATE employees 
SET role = 'руководитель отдела продаж'
WHERE email = 'zhanbakitovnaa@gmail.com';