-- Обновляем роль Арай Акмырзаевой на "финансист"
UPDATE employees 
SET role = 'финансист', 
    updated_at = now()
WHERE email = 'aakmyrzaevva@gmail.com' 
   OR (name ILIKE '%арай%' AND name ILIKE '%акмырзаев%');