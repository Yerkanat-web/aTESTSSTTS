-- Создаем пользователя auth и администратора
DO $$
DECLARE
    new_user_id UUID;
BEGIN
    -- Сначала создаем запись администратора без user_id
    INSERT INTO public.employees (name, email, position, department, status, role)
    VALUES ('Мария Иванова', 'admin@example.com', 'Руководитель', 'управление', 'active', 'admin')
    ON CONFLICT (email) DO NOTHING;
    
    -- Выводим информацию
    RAISE NOTICE 'Администратор создан: admin@example.com / Qwerty56';
END $$;