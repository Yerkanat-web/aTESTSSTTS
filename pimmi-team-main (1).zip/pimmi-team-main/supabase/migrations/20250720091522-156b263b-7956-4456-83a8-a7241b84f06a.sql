-- Удаляем проблемную политику
DROP POLICY IF EXISTS "Users can view their own employee record" ON employees;
DROP POLICY IF EXISTS "Sales employees can view sales department and admins" ON employees;

-- Создаем простые политики без рекурсии
CREATE POLICY "Users can view their own employee record" 
ON employees 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all employees" 
ON employees 
FOR SELECT 
USING (is_admin());

-- Создаем отдельную функцию для проверки доступа сотрудников продаж
CREATE OR REPLACE FUNCTION public.can_view_sales_employees()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM employees 
    WHERE user_id = auth.uid() 
    AND department = 'отдел продаж'
    AND status = 'active'
  );
$$;

-- Политика для сотрудников продаж
CREATE POLICY "Sales employees can view sales department and admins" 
ON employees 
FOR SELECT 
USING (
  can_view_sales_employees() 
  AND (
    employees.department = 'отдел продаж' 
    OR employees.role = 'admin'
  )
  AND employees.status = 'active'
);