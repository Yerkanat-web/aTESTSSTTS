-- Add RLS policy for employees to update their assigned project tasks
CREATE POLICY "Employees can update their assigned project tasks" 
ON project_tasks 
FOR UPDATE 
USING (
  assignee_id IN (
    SELECT id FROM employees WHERE user_id = auth.uid()
  )
);