-- Очищаем старые демо данные
DELETE FROM sales_results;
DELETE FROM sales_targets;
DELETE FROM employee_tasks;
DELETE FROM work_time_logs;
DELETE FROM employee_achievements;
DELETE FROM employees WHERE department IN ('отдел продаж', 'тех отдел');

-- Добавляем сотрудников отдела продаж
INSERT INTO employees (name, email, position, department, status, role) VALUES
('Нурасхан', 'nurasxan@company.kz', 'Менеджер по продажам', 'отдел продаж', 'active', 'employee'),
('Нурбек', 'nurbek@company.kz', 'Старший менеджер по продажам', 'отдел продаж', 'active', 'employee'),
('Асем', 'asem@company.kz', 'Менеджер по продажам', 'отдел продаж', 'active', 'employee');

-- Добавляем сотрудников тех отдела
INSERT INTO employees (name, email, position, department, status, role) VALUES
('Марлен', 'marlen@company.kz', 'Frontend Developer', 'тех отдел', 'active', 'employee'),
('Алмагуль', 'almagul@company.kz', 'Backend Developer', 'тех отдел', 'active', 'employee'),
('Амирбек', 'amirbek@company.kz', 'QA Engineer', 'тех отдел', 'active', 'employee'),
('Нурдаулет', 'nurdaulet@company.kz', 'UI/UX Designer', 'тех отдел', 'active', 'employee'),
('Назар', 'nazar@company.kz', 'DevOps Engineer', 'тех отдел', 'active', 'employee');

-- Создаем планы продаж на текущий месяц
INSERT INTO sales_targets (employee_id, target_amount, target_period)
SELECT id, 
  CASE 
    WHEN name = 'Нурасхан' THEN 2500000
    WHEN name = 'Нурбек' THEN 3000000
    WHEN name = 'Асем' THEN 2200000
  END,
  DATE_TRUNC('month', CURRENT_DATE)::date
FROM employees 
WHERE department = 'отдел продаж';

-- Создаем демо данные по продажам для Нурасхана
INSERT INTO sales_results (employee_id, sale_amount, sale_date, client_name, description)
SELECT e.id, 450000, CURRENT_DATE - 1, 'ТОО "Астана Строй"', 'Продажа CRM системы'
FROM employees e WHERE e.name = 'Нурасхан'
UNION ALL
SELECT e.id, 320000, CURRENT_DATE - 3, 'ИП "Алматы Трейд"', 'Внедрение автоматизации'
FROM employees e WHERE e.name = 'Нурасхан'
UNION ALL
SELECT e.id, 780000, CURRENT_DATE - 5, 'ТОО "Шымкент Лтд"', 'Консалтинговые услуги'
FROM employees e WHERE e.name = 'Нурасхан';

-- Создаем демо данные по продажам для Нурбека
INSERT INTO sales_results (employee_id, sale_amount, sale_date, client_name, description)
SELECT e.id, 550000, CURRENT_DATE - 2, 'ООО "Актобе Групп"', 'Техническая поддержка'
FROM employees e WHERE e.name = 'Нурбек'
UNION ALL
SELECT e.id, 380000, CURRENT_DATE - 4, 'ТОО "Караганда Бизнес"', 'Разработка ПО'
FROM employees e WHERE e.name = 'Нурбек'
UNION ALL
SELECT e.id, 620000, CURRENT_DATE - 6, 'ИП "Павлодар Сервис"', 'Обучение персонала'
FROM employees e WHERE e.name = 'Нурбек';

-- Создаем демо данные по продажам для Асем
INSERT INTO sales_results (employee_id, sale_amount, sale_date, client_name, description)
SELECT e.id, 290000, CURRENT_DATE - 1, 'ТОО "Костанай Плюс"', 'Интеграция систем'
FROM employees e WHERE e.name = 'Асем'
UNION ALL
SELECT e.id, 440000, CURRENT_DATE - 3, 'ООО "Атырау Ойл"', 'Аудит ИТ процессов'
FROM employees e WHERE e.name = 'Асем'
UNION ALL
SELECT e.id, 510000, CURRENT_DATE - 7, 'ТОО "Тараз Компани"', 'Модернизация оборудования'
FROM employees e WHERE e.name = 'Асем';

-- Создаем задачи для отдела продаж
INSERT INTO employee_tasks (employee_id, title, description, priority, status, category, estimated_hours, actual_hours, due_date, created_at, completed_at)
SELECT e.id, 'Подготовка коммерческого предложения', 'Составление КП для нового клиента', 'medium', 'completed', 'sales', 4, 3, CURRENT_DATE + 3, CURRENT_DATE - 5, CURRENT_DATE - 1
FROM employees e WHERE e.department = 'отдел продаж'
UNION ALL
SELECT e.id, 'Звонки потенциальным клиентам', 'Холодные звонки по базе лидов', 'low', 'completed', 'sales', 6, 5, CURRENT_DATE + 2, CURRENT_DATE - 3, CURRENT_DATE
FROM employees e WHERE e.department = 'отдел продаж'
UNION ALL
SELECT e.id, 'Встреча с клиентом', 'Презентация продукта крупному заказчику', 'high', 'in_progress', 'sales', 3, 1, CURRENT_DATE + 1, CURRENT_DATE - 2, NULL
FROM employees e WHERE e.department = 'отдел продаж';

-- Создаем задачи для тех отдела
INSERT INTO employee_tasks (employee_id, title, description, priority, status, category, estimated_hours, actual_hours, due_date, created_at, completed_at)
SELECT e.id, 'Разработка API модуля', 'Создание REST API для новой функциональности', 'high', 'completed', 'development', 16, 14, CURRENT_DATE + 5, CURRENT_DATE - 8, CURRENT_DATE - 2
FROM employees e WHERE e.name IN ('Марлен', 'Алмагуль')
UNION ALL
SELECT e.id, 'Тестирование нового функционала', 'Написание автотестов и проведение QA', 'medium', 'completed', 'development', 12, 10, CURRENT_DATE + 3, CURRENT_DATE - 6, CURRENT_DATE - 1
FROM employees e WHERE e.name = 'Амирбек'
UNION ALL
SELECT e.id, 'Дизайн пользовательского интерфейса', 'Создание макетов для мобильного приложения', 'medium', 'in_progress', 'development', 20, 12, CURRENT_DATE + 7, CURRENT_DATE - 10, NULL
FROM employees e WHERE e.name = 'Нурдаулет'
UNION ALL
SELECT e.id, 'Настройка CI/CD pipeline', 'Автоматизация процесса деплоя', 'high', 'pending', 'development', 8, 0, CURRENT_DATE + 10, CURRENT_DATE - 1, NULL
FROM employees e WHERE e.name = 'Назар';

-- Создаем логи рабочего времени за последнюю неделю для каждого сотрудника
INSERT INTO work_time_logs (employee_id, start_time, end_time, hours_worked, description, work_type)
SELECT e.id, 
       CURRENT_DATE - 6 + '09:00:00'::time,
       CURRENT_DATE - 6 + '17:30:00'::time,
       8.5,
       'Работа над проектом',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел')
UNION ALL
SELECT e.id, 
       CURRENT_DATE - 5 + '09:00:00'::time,
       CURRENT_DATE - 5 + '16:12:00'::time,
       7.2,
       'Встречи с клиентами',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел')
UNION ALL
SELECT e.id, 
       CURRENT_DATE - 4 + '09:00:00'::time,
       CURRENT_DATE - 4 + '17:48:00'::time,
       8.8,
       'Разработка функций',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел')
UNION ALL
SELECT e.id, 
       CURRENT_DATE - 3 + '09:00:00'::time,
       CURRENT_DATE - 3 + '15:30:00'::time,
       6.5,
       'Тестирование',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел')
UNION ALL
SELECT e.id, 
       CURRENT_DATE - 2 + '09:00:00'::time,
       CURRENT_DATE - 2 + '17:06:00'::time,
       8.1,
       'Планирование',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел')
UNION ALL
SELECT e.id, 
       CURRENT_DATE - 1 + '09:00:00'::time,
       CURRENT_DATE - 1 + '13:12:00'::time,
       4.2,
       'Документация',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел')
UNION ALL
SELECT e.id, 
       CURRENT_DATE + '09:00:00'::time,
       CURRENT_DATE + '11:00:00'::time,
       2.0,
       'Обучение',
       'task'
FROM employees e WHERE e.department IN ('отдел продаж', 'тех отдел');

-- Создаем достижения для сотрудников отдела продаж
INSERT INTO employee_achievements (employee_id, achievement_name, description, points, earned_at)
SELECT e.id, 'Первая продажа месяца', 'Заключил первую сделку в этом месяце', 100, CURRENT_DATE - 5
FROM employees e WHERE e.department = 'отдел продаж'
UNION ALL
SELECT e.id, 'План выполнен на 80%', 'Выполнение плана продаж на 80%', 200, CURRENT_DATE - 3
FROM employees e WHERE e.name = 'Нурбек';

-- Создаем достижения для сотрудников тех отдела
INSERT INTO employee_achievements (employee_id, achievement_name, description, points, earned_at)
SELECT e.id, 'Задача выполнена досрочно', 'Завершил задачу раньше срока', 50, CURRENT_DATE - 2
FROM employees e WHERE e.department = 'тех отдел'
UNION ALL
SELECT e.id, 'Код без багов', 'Код прошел проверку без найденных ошибок', 75, CURRENT_DATE - 1
FROM employees e WHERE e.name IN ('Марлен', 'Алмагуль');