-- Add existing sales with "Дожим чатбот" work format to project_accounts
INSERT INTO public.project_accounts (sales_result_id, service_type, login, password, subscription_end_date)
SELECT 
  sr.id as sales_result_id,
  'Дожим чатбот' as service_type,
  '' as login,
  '' as password,
  NULL as subscription_end_date
FROM public.sales_results sr
WHERE sr.work_format @> ARRAY['Дожим чатбот']::text[]
  AND NOT EXISTS (
    SELECT 1 FROM public.project_accounts pa 
    WHERE pa.sales_result_id = sr.id
  );